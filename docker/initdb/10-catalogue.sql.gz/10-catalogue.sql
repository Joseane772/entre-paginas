--
-- PostgreSQL database dump
--

\restrict L2FuSA6r1gUKCuo1fOk78pgOu6GKBZJrJMTMikoQnH8duXwJhigpuRgxdQHoUOT

-- Dumped from database version 17.12
-- Dumped by pg_dump version 17.12

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: drizzle; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA drizzle;


--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: unaccent; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS unaccent WITH SCHEMA public;


--
-- Name: EXTENSION unaccent; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION unaccent IS 'text search dictionary that removes accents';


--
-- Name: adaptation_kind; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.adaptation_kind AS ENUM (
    'film',
    'tv_series',
    'miniseries',
    'animated_film',
    'animated_series',
    'anime',
    'comic',
    'video_game',
    'game',
    'stage',
    'audio',
    'other'
);


--
-- Name: edition_region; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.edition_region AS ENUM (
    'PT',
    'BR'
);


--
-- Name: reading_state; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.reading_state AS ENUM (
    'quero_ler',
    'a_ler',
    'lido'
);


--
-- Name: tmdb_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.tmdb_type AS ENUM (
    'movie',
    'tv'
);


--
-- Name: work_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.work_status AS ENUM (
    'full',
    'stub',
    'pending'
);


--
-- Name: f_unaccent(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.f_unaccent(text) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT PARALLEL SAFE
    AS $_$ SELECT public.unaccent('public.unaccent'::regdictionary, lower($1)) $_$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: __drizzle_migrations; Type: TABLE; Schema: drizzle; Owner: -
--

CREATE TABLE drizzle.__drizzle_migrations (
    id integer NOT NULL,
    hash text NOT NULL,
    created_at bigint
);


--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE; Schema: drizzle; Owner: -
--

CREATE SEQUENCE drizzle.__drizzle_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: drizzle; Owner: -
--

ALTER SEQUENCE drizzle.__drizzle_migrations_id_seq OWNED BY drizzle.__drizzle_migrations.id;


--
-- Name: account; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.account (
    id text NOT NULL,
    account_id text NOT NULL,
    provider_id text NOT NULL,
    user_id text NOT NULL,
    access_token text,
    refresh_token text,
    id_token text,
    access_token_expires_at timestamp with time zone,
    refresh_token_expires_at timestamp with time zone,
    scope text,
    password text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: adaptations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.adaptations (
    id integer NOT NULL,
    title text NOT NULL,
    original_title text,
    kind public.adaptation_kind DEFAULT 'other'::public.adaptation_kind NOT NULL,
    year integer,
    credits text,
    overview text,
    poster_url text,
    wikidata_id text,
    tmdb_id integer,
    tmdb_type public.tmdb_type,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: adaptations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.adaptations ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.adaptations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: authors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.authors (
    id integer NOT NULL,
    slug text NOT NULL,
    name text NOT NULL,
    wikidata_id text,
    open_library_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: authors_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.authors ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.authors_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: editions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.editions (
    id integer NOT NULL,
    work_id integer NOT NULL,
    title text NOT NULL,
    language text,
    region public.edition_region,
    publisher text,
    publish_year integer,
    isbn13 text,
    isbn10 text,
    cover_url text,
    open_library_edition_id text,
    google_books_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: editions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.editions ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.editions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: import_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.import_events (
    id integer NOT NULL,
    user_id text,
    work_id integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: import_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.import_events ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.import_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: rate_limit; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rate_limit (
    id text NOT NULL,
    key text NOT NULL,
    count integer NOT NULL,
    last_request bigint NOT NULL
);


--
-- Name: reading_status; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reading_status (
    user_id text NOT NULL,
    work_id integer NOT NULL,
    state public.reading_state NOT NULL,
    started_on date,
    finished_on date,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: reviews; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reviews (
    user_id text NOT NULL,
    work_id integer NOT NULL,
    rating smallint NOT NULL,
    body text,
    spoilers boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT rating_range CHECK (((rating >= 1) AND (rating <= 5)))
);


--
-- Name: series; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.series (
    id integer NOT NULL,
    slug text NOT NULL,
    name text NOT NULL,
    wikidata_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: series_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.series ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.series_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: series_works; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.series_works (
    series_id integer NOT NULL,
    work_id integer NOT NULL,
    ordinal text,
    sort_key real
);


--
-- Name: session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session (
    id text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    token text NOT NULL,
    ip_address text,
    user_agent text,
    user_id text NOT NULL,
    impersonated_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: slug_redirects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.slug_redirects (
    slug text NOT NULL,
    work_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: user; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."user" (
    id text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    email_verified boolean DEFAULT false NOT NULL,
    image text,
    role text DEFAULT 'user'::text,
    banned boolean DEFAULT false,
    ban_reason text,
    ban_expires timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: verification; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.verification (
    id text NOT NULL,
    identifier text NOT NULL,
    value text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: work_adaptations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.work_adaptations (
    work_id integer NOT NULL,
    adaptation_id integer NOT NULL,
    via_series boolean DEFAULT false NOT NULL
);


--
-- Name: work_authors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.work_authors (
    work_id integer NOT NULL,
    author_id integer NOT NULL,
    "position" integer DEFAULT 0 NOT NULL
);


--
-- Name: work_overrides; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.work_overrides (
    work_id integer NOT NULL,
    title text,
    original_title text,
    synopsis text,
    note text,
    hide_from_series boolean DEFAULT false NOT NULL,
    updated_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: works; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.works (
    id integer NOT NULL,
    slug text NOT NULL,
    title text NOT NULL,
    original_title text,
    original_language text,
    first_published_year integer,
    synopsis text,
    synopsis_language text,
    synopsis_source_url text,
    cover_url text,
    subjects text[] DEFAULT '{}'::text[] NOT NULL,
    wikidata_id text,
    open_library_work_id text,
    status public.work_status DEFAULT 'full'::public.work_status NOT NULL,
    imported_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    editor_note text
);


--
-- Name: works_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.works ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.works_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: __drizzle_migrations id; Type: DEFAULT; Schema: drizzle; Owner: -
--

ALTER TABLE ONLY drizzle.__drizzle_migrations ALTER COLUMN id SET DEFAULT nextval('drizzle.__drizzle_migrations_id_seq'::regclass);


--
-- Data for Name: __drizzle_migrations; Type: TABLE DATA; Schema: drizzle; Owner: -
--

COPY drizzle.__drizzle_migrations (id, hash, created_at) FROM stdin;
1	01155a4ad9d9a578e65d080fd92cd8d980e239b6699a4b51a1cd5f677beaedcc	1795629902694
2	b03b689f44dc6b58c2f62b534202f3b58256f5b74951cc60bc56d67e797dfab4	1795629903663
3	cef657f17de55d3e367741ef217644a04cdf4420348cadaaed9732be160cc569	1795638020693
4	9588621dfa862a9a356fc00cb145b9f35de9b53dacc4ea2ac77a32034bd5aa68	1795639100940
\.


--
-- Data for Name: adaptations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.adaptations (id, title, original_title, kind, year, credits, overview, poster_url, wikidata_id, tmdb_id, tmdb_type, created_at, updated_at) FROM stdin;
6	Frank Herbert's Children of Dune	Frank Herbert's Children of Dune	miniseries	2003	Greg Yaitanes	\N	\N	Q1072774	9156	tv	2026-11-25 18:13:31.316651+00	2026-11-25 20:25:31.864+00
89	The Hobbit	The Hobbit	animated_film	1977	Jules Bass, Arthur Rankin Jr.	\N	\N	Q74229	1362	movie	2026-11-25 18:14:26.107462+00	2026-11-25 20:23:33.149+00
90	Der Hobbit	Der Hobbit	audio	1980	Heinz Dieter Köhler	\N	\N	Q141131125	\N	\N	2026-11-25 18:14:26.107462+00	2026-11-25 20:23:33.154+00
8	The Lord of the Rings	The Lord of the Rings	audio	1955	\N	\N	\N	Q3227048	\N	\N	2026-11-25 18:14:07.853321+00	2026-11-25 20:25:36.319+00
92	The Hobbit (jogo eletrônico de 1982)	The Hobbit (jogo eletrônico de 1982)	video_game	1982	Veronika Megler	\N	\N	Q1778141	\N	\N	2026-11-25 18:14:26.107462+00	2026-11-25 20:23:33.16+00
93	The Hobbit	The Hobbit	film	1985	Vladimir Latyshev	\N	\N	Q1187415	211047	movie	2026-11-25 18:14:26.107462+00	2026-11-25 20:23:33.163+00
95	The Hobbit	The Hobbit	video_game	2003	Midway Austin, Fizz Factor	\N	\N	Q2494353	\N	\N	2026-11-25 18:14:26.107462+00	2026-11-25 20:23:33.168+00
96	O Hobbit: A Desolação de Smaug	O Hobbit: A Desolação de Smaug	film	2013	Peter Jackson	\N	\N	Q719915	57158	movie	2026-11-25 18:14:26.107462+00	2026-11-25 20:23:33.174+00
97	O Hobbit: A Batalha dos Cinco Exércitos	O Hobbit: A Batalha dos Cinco Exércitos	film	2014	Peter Jackson	\N	\N	Q919649	122917	movie	2026-11-25 18:14:26.107462+00	2026-11-25 20:23:33.18+00
100	The Hobbit	The Hobbit	audio	\N	\N	\N	\N	Q293269	\N	\N	2026-11-25 18:14:26.107462+00	2026-11-25 20:23:33.185+00
85	O Senhor dos Anéis: A Guerra dos Rohirrim	O Senhor dos Anéis: A Guerra dos Rohirrim	animated_film	2024	Kenji Kamiyama	\N	\N	Q107210110	839033	movie	2026-11-25 18:14:23.007271+00	2026-11-25 20:24:51.676+00
9	O Senhor dos Anéis	O Senhor dos Anéis	animated_film	1978	Ralph Bakshi	\N	\N	Q378913	123	movie	2026-11-25 18:14:07.853321+00	2026-11-25 20:25:36.323+00
50	The Return of the King	The Return of the King	film	1980	Jules Bass, Arthur Rankin Jr.	\N	\N	Q115285	1361	movie	2026-11-25 18:14:19.73042+00	2026-11-25 20:25:36.325+00
10	LORD	LORD	video_game	1981	\N	\N	\N	Q25859648	\N	\N	2026-11-25 18:14:07.853321+00	2026-11-25 20:25:36.328+00
11	Middle-Earth Role Playing	Middle-Earth Role Playing	game	1984	\N	\N	\N	Q5473	\N	\N	2026-11-25 18:14:07.853321+00	2026-11-25 20:25:36.333+00
12	Khraniteli	Khraniteli	film	1991	Natalya Serebryakova	\N	\N	Q106382169	123034	tv	2026-11-25 18:14:07.853321+00	2026-11-25 20:25:36.337+00
13	Lord of the Rings	Lord of the Rings	game	2000	Reiner Knizia	\N	\N	Q1194258	\N	\N	2026-11-25 18:14:07.853321+00	2026-11-25 20:25:36.341+00
15	Middle-Earth Strategy Battle Game	Middle-Earth Strategy Battle Game	game	2001	\N	\N	\N	Q1194265	\N	\N	2026-11-25 18:14:07.853321+00	2026-11-25 20:25:36.344+00
5	Frank Herbert's Dune	Frank Herbert's Dune	miniseries	\N	John Harrison	\N	\N	Q987305	19566	tv	2026-11-25 18:13:26.621393+00	2026-11-25 20:23:23.93+00
101	Wiedźmin: Gra wyobraźni	Wiedźmin: Gra wyobraźni	game	2001	Tomasz Kreczmar, Michał Studniarek	\N	\N	Q9372678	\N	\N	2026-11-25 18:14:32.183998+00	2026-11-25 20:25:43.583+00
102	The Hexer	The Hexer	film	2001	Marek Brodzki	\N	\N	Q7739524	57278	movie	2026-11-25 18:14:32.183998+00	2026-11-25 20:25:43.587+00
16	O Senhor dos Anéis (RPG)	O Senhor dos Anéis (RPG)	game	2002	\N	\N	\N	Q1194266	\N	\N	2026-11-25 18:14:07.853321+00	2026-11-25 20:25:36.348+00
18	The Hunt for Gollum	The Hunt for Gollum	film	2009	Chris Bouchard	\N	\N	Q293219	1676563	movie	2026-11-25 18:14:07.853321+00	2026-11-25 20:25:36.355+00
19	The Lord of the Rings: War in the North	The Lord of the Rings: War in the North	video_game	2011	Snowblind Studios	\N	\N	Q1440462	\N	\N	2026-11-25 18:14:07.853321+00	2026-11-25 20:25:36.357+00
22	Middle-earth: Shadow of War	Middle-earth: Shadow of War	video_game	2017	Monolith Productions	\N	\N	Q28859887	\N	\N	2026-11-25 18:14:07.853321+00	2026-11-25 20:25:36.365+00
35	O Senhor dos Anéis - As Duas Torres	O Senhor dos Anéis - As Duas Torres	film	2002	Peter Jackson	\N	\N	Q164963	121	movie	2026-11-25 18:14:12.191358+00	2026-11-25 20:24:45.341+00
57	O Senhor dos Anéis - O Retorno do Rei	O Senhor dos Anéis - O Retorno do Rei	film	2003	Peter Jackson	\N	\N	Q131074	122	movie	2026-11-25 18:14:19.73042+00	2026-11-25 20:25:36.351+00
17	Born of Hope	Born of Hope	film	2009	Kate Madison	\N	\N	Q293181	1564496	movie	2026-11-25 18:14:07.853321+00	2026-11-25 20:25:36.353+00
103	The Witcher	The Witcher	video_game	2007	CD Projekt RED	\N	\N	Q287637	\N	\N	2026-11-25 18:14:32.183998+00	2026-11-25 20:25:43.589+00
1	Duna	Duna	film	1984	David Lynch	\N	\N	Q114819	841	movie	2026-11-25 18:13:26.621393+00	2026-11-25 20:23:23.912+00
3	Dune: Adventures in the Imperium	Dune: Adventures in the Imperium	game	2021	Chris Spivey, Banana Chan, Mari Tokuda, Nathan Dowdell, Richard August, Andrew Peregrine	\N	\N	Q137321823	\N	\N	2026-11-25 18:13:26.621393+00	2026-11-25 20:23:23.919+00
2	Dune	Dune	film	2021	Denis Villeneuve	\N	\N	Q60834962	438631	movie	2026-11-25 18:13:26.621393+00	2026-11-25 20:23:23.924+00
4	Duna: Parte Dois	Duna: Parte Dois	film	2024	Denis Villeneuve	\N	\N	Q109228991	693134	movie	2026-11-25 18:13:26.621393+00	2026-11-25 20:23:23.927+00
104	The Witcher 2: Assassins of Kings	The Witcher 2: Assassins of Kings	video_game	2011	CD Projekt RED	\N	\N	Q917272	\N	\N	2026-11-25 18:14:32.183998+00	2026-11-25 20:25:43.592+00
14	O Senhor dos Anéis - A Irmandade do Anel	O Senhor dos Anéis - A Irmandade do Anel	film	2001	Peter Jackson	\N	\N	Q127367	120	movie	2026-11-25 18:14:07.853321+00	2026-11-25 20:23:29.441+00
225	1984	1984	audio	\N	Steinar Berthelsen	\N	\N	Q19371618	\N	\N	2026-11-25 18:15:54.964525+00	2026-11-25 20:23:55.687+00
226	1984	1984	stage	\N	Édith Patenaude	\N	\N	Q101084642	\N	\N	2026-11-25 18:15:54.964525+00	2026-11-25 20:23:55.689+00
227	Pride and Prejudice	Pride and Prejudice	film	1938	\N	\N	\N	Q508865	719055	movie	2026-11-25 18:16:08.375321+00	2026-11-25 20:24:00.045+00
228	Orgulho e Preconceito	Orgulho e Preconceito	film	1940	Robert Z. Leonard	\N	\N	Q940014	43818	movie	2026-11-25 18:16:08.375321+00	2026-11-25 20:24:00.049+00
229	Pride and Prejudice	Pride and Prejudice	tv_series	1952	\N	\N	\N	Q3285010	105260	tv	2026-11-25 18:16:08.375321+00	2026-11-25 20:24:00.054+00
230	Orgoglio e Pregiudizio	Orgoglio e Pregiudizio	miniseries	1957	Daniele D'Anza	\N	\N	Q3356203	71071	tv	2026-11-25 18:16:08.375321+00	2026-11-25 20:24:00.059+00
231	Pride and Prejudice	Pride and Prejudice	miniseries	1958	\N	\N	\N	Q3356244	105263	tv	2026-11-25 18:16:08.375321+00	2026-11-25 20:24:00.063+00
232	De vier dochters Bennet	De vier dochters Bennet	miniseries	1961	\N	\N	\N	Q63994874	203865	tv	2026-11-25 18:16:08.375321+00	2026-11-25 20:24:00.067+00
233	Orgullo y Prejuicio	Orgullo y Prejuicio	miniseries	1966	\N	\N	\N	Q3356253	\N	\N	2026-11-25 18:16:08.375321+00	2026-11-25 20:24:00.07+00
206	Harry Potter and the Philosopher's Stone	Harry Potter and the Philosopher's Stone	video_game	2001	Griptonite Games	\N	\N	Q117706379	\N	\N	2026-11-25 18:15:45.440237+00	2026-11-25 20:23:43.464+00
211	Harry Potter	Harry Potter	tv_series	\N	Mark Mylod	\N	\N	Q117662601	224377	tv	2026-11-25 18:15:45.440237+00	2026-11-25 20:25:59.069+00
209	Whorrey Potter and the Sorcerer's Balls	Whorrey Potter and the Sorcerer's Balls	film	2010	Dominic Ford	\N	\N	Q3297713	871035	movie	2026-11-25 18:15:45.440237+00	2026-11-25 20:23:43.472+00
212	Desi Harry Potter	Desi Harry Potter	film	\N	\N	\N	\N	Q111918513	\N	\N	2026-11-25 18:15:45.440237+00	2026-11-25 20:25:59.073+00
105	Road without return	Road without return	stage	2012	\N	\N	\N	Q4166739	\N	\N	2026-11-25 18:14:32.183998+00	2026-11-25 20:25:43.596+00
106	The Witcher Adventure Game	The Witcher Adventure Game	video_game	2014	CD Projekt RED	\N	\N	Q28127430	\N	\N	2026-11-25 18:14:32.183998+00	2026-11-25 20:25:43.6+00
213	A Game of Thrones	A Game of Thrones	game	2005	\N	\N	\N	Q677281	\N	\N	2026-11-25 18:15:49.99351+00	2026-11-25 20:23:47.477+00
214	A Song of Ice and Fire Roleplaying	A Song of Ice and Fire Roleplaying	game	2009	\N	\N	\N	Q21233639	\N	\N	2026-11-25 18:15:49.99351+00	2026-11-25 20:23:47.483+00
234	Pride and Prejudice (1967)	Pride and Prejudice (1967)	miniseries	1967	\N	\N	\N	Q3356243	56962	tv	2026-11-25 18:16:08.375321+00	2026-11-25 20:24:00.073+00
235	Pride and Prejudice	Pride and Prejudice	tv_series	1980	Cyril Coke	\N	\N	Q2640719	4409	tv	2026-11-25 18:16:08.375321+00	2026-11-25 20:24:00.076+00
236	Pride & Prejudice: A Latter-Day Comedy	Pride & Prejudice: A Latter-Day Comedy	film	2003	Andrew Black	\N	\N	Q2088470	18087	movie	2026-11-25 18:16:08.375321+00	2026-11-25 20:24:00.081+00
244	Ensaio sobre a Cegueira	Ensaio sobre a Cegueira	film	2008	Fernando Meirelles	\N	\N	Q838405	8338	movie	2026-11-25 18:16:31.54798+00	2026-11-25 20:24:06.249+00
245	The Hunger Games	The Hunger Games	film	2012	Gary Ross	\N	\N	Q212965	70160	movie	2026-11-25 18:17:41.421255+00	2026-11-25 20:24:10.835+00
107	The Witcher 3: Wild Hunt	The Witcher 3: Wild Hunt	video_game	2015	CD Projekt RED	\N	\N	Q4267401	\N	\N	2026-11-25 18:14:32.183998+00	2026-11-25 20:25:43.604+00
108	The Witcher Battle Arena	The Witcher Battle Arena	video_game	2015	CD Projekt RED	\N	\N	Q28127429	\N	\N	2026-11-25 18:14:32.183998+00	2026-11-25 20:25:43.606+00
109	Alzur's Legacy	Alzur's Legacy	film	2019	Jakub Nurzynski	\N	\N	Q86681760	635804	movie	2026-11-25 18:14:32.183998+00	2026-11-25 20:25:43.609+00
110	The Witcher: Nightmare of the Wolf	The Witcher: Nightmare of the Wolf	film	2021	Kwang Il Han	\N	\N	Q93096991	666243	movie	2026-11-25 18:14:32.183998+00	2026-11-25 20:25:43.611+00
111	The Witcher	The Witcher	tv_series	\N	Lauren Schmidt Hissrich, Charlotte Brändström, Tomasz Bagiński, Alik Sakharov, Marc Jobst, Alex García López	\N	\N	Q47500433	71912	tv	2026-11-25 18:14:32.183998+00	2026-11-25 20:25:43.615+00
113	Wiedźmin	Wiedźmin	tv_series	\N	Marek Brodzki	\N	\N	Q1979337	17625	tv	2026-11-25 18:14:32.183998+00	2026-11-25 20:25:43.62+00
215	A Game of Thrones: Genesis	A Game of Thrones: Genesis	video_game	2011	Cyanide	\N	\N	Q659767	\N	\N	2026-11-25 18:15:49.99351+00	2026-11-25 20:23:47.489+00
216	A Guerra dos Tronos	A Guerra dos Tronos	tv_series	\N	David Benioff, D. B. Weiss	\N	\N	Q23572	1399	tv	2026-11-25 18:15:49.99351+00	2026-11-25 20:23:47.494+00
217	Game of Thrones: Conquest	Game of Thrones: Conquest	video_game	\N	Turbine	\N	\N	Q97575652	\N	\N	2026-11-25 18:15:49.99351+00	2026-11-25 20:23:47.497+00
218	Nineteen Eighty-Four	Nineteen Eighty-Four	film	1954	Rudolph Cartier	\N	\N	Q10999127	78852	movie	2026-11-25 18:15:54.964525+00	2026-11-25 20:23:55.663+00
208	Harry Potter Trading Card Game	Harry Potter Trading Card Game	game	2001	\N	\N	\N	Q1138931	\N	\N	2026-11-25 18:15:45.440237+00	2026-11-25 20:25:59.045+00
210	Severus Snape and the Marauders	Severus Snape and the Marauders	film	2016	Justin Zagri	\N	\N	Q28146833	1267671	movie	2026-11-25 18:15:45.440237+00	2026-11-25 20:25:59.061+00
207	Harry Potter e a Pedra Filosofal	Harry Potter e a Pedra Filosofal	film	2001	Chris Columbus	\N	\N	Q102438	671	movie	2026-11-25 18:15:45.440237+00	2026-11-25 20:23:43.456+00
205	Harry Potter and the Philosopher's Stone	Harry Potter and the Philosopher's Stone	video_game	2001	KnowWonder	\N	\N	Q719960	\N	\N	2026-11-25 18:15:45.440237+00	2026-11-25 20:23:43.46+00
219	1984	1984	film	1956	Michael Anderson	\N	\N	Q664787	1984	movie	2026-11-25 18:15:54.964525+00	2026-11-25 20:23:55.667+00
220	1984	1984	film	1984	Ridley Scott	\N	\N	Q203383	1838012	movie	2026-11-25 18:15:54.964525+00	2026-11-25 20:23:55.669+00
221	1984	1984	film	1984	Michael Radford	\N	\N	Q208424	9314	movie	2026-11-25 18:15:54.964525+00	2026-11-25 20:23:55.672+00
222	1984	1984	stage	2010	\N	\N	\N	Q208435	\N	\N	2026-11-25 18:15:54.964525+00	2026-11-25 20:23:55.675+00
223	1984	1984	film	2023	Diana Ringo	\N	\N	Q123574470	1107550	movie	2026-11-25 18:15:54.964525+00	2026-11-25 20:23:55.678+00
224	1984	1984	audio	\N	Dick van Putten, Steinar Berthelsen	\N	\N	Q1824426	\N	\N	2026-11-25 18:15:54.964525+00	2026-11-25 20:23:55.683+00
345	The Hobbit: An Unexpected Journey	The Hobbit: An Unexpected Journey	film	2012	Peter Jackson	\N	\N	Q80379	49051	movie	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
370	Hogwarts Legacy	Hogwarts Legacy	video_game	2023	Avalanche Software, Portkey Games	\N	\N	Q99397854	\N	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:25:59.066+00
237	Bride and Prejudice	Bride and Prejudice	film	2004	Gurinder Chadha	\N	\N	Q1354148	57825	movie	2026-11-25 18:16:08.375321+00	2026-11-25 20:24:00.084+00
238	Orgulho e Preconceito	Orgulho e Preconceito	film	2005	Joe Wright	\N	\N	Q270385	4348	movie	2026-11-25 18:16:08.375321+00	2026-11-25 20:24:00.086+00
239	Lost in Austen	Lost in Austen	tv_series	2008	Dan Zeff	\N	\N	Q2656704	15129	tv	2026-11-25 18:16:08.375321+00	2026-11-25 20:24:00.088+00
240	Stolthet och fördom	Stolthet och fördom	stage	2011	\N	\N	\N	Q27965055	\N	\N	2026-11-25 18:16:08.375321+00	2026-11-25 20:24:00.089+00
241	Fire Island	Fire Island	film	2022	Andrew Ahn	\N	\N	Q108101957	846250	movie	2026-11-25 18:16:08.375321+00	2026-11-25 20:24:00.091+00
242	Pride and Prejudice	Pride and Prejudice	miniseries	\N	Simon Langton	\N	\N	Q855673	1457	tv	2026-11-25 18:16:08.375321+00	2026-11-25 20:24:00.095+00
243	The Lizzie Bennet Diaries	The Lizzie Bennet Diaries	tv_series	\N	\N	\N	\N	Q7747920	43237	tv	2026-11-25 18:16:08.375321+00	2026-11-25 20:24:00.097+00
303	It	It	miniseries	1990	Tommy Lee Wallace	\N	\N	Q1131225	19614	tv	2026-11-25 18:27:13.989428+00	2026-11-25 20:24:14.592+00
304	It	It	film	2017	Andrés Muschietti	\N	\N	Q25136484	346364	movie	2026-11-25 18:27:13.989428+00	2026-11-25 20:24:14.598+00
305	It: Capítulo 2	It: Capítulo 2	film	2019	Andrés Muschietti	\N	\N	Q42726338	474350	movie	2026-11-25 18:27:13.989428+00	2026-11-25 20:24:14.602+00
306	It: Welcome to Derry	It: Welcome to Derry	tv_series	\N	David Hayter	\N	\N	Q112845107	200875	tv	2026-11-25 18:27:13.989428+00	2026-11-25 20:24:14.605+00
307	Woh	Woh	tv_series	\N	\N	\N	\N	Q17137755	212526	tv	2026-11-25 18:27:13.989428+00	2026-11-25 20:24:14.61+00
20	O Um Anel - Aventuras além do Limiar do Ermo	O Um Anel - Aventuras além do Limiar do Ermo	game	2011	\N	\N	\N	Q2028764	\N	\N	2026-11-25 18:14:07.853321+00	2026-11-25 20:25:36.36+00
21	Middle-earth: Shadow of Mordor	Middle-earth: Shadow of Mordor	video_game	2014	Feral Interactive, Monolith Productions	\N	\N	Q15709637	\N	\N	2026-11-25 18:14:07.853321+00	2026-11-25 20:25:36.362+00
23	O Senhor dos Anéis: Os Anéis do Poder	O Senhor dos Anéis: Os Anéis do Poder	tv_series	2022	Juan Antonio Bayona, Charlotte Brändström, Wayne Yip	\N	\N	Q59149852	84773	tv	2026-11-25 18:14:07.853321+00	2026-11-25 20:25:36.368+00
24	The Lord of the Rings: Gollum	The Lord of the Rings: Gollum	video_game	2023	Daedalic Entertainment	\N	\N	Q93235255	\N	\N	2026-11-25 18:14:07.853321+00	2026-11-25 20:25:36.37+00
25	The Lord of the Rings: Journey to Rivendell	The Lord of the Rings: Journey to Rivendell	video_game	\N	Parker Brothers	\N	\N	Q6680121	\N	\N	2026-11-25 18:14:07.853321+00	2026-11-25 20:25:36.372+00
26	Lord of the Rings	Lord of the Rings	stage	\N	\N	\N	\N	Q905691	\N	\N	2026-11-25 18:14:07.853321+00	2026-11-25 20:25:36.375+00
27	Hobitit	Hobitit	miniseries	\N	\N	\N	\N	Q11863501	35520	tv	2026-11-25 18:14:07.853321+00	2026-11-25 20:25:36.378+00
112	The Witcher: Blood Origin	The Witcher: Blood Origin	miniseries	\N	Declan de Barra	\N	\N	Q104411188	106541	tv	2026-11-25 18:14:32.183998+00	2026-11-25 20:25:43.617+00
518	Harry Potter and the Chamber of Secrets	Harry Potter and the Chamber of Secrets	film	2002	Chris Columbus	\N	\N	Q102244	672	movie	2026-11-25 20:25:22.092099+00	2026-11-25 20:25:59.05+00
309	Harry Potter and the Chamber of Secrets	Harry Potter and the Chamber of Secrets	video_game	2002	Eurocom, EA Bright Light, KnowWonder	\N	\N	Q726167	\N	\N	2026-11-25 18:31:27.530841+00	2026-11-25 20:25:59.055+00
\.


--
-- Data for Name: authors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.authors (id, slug, name, wikidata_id, open_library_id, created_at, updated_at) FROM stdin;
5	george-r-r-martin	George R. R. Martin	Q181677	OL234664A	2026-11-25 18:15:49.99351+00	2026-11-25 20:23:47.442+00
6	george-orwell	George Orwell	\N	OL15318546A	2026-11-25 18:15:54.964525+00	2026-11-25 20:23:55.545+00
7	jane-austen	Jane Austen	Q36322	OL21594A	2026-11-25 18:16:08.375321+00	2026-11-25 20:23:59.918+00
8	eca-de-queiroz	Eça de Queiroz	Q316327	OL73090A	2026-11-25 18:16:11.573378+00	2026-11-25 20:24:02.172+00
9	jose-saramago	José Saramago	Q37060	OL3112635A	2026-11-25 18:16:31.54798+00	2026-11-25 20:24:06.233+00
10	suzanne-collins	Suzanne Collins	Q228624	OL1394359A	2026-11-25 18:17:41.421255+00	2026-11-25 20:24:10.797+00
11	stephen-king	Stephen King	Q39829	OL19981A	2026-11-25 18:27:13.989428+00	2026-11-25 20:24:14.552+00
1	frank-herbert	Frank Herbert	Q7934	OL79034A	2026-11-25 18:13:26.621393+00	2026-11-25 20:25:31.827+00
2	j-r-r-tolkien	J.R.R. Tolkien	Q892	OL26320A	2026-11-25 18:14:07.853321+00	2026-11-25 20:25:36.244+00
3	andrzej-sapkowski	Andrzej Sapkowski	Q312101	OL368638A	2026-11-25 18:14:32.183998+00	2026-11-25 20:25:43.567+00
4	j-k-rowling	J. K. Rowling	Q34660	OL23919A	2026-11-25 18:15:45.440237+00	2026-11-25 20:25:58.958+00
\.


--
-- Data for Name: editions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.editions (id, work_id, title, language, region, publisher, publish_year, isbn13, isbn10, cover_url, open_library_edition_id, google_books_id, created_at, updated_at) FROM stdin;
7225	38	1984	dan	\N	Gyldendal	2026	9788702291872	\N	https://covers.openlibrary.org/b/id/15258673-M.jpg	OL62597712M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7226	38	Nineteen Eighty-Four - Unabridged	eng	\N	Ft. Raphael Publishing Company	2026	9798892823333	\N	\N	OL62572892M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7227	38	一九八四	zho	\N	Dong da tu shu gong si	1991	\N	9571913103	\N	OL62433363M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7228	38	Nineteen Eighty-Four	eng	\N	Penguin Books	2015	9780143425809	0143425803	https://covers.openlibrary.org/b/id/15257423-M.jpg	OL61722366M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7229	38	1984	\N	\N	PandorgA	2020	9786555790627	\N	https://covers.openlibrary.org/b/id/15200523-M.jpg	OL61439304M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7230	38	1984	eng	\N	Books Worldwide	2020	9788194215813	8194215811	https://covers.openlibrary.org/b/id/15196195-M.jpg	OL61427489M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7231	38	1984	eng	\N	Arcturus Publishing	2025	9781398856141	\N	\N	OL60856721M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7232	38	Nineteen Eighty-Four	eng	\N	Faber & Faber, Limited	2025	9780571394388	\N	\N	OL60853298M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7233	38	1984-ieji	lit	\N	Jotema	2015	9789955135005	995513500X	https://covers.openlibrary.org/b/id/15257033-M.jpg	OL60406447M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7234	38	al-ʻĀlam ʻām alf wa-tasʻmiʻah wa-arbaʻah wa-thamānīn	ara	\N	Tihāmah	1984	\N	\N	\N	OL60284982M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7235	38	Alf wa-tisʻamīyah wa-arbaʻah wa-thamānūn, 1984	ara	\N	al-Jamʻīyah al-Filasṭīnīyah al-Akādimīyah lil-Shuʾūn al-Dawlīyah	1990	\N	\N	\N	OL59518467M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7236	38	1984	\N	\N	Mirlo Ediciones	2023	9786071440884	\N	https://covers.openlibrary.org/b/id/15088440-M.jpg	OL59156105M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7237	38	Nineteen Eighty-Four	eng	\N	Penguin Books	1954	\N	\N	https://covers.openlibrary.org/b/id/15256033-M.jpg	OL58962733M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7238	38	1984	eng	\N	Perma-Bound	1981	\N	\N	https://covers.openlibrary.org/b/id/15256123-M.jpg	OL58694663M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7239	38	Nineteen Eighty-Four	eng	\N	Penguin Books	1959	\N	\N	https://covers.openlibrary.org/b/id/15256090-M.jpg	OL58637382M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7240	38	Nineteen eighty-four	eng	\N	Harcourt, Brace & World	1949	\N	\N	https://covers.openlibrary.org/b/id/15256129-M.jpg	OL58703977M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7241	38	Nineteen Eighty-Four	eng	\N	Penguin Books	1959	\N	\N	https://covers.openlibrary.org/b/id/15257353-M.jpg	OL62592152M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7242	38	Nineteen Eighty-Four	eng	\N	Penguin Books	1999	\N	\N	https://covers.openlibrary.org/b/id/15256044-M.jpg	OL58626452M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7243	38	Nineteen Eighty-Four	eng	\N	Penguin Books	1999	\N	\N	https://covers.openlibrary.org/b/id/15257340-M.jpg	OL62592138M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7244	38	1984	eng	\N	New American Library	1963	\N	\N	https://covers.openlibrary.org/b/id/15257469-M.jpg	OL58527242M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7245	38	1984	eng	\N	New American Library	1961	\N	\N	https://covers.openlibrary.org/b/id/15257467-M.jpg	OL58527191M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7246	38	1984	eng	\N	The New American Library	1961	\N	\N	https://covers.openlibrary.org/b/id/14862408-M.jpg	OL58527122M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7247	38	Nineteen eighty-four	eng	\N	Easton Press	1992	\N	\N	https://covers.openlibrary.org/b/id/15257442-M.jpg	OL57360519M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7248	38	一九八四年	zho	\N	Hua guo chu ban she	\N	\N	\N	\N	OL57259784M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7249	38	1984 by George Orwell	\N	\N	Orwell	1949	\N	\N	\N	OL56933520M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7250	38	1984	spa	\N	Editorial Planeta Mexicana	2024	9786073907163	\N	\N	OL56904183M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7251	38	Nineteen Eighty-Four	eng	\N	CreateSpace Independent Publishing Platform	2017	9781979429047	\N	\N	OL56240236M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7252	38	Nineteen Eighty-Four	eng	\N	CreateSpace Independent Publishing Platform	2017	9781548880330	\N	\N	OL56298555M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7253	38	Nineteen Eighty-Four	eng	\N	CreateSpace Independent Publishing Platform	2017	9781976587337	\N	\N	OL56350194M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7254	38	Nineteen Eighty-Four	eng	\N	CreateSpace Independent Publishing Platform	2017	9781977552105	\N	\N	OL56400581M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7255	38	1984. Spanish Edition	spa	\N	CreateSpace Independent Publishing Platform	2014	9781500143794	\N	\N	OL56223038M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7256	38	1984 (Spanish Edition)	spa	\N	CreateSpace Independent Publishing Platform	2015	9781518719240	\N	\N	OL55972580M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7257	38	1984 (Spanish Edition)	spa	\N	CreateSpace Independent Publishing Platform	2015	9781514630419	\N	\N	OL56103219M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7258	38	1984 (Nineteen Eighty-Four)	eng	\N	CreateSpace Independent Publishing Platform	2017	9781542940221	\N	\N	OL55803000M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7259	38	1984 (Signet Classics)	eng	\N	CreateSpace Independent Publishing Platform	2017	9781973896630	\N	\N	OL55631583M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7260	38	1984	eng	\N	CreateSpace Independent Publishing Platform	2018	9781986508148	\N	\N	OL55440462M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7261	38	Nineteen Eighty-Four	eng	\N	CreateSpace Independent Publishing Platform	2014	9781497345348	\N	\N	OL55279774M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7262	38	Nineteen Eighty-Four	eng	\N	CreateSpace Independent Publishing Platform	2018	9781719462358	\N	\N	OL55375847M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7263	38	Nineteen Eighty-Four	eng	\N	CreateSpace Independent Publishing Platform	2017	9781547187492	\N	\N	OL55690876M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7264	38	Nineteen Eighty-Four	eng	\N	CreateSpace Independent Publishing Platform	2014	9781503122758	\N	\N	OL55909427M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7265	38	'Nineteen Eighty-Four'	eng	\N	CreateSpace Independent Publishing Platform	2014	9781500440268	\N	\N	OL55190154M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7266	38	1984 (Spanish Edition)	spa	\N	CreateSpace Independent Publishing Platform	2015	9781518719912	\N	\N	OL54782241M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7267	38	1984 (Spanish Edition)	spa	\N	CreateSpace Independent Publishing Platform	2016	9781537215884	\N	\N	OL55323293M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7268	38	1984 (Spanish Edition)	spa	\N	CreateSpace Independent Publishing Platform	2017	9781544256122	\N	\N	OL55335602M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7269	38	Rok 1984	pol	\N	Muza SA	2009	9788374953986	8374953985	https://covers.openlibrary.org/b/id/15256088-M.jpg	OL53452623M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7270	38	Nineteen Eighty-Four (Collector's Edition)	eng	\N	Wordsworth Editions, Limited	2024	9781840228823	\N	\N	OL53266438M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7271	38	Nineteen Eighty-Four	eng	\N	ReadHowYouWant.com, Limited	2024	9781038770288	\N	\N	OL52562109M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7272	38	Nineteen Eighty-four	\N	\N	Penguin	2013	9780241969694	0241969697	\N	OL52981797M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7273	38	Nineteen Eighty-Four	eng	\N	Hodder & Stoughton	1998	9780436203855	\N	\N	OL53237395M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7274	38	Nineteen Eighty Four	eng	\N	CreateSpace Independent Publishing Platform	2016	9781533624833	\N	\N	OL54650723M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7275	38	Nineteen Eighty-Four	eng	\N	CreateSpace Independent Publishing Platform	2017	9781974272846	\N	\N	OL54797305M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7276	38	1984	spa	\N	Penguin Random House Grupo Editorial	2024	9786073844321	\N	https://covers.openlibrary.org/b/id/15242775-M.jpg	OL52231685M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7277	38	1984 (George Orwell)	eng	\N	Golgotha Press	2011	9781610424516	\N	\N	OL52012966M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7278	38	1984	eng	\N	Wilco	2021	9789386869388	\N	https://covers.openlibrary.org/b/id/15255968-M.jpg	OL50300186M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7279	38	COMPLETE UNABRIDGED nineteen eighty-four 972	\N	\N	PENGUIN BOOKS	1955	\N	\N	\N	OL49817774M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7280	38	1984	zho	\N	Ji lin chu ban ji tuan you xian ze ren gong si	2013	9787553415253	7553415251	https://covers.openlibrary.org/b/id/15255992-M.jpg	OL49811903M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7281	38	Nineteen Eighty-Four	zho	\N	Shanghai san lian shu dian	2009	9787542631466	7542631462	https://covers.openlibrary.org/b/id/15256127-M.jpg	OL49667304M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7282	38	Nineteen Eighty-Four	eng	\N	Penguin Books	1969	\N	\N	https://covers.openlibrary.org/b/id/15256019-M.jpg	OL49633037M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7283	38	Nineteen Eighty-Four	eng	\N	Penguin Books	1964	\N	\N	https://covers.openlibrary.org/b/id/15256020-M.jpg	OL49366043M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7284	38	Nineteen Eighty-Four	eng	\N	Penguin Books	1964	\N	\N	https://covers.openlibrary.org/b/id/15257385-M.jpg	OL62592310M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7285	38	1984 - ieji	lit	\N	Jotema	2007	9789955131199	9955131195	https://covers.openlibrary.org/b/id/15255957-M.jpg	OL49238878M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7286	38	Nineteen Eighty-Four	eng	\N	Independently Published	2021	9798500434999	\N	\N	OL48767919M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7287	38	Nineteen Eighty-Four	eng	\N	Independently Published	2020	9798588129268	\N	\N	OL49102882M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7288	38	Nineteen Eighty-Four	eng	\N	RosettaBooks	2002	9780795309151	\N	\N	OL49279492M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7289	38	1984	spa	\N	Nova	2023	9788419260154	\N	https://covers.openlibrary.org/b/id/15256133-M.jpg	OL48275650M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7290	38	Nineteen Eighty-Four	eng	\N	Secker & Warburg	1966	\N	\N	https://covers.openlibrary.org/b/id/15255709-M.jpg	OL47772289M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7291	38	Nineteen Eighty-Four.	\N	\N	Secker & Warburg	1951	\N	\N	\N	OL47745305M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7292	38	Nineteen eighty-four	eng	\N	Edito-Service S.A.	1974	\N	\N	https://covers.openlibrary.org/b/id/15255708-M.jpg	OL47703118M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7293	38	1984  Orwell,George	\N	\N	Total Book	\N	9786078578245	6078578243	https://covers.openlibrary.org/b/id/14301224-M.jpg	OL47674400M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7294	38	1984 - Mehudash	heb	\N	Am Oved Books	2019	9789651327759	9651327758	https://covers.openlibrary.org/b/id/14254419-M.jpg	OL47627777M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7295	38	1984	\N	\N	Ediciones Akal	2022	9788446052654	8446052652	https://covers.openlibrary.org/b/id/14059003-M.jpg	OL47454866M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7296	38	1984	\N	\N	Minotauro	2021	9788445010273	8445010271	https://covers.openlibrary.org/b/id/14119670-M.jpg	OL47506754M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7297	38	1984	\N	\N	Booket	2021	9788423359394	8423359395	https://covers.openlibrary.org/b/id/14157173-M.jpg	OL47540118M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7298	38	1984 - Edicao com Postais e Marcador	\N	\N	Via Leitura	2019	9786587034201	6587034209	https://covers.openlibrary.org/b/id/13873094-M.jpg	OL47323721M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7299	38	1984........................TRIDENT	\N	\N	Destino CAT	2002	9788423322350	8423322351	https://covers.openlibrary.org/b/id/13622349-M.jpg	OL47196252M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7300	38	1984	\N	\N	EDICIONES OBELISCO S.L.	2021	9788491117643	8491117644	https://covers.openlibrary.org/b/id/13451438-M.jpg	OL47086090M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7301	38	Nineteen Eighty - Four	\N	\N	Prakash Book Depot	2015	9788172345143	8172345143	\N	OL46931099M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7302	38	Nineteen Eighty-Four	\N	\N	The Folio Society	2003	\N	\N	\N	OL47020708M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7303	38	1984 (Illustré et Annoté)	fra	\N	[publisher not identified]	2018	9781976908712	197690871X	https://covers.openlibrary.org/b/id/15255382-M.jpg	OL46924062M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7304	38	1984 George Orwell - Nineteen Eighty-Four - Paperback	\N	\N	Books&Coffe	1949	9786057462220	605746222X	\N	OL46904060M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7305	38	1984	eng	\N	The New American Library	1961	\N	\N	https://covers.openlibrary.org/b/id/15255701-M.jpg	OL46876900M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7306	38	Nineteen Eighty-Four	\N	\N	Secker & Warburg	1949	\N	\N	\N	OL46856761M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7307	38	1984	ita	\N	Intra	2021	9791280035158	\N	https://covers.openlibrary.org/b/id/15255646-M.jpg	OL44787960M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7308	38	1984 Nineteen Eighty-Four	eng	\N	Birlinn, Limited	2021	9781788853804	\N	\N	OL44183990M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7309	38	Wrūstay saṛay 1984	pus	\N	Mewand Khprandūyah Ṭolanah	2011	\N	\N	\N	OL44045674M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7310	38	Nineteen Eighty-Four	eng	\N	Secker & Warburg Waterstone's	1996	9780436204241	043620424X	https://covers.openlibrary.org/b/id/15255275-M.jpg	OL43318041M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7311	38	Nineteen Eighty-Four	\N	\N	Penguin Books, Limited	2024	\N	\N	\N	OL43112234M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7312	38	1984	eng	\N	Penguin Books	2011	9780143440314	0143440314	https://covers.openlibrary.org/b/id/15255318-M.jpg	OL42959392M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7313	38	1984 : (English Edition with Illustrations)	eng	\N	Independently Published	2021	9798700267694	\N	\N	OL42632141M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7314	38	1984	eng	\N	Independently Published	2021	9798490937784	\N	\N	OL42602217M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7315	38	1984	eng	\N	Independently Published	2021	9798597889450	\N	\N	OL42475102M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7316	38	1984 (Traducido)	spa	\N	Independently Published	2021	9798592875793	\N	\N	OL42473348M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7317	38	1984	fra	\N	Independently Published	2021	9798707174650	\N	\N	OL42355655M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7318	38	1984	fra	\N	Independently Published	2021	9798708215833	\N	\N	OL42382099M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7319	38	1984	eng	\N	Independently Published	2021	9798589519365	\N	\N	OL42383395M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7320	38	1984	eng	\N	Independently Published	2021	9798599270850	\N	\N	OL42388554M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7321	38	1984	eng	\N	Independently Published	2021	9798578483066	\N	\N	OL42404810M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7322	38	1984	ita	\N	Independently Published	2021	9798590144907	\N	\N	OL42471716M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7323	38	1984	ita	\N	Independently Published	2021	9798729342228	\N	\N	OL42501068M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7324	38	1984	spa	\N	Editorial Alma	2023	9788418933011	\N	https://covers.openlibrary.org/b/id/14351142-M.jpg	OL42588963M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7325	38	Nineteen Eighty-Four	eng	\N	Independently Published	2021	9798703091920	\N	\N	OL42247753M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7326	38	Nineteen Eighty-Four / 1984	eng	\N	Independently Published	2017	9781973370369	\N	\N	OL40809920M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7327	38	1984 (Illustated and Annotated)	eng	\N	Independently Published	2017	9781973398776	\N	\N	OL40701015M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7328	38	Nineteen Eighty-Four	eng	\N	Independently Published	2017	9781520520605	\N	\N	OL40518824M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7329	38	Nineteen Eighty-Four	eng	\N	Independently Published	2017	9781521900512	\N	\N	OL40584443M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7330	38	Nineteen Eighty-Four	eng	\N	Independently Published	2017	9781520471822	\N	\N	OL40737495M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7331	38	Nineteen Eighty-Four	eng	\N	Independently Published	2018	9781730737824	\N	\N	OL40772147M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7332	38	Nineteen Eighty-Four	eng	\N	Independently Published	2017	9781520471679	\N	\N	OL40845789M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7333	38	Nineteen Eighty-Four	eng	\N	Independently Published	2019	9781795808149	\N	\N	OL41478411M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7334	38	Nineteen Eighty-Four	eng	\N	Lulu Press, Inc.	2012	9781326583309	\N	\N	OL40027263M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7335	38	Nineteen Eighty-Four	eng	\N	Penguin Books, Limited	2000	9780140817621	\N	\N	OL40330195M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7336	38	Nineteen Eighty-Four	eng	\N	Pearson Education, Limited	2003	9780131842700	\N	\N	OL40345989M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7337	38	1984	por	BR	Quadrinhos Na Cia	2019	9788535932522	8535932526	https://covers.openlibrary.org/b/id/12919343-M.jpg	OL39484597M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7338	38	1984	pol	\N	Instytut Literacki	1953	\N	\N	\N	OL43113485M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7339	38	1984	fas	\N	Nīlūfar	2010	9789644480447	9644480449	\N	OL43904002M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7340	38	1984	ita	\N	Independently Published	2022	9798834999539	\N	\N	OL39437004M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7341	38	1984	eng	\N	Bloomsbury Publishing Plc	2022	9781350362239	\N	\N	OL39277867M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7342	38	1984	ita	\N	Independently Published	2022	9798835786282	\N	\N	OL39425909M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7343	38	1984	\N	\N	Anonim Yayincilik	2021	9786053034087	6053034088	\N	OL39487906M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7344	38	1984	eng	\N	Independently Published	2022	9798837303432	\N	\N	OL39659363M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7345	38	1984	\N	\N	Alfaguara	2022	9788418915093	\N	https://covers.openlibrary.org/b/id/13009792-M.jpg	OL41435539M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7346	38	Nineteen Eighty-Four	eng	\N	Penguin Books, Limited	2013	9780718193645	\N	\N	OL38672469M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7347	38	Nineteen Eighty-Four	eng	\N	Penguin Books, Limited	2021	9780141992358	\N	\N	OL38796903M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7348	38	Nineteen Eighty-Four	eng	\N	Pierian Springs Press	2022	9781953136114	\N	\N	OL38187578M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7349	38	1984	eng	\N	New American Library	1961	\N	\N	https://covers.openlibrary.org/b/id/15257461-M.jpg	OL62592758M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7350	38	1984	eng	\N	New American Library	1961	\N	\N	https://covers.openlibrary.org/b/id/15257459-M.jpg	OL62592752M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7351	38	Nineteen Eighty-Four	eng	\N	Alfred A. Knopf	1992	\N	0679417397	https://covers.openlibrary.org/b/id/15257453-M.jpg	OL62592712M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7352	38	1984	eng	\N	Signet Classics	1977	9780451524935	\N	https://covers.openlibrary.org/b/id/15279181-M.jpg	OL62592675M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7353	38	Nineteen Eighty-Four	eng	\N	[publisher not identified]	\N	\N	\N	https://covers.openlibrary.org/b/id/15257407-M.jpg	OL62592404M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7354	38	1984	eng	\N	New American Library	1962	\N	\N	https://covers.openlibrary.org/b/id/15257405-M.jpg	OL62592402M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7355	38	1984	eng	\N	New American Library	1961	\N	\N	https://covers.openlibrary.org/b/id/15257403-M.jpg	OL62592401M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7356	38	Nineteen Eighty-Four	eng	\N	Penguin Books	1969	\N	\N	https://covers.openlibrary.org/b/id/15257402-M.jpg	OL62592400M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7357	38	1984	eng	\N	New American Library	1962	\N	\N	https://covers.openlibrary.org/b/id/15257401-M.jpg	OL62592398M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7358	38	Nineteen Eighty-Four	eng	\N	The Observer	1981	\N	\N	https://covers.openlibrary.org/b/id/15257395-M.jpg	OL62592394M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7359	38	1984	eng	\N	New American Library	1961	\N	\N	https://covers.openlibrary.org/b/id/15257386-M.jpg	OL62592368M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7360	38	1984	eng	\N	New American Library	1961	\N	\N	https://covers.openlibrary.org/b/id/15257384-M.jpg	OL62592309M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7361	38	1984	eng	\N	New American Library	1961	\N	\N	https://covers.openlibrary.org/b/id/15257382-M.jpg	OL62592308M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7362	38	1984	eng	\N	New American Library	1961	\N	\N	https://covers.openlibrary.org/b/id/15257378-M.jpg	OL62592279M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7363	38	1984	eng	\N	Signet Classic	1984	\N	0451524934	https://covers.openlibrary.org/b/id/15279182-M.jpg	OL62592264M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7364	38	Nineteen Eighty-Four	eng	\N	New American Library	1961	\N	\N	https://covers.openlibrary.org/b/id/15257374-M.jpg	OL62592251M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7365	38	1984	eng	\N	New American Library	1961	\N	\N	https://covers.openlibrary.org/b/id/15257372-M.jpg	OL62592241M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7366	38	1984	eng	\N	New American Library	1961	\N	\N	https://covers.openlibrary.org/b/id/15257368-M.jpg	OL62592233M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7367	38	1984	eng	\N	New American Library	1961	\N	\N	https://covers.openlibrary.org/b/id/15257367-M.jpg	OL62592221M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7368	38	1984	eng	\N	New American Library	1962	\N	\N	https://covers.openlibrary.org/b/id/15257363-M.jpg	OL62592199M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7369	38	1984	eng	\N	New American Library	1983	\N	\N	https://covers.openlibrary.org/b/id/15257360-M.jpg	OL62592190M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7370	38	1984	eng	\N	New American Library	1962	\N	\N	https://covers.openlibrary.org/b/id/15257358-M.jpg	OL62592170M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7371	38	1984	eng	\N	New American Library	1961	\N	\N	https://covers.openlibrary.org/b/id/15257335-M.jpg	OL62592136M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7372	38	1984	eng	\N	New American Library	1961	\N	\N	https://covers.openlibrary.org/b/id/15257333-M.jpg	OL62592133M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7373	38	Nineteen Eighty-Four	eng	\N	Harcourt, Brace & World, Inc.	1949	\N	\N	https://covers.openlibrary.org/b/id/15257331-M.jpg	OL62592131M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7374	38	Nineteen Eighty-Four	eng	\N	Harcourt, Brace & World, Inc.	1949	\N	\N	https://covers.openlibrary.org/b/id/15257328-M.jpg	OL62592129M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7375	38	1984	eng	\N	New American Library	1961	\N	\N	https://covers.openlibrary.org/b/id/15257320-M.jpg	OL62592089M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7376	38	Nineteen Eighty-Four	eng	\N	Penguin Books	1967	\N	\N	https://covers.openlibrary.org/b/id/15257317-M.jpg	OL62592084M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7377	38	1984	eng	\N	New American Library	1961	\N	\N	https://covers.openlibrary.org/b/id/15257314-M.jpg	OL62592082M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7378	38	1984	eng	\N	New American Library	1961	\N	\N	https://covers.openlibrary.org/b/id/15257312-M.jpg	OL62592079M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
9170	16	Sword of Destiny (eBook)	eng	\N	Orion Publishing Group, Limited	2015	9781473211551	\N	\N	OL34517298M	\N	2026-11-25 20:24:57.003553+00	2026-11-25 20:24:57.003553+00
9171	16	Sword of Destiny	eng	\N	Orion Publishing Group, Limited	2023	9781399611411	\N	\N	OL46577742M	\N	2026-11-25 20:24:57.003553+00	2026-11-25 20:24:57.003553+00
9172	16	Sword of Destiny	\N	\N	Gai YA	2019	9789866157752	986615775X	https://covers.openlibrary.org/b/id/13343291-M.jpg	OL46848843M	\N	2026-11-25 20:24:57.003553+00	2026-11-25 20:24:57.003553+00
9173	16	Sword of Destiny	eng	\N	Orbit	2022	9780316452564	\N	https://covers.openlibrary.org/b/id/15213438-M.jpg	OL38065754M	\N	2026-11-25 20:24:57.003553+00	2026-11-25 20:24:57.003553+00
9174	16	Sword of Destiny	eng	\N	Orbit	2022	9780316453264	\N	https://covers.openlibrary.org/b/id/14858637-M.jpg	OL38153651M	\N	2026-11-25 20:24:57.003553+00	2026-11-25 20:24:57.003553+00
9175	16	Sword of Destiny	\N	\N	Gollancz	2020	9781473231085	1473231086	https://covers.openlibrary.org/b/id/14648788-M.jpg	OL38225900M	\N	2026-11-25 20:24:57.003553+00	2026-11-25 20:24:57.003553+00
9176	16	Sword of Destiny	eng	\N	Orion Publishing Group, Limited	2022	9781399607247	\N	https://covers.openlibrary.org/b/id/14648786-M.jpg	OL38815806M	\N	2026-11-25 20:24:57.003553+00	2026-11-25 20:24:57.003553+00
9177	16	Sword of Destiny	eng	\N	Orbit	2015	9781478962229	1478962224	https://covers.openlibrary.org/b/id/10657690-M.jpg	OL31983676M	\N	2026-11-25 20:24:57.003553+00	2026-11-25 20:24:57.003553+00
9178	16	Sword of Destiny	eng	\N	Orbit	2015	9780316389716	\N	\N	OL34010388M	\N	2026-11-25 20:24:57.003553+00	2026-11-25 20:24:57.003553+00
9179	16	Sword of Destiny	eng	\N	Orion Publishing Group, Limited	2015	9781473211537	1473211530	https://covers.openlibrary.org/b/id/14427814-M.jpg	OL34513324M	\N	2026-11-25 20:24:57.003553+00	2026-11-25 20:24:57.003553+00
9180	16	Sword of destiny	eng	\N	\N	2015	9780316389709	0316389706	\N	OL26976220M	\N	2026-11-25 20:24:57.003553+00	2026-11-25 20:24:57.003553+00
9181	16	A végzet kardja	hun	\N	GABO	2020	9789634069522	\N	https://covers.openlibrary.org/b/id/15156289-M.jpg	OL61037608M	\N	2026-11-25 20:24:57.003553+00	2026-11-25 20:24:57.003553+00
9182	16	Miecz przeznaczenia	pol	\N	SuperNOWA	2014	9788375780826	\N	https://covers.openlibrary.org/b/id/14843285-M.jpg	OL57709938M	\N	2026-11-25 20:24:57.003553+00	2026-11-25 20:24:57.003553+00
9183	16	Meč osudu	ces	\N	Leonardo	2022	9788074770807	\N	https://covers.openlibrary.org/b/id/14548206-M.jpg	OL49953068M	\N	2026-11-25 20:24:57.003553+00	2026-11-25 20:24:57.003553+00
9184	16	Das Schwert der Vorsehung	deu	\N	dtv	2020	9783423262651	\N	https://covers.openlibrary.org/b/id/14425812-M.jpg	OL49634215M	\N	2026-11-25 20:24:57.003553+00	2026-11-25 20:24:57.003553+00
9185	16	Miecz przeznaczenia	ita	\N	Editrice Nord	2019	9788842932420	\N	https://covers.openlibrary.org/b/id/12649106-M.jpg	OL37413606M	\N	2026-11-25 20:24:57.003553+00	2026-11-25 20:24:57.003553+00
9186	16	Sword of Destiny	eng	\N	Gollancz	2016	9781473211544	\N	https://covers.openlibrary.org/b/id/12586619-M.jpg	OL29485062M	\N	2026-11-25 20:24:57.003553+00	2026-11-25 20:24:57.003553+00
9187	16	Skæbnens sværd	dan	\N	Gyldendal	2017	9788702188981	\N	\N	OL31900113M	\N	2026-11-25 20:24:57.003553+00	2026-11-25 20:24:57.003553+00
9188	16	Das Schwert der Vorsehung	deu	\N	Deutscher Taschenbuch Verlag	2018	9783423210690	\N	https://covers.openlibrary.org/b/id/10554468-M.jpg	OL31879207M	\N	2026-11-25 20:24:57.003553+00	2026-11-25 20:24:57.003553+00
9189	16	Miecz przeznaczenia	\N	\N	SuperNOWA	2014	9788375780642	\N	https://covers.openlibrary.org/b/id/10087327-M.jpg	OL28145896M	\N	2026-11-25 20:24:57.003553+00	2026-11-25 20:24:57.003553+00
9190	16	Miecz przeznaczenia	pol	\N	SuperNOWA	1992	\N	8370540376	https://covers.openlibrary.org/b/id/8457617-M.jpg	OL26802090M	\N	2026-11-25 20:24:57.003553+00	2026-11-25 20:24:57.003553+00
9191	16	Miecz przeznaczenia	pol	\N	SuperNOWA	1995	\N	\N	\N	OL625775M	\N	2026-11-25 20:24:57.003553+00	2026-11-25 20:24:57.003553+00
9192	16	Miecz przeznaczenia	pol	\N	SuperNOWA	2004	\N	8370540376	https://covers.openlibrary.org/b/id/12848708-M.jpg	OL22146152M	\N	2026-11-25 20:24:57.003553+00	2026-11-25 20:24:57.003553+00
9193	17	Wieża jaskółki	\N	\N	SuperNOWA	2001	\N	8370541240	https://covers.openlibrary.org/b/id/10539652-M.jpg	OL31845042M	\N	2026-11-25 20:25:00.322569+00	2026-11-25 20:25:00.322569+00
9194	18	Feuertaufe	deu	\N	Deutscher Taschenbuch Verlag	2009	9783423247559	342324755X	https://covers.openlibrary.org/b/id/12933400-M.jpg	OL27038529M	\N	2026-11-25 20:25:04.789255+00	2026-11-25 20:25:04.789255+00
9195	19	Pani Jeziora	pol	\N	superNOWA	1999	\N	8370541291	https://covers.openlibrary.org/b/id/12648863-M.jpg	OL37340021M	\N	2026-11-25 20:25:12.582742+00	2026-11-25 20:25:12.582742+00
7379	38	一九八四	zho	\N	南海出版公司	2015	9787553468358	\N	https://covers.openlibrary.org/b/id/15257311-M.jpg	OL62592073M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7380	38	1984	eng	\N	New American Library	1983	\N	\N	https://covers.openlibrary.org/b/id/15257299-M.jpg	OL62592062M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7381	38	1984	eng	\N	TransWorld Publication	2019	9789937062749	\N	https://covers.openlibrary.org/b/id/15257286-M.jpg	OL62592059M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7382	38	1984	eng	\N	New American Library	1983	\N	\N	https://covers.openlibrary.org/b/id/15257284-M.jpg	OL62592058M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7383	38	Nineteen Eighty-Four	eng	\N	New American Library	1981	\N	\N	https://covers.openlibrary.org/b/id/15257282-M.jpg	OL62592046M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7384	38	Nineteen Eighty-Four	eng	\N	Penguin Books	1958	\N	\N	https://covers.openlibrary.org/b/id/15257279-M.jpg	OL62592026M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7385	38	1984	eng	\N	CreateSpace Independent Publishing Platform	2017	9781976304699	\N	\N	OL55257669M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7386	38	1984	eng	\N	CreateSpace Independent Publishing Platform	2018	9781987679359	\N	\N	OL55266723M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7387	38	1984	spa	\N	CreateSpace Independent Publishing Platform	2015	9781517514181	\N	\N	OL55302621M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7388	38	1984	eng	\N	CreateSpace Independent Publishing Platform	2018	9781717012890	\N	\N	OL55441533M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7389	38	1984	eng	\N	CreateSpace Independent Publishing Platform	2016	9781530044351	\N	\N	OL55455937M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7390	38	1984	eng	\N	CreateSpace Independent Publishing Platform	2016	9781530043927	\N	\N	OL55486784M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7391	38	1984	eng	\N	CreateSpace Independent Publishing Platform	2016	9781535061766	\N	\N	OL55519843M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7392	38	1984	eng	\N	CreateSpace Independent Publishing Platform	2018	9781986607766	\N	\N	OL55532981M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7393	38	1984	eng	\N	CreateSpace Independent Publishing Platform	2018	9781987598384	\N	\N	OL55533675M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7394	38	1984	eng	\N	CreateSpace Independent Publishing Platform	2016	9781537775050	\N	\N	OL55569478M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7395	38	1984	spa	\N	CreateSpace Independent Publishing Platform	2015	9781522932376	\N	\N	OL55652244M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7396	38	1984	eng	\N	CreateSpace Independent Publishing Platform	2016	9781530644049	\N	\N	OL55683897M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7397	38	1984	spa	\N	CreateSpace Independent Publishing Platform	2015	9781517277703	\N	\N	OL55708108M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7398	38	1984	spa	\N	CreateSpace Independent Publishing Platform	2018	9781979644358	\N	\N	OL55725219M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7399	38	1984	eng	\N	ENWISE	2024	9781964960005	\N	\N	OL52637236M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7400	38	1984	eng	\N	ENWISE	2024	9781964960050	\N	\N	OL52649478M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7401	38	1984	eng	\N	Sweet Cherry Publishing	2024	9781802633900	\N	\N	OL54024847M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7402	38	1984	eng	\N	CreateSpace Independent Publishing Platform	2012	9781477550380	\N	\N	OL54238554M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7403	38	1984	eng	\N	CreateSpace Independent Publishing Platform	2012	9781477550182	\N	\N	OL54304891M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7404	38	1984	eng	\N	CreateSpace Independent Publishing Platform	2014	9781503241312	\N	\N	OL54620413M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7405	38	1984	eng	\N	CreateSpace Independent Publishing Platform	2018	9781717012227	\N	\N	OL54713242M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7406	38	1984	eng	\N	CreateSpace Independent Publishing Platform	2016	9781530036097	\N	\N	OL54826673M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7407	38	1984	eng	\N	CreateSpace Independent Publishing Platform	2015	9781514223000	\N	\N	OL54958802M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7408	38	1984	spa	\N	CreateSpace Independent Publishing Platform	2015	9781512393934	\N	\N	OL55068920M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7409	38	1984	eng	\N	CreateSpace Independent Publishing Platform	2017	9781979898614	\N	\N	OL55090866M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7410	38	1984	eng	\N	Liese. Outside The Box, Andreas	2020	9783962725297	\N	\N	OL51102525M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7411	38	1984	eng	\N	Blurb	2018	9781388730925	\N	\N	OL51874222M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7412	38	1984	eng	\N	Blurb	2015	9781320829731	\N	\N	OL51988745M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7413	38	1984	eng	\N	Independently Published	2021	9798485404635	\N	\N	OL49174051M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7414	38	1984	eng	\N	Independently Published	2021	9798594919693	\N	\N	OL49178322M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7415	38	1984	spa	\N	Independently Published	2021	9798732781649	\N	\N	OL48236395M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7416	38	1984	nld	\N	Independently Published	2021	9798528164908	\N	\N	OL48476596M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7417	38	1984	por	\N	Independently Published	2021	9798599858768	\N	\N	OL48486997M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7418	38	1984	eng	\N	Independently Published	2021	9798589924183	\N	\N	OL48500788M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7419	38	1984	deu	\N	Independently Published	2021	9798528142388	\N	\N	OL48517005M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7420	38	1984	fra	\N	Independently Published	2021	9798664304275	\N	\N	OL48520055M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7421	38	1984	eng	\N	Independently Published	2021	9798747349483	\N	\N	OL48802930M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7422	38	1984	spa	\N	Independently Published	2021	9798468865927	\N	\N	OL48859063M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7423	38	1984	spa	\N	Independently Published	2021	9798472370790	\N	https://covers.openlibrary.org/b/id/15230634-M.jpg	OL48974251M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7424	38	1984	\N	\N	עם עובד	1971	9788804719137	8804719133	https://covers.openlibrary.org/b/id/13770046-M.jpg	OL47305574M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7425	38	1984	urd	\N	Urdū Akeḍĕmī Sindh	1958	\N	\N	\N	OL49852822M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7426	38	1984	ara	\N	Dār al-Adīb	1956	\N	\N	\N	OL49972499M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7427	38	1984	\N	\N	Editorial Edaf, S.L.	2022	9788441440678	8441440670	https://covers.openlibrary.org/b/id/13614819-M.jpg	OL47190609M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7428	38	1984	cat	\N	Edicions 62	2003	9788429753219	8429753214	https://covers.openlibrary.org/b/id/13706328-M.jpg	OL47257367M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7429	38	1984	\N	\N	Blackstone Pub	2008	9781606406984	1606406981	https://covers.openlibrary.org/b/id/13913104-M.jpg	OL47328450M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7430	38	1984	\N	\N	Libros del Zorro Rojo	2021	9788412270518	8412270517	https://covers.openlibrary.org/b/id/13919651-M.jpg	OL47332872M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7431	38	1984	eng	\N	Independently Published	2022	9798443126265	\N	\N	OL46761656M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7432	38	1984	\N	\N	BUZZ	2019	9786586077698	6586077699	https://covers.openlibrary.org/b/id/13339502-M.jpg	OL46847927M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7433	38	1984	\N	\N	Fingerprint! Publishing	2019	9789389053739	9389053730	https://covers.openlibrary.org/b/id/15228881-M.jpg	OL46865755M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7434	38	1984	\N	\N	Txalaparta	2020	9788418252266	841825226X	https://covers.openlibrary.org/b/id/13459134-M.jpg	OL47090527M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7435	38	1984	\N	\N	Destino	2001	\N	\N	https://covers.openlibrary.org/b/id/13113204-M.jpg	OL44881954M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7436	38	1984	eng	\N	The New American Library of World Literature	1963	\N	\N	\N	OL45208794M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7437	38	1984	eng	\N	New American Library	1950	\N	\N	\N	OL47071348M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7438	38	1984	eng	\N	Penguin Publishing Group	2011	9780143416302	\N	\N	OL44271473M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7439	38	1984	\N	\N	Krevi	2019	9786555522266	6555522267	https://covers.openlibrary.org/b/id/13122540-M.jpg	OL45137401M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7440	38	1984	\N	\N	Penguin Group USA	\N	9780140862546	0140862544	https://covers.openlibrary.org/b/id/13125062-M.jpg	OL45278258M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7441	38	1984	eng	\N	Ediciones Lea S.A.	2022	9789877187182	\N	\N	OL46308790M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7442	38	1984	eng	\N	Independently Published	2022	9798365339477	\N	\N	OL46706731M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7443	38	1984 by George Orwell	eng	\N	Independently Published	2021	9798520497264	\N	\N	OL42628600M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7444	38	1984 by George Orwell	eng	\N	Independently Published	2021	9798500243164	\N	\N	OL48517776M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7445	38	1984	nld	\N	Independently Published	2020	9798552520060	\N	\N	OL42052784M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7446	38	1984	ita	\N	Independently Published	2020	9798699260331	\N	\N	OL42077487M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7447	38	1984	eng	\N	Independently Published	2020	9798698422624	\N	\N	OL42104193M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7448	38	1984	eng	\N	Independently Published	2019	9798673723265	\N	\N	OL42196737M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7449	38	1984	por	\N	Independently Published	2020	9798699549153	\N	\N	OL42208438M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7450	38	1984	spa	\N	Independently Published	2020	9798698125211	\N	\N	OL42232313M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7451	38	1984	\N	\N	E-Kitap Projesi & Cheapest Books	2022	9786257120890	6257120896	\N	OL39803444M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7452	38	1984	eng	\N	Pegasus Books	2021	9781643136981	\N	\N	OL40101301M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7453	38	1984	eng	\N	Independently Published	2022	9798817200782	\N	\N	OL40184830M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7454	38	1984	srp	\N	Libretto	2004	9788683725069	8683725065	https://covers.openlibrary.org/b/id/15255958-M.jpg	OL40228844M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7455	38	1984	\N	\N	Austral	2007	9788467024777	8467024771	\N	OL40268475M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7456	38	1984	\N	\N	Austral	2022	9788445012772	8445012770	\N	OL40279735M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7457	38	1984	\N	\N	\N	\N	9783730609767	3730609769	https://covers.openlibrary.org/b/id/11187836-M.jpg	OL32539027M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7458	38	1984	eng	\N	New American Library	1964	\N	\N	https://covers.openlibrary.org/b/id/15257388-M.jpg	OL43168412M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7459	38	1984	\N	\N	Hawk Press	1994	9789388318563	9388318560	https://covers.openlibrary.org/b/id/13729733-M.jpg	OL44003434M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7460	38	1984	eng	\N	Arcturus Publishing	2021	9781788282369	\N	\N	OL44179713M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7461	38	1984	spa	\N	ASAP, S.A.	2021	9789962904946	\N	https://covers.openlibrary.org/b/id/15136841-M.jpg	OL60553257M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7462	38	Rok 1984	pol	\N	Wydawnictwo MUZA S.A.	2013	9788328722156	\N	https://covers.openlibrary.org/b/id/15123607-M.jpg	OL60135617M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7463	38	1984	por	BR	Editora Aleph	2021	9786586064377	\N	https://covers.openlibrary.org/b/id/15017403-M.jpg	OL58946388M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7464	38	1984	\N	\N	Gramedia Pustaka Utama	2022	9786020661988	\N	\N	OL58373024M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7465	38	Nineteen Eighty-Four	eng	\N	Penguin	2004	9780141919959	\N	https://covers.openlibrary.org/b/id/14653131-M.jpg	OL53012478M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7466	38	Nineteen Eighty-Four	\N	\N	Penguin Modern Classics	2004	\N	\N	\N	OL53012477M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7467	38	Nineteen Eighty-Four	\N	\N	Penguin Modern Classics	2004	\N	\N	\N	OL53012476M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7468	38	1984	\N	\N	Feltrinelli	2021	\N	8807903814	\N	OL51295440M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7469	38	Nineteen Eighty-Four	eng	\N	Penguin Books	1961	\N	\N	https://covers.openlibrary.org/b/id/15257323-M.jpg	OL47677164M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7470	38	1984	tur	\N	Can Yayınları	2019	9789750718533	\N	\N	OL46545044M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7471	38	Nineteen Eighty-Four	eng	\N	Penguin Publishing Group	1950	9780451512185	\N	\N	OL44231675M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7472	38	Nineteen Eighty-Four	eng	\N	Penguin Publishing Group	1971	9780451503114	\N	\N	OL44231668M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7473	38	Nineteen Eighty-Four	eng	\N	Penguin Publishing Group	1960	9780451016409	\N	\N	OL44231662M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7474	38	1984	fra	\N	Independently Published	2017	9781520485744	\N	\N	OL40573145M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7475	38	1984	eng	\N	Independently Published	2018	9781980405573	\N	\N	OL40594989M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7476	38	1984	eng	\N	Independently Published	2018	9781980784654	\N	\N	OL40655194M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7477	38	1984	eng	\N	Independently Published	2017	9781521360286	\N	\N	OL40743730M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7478	38	1984	eng	\N	Independently Published	2016	9781520185903	\N	\N	OL40789454M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7479	38	1984	eng	\N	Independently Published	2017	9781520817897	\N	\N	OL40848870M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7480	38	1984	eng	\N	Independently Published	2017	9781521430934	\N	\N	OL40853148M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7481	38	1984	eng	\N	Independently Published	2017	9781520557656	\N	\N	OL40901017M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7482	38	1984	eng	\N	Independently Published	2017	9781520937748	\N	\N	OL40903646M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7483	38	1984	eng	\N	Independently Published	2017	9781520961767	\N	\N	OL40904286M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7484	38	1984	eng	\N	Independently Published	2017	9781973404347	\N	\N	OL40919272M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7485	38	1984	eng	\N	Independently Published	2018	9781980719809	\N	\N	OL40924832M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7486	38	1984	eng	\N	Independently Published	2018	9781980558590	\N	\N	OL41453375M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7487	38	1984	eng	\N	Independently Published	2019	9781090265012	\N	\N	OL41581045M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7488	38	Rok 1984	\N	\N	Wydawnictwo Da Capo	1993	\N	8385373489	https://covers.openlibrary.org/b/id/12374349-M.jpg	OL35671992M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7489	38	1984	\N	\N	Constable	2021	9781472133038	\N	https://covers.openlibrary.org/b/id/12804575-M.jpg	OL38566695M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7490	38	1984	ukr	\N	Видавництво Жупанського	2021	\N	\N	https://covers.openlibrary.org/b/id/13027594-M.jpg	OL42905608M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7491	38	Nineteen Eighty-Four	\N	\N	Chiltern	2021	9781912714988	\N	https://covers.openlibrary.org/b/id/13011900-M.jpg	OL42361420M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7492	38	1984	\N	\N	Bentang Pustaka	2004	\N	9793062339	https://covers.openlibrary.org/b/id/12968722-M.jpg	OL40212988M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7493	38	1984	eng	\N	Brawtley Press	2017	9781943138432	\N	https://covers.openlibrary.org/b/id/12919048-M.jpg	OL39803336M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7494	38	1984	eng	\N	New American Library	1962	\N	\N	https://covers.openlibrary.org/b/id/12919045-M.jpg	OL39803316M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7495	38	1984	eng	\N	Follett Bound	1977	9780329059576	\N	https://covers.openlibrary.org/b/id/12919044-M.jpg	OL39803306M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7496	38	1984 (Warbler Classics Annotated Edition)	eng	\N	Warbler Press	2022	9781957240695	\N	\N	OL39276931M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7497	38	1984 (Warbler Classics Annotated Edition)	eng	\N	Warbler Press	2022	9781957240701	\N	\N	OL39280227M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7498	38	1984	eng	\N	Wyatt North	2020	9781647986155	\N	\N	OL38886826M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7499	38	1984	eng	\N	Wyatt North	2020	9781647986377	\N	\N	OL38892416M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7500	38	1984	eng	\N	Wyatt North	2021	9781667300009	\N	\N	OL38892683M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7501	38	1984	ita	\N	Independently Published	2022	9798834947714	\N	\N	OL38957016M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7502	38	1984	eng	\N	Independently Published	2021	9798529341834	\N	\N	OL38975226M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7503	38	1984	\N	\N	Listening Library	2006	9789381607794	9381607796	https://covers.openlibrary.org/b/id/11394456-M.jpg	OL32766748M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7504	38	Nineteen Eighty-Four (1984) Edited	eng	\N	Independently Published	2022	9798822070233	\N	\N	OL38499591M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7505	38	Nineteen Eighty-Four	\N	\N	Easton Press	2018	9781781399354	1781399352	\N	OL38226359M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7506	38	1984	eng	\N	Birch Tree Publishing	2021	9781990089268	\N	\N	OL38093677M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7507	38	1984	eng	\N	Independently Published	2022	9798442486889	\N	\N	OL38105233M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7508	38	1984	eng	\N	Independently Published	2022	9798810814733	\N	https://covers.openlibrary.org/b/id/12819291-M.jpg	OL38489109M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7509	38	1984	eng	\N	Independently Published	2021	9798548564603	\N	\N	OL35042766M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7510	38	1984	\N	\N	e-book	1949	\N	\N	\N	OL37851194M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7511	38	1984	eng	\N	Amazing Reads	2014	9788192910901	8192910903	https://covers.openlibrary.org/b/id/15256055-M.jpg	OL38218514M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7512	38	Nineteen Eighty-Four	eng	\N	Wordsworth Editions, Limited	2021	9781840228021	\N	https://covers.openlibrary.org/b/id/14716998-M.jpg	OL37313431M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7513	38	Nineteen Eighty-Four	eng	\N	Independently Published	2021	9798790593031	\N	\N	OL36997470M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7514	38	Nineteen Eighty-Four	\N	\N	Klett Sprachen GmbH	2021	9783125402027	3125402026	https://covers.openlibrary.org/b/id/12509941-M.jpg	OL36618425M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7515	38	Nineteen Eighty Four	eng	\N	Independently Published	2020	9798639952326	\N	\N	OL36871269M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7516	38	Nineteen Eighty-four	\N	\N	BBC Books	2013	9781471331435	1471331431	https://covers.openlibrary.org/b/id/12459175-M.jpg	OL35722823M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7517	38	Nineteen Eighty-Four	eng	\N	Faber & Faber, Limited	2021	9780571355891	\N	\N	OL35849712M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7518	38	Nineteen eighty-four	\N	\N	Penguin Books	2008	9780141036144	\N	https://covers.openlibrary.org/b/id/14370497-M.jpg	OL32693896M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7519	38	Nineteen Eighty-Four	eng	\N	Faber & Faber, Limited	2021	9780571355884	\N	https://covers.openlibrary.org/b/id/12414339-M.jpg	OL33759449M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7520	38	Nineteen Eighty-Four	eng	\N	Real Reads Ltd.	2021	9781911091103	\N	\N	OL33816589M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7521	38	Nineteen Eighty-Four	eng	\N	Orion Publishing Group, Limited	2022	9781473234802	\N	https://covers.openlibrary.org/b/id/13170618-M.jpg	OL33919680M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7522	38	Nineteen Eighty-Four	eng	\N	Penguin Books, Limited	2022	9780241436523	\N	\N	OL33950516M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7523	38	Nineteen Eighty-Four	eng	\N	Harcourt, Brace and Company	1949	\N	\N	https://covers.openlibrary.org/b/id/12725451-M.jpg	OL37824533M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7524	38	1984	zho	\N	Tian jin ren min chu ban she	2018	9787201106380	\N	https://covers.openlibrary.org/b/id/12725444-M.jpg	OL37824529M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7525	38	Nineteen Eighty-Four	eng	\N	Alfred A. Knopf	1992	9780679417392	0679417397	https://covers.openlibrary.org/b/id/15254953-M.jpg	OL37823274M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7526	38	1984	eng	\N	New American Library	1981	\N	\N	https://covers.openlibrary.org/b/id/12724071-M.jpg	OL37823270M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7527	38	1984 (Annotated)	eng	\N	Independently Published	2021	9798499447116	\N	\N	OL37700778M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7528	38	Nineteen Eighty-Four : 1984, a Dystopian Novel	eng	\N	Independently Published	2021	9798781502288	\N	\N	OL37511251M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7529	38	Nineteen Eighty-Four : 1984, a Dystopian Novel	eng	\N	Independently Published	2021	9798781501915	\N	\N	OL37694656M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7530	38	1984	eng	\N	Houghton Mifflin Harcourt Trade & Reference Publishers	1983	9781299885851	\N	\N	OL37176984M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7531	38	1984	spa	\N	Independently Published	2021	9798769856891	\N	\N	OL37547628M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7532	38	1984	spa	\N	Editorial Planeta, S. A.	2022	9786070782640	\N	\N	OL37622899M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7533	38	1984	eng	\N	Independently Published	2021	9798490929895	\N	\N	OL36951247M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7534	38	1984 by George Orwell	eng	\N	Independently Published	2021	9798518317222	\N	\N	OL36368247M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7535	38	1984	\N	\N	New American Library	1981	9780451521231	0451521234	\N	OL24199104M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7536	38	Mil Novecentos e Oitenta e Quatro	por	PT	Antígona	2007	9789726081890	\N	https://covers.openlibrary.org/b/id/15257493-M.jpg	OL37813678M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7537	38	1984	spa	\N	Grupo Editorial Tomo	2006	9789706665652	970666565X	https://covers.openlibrary.org/b/id/15255313-M.jpg	OL37052191M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7538	38	1984 by George Orwell	eng	\N	Independently Published	2021	9798476844068	\N	\N	OL36890997M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7539	38	1984	\N	\N	Harcourt	2000	9780151005680	0151005680	\N	OL36664839M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7540	38	1984	\N	\N	Folio	2020	9782072878497	\N	https://covers.openlibrary.org/b/id/12480476-M.jpg	OL35736079M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7541	38	1984	eng	\N	Arcturus	2013	9781782124207	1782124209	https://covers.openlibrary.org/b/id/15255280-M.jpg	OL36632156M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7542	38	1984 - Edicao Especial	\N	\N	Companhia das Letras	2019	9788535932966	8535932968	https://covers.openlibrary.org/b/id/12369992-M.jpg	OL35664270M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7543	38	1984 - George Orwell	\N	\N	HARRAPS	2021	9782818707517	281870751X	https://covers.openlibrary.org/b/id/12359001-M.jpg	OL35652254M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7544	38	1984 [TURKISH EDITION]	\N	\N	Altin Kitaplar	2021	9789752126138	9752126138	https://covers.openlibrary.org/b/id/12302903-M.jpg	OL35596657M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7545	38	1984	\N	\N	Insan Kitap	2021	9789755749761	9755749764	https://covers.openlibrary.org/b/id/12348108-M.jpg	OL35640871M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7546	38	1984 Nineteen Eighty-Four (Collins Classics)	eng	\N	HarperCollins Publishers Limited	2021	9780008442613	\N	https://covers.openlibrary.org/b/id/13780360-M.jpg	OL35558418M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7547	38	1984 [TURKISH EDITION] Bin Dokuz Yüz Seksendört	\N	\N	Herdem Kitap	2021	9786257245883	6257245885	https://covers.openlibrary.org/b/id/12270312-M.jpg	OL35428771M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7548	38	1984	\N	\N	Cem Yayinevi	2021	9786257163354	6257163358	https://covers.openlibrary.org/b/id/12255380-M.jpg	OL35413372M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7549	38	1984	\N	\N	Ren Kitap	2020	9786257310031	6257310032	https://covers.openlibrary.org/b/id/12256210-M.jpg	OL35414235M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7550	38	1984	\N	\N	Ithaki Yayinlari	2021	9786257442343	6257442346	https://covers.openlibrary.org/b/id/12257065-M.jpg	OL35415110M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7551	38	1984 [TURKISH EDITION]	\N	\N	Indigo Kitap	2021	9786257671026	6257671027	https://covers.openlibrary.org/b/id/12257727-M.jpg	OL35415794M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7552	38	1984 [TURKISH EDITION]	\N	\N	Iz Yayincilik	2021	9786053265016	6053265012	https://covers.openlibrary.org/b/id/12259904-M.jpg	OL35418076M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7553	38	1984	\N	\N	İnkılap Kitabevi	2021	9789751041876	9751041872	https://covers.openlibrary.org/b/id/12274965-M.jpg	OL35433563M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7554	38	1984	eng	\N	Birlinn, Limited	2021	9781846975769	\N	\N	OL35546665M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7555	38	1984	spa	\N	Independently Published	2020	9798552032730	\N	\N	OL34175718M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7556	38	1984	\N	\N	Debolsillo	2020	9788466352062	\N	https://covers.openlibrary.org/b/id/10497578-M.jpg	OL30766548M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7557	38	1984	eng	\N	Independently Published	2021	9798499486917	\N	\N	OL36172249M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7558	38	1984	eng	\N	Independently Published	2021	9798485159634	\N	\N	OL36415874M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7559	38	1984	eng	\N	Independently Published	2021	9798485158507	\N	\N	OL36429184M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7560	38	1984	spa	\N	Destino	2000	9788423309832	8423309835	https://covers.openlibrary.org/b/id/12597191-M.jpg	OL37016955M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7561	38	1984	ita	\N	Mondadori	2013	9788804627821	\N	https://covers.openlibrary.org/b/id/12454965-M.jpg	OL35719243M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7562	38	1984	spa	\N	Salvat	1970	\N	\N	https://covers.openlibrary.org/b/id/12391400-M.jpg	OL35694089M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7563	38	1984	\N	\N	Companhia Das Letras	2019	9788582851197	8582851197	https://covers.openlibrary.org/b/id/12373832-M.jpg	OL35671036M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7564	38	1984	eng	\N	Arcturus	2016	9781785996313	1785996312	https://covers.openlibrary.org/b/id/15255279-M.jpg	OL35689491M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7565	38	1984	eng	\N	Carpentino, Michela	2021	9781638433774	\N	\N	OL35142160M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7566	38	1984	eng	\N	Carpentino, Michela	2021	9781638433811	\N	\N	OL35142161M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7567	38	1984	eng	\N	Carpentino, Michela	2021	9781638433750	\N	\N	OL35142162M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7568	38	1984	eng	\N	Carpentino, Michela	2021	9781638433798	\N	\N	OL35142167M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7569	38	1984	eng	\N	Carpentino, Michela	2021	9781638433835	\N	\N	OL35142169M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7570	38	1984	eng	\N	Carpentino, Michela	2021	9781638433828	\N	\N	OL35142173M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7571	38	1984	eng	\N	Carpentino, Michela	2021	9781638433767	\N	\N	OL35142174M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7572	38	1984	eng	\N	Carpentino, Michela	2021	9781638433842	\N	\N	OL35142179M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7573	38	1984	eng	\N	Carpentino, Michela	2021	9781638433804	\N	\N	OL35142184M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7574	38	1984 [TURKISH EDITION]	\N	\N	Sahi Kitap	2021	9786050668025	6050668027	https://covers.openlibrary.org/b/id/12109814-M.jpg	OL35298636M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7575	38	1984 [TURKISH EDITION]	\N	\N	Hayat Yayinlari	2021	9786051513423	6051513426	https://covers.openlibrary.org/b/id/12114484-M.jpg	OL35303469M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7576	38	1984 [TURKISH EDITION]	\N	\N	Yakamoz Yayinevi	2021	9786052973578	6052973579	https://covers.openlibrary.org/b/id/12120669-M.jpg	OL35309772M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7577	38	1984	\N	\N	Timas Yayinlari	2021	9786050839203	6050839204	https://covers.openlibrary.org/b/id/12201102-M.jpg	OL35358883M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7578	38	1984	\N	\N	Sule Yayinlari	2021	9786052199701	6052199709	https://covers.openlibrary.org/b/id/12214332-M.jpg	OL35371082M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7579	38	1984 [TURKISH EDITION]	\N	\N	Maviçati Yayinlari	2021	9786052942734	6052942738	https://covers.openlibrary.org/b/id/12217685-M.jpg	OL35374530M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7580	38	1984 [TURKISH EDITION]	\N	\N	Ayrinti Yayinlari	2021	9786053144953	6053144959	https://covers.openlibrary.org/b/id/12220882-M.jpg	OL35377789M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7581	38	1984 [TURKISH EDITION]	\N	\N	Akçag Yayinlari - Özel Ürün	2021	9786053425854	6053425850	https://covers.openlibrary.org/b/id/12223859-M.jpg	OL35380866M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7582	38	1984	\N	\N	Fark Yayınları	2021	9786057676658	6057676653	https://covers.openlibrary.org/b/id/12242133-M.jpg	OL35399846M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7583	38	1984 Nineteen Eighty-Four (Collins Classics)	eng	\N	HarperCollins Publishers Limited	2021	9780008322069	\N	https://covers.openlibrary.org/b/id/14633638-M.jpg	OL34753679M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7584	38	1984	eng	\N	Penguin Random House	2021	9781784876593	\N	https://covers.openlibrary.org/b/id/14279067-M.jpg	OL34674654M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7585	38	1984	eng	\N	Penguin Random House	2021	9781473581579	\N	\N	OL34770005M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7586	38	1984	eng	\N	Montecristo Publishing LLC	2021	9781619652705	\N	\N	OL35099580M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7587	38	1984	eng	\N	Carpentino, Michela	2021	9781638433781	\N	\N	OL35142153M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7588	38	1984 Edizione Speciale	ita	\N	Independently Published	2021	9798527219692	\N	\N	OL34239235M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7589	38	1984 Nineteen Eighty-Four	eng	\N	HarperCollins Publishers Limited	2021	9780008516086	\N	\N	OL33956669M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7590	38	1984	\N	\N	Debolsillo	2021	9788466357562	8466357564	https://covers.openlibrary.org/b/id/11384764-M.jpg	OL32757969M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7591	38	1984	\N	\N	Insel Verlag GmbH	2021	9783458178767	3458178767	https://covers.openlibrary.org/b/id/11987066-M.jpg	OL33874347M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7592	38	1984	eng	\N	Oberon Books, Limited	2017	9781786820822	\N	https://covers.openlibrary.org/b/id/13586688-M.jpg	OL33909885M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7593	38	1984	eng	\N	Bloomsbury Publishing Plc	2021	9781350262713	\N	\N	OL33942280M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7594	38	1984	eng	\N	Penguin Young Readers Group	1950	9781484460665	\N	\N	OL34105948M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7595	38	1984	eng	\N	Houghton Mifflin Harcourt Publishing Company	2022	9780358120353	\N	\N	OL34128359M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7596	38	1984 Nineteen-Eighty Four	\N	\N	Alma Books	2021	9781847498571	1847498574	https://covers.openlibrary.org/b/id/10833087-M.jpg	OL32174003M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7597	38	1984 Nineteen Eighty-Four	eng	\N	HarperCollins Publishers Limited	2021	9780008442620	\N	\N	OL34769818M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7598	38	1984	por	BR	Editora Penkal	2021	9786588843284	\N	https://covers.openlibrary.org/b/id/12226327-M.jpg	OL35382933M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7599	38	Mil novecientos ochenta y cuatro	spa	\N	Editorial Kraft	1973	9788432013881	8432013889	https://covers.openlibrary.org/b/id/12054715-M.jpg	OL33338961M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7600	38	1984	\N	\N	Metacom	1985	9780886760403	0886760402	\N	OL11259663M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7601	38	1984	eng	\N	Blackstone Audio Inc.	2007	9781433202469	1433202468	https://covers.openlibrary.org/b/id/1860524-M.jpg	OL9865729M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7602	38	1984	eng	\N	Signet Classics	1950	9780451516756	0451516753	https://covers.openlibrary.org/b/id/15099337-M.jpg	OL7576669M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7603	38	1984	\N	\N	Destino Ediciones	2005	9789875800021	9875800023	\N	OL9200457M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7604	38	1984.	deu	\N	Heyne	2002	9783453164215	3453164210	\N	OL9041085M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7605	38	1984	\N	\N	Harvill Secker	2009	9781846553288	1846553288	https://covers.openlibrary.org/b/id/6297716-M.jpg	OL24083472M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7606	38	Nineteen eighty-four	eng	\N	Compact	1993	\N	074931723X	\N	OL22303898M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7607	38	Nineteen Eighty-Four	eng	\N	Penguin Books	1981	9780140009729	0140009728	https://covers.openlibrary.org/b/id/15256013-M.jpg	OL16229017M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7608	38	1984	eng	\N	Blackstone Audiobooks	2003	9780786188161	0786188162	https://covers.openlibrary.org/b/id/1469468-M.jpg	OL8108960M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7609	38	1984	\N	\N	bnpublishing.com	2005	9789568356309	9568356304	\N	OL13057937M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7610	38	1984	rus	\N	[s.n.]	\N	\N	\N	\N	OL22602629M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7611	38	1984	eng	\N	New American Library	1961	\N	0881030368	https://covers.openlibrary.org/b/id/4735540-M.jpg	OL22111892M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7612	38	Nineteen eighty-four	eng	\N	Secker & Warburg	1984	\N	043635022X	\N	OL15044129M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7613	38	Yi jiu ba si.	zho	\N	Zhi Wen	1986	\N	\N	\N	OL20661466M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7614	38	Nafrat	urd	\N	Siti Buk Poʾinṭ	2004	\N	\N	\N	OL22997849M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7615	38	Neunzehnhundertvierundachtzig	deu	\N	Ullstein	1981	\N	3550063474	\N	OL22806170M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7616	38	1984	\N	\N	HN Publishing	2006	9789562910330	9562910334	https://covers.openlibrary.org/b/id/2292410-M.jpg	OL9475486M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7617	38	Neunzehnhundertvierundachtzig =	deu	\N	Diana Verlag	1974	\N	387158035X	\N	OL15295594M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7618	38	1984 (Signet Classics)	eng	\N	Tandem Library	1999	9780881030365	0881030368	https://covers.openlibrary.org/b/id/4735539-M.jpg	OL8136314M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7619	38	1984	eng	\N	New American Library	1983	9780451519849	0451519841	https://covers.openlibrary.org/b/id/15254959-M.jpg	OL7576829M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7620	38	Nineteen eighty-four	eng	\N	Heinemann Ed	1965	\N	\N	\N	OL20390645M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7621	38	Nineteen Eighty - Four	eng	\N	Penguin Books	1990	9780140126716	0140126716	https://covers.openlibrary.org/b/id/15255705-M.jpg	OL7348183M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7622	38	Nineteen eighty-four	eng	\N	Secker & Warburg	1949	\N	\N	https://covers.openlibrary.org/b/id/3371955-M.jpg	OL14564241M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7623	38	1984	eng	\N	Plume	1983	9780452262935	0452262933	https://covers.openlibrary.org/b/id/296204-M.jpg	OL7590311M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7624	38	Nineteen eighty-four	eng	\N	Penguin Books	1965	\N	\N	\N	OL22204378M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7625	38	Nineteen eighty-four	eng	\N	Penguin Books in association with Secker & Warburg	1954	\N	\N	\N	OL22221800M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7626	38	1984	\N	\N	Books On Tape	1997	9785553676292	5553676290	\N	OL12578357M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7627	38	1984	\N	\N	Signet Classics	1950	9780451518002	0451518004	\N	OL7576723M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7628	38	Yi jiu ba si	zho	\N	Zhi wen chu ban she	1991	\N	9575455282	\N	OL22905960M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7629	38	Nineteen eighty-four	eng	\N	Clarendon Press	1984	\N	0198185219	https://covers.openlibrary.org/b/id/15255315-M.jpg	OL3174961M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7630	38	1984	eng	\N	Harcourt	2000	\N	\N	\N	OL6784648M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7631	38	Nineteen eighty-four	eng	\N	Music for Pleasure	1984	\N	\N	\N	OL19322160M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7632	38	Nineteen Eighty-Four	eng	\N	Longman	1983	\N	0582536588	https://covers.openlibrary.org/b/id/12654163-M.jpg	OL18051661M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7633	38	1984	\N	\N	Books on Tape	1980	9785557024198	5557024190	\N	OL12580256M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7634	38	Nineteen Eighty-four (Everyman's Library Classics)	\N	\N	Everyman's Library	1992	9781857151343	1857151348	https://covers.openlibrary.org/b/id/908602-M.jpg	OL8998493M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7635	38	1984	\N	\N	Signet Classics	1950	9780451516268	0451516265	\N	OL7576651M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7636	38	1984	\N	\N	Signet Classics	1971	9780451505521	0451505522	\N	OL10273962M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7637	38	1984	fra	\N	Gallimard	\N	9782070248100	2070248100	https://covers.openlibrary.org/b/id/966097-M.jpg	OL8837183M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7638	38	1984	eng	\N	Blackstone Audio Inc.	2007	9781433202452	143320245X	https://covers.openlibrary.org/b/id/1860523-M.jpg	OL9337694M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7639	38	Nineteen eighty-four	eng	\N	Secker & Warburg	1965	\N	\N	\N	OL18937300M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7640	38	1984	eng	\N	Blackstone Audio Inc.	2007	9781433202476	1433202476	https://covers.openlibrary.org/b/id/1860525-M.jpg	OL8547225M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7641	38	1984	eng	\N	Blackstone Audiobooks	2004	9780786183920	0786183926	https://covers.openlibrary.org/b/id/540475-M.jpg	OL8108728M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7642	38	1984	eng	\N	Recorded Books	1990	9781556905803	1556905807	\N	OL12034227M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7643	38	1984	eng	\N	NAL/Dutton	\N	9780614221145	0614221145	\N	OL10982698M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7644	38	Nineteen eighty-four	eng	\N	Penguin Books in association with Secker & Warburg	1972	\N	\N	\N	OL20883702M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7645	38	Nineteen eighty-four	eng	\N	Houghton Mifflin Harcourt	2008	9780156035842	\N	\N	OL22659047M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7646	38	1984	fra	\N	Gallimard	1966	\N	\N	\N	OL19621617M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7647	38	Nineteen eighty-four	eng	\N	Twentieth Century Classics	1970	\N	\N	\N	OL13874273M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7648	38	Nineteen eighty-four	eng	\N	Secker & Warburg	1984	\N	043635019X	\N	OL17523450M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7649	38	Nineteen Eighty-Four	eng	\N	Penguin Classics	2004	9780141187761	014118776X	https://covers.openlibrary.org/b/id/12824243-M.jpg	OL7359256M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7650	38	Nineteen eighty-four	eng	\N	Heinemann Educational	1965	\N	0435176706	\N	OL16172404M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7651	38	Nineteen eighty-four	eng	\N	Penguin in association with Martin Secker & Warburg	1983	\N	0140160086	\N	OL14949259M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7652	38	Nineteen Eighty Four	eng	\N	1st World Library	2004	9781595404329	1595404325	https://covers.openlibrary.org/b/id/874620-M.jpg	OL8881858M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7653	38	1984	deu	\N	Ullstein-Taschenbuch-Verlag, Zweigniederlassung de	1994	9783548234106	3548234100	https://covers.openlibrary.org/b/id/12724109-M.jpg	OL9064021M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7654	38	1984	eng	\N	Buccaneer Books	1982	9780899663685	0899663680	https://covers.openlibrary.org/b/id/700487-M.jpg	OL8276667M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7655	38	Nineteen Eighty-Four	eng	\N	Harcourt, Brace and Company	1949	\N	\N	https://covers.openlibrary.org/b/id/15257280-M.jpg	OL21733390M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7656	38	Nineteen eighty-four	eng	\N	Penguin Books in association with Secker & Warburg	1954	\N	\N	https://covers.openlibrary.org/b/id/15257381-M.jpg	OL18287136M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7657	38	1984	\N	\N	Signet Classics	1971	9780451501004	0451501004	\N	OL7576371M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7658	38	1984	\N	\N	Signet Classics	1950	9780451506887	045150688X	https://covers.openlibrary.org/b/id/14168119-M.jpg	OL7576436M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7659	38	Nineteen Eighty-four (Penguin Modern Classics)	\N	\N	Penguin Audiobooks	2000	9780141801919	0141801913	https://covers.openlibrary.org/b/id/109164-M.jpg	OL7360013M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7660	38	1984	\N	\N	Booket	1997	9788483280065	848328006X	https://covers.openlibrary.org/b/id/4914647-M.jpg	OL9144588M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7661	38	1984	\N	\N	Signet Classics	1950	9780451514745	0451514742	\N	OL7576608M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7662	38	1984	eng	\N	Blackstone Audio Inc.	2007	9781433202445	1433202441	https://covers.openlibrary.org/b/id/1860522-M.jpg	OL8547224M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7663	38	1984	ita	\N	Arnoldo Mondadori Editore	1995	\N	8804325739	https://covers.openlibrary.org/b/id/15201657-M.jpg	OL22486037M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7664	38	Nineteen eighty-four	eng	\N	Penguin	1990	\N	0140126716	\N	OL22604094M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7665	38	Nineteen eighty four	urd	\N	National Academy	\N	\N	\N	\N	OL13871149M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7666	38	1984	eng	\N	Books on Tape	2001	9780736667746	0736667741	\N	OL10602153M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7667	38	1984	spa	\N	Lectorum Publications	2004	9788423335039	8423335038	https://covers.openlibrary.org/b/id/1046910-M.jpg	OL9118079M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7668	38	1984	\N	\N	Signet	\N	9780451007988	0451007980	https://covers.openlibrary.org/b/id/6456334-M.jpg	OL7569648M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7669	38	1984	eng	\N	New American Library	1951	\N	\N	https://covers.openlibrary.org/b/id/15257483-M.jpg	OL24199103M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7670	38	Nineteen eighty-four	eng	\N	Secker & Warburg	1949	\N	\N	https://covers.openlibrary.org/b/id/3371956-M.jpg	OL14589454M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7671	38	1984	eng	\N	DH Audio	1986	9780886460891	0886460891	\N	OL11259052M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7672	38	Nineteen eighty-four	eng	\N	New American Library	1949	\N	\N	\N	OL22776522M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7673	38	1984	eng	\N	New American Library	1983	\N	\N	https://covers.openlibrary.org/b/id/15257278-M.jpg	OL62592013M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7674	38	Nineteen Eighty-Four	eng	\N	Penguin Books	1969	\N	\N	https://covers.openlibrary.org/b/id/15257061-M.jpg	OL62591440M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7675	38	Nineteen Eighty-Four	eng	\N	Penguin Books	1956	\N	\N	https://covers.openlibrary.org/b/id/15257057-M.jpg	OL62591438M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7676	38	1984	eng	\N	New American Library	1961	\N	\N	https://covers.openlibrary.org/b/id/15257055-M.jpg	OL62591436M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7677	38	Nineteen Eighty-Four	eng	\N	FolletBound Platinum	1977	9780758797414	\N	https://covers.openlibrary.org/b/id/15257053-M.jpg	OL62591434M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7678	38	1984	eng	\N	New American Library	1961	\N	\N	https://covers.openlibrary.org/b/id/15257052-M.jpg	OL62591433M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7679	38	1984	eng	\N	New American Library	1961	\N	\N	https://covers.openlibrary.org/b/id/15257051-M.jpg	OL62591432M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7680	38	Nineteen Eighty-Four	eng	\N	Harcourt, Brace and Company	1949	\N	\N	https://covers.openlibrary.org/b/id/15257049-M.jpg	OL62591431M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7681	38	Nineteen Eighty-Four	eng	\N	Penguin Books	1990	\N	\N	https://covers.openlibrary.org/b/id/15257048-M.jpg	OL62591430M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7682	38	Nineteen Eighty-Four	eng	\N	Penguin Books	1968	\N	\N	https://covers.openlibrary.org/b/id/15257047-M.jpg	OL62591427M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7683	38	Nineteen Eighty-Four	eng	\N	Penguin Books	1958	\N	\N	https://covers.openlibrary.org/b/id/15257036-M.jpg	OL62591417M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7684	38	1984	nld	\N	Uitgeverij de Arbeiderspers	2016	9789029587099	\N	https://covers.openlibrary.org/b/id/15257030-M.jpg	OL62591414M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7685	38	1984	zho	\N	Hua dong shi fan da xue chu ban she	2013	9787567504424	\N	https://covers.openlibrary.org/b/id/15257029-M.jpg	OL62591413M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7686	38	1984	eng	\N	Öteki Adam	2023	9786055114343	\N	https://covers.openlibrary.org/b/id/15256136-M.jpg	OL62582104M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7687	38	1984	eng	\N	Maple Press	2010	9788190782692	\N	https://covers.openlibrary.org/b/id/15256132-M.jpg	OL62582079M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7688	38	Nineteen Eighty-Four	eng	\N	Secker & Warburg	1955	\N	\N	https://covers.openlibrary.org/b/id/15256118-M.jpg	OL62582000M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7689	38	Nineteen Eighty-Four	eng	\N	Penguin Books	2008	9781405965347	\N	https://covers.openlibrary.org/b/id/15256117-M.jpg	OL62581987M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
9451	3	Dune: Tome 4 - L'Empereur-Dieu de Dune	\N	\N	Pocket	2022	9782266320511	\N	https://covers.openlibrary.org/b/id/15123107-M.jpg	OL60126269M	\N	2026-11-25 20:25:28.381809+00	2026-11-25 20:25:28.381809+00
9452	3	God-Keizer op Duin	\N	\N	Samenw. uitgeverijen Meulenhoff Boekerij	1999	9789029042840	9029042842	\N	OL45929986M	\N	2026-11-25 20:25:28.381809+00	2026-11-25 20:25:28.381809+00
9453	3	God Emperor of Dune	\N	\N	G.P. Putnam's Sons	1981	9781439501610	1439501610	\N	OL43919880M	\N	2026-11-25 20:25:28.381809+00	2026-11-25 20:25:28.381809+00
9454	3	God Emperor of Dune	eng	\N	Orion Publishing Group, Limited	2010	9780575104440	\N	\N	OL40376398M	\N	2026-11-25 20:25:28.381809+00	2026-11-25 20:25:28.381809+00
9455	3	God Emperor of Dune	eng	\N	Turtleback	1981	9780606030816	\N	\N	OL40503794M	\N	2026-11-25 20:25:28.381809+00	2026-11-25 20:25:28.381809+00
9456	3	Dios Emperador de Dune / God Emperor of Dune	spa	\N	Penguin Random House Grupo Editorial	2022	9788466359443	\N	\N	OL34987067M	\N	2026-11-25 20:25:28.381809+00	2026-11-25 20:25:28.381809+00
9457	3	God Emperor of Dune	eng	\N	Orion Publishing Group, Limited	2021	9781473233805	\N	https://covers.openlibrary.org/b/id/14787645-M.jpg	OL34690788M	\N	2026-11-25 20:25:28.381809+00	2026-11-25 20:25:28.381809+00
9458	3	Imperador Deus de Duna	por	BR	Editora Aleph	2017	9788576572626	8576572621	https://covers.openlibrary.org/b/id/10210554-M.jpg	OL28285129M	\N	2026-11-25 20:25:28.381809+00	2026-11-25 20:25:28.381809+00
9459	3	L'Empereur-Dieu de Dune	fra	\N	Pocket	2024	9782266349895	\N	https://covers.openlibrary.org/b/id/14896075-M.jpg	OL58635870M	\N	2026-11-25 20:25:28.381809+00	2026-11-25 20:25:28.381809+00
9460	3	L'Empereur-Dieu de Dune	fra	\N	Robert Laffont	2022	9782221263174	2221263170	https://covers.openlibrary.org/b/id/13120983-M.jpg	OL45070268M	\N	2026-11-25 20:25:28.381809+00	2026-11-25 20:25:28.381809+00
9461	3	L'empereur-dieu de Dune	fra	\N	France Loisirs	1984	9782724215908	2724215907	https://covers.openlibrary.org/b/id/14836314-M.jpg	OL31379919M	\N	2026-11-25 20:25:28.381809+00	2026-11-25 20:25:28.381809+00
9462	3	Bóg Imperator Diuny	pol	\N	Dom Wydawniczy Rebis	2020	9788381887786	\N	https://covers.openlibrary.org/b/id/14613132-M.jpg	OL51567303M	\N	2026-11-25 20:25:28.381809+00	2026-11-25 20:25:28.381809+00
9463	3	L'Empereur-Dieu de Dune	fra	\N	Robert Laffont	2021	9782221252321	2221252322	https://covers.openlibrary.org/b/id/12873429-M.jpg	OL39473672M	\N	2026-11-25 20:25:28.381809+00	2026-11-25 20:25:28.381809+00
9464	3	Dune Tanri Imparatoru	\N	\N	Ithaki Yayinlari	2000	9786053757207	6053757209	https://covers.openlibrary.org/b/id/10851157-M.jpg	OL32201981M	\N	2026-11-25 20:25:28.381809+00	2026-11-25 20:25:28.381809+00
9465	3	Dune : Tanri Imparatoru	\N	\N	Kabalci Yayinevi	2009	9789759971434	9759971437	https://covers.openlibrary.org/b/id/8497752-M.jpg	OL26826523M	\N	2026-11-25 20:25:28.381809+00	2026-11-25 20:25:28.381809+00
9466	3	Le Cycle de Dune, tome 5 	fra	\N	Pocket	1992	9782266027236	2266027239	https://covers.openlibrary.org/b/id/979506-M.jpg	OL8889704M	\N	2026-11-25 20:25:28.381809+00	2026-11-25 20:25:28.381809+00
9467	3	L'Empereur-Dieu de Dune - tome 5	\N	\N	Pocket	2005	9782266153744	2266153749	https://covers.openlibrary.org/b/id/10229140-M.jpg	OL28302643M	\N	2026-11-25 20:25:28.381809+00	2026-11-25 20:25:28.381809+00
9468	3	God Emperor of Dune	\N	\N	Brand: Macmillan Audio	2008	9781427203151	1427203156	https://covers.openlibrary.org/b/id/10108358-M.jpg	OL28170348M	\N	2026-11-25 20:25:28.381809+00	2026-11-25 20:25:28.381809+00
9469	3	God Emperor of Dune	\N	\N	Ace	2020	9780593201756	0593201752	https://covers.openlibrary.org/b/id/10226364-M.jpg	OL28300557M	\N	2026-11-25 20:25:28.381809+00	2026-11-25 20:25:28.381809+00
9470	3	God Emperor of Dune	eng	\N	Penguin Publishing Group	2019	9780593098257	\N	https://covers.openlibrary.org/b/id/14816239-M.jpg	OL28895492M	\N	2026-11-25 20:25:28.381809+00	2026-11-25 20:25:28.381809+00
9471	3	God Emperor of Dune	eng	\N	Gollancz	1981	9780575029767	0575029765	https://covers.openlibrary.org/b/id/13396751-M.jpg	OL27305728M	\N	2026-11-25 20:25:28.381809+00	2026-11-25 20:25:28.381809+00
9472	3	God Emperor of Dune, Book Club Edition	\N	\N	Putnam	1981	9780739433911	0739433911	https://covers.openlibrary.org/b/id/8673281-M.jpg	OL27057632M	\N	2026-11-25 20:25:28.381809+00	2026-11-25 20:25:28.381809+00
9473	3	God Emperor of Dune	eng	\N	Turtleback Books Distributed by Demco Media	1987	9780606348157	0606348158	https://covers.openlibrary.org/b/id/14816240-M.jpg	OL7585138M	\N	2026-11-25 20:25:28.381809+00	2026-11-25 20:25:28.381809+00
9474	3	God Emperor of Dune	eng	\N	Gollancz	2003	9780575075061	0575075066	https://covers.openlibrary.org/b/id/380231-M.jpg	OL7878782M	\N	2026-11-25 20:25:28.381809+00	2026-11-25 20:25:28.381809+00
9475	3	God Emperor of Dune	eng	\N	Ace Books	2008	9780441016310	\N	https://covers.openlibrary.org/b/id/13267563-M.jpg	OL23158590M	\N	2026-11-25 20:25:28.381809+00	2026-11-25 20:25:28.381809+00
9476	3	GOD EMPEROR OF DUNE	\N	\N	\N	\N	\N	\N	https://covers.openlibrary.org/b/id/14816234-M.jpg	OL14436579M	\N	2026-11-25 20:25:28.381809+00	2026-11-25 20:25:28.381809+00
9477	3	God emperor of Dune	eng	\N	Gollancz	1984	\N	0575035439	https://covers.openlibrary.org/b/id/13267567-M.jpg	OL21540522M	\N	2026-11-25 20:25:28.381809+00	2026-11-25 20:25:28.381809+00
9478	3	God Emperor of Dune	eng	\N	New English Library	1982	\N	0450052621	https://covers.openlibrary.org/b/id/9256384-M.jpg	OL18222919M	\N	2026-11-25 20:25:28.381809+00	2026-11-25 20:25:28.381809+00
9479	3	God Emperor of Dune	eng	\N	Putnam	1981	\N	0399125930	https://covers.openlibrary.org/b/id/14950820-M.jpg	OL4110208M	\N	2026-11-25 20:25:28.381809+00	2026-11-25 20:25:28.381809+00
9480	3	God Emperor of Dune	eng	\N	Harper Audio	1994	9781559949101	1559949104	https://covers.openlibrary.org/b/id/13267566-M.jpg	OL9644713M	\N	2026-11-25 20:25:28.381809+00	2026-11-25 20:25:28.381809+00
9481	3	Der Gottkaiser des Wüstenplaneten	deu	\N	Wilhelm Heyne Verlag	2001	9783453186866	\N	https://covers.openlibrary.org/b/id/11379024-M.jpg	OL32752755M	\N	2026-11-25 20:25:28.381809+00	2026-11-25 20:25:28.381809+00
9482	3	Bóg imperator Diuny	pol	\N	Phantom Press International	1992	\N	8370754570	https://covers.openlibrary.org/b/id/7932259-M.jpg	OL19610813M	\N	2026-11-25 20:25:28.381809+00	2026-11-25 20:25:28.381809+00
9483	3	L' Empereur-dieu de Dune	fra	\N	Laffont	1982	\N	2221007751	https://covers.openlibrary.org/b/id/11668282-M.jpg	OL15229386M	\N	2026-11-25 20:25:28.381809+00	2026-11-25 20:25:28.381809+00
9484	3	God Emperor for Dune	\N	\N	Orion Publishing Co	1984	9780575035430	0575035439	https://covers.openlibrary.org/b/id/14816238-M.jpg	OL7877928M	\N	2026-11-25 20:25:28.381809+00	2026-11-25 20:25:28.381809+00
9485	3	God Emperor Dune/int	\N	\N	Berkley	1981	9780425053393	0425053393	https://covers.openlibrary.org/b/id/14816235-M.jpg	OL7501419M	\N	2026-11-25 20:25:28.381809+00	2026-11-25 20:25:28.381809+00
9486	3	God Emperor Dune Ca	\N	\N	Berkley	1983	9780425062425	0425062422	https://covers.openlibrary.org/b/id/14816243-M.jpg	OL7501674M	\N	2026-11-25 20:25:28.381809+00	2026-11-25 20:25:28.381809+00
9487	3	Dios Emperador De Dune / God Emperor of Dune	spa	\N	Debolsillo	2005	9788497597487	8497597486	https://covers.openlibrary.org/b/id/4918370-M.jpg	OL9154487M	\N	2026-11-25 20:25:28.381809+00	2026-11-25 20:25:28.381809+00
9488	3	Dios emperador de dune	spa	\N	Plaza & Janés	1995	\N	8401469341	\N	OL18263786M	\N	2026-11-25 20:25:28.381809+00	2026-11-25 20:25:28.381809+00
9489	3	God Emperor of Dune (Dune Chronicles, Book 4)	\N	\N	Books on Tape, Inc.	1998	9780736644228	0736644229	https://covers.openlibrary.org/b/id/1365210-M.jpg	OL9528074M	\N	2026-11-25 20:25:28.381809+00	2026-11-25 20:25:28.381809+00
9490	3	God Emperor of Dune (Dune Chronicles, Book 4)	\N	\N	Berkley	1984	9780425080030	042508003X	https://covers.openlibrary.org/b/id/14816237-M.jpg	OL7502178M	\N	2026-11-25 20:25:28.381809+00	2026-11-25 20:25:28.381809+00
9491	3	God Emperor of Dune (Dune Chronicles, Book 4)	eng	\N	Tandem Library	1999	9780881036350	0881036358	https://covers.openlibrary.org/b/id/677695-M.jpg	OL8136409M	\N	2026-11-25 20:25:28.381809+00	2026-11-25 20:25:28.381809+00
9492	3	God Emperor of Dune (Dune Chronicles, Book 4)	eng	\N	Berkley	1983	9780425062333	0425062333	https://covers.openlibrary.org/b/id/14612739-M.jpg	OL7501667M	\N	2026-11-25 20:25:28.381809+00	2026-11-25 20:25:28.381809+00
9493	3	God Emperor of Dune (Dune Chronicles, Book 4)	eng	\N	Ace Books	1987	9780441294671	0441294677	https://covers.openlibrary.org/b/id/284524-M.jpg	OL7525477M	\N	2026-11-25 20:25:28.381809+00	2026-11-25 20:25:28.381809+00
9494	3	God Emperor of Dune (Dune Chronicles, Book 4)	\N	\N	Berkley Trade	1982	9780425061282	0425061280	https://covers.openlibrary.org/b/id/14816236-M.jpg	OL7501639M	\N	2026-11-25 20:25:28.381809+00	2026-11-25 20:25:28.381809+00
9495	3	God Emperor of Dune (Dune Chronicles, Book 4)	\N	\N	Berkley	1984	9780425072721	042507272X	https://covers.openlibrary.org/b/id/14816241-M.jpg	OL7501984M	\N	2026-11-25 20:25:28.381809+00	2026-11-25 20:25:28.381809+00
9496	3	God Emperor of Dune (Dune Chronicles, Book 4)	\N	\N	Berkley Trade	1982	9780425053126	0425053121	https://covers.openlibrary.org/b/id/13711492-M.jpg	OL7501407M	\N	2026-11-25 20:25:28.381809+00	2026-11-25 20:25:28.381809+00
9497	5	Dzieci Diuny - Frank Herbert, Wojciech Siudmak [KSIÄĹťKA]	pol	\N	Rebis	2020	9788381880473	8381880475	https://covers.openlibrary.org/b/id/13955465-M.jpg	OL47362500M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9498	5	沙丘(3沙丘之子)	zho	\N	江苏凤凰文艺出版社	2017	9787559411174	\N	\N	OL43022658M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9499	5	Dune-Zyklus	deu	\N	Heyne	1985	9783453305243	3453305248	https://covers.openlibrary.org/b/id/10023568-M.jpg	OL25563083M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9500	5	Children of Dune	\N	\N	Ace Books	1991	9789994737505	9994737503	\N	OL9207540M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9501	5	Hijos de Dune / Children of Dune	spa	\N	Penguin Random House Grupo Editorial	2024	9788466372022	\N	\N	OL50718776M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9502	5	Children of Dune - Dune Novels 3 (NEL)	\N	\N	\N	\N	\N	\N	\N	OL49631114M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9503	5	Children of Dune	\N	\N	Paw Prints 2008-06-26	2008	9781439501627	1439501629	\N	OL44658386M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9504	5	Children of Dune	\N	\N	New English Library Ltd	1996	9780450053078	0450053075	\N	OL44735541M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9505	5	Children of Dune- The Climax of the Dune Trilogy	\N	\N	Berkley Publishing Corporation by G.P Putnam's Sons	1976	\N	\N	\N	OL43027879M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9506	5	Ketters van Duin	\N	\N	Volt	2019	9789021415321	9021415321	\N	OL42858833M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9507	5	Children of Dune	eng	\N	Orion Publishing Group, Limited	2007	9780575081512	\N	\N	OL40357608M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9508	5	Children of Dune	eng	\N	Orion Publishing Group, Limited	2010	9780575104402	\N	\N	OL40380867M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9509	5	Children of Dune	eng	\N	Turtleback	1991	9780606008273	\N	\N	OL40484766M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9510	5	Children of Dune	eng	\N	Penguin Publishing Group	1977	9780441104123	\N	\N	OL40491926M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9511	5	Children of Dune	eng	\N	Penguin Publishing Group	2008	9781436221207	\N	\N	OL40493403M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9512	5	Children of Dune	eng	\N	Penguin Publishing Group	1978	9780425039311	\N	\N	OL40498733M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9513	5	Hijos de Dune (Edición Ilustrada) / Children of Dune	spa	\N	Ediciones B	2023	9788418037719	\N	\N	OL40173239M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9514	5	Les enfants de Dune	fra	\N	Pocket	2008	9782266152525	2266152521	https://covers.openlibrary.org/b/id/12907001-M.jpg	OL39795325M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9515	5	Children of Dune	eng	\N	Penguin Publishing Group	2023	9780593548455	\N	https://covers.openlibrary.org/b/id/14613340-M.jpg	OL39443998M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9516	5	Kinderen van Duin	nld	\N	Meulenhoff	1989	9789029042130	9029042133	https://covers.openlibrary.org/b/id/12714383-M.jpg	OL37806992M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9517	5	Ketters van Duin	nld	\N	Meulenhoff	1989	9789029043151	9029043156	https://covers.openlibrary.org/b/id/12714357-M.jpg	OL37806976M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9518	5	Filhos de Duna	por	BR	Editora Aleph	2014	9788576571650	857657165X	https://covers.openlibrary.org/b/id/14545225-M.jpg	OL37115179M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9519	5	Hijos de Dune. Nueva Edición / Children of Dune	spa	\N	Penguin Random House Grupo Editorial	2021	9788466357005	\N	\N	OL34155935M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9520	5	Hijos de Dune	\N	\N	Debolsillo	2009	9788497594325	\N	https://covers.openlibrary.org/b/id/13154618-M.jpg	OL46525542M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9521	5	Children of Dune	\N	\N	Macmillan Audio	2012	9781427228499	1427228493	https://covers.openlibrary.org/b/id/11461904-M.jpg	OL32829957M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9522	5	Children Of Dune	\N	\N	Gollancz	2021	9781473233782	147323378X	https://covers.openlibrary.org/b/id/11981729-M.jpg	OL33784791M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9523	5	Les Enfants de Dune	fra	\N	Pocket	2024	9782266349888	\N	https://covers.openlibrary.org/b/id/14896356-M.jpg	OL58638429M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9524	5	Les Enfants de Dune	fra	\N	Robert Laffont	2022	9782221259931	2221259939	https://covers.openlibrary.org/b/id/13120986-M.jpg	OL45070299M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9525	5	Dzieci Diuny	pol	\N	Dom Wydawniczy Rebis	2020	9788381887557	\N	https://covers.openlibrary.org/b/id/14596254-M.jpg	OL51257349M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9526	5	Les Enfants de Dune	fra	\N	Robert Laffont	2021	9782221252314	2221252314	https://covers.openlibrary.org/b/id/12873424-M.jpg	OL39473670M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9527	5	Dune'un Çocukları	\N	\N	Sarmal Yayınevi	\N	9789756557297	975655729X	https://covers.openlibrary.org/b/id/8765798-M.jpg	OL27285041M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9528	5	Le Cycle de Dune, tome 4 	fra	\N	Pocket	1992	9782266027229	2266027220	https://covers.openlibrary.org/b/id/979505-M.jpg	OL8889703M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9529	5	Dune, tome 2 	fra	\N	Robert Laffont	1997	9782221087039	2221087038	https://covers.openlibrary.org/b/id/975024-M.jpg	OL8865837M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9530	5	Dzieci Diuny	\N	\N	Rebis	2017	9788373017269	8373017267	https://covers.openlibrary.org/b/id/10173942-M.jpg	OL28242956M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9531	5	Filhos de Duna	por	BR	Aleph	2017	9788576573142	8576573148	https://covers.openlibrary.org/b/id/8785347-M.jpg	OL27314510M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9532	5	Dune Cocuklari	\N	\N	Ithaki Yayinlari	2016	9786053756026	6053756024	https://covers.openlibrary.org/b/id/10850500-M.jpg	OL32201326M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9533	5	Dune Cocuklari	\N	\N	Kabalci Yayinevi	2008	9789759971342	9759971348	https://covers.openlibrary.org/b/id/8541767-M.jpg	OL26854849M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9534	5	Les enfants de Dune	\N	\N	Robert Laffont	1978	9782221000458	2221000455	https://covers.openlibrary.org/b/id/10213104-M.jpg	OL28287949M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9535	5	Children of Dune	\N	\N	Macmillan Audio	2008	9780792752325	0792752325	https://covers.openlibrary.org/b/id/8790960-M.jpg	OL27324381M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9536	5	Children of Dune	\N	\N	Ace	2020	9780593201749	0593201744	https://covers.openlibrary.org/b/id/10226359-M.jpg	OL28300552M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9537	5	Children of Dune	eng	\N	Ace	2019	9780593098240	0593098242	https://covers.openlibrary.org/b/id/8765428-M.jpg	OL27284693M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9538	5	Children Of Dune	\N	\N	Berkley	1977	9780425033104	0425033104	https://covers.openlibrary.org/b/id/8577630-M.jpg	OL26968814M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9539	5	Les Enfants De Dune	\N	\N	Editions Robert Laffront, S.A.	1978	9782266013031	2266013033	https://covers.openlibrary.org/b/id/8576786-M.jpg	OL26917266M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9540	5	Le messie de dune, les enfants de dune	\N	\N	France loisirs	1983	9782724212983	2724212983	https://covers.openlibrary.org/b/id/8435276-M.jpg	OL26782050M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9541	5	Children of Dune (Dune Chronicles, Book 3)	\N	\N	Berkley	1984	9780425071793	0425071790	https://covers.openlibrary.org/b/id/6610486-M.jpg	OL7501961M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9542	5	Children of Dune (Dune Chronicles, Book 3)	eng	\N	Not Avail	1997	9780736640190	0736640193	https://covers.openlibrary.org/b/id/463243-M.jpg	OL7893252M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9543	5	Children of Dune (Dune Chronicles, Book 3)	\N	\N	Berkley	1984	9780425074992	0425074994	\N	OL7502060M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9544	5	Children of Dune (Dune Chronicles, Book 3)	eng	\N	Ace	1987	9780441104024	0441104029	https://covers.openlibrary.org/b/id/284479-M.jpg	OL7524870M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9545	5	Children of Dune (Dune Chronicles, Book 3)	\N	\N	Berkley Trade	1982	9780425053157	0425053156	https://covers.openlibrary.org/b/id/4627687-M.jpg	OL7501410M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9546	5	Children of Dune (Dune Chronicles, Book 3)	eng	\N	Berkley	1983	9780425064351	0425064352	\N	OL7501755M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9547	5	Children of Dune (Dune Chronicles, Book 3)	eng	\N	Ace Books	1987	9780441104116	0441104118	\N	OL7524871M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
6969	20	Harry Potter og de vises sten	dan	\N	Gyldendal	2000	9788700398368	8700398365	\N	OL23029279M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6970	20	Harry Potter ve felsefe tasi	tur	\N	YKY	2001	9789750802942	9750802942	\N	OL20569571M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6971	20	Harry Potter và Hòn Đá Phù Thủy	vie	\N	NXB Trke	1997	\N	\N	https://covers.openlibrary.org/b/id/14826421-M.jpg	OL23024206M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6972	20	哈利波特	zho	\N	Huang guan wen hua chu ban you xian gong si	2000	9789573317241	9573317249	https://covers.openlibrary.org/b/id/13028159-M.jpg	OL23035226M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6973	20	Гарри Поттер и философский камень	rus	\N	Rosmėn	2006	9785353003083	535300308X	\N	OL19680813M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6974	20	Hǣrī Phō̜ttœ̄ kap silʻāthan	tha	\N	Bō̜risāt Nānmībuk	2001	9789744723628	9744723629	\N	OL23050677M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6975	20	Harry Potter y la piedra filosofal	spa	\N	Emecé Editores	2000	9788478885541	8478885544	\N	OL22858290M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6976	20	Harry Potter és a bölcsek köve	hun	\N	Animus	2000	9789638386892	9638386894	https://covers.openlibrary.org/b/id/14320053-M.jpg	OL23038915M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6977	20	हैरी पॉटर और पारस पत्थर	hin	\N	Mañjula Pabliśiṅga Hāusa	2003	9788186775608	8186775609	https://covers.openlibrary.org/b/id/15155838-M.jpg	OL23032880M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6978	20	Harry Potter a kámen mudrců	ces	\N	Albatros	2002	9788000010403	8000010402	\N	OL23037597M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6979	20	Harry Potter à l'école des sorciers	fra	\N	Gallimard	2006	9782070541270	2070541274	\N	OL19679484M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6980	20	Harry Potter en die towenaar se steen	afr	\N	Human & Rousseau	2000	9780798140232	0798140232	\N	OL23032819M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6981	20	Harry Potter Büyülü Taş	tur	\N	Dost Kitabevi Yayinlari	1999	9789757501954	9757501956	https://covers.openlibrary.org/b/id/14419325-M.jpg	OL19220977M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6982	20	Hari Patter va Sang-i Jādū	fas	\N	Tandis Books	2000	9789645757029	9645757029	https://covers.openlibrary.org/b/id/12860169-M.jpg	OL23019679M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6983	20	Garri Potter i filosofskii kamen'	rus	\N	Rosmen	2002	9785353002130	535300213X	\N	OL18884467M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6984	20	Harry Potter og viskusteinninn	isl	\N	Bjartur	1999	9789979865551	9979865555	https://covers.openlibrary.org/b/id/13171285-M.jpg	OL23018371M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6985	20	Ἄρειος Ποτὴρ καὶ ἡ τοῦ φιλοσόφου λίθος	ell	\N	Bloomsbury	2004	9781582348261	158234826X	https://covers.openlibrary.org/b/id/7088561-M.jpg	OL23059913M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6986	20	Hari Poter i kamen mudrosti	hrv	\N	Narodna Knjiga	2000	\N	\N	\N	OL23096517M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6987	20	Гарри Поттер и философский камень	rus	\N	Rosmen	2001	9785845107411	5845107415	\N	OL23021231M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6988	20	Harry Potter and the Philosopher's Stone	eng	\N	Bloomsbury Publishing PLC	1998	9780747542049	074754204X	\N	OL7961781M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6989	20	Harry Potter and the Sorcerer's stone	eng	\N	Scholastic Press	2000	9780439203524	043920352X	https://covers.openlibrary.org/b/id/8267749-M.jpg	OL16786331M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6990	20	Harry Potter and the Philosopher's Stone	eng	\N	Raincoast Books	2000	9781551923963	1551923963	https://covers.openlibrary.org/b/id/771854-M.jpg	OL13639000M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6991	20	Harry Potter and the Philosopher's Stone	eng	\N	Bloomsbury	1999	9780747545729	0747545723	\N	OL18137709M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6992	20	Harry Potter and the Philosopher's Stone	eng	\N	Scholastic	1997	\N	\N	\N	OL24329396M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6993	20	Harry Potter e la Pietra Filosofale	ita	\N	Salani	2006	9788884516107	8884516102	https://covers.openlibrary.org/b/id/8267048-M.jpg	OL9073667M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6994	20	Harry Potter and the Philosopher's Stone	eng	\N	BBC Audiobooks	1999	9781855493940	1855493942	https://covers.openlibrary.org/b/id/8267746-M.jpg	OL8993476M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6995	20	Harry Potter a kámen mudrců	ces	\N	Albatros	2010	9788000027562	8000027569	\N	OL26418548M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6996	20	Harrī Poṭṭur aur pāras pathar	urd	\N	Oxford University Press	2002	9780195798586	0195798589	\N	OL23032778M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6997	20	Harry Potter y la piedra filosofal	spa	\N	Tandem Library	2001	9780613359603	0613359607	https://covers.openlibrary.org/b/id/5024696-M.jpg	OL9894276M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6998	20	Harry Potter and the Sorcerer's Stone	eng	\N	James Bay	2009	\N	132	\N	OL26469728M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6999	20	Harry Potter and the Sorcerer's Stone	eng	\N	Large Print Press	2003	9781594130007	1594130000	https://covers.openlibrary.org/b/id/8266555-M.jpg	OL3688332M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7000	20	Harry Potter and the Sorcerer's stone	eng	\N	National Braille Press	1999	\N	\N	\N	OL18345253M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7001	20	Harry Potter and the Philosopher's Stone	eng	\N	BBC Audiobooks Ltd	1999	9781855498600	185549860X	\N	OL11999814M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7002	20	Harry Potter and the Philosopher's Stone	gla	\N	Bloomsbury USA Children's Books	2008	9781582346816	158234681X	\N	OL8786504M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7003	20	Harry Potter i kamien filozoficzny	pol	\N	Media Rodzina	2000	\N	8372780110	https://covers.openlibrary.org/b/id/15155644-M.jpg	OL16418942M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7004	20	Harry Potter and the Philosopher's Stone	eng	\N	Ted Smart	1998	9781856134033	1856134032	https://covers.openlibrary.org/b/id/8267078-M.jpg	OL22620224M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7005	20	Harry Potter y la piedra filosofal	spa	\N	Emecé Editores	1999	9788478884452	8478884459	https://covers.openlibrary.org/b/id/8267049-M.jpg	OL9142275M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7006	20	Harry Potter and the Philosopher's Stone	eng	\N	BBC Audiobooks	2001	9781855496804	1855496801	https://covers.openlibrary.org/b/id/906289-M.jpg	OL8993490M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7007	20	ハリー・ポッターと賢者の石	jpn	\N	Say-zan-sha Publication	1999	9784915512377	4915512371	https://covers.openlibrary.org/b/id/8266536-M.jpg	OL26352045M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
9548	5	Children of Dune (Dune Chronicles, Book 3)	\N	\N	Berkley Trade	1984	9780425079027	0425079023	https://covers.openlibrary.org/b/id/13174086-M.jpg	OL7502160M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9549	5	Hijos De Dune/Children of Dune	spa	\N	Acervo	1977	9788470022333	8470022334	https://covers.openlibrary.org/b/id/14555554-M.jpg	OL9134536M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9550	5	Hijos de Dune	spa	\N	Plaza & Janés	\N	\N	8401469333	\N	OL18263764M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9551	5	Die Kinder des Wüstenplaneten.	deu	\N	Heyne	2001	9783453186859	3453186850	https://covers.openlibrary.org/b/id/1009422-M.jpg	OL9041233M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9552	5	Children of Dune	\N	\N	Berkley Publishing Company	1984	9780575035423	0575035420	\N	OL7877927M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9553	5	Children Of Dune	\N	\N	New English Library	1980	\N	0450050750	https://covers.openlibrary.org/b/id/9256651-M.jpg	OL7569339M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9554	5	Children of Dune	eng	\N	Audio Renaissance	2008	9781427202918	1427202915	https://covers.openlibrary.org/b/id/13510803-M.jpg	OL9405597M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9555	5	Children of Dune	eng	\N	\N	2008	9780441015900	\N	\N	OL19141856M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9556	5	Children Of Dune	eng	\N	Berkley	1982	9780425061749	0425061744	\N	OL10214709M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9557	5	Children of Dune	eng	\N	Berkley Pub. Corp. : distributed by Putnam	1976	\N	0399116974	https://covers.openlibrary.org/b/id/8357660-M.jpg	OL5213852M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9558	5	Children Of Dune	eng	\N	Berkley	1981	9780425043837	0425043835	\N	OL7501106M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9559	5	Children Of Dune	eng	\N	Berkley	1981	9780425054727	0425054721	\N	OL7501461M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9560	5	Children of Dune.	eng	\N	Berkley Publishing	1977	\N	0425040755	https://covers.openlibrary.org/b/id/13510801-M.jpg	OL15037315M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9561	5	Children of Dune	eng	\N	New English Library	1978	\N	0450034275	https://covers.openlibrary.org/b/id/10206866-M.jpg	OL18121723M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9562	5	Children of Dune	eng	\N	Gollancz	1976	\N	057502190X	https://covers.openlibrary.org/b/id/13893931-M.jpg	OL17405110M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9563	5	CHILDREN OF DUNE	\N	\N	\N	\N	\N	\N	\N	OL14436576M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9564	5	Children of Dune	eng	\N	Berkley Pub. Corp.	1976	\N	\N	\N	OL16076058M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9565	5	Children of Dune	eng	\N	Penguin Group USA, Inc.	2008	9781436221184	\N	https://covers.openlibrary.org/b/id/15150065-M.jpg	OL24270160M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9566	5	Children of Dune	eng	\N	Tandem Library	1999	9780808520948	0808520946	https://covers.openlibrary.org/b/id/592160-M.jpg	OL7973622M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9567	5	The Children of Dune	eng	\N	Gollancz	2003	9780575074903	0575074906	https://covers.openlibrary.org/b/id/380219-M.jpg	OL7878772M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9568	5	Children of Dune	eng	\N	Berkley Pub. Corp.	1976	9780399116971	0399116974	https://covers.openlibrary.org/b/id/6822406-M.jpg	OL24768564M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9569	5	Sha qiu zhi zi	zho	\N	Mao tou ying chu ban she	2007	9789867001726	9867001729	\N	OL23127073M	\N	2026-11-25 20:25:31.775995+00	2026-11-25 20:25:31.775995+00
9570	9	Kraljeva vrnitev	slv	\N	Mladinska knjiga	2003	\N	861116301X	https://covers.openlibrary.org/b/id/15261273-M.jpg	OL62623570M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9571	9	Gredzenu pavēlnieks. Ķēniņa atgriešanās	\N	\N	Jumava	2026	9789934207433	\N	https://covers.openlibrary.org/b/id/15247135-M.jpg	OL62454010M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9572	9	Shivat ha-melekh	heb	\N	Zemorah-Bitan	1998	\N	\N	\N	OL61426619M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9573	9	The return of the king	eng	\N	Allen & Unwin	1973	\N	\N	\N	OL60044838M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9574	9	The return of the king	eng	\N	Houghton Mifflin Company	1967	\N	\N	\N	OL59016902M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9575	9	The return of king	eng	\N	Ballantine Books, New York	1965	\N	\N	\N	OL59016899M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9576	9	Return of the King	eng	\N	CreateSpace Independent Publishing Platform	2015	9781514298138	\N	\N	OL55777406M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9577	9	Return of the King	eng	\N	CreateSpace Independent Publishing Platform	2018	9781727421194	\N	\N	OL56743437M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9578	9	the return of the king	eng	\N	\N	1965	\N	\N	https://covers.openlibrary.org/b/id/14911818-M.jpg	OL58652632M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9579	9	the return of the king	eng	\N	\N	1969	\N	\N	https://covers.openlibrary.org/b/id/14921231-M.jpg	OL58692467M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9580	9	Return of the King	eng	\N	Bound to Stay Bound Books	1986	9798855136418	\N	\N	OL53336312M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9581	9	Shuvo shel melekh	heb	\N	Zemorah, Bitan, Modan	1980	\N	\N	\N	OL50255738M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9582	9	Le Seigneur des Anneaux	fra	\N	Pocket	1991	9782266108003	226610800X	https://covers.openlibrary.org/b/id/15236144-M.jpg	OL60317501M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9583	9	El Senyor Dels Anells Iii	cat	\N	Editorial Vicens Vives	2002	9788431668310	8431668318	https://covers.openlibrary.org/b/id/14031784-M.jpg	OL47431086M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9584	9	De terugkeer van de koning	nld	\N	Het Spectrum	2001	9789027475787	\N	https://covers.openlibrary.org/b/id/15154834-M.jpg	OL61005588M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9585	9	Il Signore degli Anelli. Parte 3. Il ritorno del Re	ita	\N	Bompiani	2023	9788830102729	\N	https://covers.openlibrary.org/b/id/15123275-M.jpg	OL60127670M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9586	9	Wladca Pierscieni Tom 3 Powrot krola	pol	\N	Zysk i S-ka	2018	9788381165211	8381165210	https://covers.openlibrary.org/b/id/13915457-M.jpg	OL47329668M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9587	9	Powrot krola	pol	\N	Zysk i S-ka	2017	9788381161756	8381161754	https://covers.openlibrary.org/b/id/13915455-M.jpg	OL47329666M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9588	9	Wladca Pierscieni Tom 3	pol	\N	Zysk i S-ka	2015	9788377856826	8377856824	https://covers.openlibrary.org/b/id/13915453-M.jpg	OL47329664M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9589	9	Władca pierścieni. T. 3 Powrót króla	pol	\N	Warszawskie Wydawnictwo Literackie Muza	2012	9788374958882	\N	https://covers.openlibrary.org/b/id/12685172-M.jpg	OL37777552M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9590	9	El Señor de los Anillos III. El Retorno del Rey	\N	\N	Booket	2012	9788445000687	8445000683	https://covers.openlibrary.org/b/id/10506396-M.jpg	OL30903257M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9591	9	senor de los anillos	spa	\N	HarperCollins Publishers	2009	9780061756771	\N	\N	OL37355059M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9592	9	El Señor de los Anillos	spa	\N	Planeta Publishing	2012	9786070712746	6070712749	https://covers.openlibrary.org/b/id/12524639-M.jpg	OL36631498M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9593	9	Return of the King Collector's Edition	eng	\N	HarperCollins Publishers	2024	9780063412637	\N	\N	OL51102935M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9594	9	Return of the King	eng	\N	Zondervan	2002	9780007136612	\N	\N	OL48607193M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9595	9	The Return of the King	\N	\N	Del Rey	1986	\N	\N	\N	OL47856185M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9596	9	The Return of The King	\N	\N	Ballantine Books	1968	\N	\N	\N	OL47822244M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9597	9	The Return of the King, Part Three of the Lord of the Rings Trilogy	\N	\N	Ballantine Books c.1965	1965	\N	\N	\N	OL47699364M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9598	9	O Archontas Ton Dachtylidion 3 : I Epistrophi Tou Vasilia - The Lord of the Rings Book 3	ell	\N	Kedros	2002	9789600404388	9600404380	https://covers.openlibrary.org/b/id/13811436-M.jpg	OL47316297M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9599	9	The Lord Of The Rings The Return Of The King	\N	\N	BBC Books	2002	9780563536598	0563536594	https://covers.openlibrary.org/b/id/13787154-M.jpg	OL47314378M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9600	9	De terugkeer van de koning	nld	\N	\N	\N	9789022597101	9022597105	https://covers.openlibrary.org/b/id/13775060-M.jpg	OL47310376M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9601	9	The Return of the King : The Classic Bestselling Fantasy Novel	\N	\N	HarperCollins	2021	9780008487324	0008487324	https://covers.openlibrary.org/b/id/13632812-M.jpg	OL47204093M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9163	10	Appendices Final Book Lord of the Rings	\N	\N	Houghton Mifflin Co	\N	9780618042265	0618042261	\N	OL7603341M	\N	2026-11-25 20:24:51.545748+00	2026-11-25 20:24:51.545748+00
9602	9	El Señor de los Anillos	spa	\N	Minotauro	2022	9788445013977	8445013971	https://covers.openlibrary.org/b/id/14626856-M.jpg	OL47181064M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9603	9	El Señor de los Anillos nº 03/03 El Retorno del Rey	spa	\N	MINOTAURO	2022	9788445009611	8445009613	https://covers.openlibrary.org/b/id/13479604-M.jpg	OL47104352M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9604	9	THE RETURN OF THE KING	\N	\N	FOLIO SOCIETY	1977	\N	\N	\N	OL46984651M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9605	9	De Terugkeer van de Koning	nld	\N	UITGEVERIJ	2002	9789022531952	9022531953	https://covers.openlibrary.org/b/id/13239139-M.jpg	OL46536347M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9606	9	Return of the King	\N	\N	Ballantine Books	1969	\N	\N	\N	OL45821356M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9607	9	Señor de los anillos, el; tomo 3	spa	\N	n/a	1984	9788435002790	8435002799	\N	OL45764884M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9608	9	The Return of the King Being the Third Part of the Lord of the Rings	\N	\N	Ballantine Books	1969	\N	\N	\N	OL45620266M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9609	9	The Return of the King Being the Third Part of The Lord of the Rings	\N	\N	Ballantine Books	1973	\N	\N	\N	OL43443324M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9610	9	The Return of the King	\N	\N	George, Allen and Unwin	1955	\N	\N	\N	OL43327853M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9611	9	The Return of the King	\N	\N	Recorded Books, Inc.	2021	9781705047620	1705047629	https://covers.openlibrary.org/b/id/13443688-M.jpg	OL47081350M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9612	9	The Return of the King	\N	\N	HighBridge Audio	2002	9781565116696	1565116690	https://covers.openlibrary.org/b/id/13522782-M.jpg	OL47130398M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9613	9	Return of the King	\N	\N	Ballantine U7042	1967	\N	\N	\N	OL43140093M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9614	9	Return of the King	eng	\N	HarperCollins Publishers Limited	1992	9780261102941	\N	\N	OL44096715M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9615	9	The Return of the King  The Original Ballantine Paperback	\N	\N	Ballantine Books	1973	\N	\N	\N	OL42919765M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9616	9	By J. R. R. Tolkien Return of the King	\N	\N	\N	\N	\N	\N	\N	OL40269050M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9617	9	Le Seigneur des Anneaux - tome 3 Le Retour du Roi	fra	\N	POCKET	2017	9782266282413	2266282417	\N	OL40228801M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9618	9	The return of the king	eng	\N	Ballantine Books	1973	9780345015358	0345015355	https://covers.openlibrary.org/b/id/14626055-M.jpg	OL39485753M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9619	9	The return of the king	eng	\N	Ace Books	\N	\N	\N	\N	OL45329683M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9620	9	SEÑor de LOS ANILLOS 3. el Retorno Del Rey (TV Tie-In). the LORD of the RINGS 3. the Return of the King (TV Tie-in) (Spanish Edition)	spa	\N	Editorial Planeta, S. A.	2022	9786070792410	\N	https://covers.openlibrary.org/b/id/14767576-M.jpg	OL39382833M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9621	9	THE RETURN OF THE KING. Being the Third Part of The Lord of the Rings.	\N	\N	Harper Collins	1999	9780261103870	0261103873	\N	OL39211806M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9622	9	Return of the King (the Lord of the Rings, Book 3)	eng	\N	HarperCollins Publishers Limited	2022	9780008537791	\N	\N	OL38803361M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9623	9	Return of the King : The Lord of the Rings	eng	\N	Random House Worlds	2022	9780593500507	\N	\N	OL38403117M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9624	9	The Return of the King	eng	\N	HarperCollins Publishers	2022	9780063270909	0008537747	https://covers.openlibrary.org/b/id/15244483-M.jpg	OL38060532M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9625	9	Return of the King	eng	\N	HarperCollins Publishers Limited	2022	9780008567149	\N	\N	OL38343111M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
7690	38	Nineteen Eighty-Four	eng	\N	Penguin Books	1975	\N	0140009728	https://covers.openlibrary.org/b/id/15256080-M.jpg	OL62581867M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7691	38	Nineteen Eighty-Four	eng	\N	Heron Books	1970	\N	\N	https://covers.openlibrary.org/b/id/15256049-M.jpg	OL62581804M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7692	38	Nineteen Eighty-Four	eng	\N	Penguin Books	2013	9780241334669	\N	https://covers.openlibrary.org/b/id/15256039-M.jpg	OL62581682M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7693	38	Nineteen Eighty-Four	eng	\N	Ardash Books	2011	\N	8187138378	https://covers.openlibrary.org/b/id/15256029-M.jpg	OL62581639M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7694	38	Nineteen Eighty-Four	eng	\N	Penguin Books	1969	\N	0140009728	https://covers.openlibrary.org/b/id/15256016-M.jpg	OL62581592M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7695	38	Nineteen Eighty-Four	eng	\N	Secker & Warburg	1950	\N	\N	https://covers.openlibrary.org/b/id/15255939-M.jpg	OL62580888M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7696	38	Nineteen Eighty-Four	eng	\N	The Folio Society	2001	\N	\N	https://covers.openlibrary.org/b/id/15255326-M.jpg	OL62557830M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7697	38	1984	ita	\N	Feltrinelli	2021	9788807903816	\N	https://covers.openlibrary.org/b/id/15248977-M.jpg	OL62491998M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7698	38	1984	eng	\N	Wilco	2026	9789363120341	\N	https://covers.openlibrary.org/b/id/15227361-M.jpg	OL62084415M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7699	38	1984	\N	\N	Zig-zag	2017	\N	\N	https://covers.openlibrary.org/b/id/15217277-M.jpg	OL61748275M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7700	38	Rok 1984	eng	\N	[ze słownikiem]	2021	9788366471191	8366471195	https://covers.openlibrary.org/b/id/15193085-M.jpg	OL61424751M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7701	38	Nineteen Eighty-Four	eng	\N	HarperCollins Publishers India Pvt Limited	2024	9789356996649	\N	https://covers.openlibrary.org/b/id/15180086-M.jpg	OL61398677M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7702	38	1984	\N	\N	Livraria Lello	2022	9789899135024	\N	https://covers.openlibrary.org/b/id/14840224-M.jpg	OL57643843M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7703	38	1984	eng	\N	New American Library	1961	\N	\N	https://covers.openlibrary.org/b/id/15257050-M.jpg	OL59141093M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7704	38	1984	rus	\N	[s.n.]	1960	\N	\N	\N	OL59459423M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7705	38	1984	eng	\N	Penguin Random House	2025	9781784878979	\N	\N	OL57528867M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7706	38	1984	eng	\N	Penguin Random House	2025	9781529962253	\N	\N	OL57546000M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7707	38	1984	spa	\N	Rosetta Edu	2021	9781916939288	\N	\N	OL57782403M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7708	38	1. 984	spa	\N	CreateSpace Independent Publishing Platform	2014	9781503378179	\N	\N	OL56099456M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7709	38	1984	spa	\N	CreateSpace Independent Publishing Platform	2015	9781517236755	\N	\N	OL56104401M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7710	38	1984	eng	\N	CreateSpace Independent Publishing Platform	2018	9781986513555	\N	\N	OL56154572M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7711	38	1984	eng	\N	CreateSpace Independent Publishing Platform	2016	9781523373611	\N	\N	OL56365569M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7712	38	1984	eng	\N	CreateSpace Independent Publishing Platform	2017	9781978127890	\N	\N	OL56375881M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7713	38	1984	eng	\N	CreateSpace Independent Publishing Platform	2017	9781542666497	\N	\N	OL56420693M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7714	38	1984	spa	\N	CreateSpace Independent Publishing Platform	2016	9781533002907	\N	\N	OL56608224M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7715	38	1984	spa	\N	CreateSpace Independent Publishing Platform	2018	9781727550245	\N	\N	OL56703431M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7716	38	1984	eng	\N	The New American Library	1959	\N	\N	https://covers.openlibrary.org/b/id/15256051-M.jpg	OL58520457M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7717	38	1984	\N	\N	Maple Press	2017	9789352230761	9352230760	https://covers.openlibrary.org/b/id/15242016-M.jpg	OL60370711M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7718	38	1984	eng	\N	CreateSpace Independent Publishing Platform	2018	9781983556081	\N	\N	OL55177986M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7719	38	Nineteen Eighty Four (Twentieth Century Classics)	spa	\N	Penguin Books	1999	9780140182347	0140182349	https://covers.openlibrary.org/b/id/97190-M.jpg	OL9304259M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7720	38	1984	fra	\N	Gallimard	1993	9782070368228	207036822X	https://covers.openlibrary.org/b/id/967386-M.jpg	OL8838059M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7721	38	1984	eng	\N	1st World Library	2005	9781421808321	1421808323	https://covers.openlibrary.org/b/id/765647-M.jpg	OL8491447M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7722	38	Yi jiu ba si	zho	\N	Shu hua chu ban shi ye you xian gong si	1994	9789575516987	9575516982	\N	OL19222741M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7723	38	Nineteen Eighty-Four	deu	\N	Langensch.-Hachette, M	2001	9783526431398	3526431396	\N	OL12765223M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7724	38	1984	spa	\N	La Marca Editora	1997	9788423328659	8423328651	https://covers.openlibrary.org/b/id/14584417-M.jpg	OL9118031M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7725	38	1984	eng	\N	Thorndike Press	2001	9780783893686	078389368X	https://covers.openlibrary.org/b/id/4724832-M.jpg	OL8097314M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7726	38	Nineteen Eighty-Four	eng	\N	Harcourt, Brace and Company	1949	\N	\N	https://covers.openlibrary.org/b/id/14574184-M.jpg	OL6049335M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7727	38	Yi jiu ba si	zho	\N	Gui guan	1994	\N	9575516982	\N	OL19430811M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7728	38	Nineteen eighty-four	eng	\N	M & S Press	1984	\N	\N	\N	OL14417446M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7729	38	1984	spa	\N	J.A. Mestas	2003	9788495994073	8495994070	\N	OL23084175M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7730	38	1984	\N	\N	Signet Classics	1950	9780451520500	0451520505	https://covers.openlibrary.org/b/id/5722405-M.jpg	OL7576871M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7731	38	Nineteen eighty-four	eng	\N	Secker & Warburg	1949	\N	\N	https://covers.openlibrary.org/b/id/15255697-M.jpg	OL6055885M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7732	38	1984	eng	\N	Harcourt Brace Jovanovich	1983	\N	0151660387	https://covers.openlibrary.org/b/id/7890871-M.jpg	OL3176040M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7733	38	Nineteen eighty-four	eng	\N	Secker and Warburg	1965	\N	\N	\N	OL16849545M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7734	38	1984	fra	\N	Gallimard	1950	\N	\N	\N	OL21330570M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7735	38	1984	eng	\N	New American Library	1961	\N	\N	https://covers.openlibrary.org/b/id/15255325-M.jpg	OL13545578M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7736	38	Nineteen eighty-four	eng	\N	Harcourt, Brace & World, Inc.	1949	\N	\N	https://covers.openlibrary.org/b/id/12919043-M.jpg	OL16181379M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7737	38	Nineteen eighty-four	eng	\N	Penguin	\N	\N	014006205X	\N	OL14946390M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7738	38	1984	eng	\N	Blackstone Audiobooks	2004	9780786128686	0786128682	https://covers.openlibrary.org/b/id/539618-M.jpg	OL8106477M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7739	38	Nineteen eighty-four	eng	\N	Edito-Service S.A.	1974	\N	\N	\N	OL5231703M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7740	38	1984	eng	\N	Blackstone Audiobooks	2004	9780786184040	0786184043	\N	OL11044663M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7741	38	1984	\N	\N	Signet Classic	1990	9789990833287	9990833281	\N	OL13247333M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7742	38	Nineteen Eighty-Four	\N	\N	Perfection Learning Prebound	1977	9780812416299	0812416295	\N	OL11346326M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7743	38	1984	eng	\N	Blackstone Audiobooks	1991	9780786102396	078610239X	https://covers.openlibrary.org/b/id/1467939-M.jpg	OL8105090M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7744	38	1984	\N	\N	Books on Tape, Inc.	1980	9780736605687	0736605681	https://covers.openlibrary.org/b/id/2560352-M.jpg	OL10600940M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7745	38	Nineteen eighty-Four.	eng	\N	Secker & Warburg	1959	\N	\N	\N	OL13751803M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7746	38	Nineteen Eighty Four	eng	\N	1st World Library	2004	9781595404824	1595404821	https://covers.openlibrary.org/b/id/4858277-M.jpg	OL8881878M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7747	38	Nineteen Eighty-Four	eng	\N	Longman	1983	9780582331655	058233165X	https://covers.openlibrary.org/b/id/10616570-M.jpg	OL17384695M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7748	38	1984	swe	\N	N A L	1983	9789174862997	9174862995	https://covers.openlibrary.org/b/id/14585290-M.jpg	OL9122726M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7749	38	Nineteen eighty-four	eng	\N	Longman	1991	\N	0582060184	\N	OL21545610M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7750	38	Nineteen Eighty Four	eng	\N	Secker & Warburg	1999	9780436231315	043623131X	\N	OL7509327M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7751	38	Nineteen Eighty-Four	eng	\N	Plume	2003	\N	0452284236	https://covers.openlibrary.org/b/id/15254955-M.jpg	OL3705019M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7752	38	1984	\N	\N	Signet Book	1949	9783548225623	3548225624	https://covers.openlibrary.org/b/id/1019611-M.jpg	OL9064010M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7753	38	1984	\N	\N	bnpublishing.com	2005	9789568530273	9568530274	\N	OL13057956M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7754	38	1984	\N	\N	Signet Classics	1950	9780451509420	0451509420	\N	OL10274097M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7755	38	1984	ita	\N	Mondadori	1973	\N	\N	\N	OL13708884M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7756	38	1984	eng	\N	Blackstone Audiobooks	2003	9780786189939	0786189932	\N	OL8109072M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7757	38	1984	eng	\N	Signet Classics	1985	9780451518651	0451518659	https://covers.openlibrary.org/b/id/14351143-M.jpg	OL7576756M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7758	38	Nineteen eighty-four	eng	\N	De Arbeiderspers (by arrangement with Martin Secker & Warburg, London, and M & S Press, Mass.)	1984	\N	9029532807	\N	OL21376047M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7759	38	Nineteen Eighty-Four	eng	\N	Penguin Books	2003	9780141187358	0141187352	https://covers.openlibrary.org/b/id/15254967-M.jpg	OL7359222M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7760	38	Nineteen eighty-four	eng	\N	Harcourt, Brace, Jovanovich	1984	\N	0151660344	https://covers.openlibrary.org/b/id/112531-M.jpg	OL2841946M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7761	38	Nineteen eighty-four	eng	\N	[Secker & Warburg]	1974	\N	\N	https://covers.openlibrary.org/b/id/6737108-M.jpg	OL21028113M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7762	38	Nineteen Eighty-Four	eng	\N	Penguin Books in association with Martin Secker & Warburg	2000	\N	0141182474	https://covers.openlibrary.org/b/id/15255314-M.jpg	OL13570329M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7763	38	Nineteen eighty-four	eng	\N	Harcourt, Brace & World, Inc.	1949	\N	0151660352	https://covers.openlibrary.org/b/id/15256128-M.jpg	OL16938689M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7764	38	Neunzehnhundertvierundachtzig	deu	\N	Diana Verlag	1956	\N	\N	\N	OL21834096M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7765	38	1984	eng	\N	Penguin Audio	1996	9780140862539	0140862536	https://covers.openlibrary.org/b/id/106258-M.jpg	OL7357748M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7766	38	1984	nor	\N	Den Norske Bokklubben	1983	\N	8252511686	\N	OL22821383M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7767	38	Nineteen eighty-four	eng	\N	Secker & Warburg	1974	\N	0436350076	\N	OL21490109M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7768	38	1984	eng	\N	New American Library	1983	\N	0452254264	\N	OL3248629M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7769	38	Nineteen Eighty Four	\N	\N	Methuen Publishing Ltd	1993	9780749317232	074931723X	\N	OL7966300M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7770	38	1984	spa	\N	Lectorum	2002	\N	\N	\N	OL23017303M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7771	38	1984	eng	\N	Blackstone Audio Inc.	2007	9781433202438	1433202433	https://covers.openlibrary.org/b/id/1860521-M.jpg	OL8547223M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7772	38	Nineteen Eighty-Four	eng	\N	Secker & Warburg	1999	9780436410550	0436410559	https://covers.openlibrary.org/b/id/275399-M.jpg	OL7509446M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7773	38	Nineteen eighty-four	eng	\N	Penguin Books	1954	\N	\N	\N	OL20068988M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7774	38	1984	swe	\N	Aldus/Bonniers	1963	\N	\N	https://covers.openlibrary.org/b/id/7375382-M.jpg	OL25796539M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7775	38	Nineteen eighty-four	eng	\N	Plume	2003	\N	0452284236	https://covers.openlibrary.org/b/id/7898938-M.jpg	OL26224448M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7776	38	1984	por	BR	Companhia das Letras	2009	9788535914849	\N	https://covers.openlibrary.org/b/id/8172473-M.jpg	OL26449397M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7777	38	1984	cat	\N	labutxaca	2011	9788499302157	\N	https://covers.openlibrary.org/b/id/8224181-M.jpg	OL26482623M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7778	38	1984 (Spanish)	spa	\N	Tandem Library	2001	9780613447829	0613447824	\N	OL7599999M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7779	38	1984 (Spanish)	spa	\N	Rebound by Sagebrush	1998	9781417656103	1417656107	https://covers.openlibrary.org/b/id/13173239-M.jpg	OL11761012M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7780	38	1984 (20093)	\N	\N	Bookthrift Co	1988	9789998992108	9998992109	\N	OL9208819M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7781	38	1984 (In Russian)	\N	\N	Ardis	1984	9780882339726	0882339729	https://covers.openlibrary.org/b/id/11205534-M.jpg	OL11226337M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7782	38	1984 ( Neunzehnhundertvierundachtzig). Jubiläumsausgabe. Roman.	\N	\N	Ullstein Tb	2003	9783548256276	3548256279	https://covers.openlibrary.org/b/id/3233432-M.jpg	OL12812511M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7783	38	Rok 1984	pol	\N	Muza Warszawskie Wydawnictwo Literackie	2018	9788374959056	\N	https://covers.openlibrary.org/b/id/8401033-M.jpg	OL26749168M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7784	38	1984 (Spanish Edition)	\N	\N	Debolsillo	2014	9788490328248	8490328242	https://covers.openlibrary.org/b/id/8497943-M.jpg	OL26826615M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7785	38	1984 (Contemporanea (Debolsillo)) (Spanish Edition)	spa	\N	Debolsillo	2015	9788499890944	8499890946	https://covers.openlibrary.org/b/id/8495146-M.jpg	OL26825242M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7786	38	1984 (Spanish Edition)	\N	\N	CreateSpace Independent Publishing Platform	2014	9781499299861	1499299869	https://covers.openlibrary.org/b/id/8566784-M.jpg	OL26870852M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7787	38	1984	eng	\N	New American Library of World Literature	1950	\N	\N	https://covers.openlibrary.org/b/id/7261715-M.jpg	OL25430720M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7788	38	1984	spa	\N	Destino	2007	9788423337323	\N	https://covers.openlibrary.org/b/id/7014491-M.jpg	OL25175311M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7789	38	1984	eng	\N	New American Library	1961	\N	\N	https://covers.openlibrary.org/b/id/15257285-M.jpg	OL24976268M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7790	38	1984	\N	\N	Signet Classics	1949	\N	\N	\N	OL24969091M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7791	38	1984	nld	\N	De Arbeiderspers	1984	\N	9029532815	https://covers.openlibrary.org/b/id/6732268-M.jpg	OL24636613M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7792	38	1984	\N	\N	Penguin	1950	\N	\N	\N	OL25262386M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7793	38	1984	spa	\N	Lumen	2014	9788426400260	\N	https://covers.openlibrary.org/b/id/15255374-M.jpg	OL25892628M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7794	38	1984	eng	\N	Random House Value Publishing	\N	9780517665947	0517665948	\N	OL7705869M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7795	38	1984	eng	\N	Listening Library	2006	9780736687683	0736687688	https://covers.openlibrary.org/b/id/6255543-M.jpg	OL10602319M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7796	38	1984	ell	\N	Kaktos	1999	9789603824688	9603824682	https://covers.openlibrary.org/b/id/9267240-M.jpg	OL25543140M	\N	2026-11-25 20:23:55.533503+00	2026-11-25 20:23:55.533503+00
7797	39	Pride and Prejudice (Heron Faux-Leather Literary Heritage Collection) by Jane Austen (November 1, 1978) Hardcover	\N	\N	\N	\N	\N	\N	\N	OL49198652M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7798	39	Pride and Prejudice, 1946 Fine Editions Press, Cleveland	eng	\N	FINE EDITIONS PRESS	1946	\N	\N	https://covers.openlibrary.org/b/id/15043406-M.jpg	OL49836838M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7799	39	Pride and Prejudice	eng	\N	Dell Publishing Co. Inc.	1960	\N	\N	https://covers.openlibrary.org/b/id/14619629-M.jpg	OL51673567M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7800	39	Pride and Prejudice complete and unabriged	\N	\N	Dell - Laurel	1959	\N	\N	\N	OL51004537M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7801	39	Pride and Prejudice	eng	\N	New American Library	1980	\N	\N	https://covers.openlibrary.org/b/id/14617366-M.jpg	OL51651979M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7802	39	Pride and Prejudice	\N	\N	Heron	1968	\N	\N	\N	OL50971605M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7803	39	Pride and Prejudice	\N	\N	Fine Editions Press	1946	\N	\N	\N	OL50990674M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7804	39	Pride and Prejudice	eng	\N	New American Library	1961	\N	\N	https://covers.openlibrary.org/b/id/14858485-M.jpg	OL50998784M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7805	39	Pride and Prejudice	eng	\N	Cambridge University Press	2024	9781009432580	\N	\N	OL51047237M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7806	39	Pride and Prejudice	eng	\N	Oxford University Press, Incorporated	2024	9781382052344	\N	\N	OL51095752M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7807	39	Pride and Prejudice	eng	\N	Page Publications	2024	9781648337093	\N	https://covers.openlibrary.org/b/id/14665299-M.jpg	OL51113754M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7808	39	Pride and Prejudice	eng	\N	Adams Media Corporation	2014	9781283474832	\N	\N	OL51318418M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7809	39	Stolz und Vorurteil	deu	\N	Anaconda	2018	9783730606490	3730606492	https://covers.openlibrary.org/b/id/14568556-M.jpg	OL50552339M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7810	39	Pride and prejudice	eng	\N	Harcourt, Brace & World	1962	\N	\N	\N	OL50489267M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7811	39	Pride and Prejudice	eng	\N	T. Nelson & Sons	\N	\N	\N	https://covers.openlibrary.org/b/id/15095637-M.jpg	OL50444320M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7812	39	Pride and Prejudice	eng	\N	Guild Publishing	1979	\N	\N	https://covers.openlibrary.org/b/id/14554089-M.jpg	OL50444263M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7813	39	Pride and Prejudice	eng	\N	Nelson Doubleday	1813	\N	\N	https://covers.openlibrary.org/b/id/14553953-M.jpg	OL50424069M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7814	39	Pride and prejudice	eng	\N	Dutton	1933	\N	\N	\N	OL50339981M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7815	39	오만과 편견	kor	\N	Brown Hill Publishing Co	2014	9788990324788	\N	https://covers.openlibrary.org/b/id/14552693-M.jpg	OL50293431M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7816	39	Orgoglio e pregiudizio	ita	\N	Newton Compton editori	2014	9788854165052	\N	https://covers.openlibrary.org/b/id/14552692-M.jpg	OL50293430M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7817	39	Orgoglio e Pregiudizio Di Jane Austen	ita	\N	Independently Published	2020	9798667127451	\N	\N	OL42197035M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7818	39	Pride and Prejudice	eng	\N	Dolphin Books	2017	9787511024831	7511024831	https://covers.openlibrary.org/b/id/14543311-M.jpg	OL43294729M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7819	39	Pride and Prejudice	eng	\N	Macmillan Popular Classics	2018	9781509896370	\N	https://covers.openlibrary.org/b/id/14543309-M.jpg	OL49837260M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7218	29	Juego de tronos	spa	\N	Planeta DeAgostini	2012	\N	\N	https://covers.openlibrary.org/b/id/7266799-M.jpg	OL25434406M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7820	39	Pride and Prejudice	eng	\N	Lulu Press, Inc.	2014	9781312324619	\N	\N	OL49693317M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7821	39	Pride & Prejudice	\N	\N	Stage Partners	2023	\N	\N	\N	OL43374576M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7822	39	Level 5: Pride and Prejudice (2nd Edition) (Penguin Readers, Level 5)	\N	\N	Pearson Elt	2008	9781405862462	1405862467	https://covers.openlibrary.org/b/id/8748572-M.jpg	OL27253989M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7823	39	Pride & Prejudice	eng	\N	Invincible Publishers	2018	9789388333061	9388333063	https://covers.openlibrary.org/b/id/14534701-M.jpg	OL43119408M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7824	39	Pride and Prejudice Illustrated	eng	\N	Lulu Press, Inc.	2019	9780359374564	\N	\N	OL49707924M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7825	39	Pride and Prejudice	eng	\N	Books on Demand GmbH	2016	9782322156337	\N	\N	OL49533016M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7826	39	Pride and Prejudice	eng	\N	Books on Demand GmbH	2020	9783750436978	\N	\N	OL49576872M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7827	39	Pride and Prejudice	eng	\N	Lulu Press, Inc.	2020	9781716833595	\N	\N	OL49694726M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7828	39	Pride and Prejudice	eng	\N	Lulu Press, Inc.	2011	9781257968190	\N	\N	OL49709180M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7829	39	Pride and Prejudice	eng	\N	Lulu Press, Inc.	2017	9781365964893	\N	\N	OL49717411M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7830	39	Pride and Prejudice	eng	\N	Lulu Press, Inc.	2017	9781365964886	\N	\N	OL49741403M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7831	39	Pride and Prejudice	eng	\N	Lulu Press, Inc.	2017	9780244617783	\N	\N	OL49747895M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7832	39	Pride and Prejudice	eng	\N	Lulu Press, Inc.	2020	9781716833724	\N	\N	OL49750451M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7833	39	Pride and Prejudice	eng	\N	Historium Press	2022	9780578280943	\N	\N	OL49764478M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7834	39	Pride and Prejudice	eng	\N	HarperCollins Children's Books	2009	9780007874699	\N	https://covers.openlibrary.org/b/id/14534676-M.jpg	OL45815348M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7835	39	Jane Austen's Pride and Prejudice. a Romantic Novel	eng	\N	Independently Published	2020	9798618899659	\N	\N	OL42064624M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7836	39	Pride and Prejudice (Illustrated) - Francson Classics	eng	\N	Independently Published	2017	9781522002154	\N	\N	OL40694369M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7837	39	Pride and Prejudice : (English Rose Edition)	eng	\N	Ballard Classics	2022	9798844238420	\N	\N	OL39792078M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7838	39	Pride and Prejudice	eng	\N	Planet Three Publishing Network	2003	\N	\N	https://covers.openlibrary.org/b/id/14534674-M.jpg	OL49821105M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7839	39	Pride and Prejudice	eng	\N	Washington Square Press	1960	\N	\N	https://covers.openlibrary.org/b/id/14429767-M.jpg	OL49646782M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7840	39	Pride and Prejudice - the World's Masterpieces of All Time	eng	\N	Independently Published	2021	9798543183663	\N	\N	OL48948184M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7841	39	Pride and Prejudice	eng	\N	Books, Inc.	\N	\N	\N	https://covers.openlibrary.org/b/id/14423695-M.jpg	OL46889511M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7842	39	Pride & Prejudice	eng	\N	Folio Society	1989	\N	\N	https://covers.openlibrary.org/b/id/14423694-M.jpg	OL49574287M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7843	39	Pride & Prejudice : Written by Jane Austen, 1975 Edition,  Publisher	\N	\N	\N	\N	\N	\N	\N	OL45615714M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7844	39	Pride and Prejudice	eng	\N	Holt, Rinehart and Winston	1963	\N	\N	https://covers.openlibrary.org/b/id/14590600-M.jpg	OL49563312M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7845	39	Pride and Prejudice	eng	\N	Pan Books Ltd	1968	9780330106894	0330106899	https://covers.openlibrary.org/b/id/14417865-M.jpg	OL49359464M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7846	39	Pride and Prejudice	eng	\N	[publisher not identified]	1993	9781478107163	\N	https://covers.openlibrary.org/b/id/14417861-M.jpg	OL49359454M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7847	39	Aşk ve Gurur	\N	\N	Can Yayınları	2017	9789750734724	9750734726	https://covers.openlibrary.org/b/id/12363920-M.jpg	OL35656853M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7848	39	Ask ve Gurur	\N	\N	Bilge Kültür Sanat	2005	9789756316627	9756316624	https://covers.openlibrary.org/b/id/12360499-M.jpg	OL35654160M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7849	39	Ask ve Gurur	\N	\N	Can Yayinlari	2014	9789750708619	975070861X	https://covers.openlibrary.org/b/id/12295509-M.jpg	OL35566499M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7850	39	Ask ve Gurur	\N	\N	Oda Yayinlari	2006	9789753853521	9753853521	https://covers.openlibrary.org/b/id/12310309-M.jpg	OL35604263M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7851	39	Aşk ve Gurur	\N	\N	Can Yayınları	2019	9789750739903	9750739906	https://covers.openlibrary.org/b/id/12273548-M.jpg	OL35432088M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7852	39	Ask ve Gurur	\N	\N	Tutku Yayinevi	2018	9786059734349	6059734340	https://covers.openlibrary.org/b/id/12250970-M.jpg	OL35408845M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7853	39	Ask ve Gurur	\N	\N	Alter Yayinlari	2015	9786059870306	6059870309	https://covers.openlibrary.org/b/id/12252114-M.jpg	OL35410036M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7854	39	Ask ve Gurur	\N	\N	Dokuz Yayinlari	2021	9786257642118	6257642116	https://covers.openlibrary.org/b/id/12257577-M.jpg	OL35415645M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7855	39	Ask ve Gurur	\N	\N	Antik Kitap	2013	9789944184922	9944184926	https://covers.openlibrary.org/b/id/12288207-M.jpg	OL35445724M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7856	39	Aşk ve Gurur	\N	\N	Artemis Yaynlar	2016	9786051428741	6051428747	https://covers.openlibrary.org/b/id/12117459-M.jpg	OL35306519M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7857	39	Aşk ve Gurur	\N	\N	Dorlion Yayinevi	2018	9786052491515	6052491515	https://covers.openlibrary.org/b/id/12119485-M.jpg	OL35308566M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7858	39	Ask Ve Gurur	\N	\N	Artemis Yayinlari	2016	9786051428765	6051428763	https://covers.openlibrary.org/b/id/12114381-M.jpg	OL35303367M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7859	39	Ask ve Gurur	\N	\N	Ayrinti Yayinlari	2017	9786053142171	6053142174	https://covers.openlibrary.org/b/id/12121912-M.jpg	OL35311026M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7860	39	Ask ve Gurur	\N	\N	Altin Post Yayincilik	2012	9786055248345	6055248344	https://covers.openlibrary.org/b/id/12131689-M.jpg	OL35320476M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7861	39	Ask ve Gurur	\N	\N	Ren Kitap	2018	9786052398692	6052398698	https://covers.openlibrary.org/b/id/12216106-M.jpg	OL35372910M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7862	39	Ask ve Gurur	\N	\N	Gece Kitapligi	2014	9786053243229	6053243221	https://covers.openlibrary.org/b/id/12225611-M.jpg	OL35382883M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7863	39	Ask ve Gurur	\N	\N	Marti Yayinlari	2012	9786055420819	6055420813	https://covers.openlibrary.org/b/id/12236069-M.jpg	OL35393499M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7864	39	Ask ve Gurur	\N	\N	Koridor Yayincilik	2019	9786057572141	6057572149	https://covers.openlibrary.org/b/id/12241227-M.jpg	OL35398918M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7865	39	Ask ve Gurur	\N	\N	Armada	2016	9786059660020	6059660029	https://covers.openlibrary.org/b/id/12250350-M.jpg	OL35408227M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7866	39	Ask ve Gurur - Klasik Kadinlar	\N	\N	Can Yayinlari	2021	9789750738173	9750738179	https://covers.openlibrary.org/b/id/10851733-M.jpg	OL32202559M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7867	39	Aşk ve Gurur	\N	\N	Fark Yayinlari	2019	9786052240748	6052240741	https://covers.openlibrary.org/b/id/10849692-M.jpg	OL32200520M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7868	39	Ask ve Gurur	\N	\N	Koridor Yayincilik	2016	9786059702232	6059702236	https://covers.openlibrary.org/b/id/10848960-M.jpg	OL32199743M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7869	39	Ask ve Gurur	\N	\N	Tima Yaynlar	2014	9786050816624	605081662X	https://covers.openlibrary.org/b/id/10850027-M.jpg	OL32200855M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7870	39	Orgueil et Prévention	fra	\N	Independently Published	2020	9798637085361	\N	\N	OL41955224M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7871	39	Orgueil et Prévention	fra	\N	Independently Published	2017	9781549784767	\N	\N	OL40860217M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7872	39	Orgueil et préjugé	\N	\N	MOTIFS	2004	9782907573047	2907573047	https://covers.openlibrary.org/b/id/12367115-M.jpg	OL35661393M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7873	39	Orgueil et préjugés	fra	\N	Archipoche	2013	9782352875109	2352875102	https://covers.openlibrary.org/b/id/14534647-M.jpg	OL30518691M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7874	39	Orgueil et Préjugés	fra	\N	Independently Published	2020	9798644666454	\N	\N	OL48372286M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7875	39	Orgueil et Préjugés	fra	\N	Independently Published	2020	9798694050326	\N	\N	OL48393435M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7876	39	Orgueil et préjugés	\N	\N	FLAMMARION	2010	9782081229518	208122951X	\N	OL37738866M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7877	39	Orgulho e Preconceito	por	\N	Independently Published	2020	9798671220674	\N	\N	OL42155129M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7878	39	Orgulho e Preconceito de Jane Austen	por	\N	Independently Published	2020	9798667132899	\N	\N	OL42145515M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7879	39	Orgulho e Preconceito	\N	\N	Relógio D''Água	2012	9789896413231	9896413231	https://covers.openlibrary.org/b/id/10452728-M.jpg	OL30376847M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7880	39	Pride and Predjudice (54)	\N	\N	YBM Si-sa	2006	9788917161373	8917161375	\N	OL46963701M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7881	39	Pride and Predjudice	\N	\N	CreateSpace Independent Publishing Platform	2016	9781537091297	1537091298	https://covers.openlibrary.org/b/id/14121925-M.jpg	OL37745834M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7882	39	Stolz und Vorurteil	\N	\N	Coppenrath F	2018	9783649629726	3649629720	https://covers.openlibrary.org/b/id/13158217-M.jpg	OL46527093M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7883	39	Jane Austens Stolz und Vorurteile	deu	\N	Independently Published	2020	9798667141747	\N	\N	OL42093587M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7884	39	Stolz und Vorurteil	\N	\N	Createspace Independent Publishing Platform	2013	9781484803530	1484803531	https://covers.openlibrary.org/b/id/12503110-M.jpg	OL36171224M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7885	39	Stolz und Vorurteil	\N	\N	Createspace Independent Publishing Platform	2016	9781535233248	1535233249	https://covers.openlibrary.org/b/id/11245359-M.jpg	OL32608524M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7886	39	Stolz und Vorurteil	\N	\N	FISCHER Taschenbuch	2012	9783596512065	3596512069	https://covers.openlibrary.org/b/id/9354933-M.jpg	OL27966554M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7887	39	Stolz und Vorurteil	\N	\N	FISCHER Taschenbuch	2008	9783596900046	3596900042	https://covers.openlibrary.org/b/id/10107685-M.jpg	OL28169471M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7888	39	Stolz und Vorurteil	\N	\N	FISCHER Taschenbuch	2019	9783596907205	3596907209	https://covers.openlibrary.org/b/id/10117616-M.jpg	OL28180723M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7889	39	Stolz und Vorurteil	\N	\N	FISCHER Taschenbuch	2015	9783596906031	3596906032	https://covers.openlibrary.org/b/id/10154845-M.jpg	OL28222073M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7890	39	Stolz und Vorurteil	\N	\N	FISCHER Taschenbuch	2014	9783596950140	3596950147	https://covers.openlibrary.org/b/id/10175262-M.jpg	OL28244595M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7891	39	Cinq Filles de Mrs Bennet	fra	\N	Independently Published	2019	9781695203310	\N	\N	OL48773459M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7892	39	Cinq Filles de Mrs Bennet	fra	\N	Independently Published	2020	9798646848711	\N	\N	OL42110260M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7893	39	Cinq Filles de Mrs Bennet	fra	\N	Independently Published	2018	9781731281777	\N	\N	OL41240438M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7894	39	CINQ FILLES de Mrs BENNET	fra	\N	Independently Published	2017	9781520941370	\N	\N	OL40740648M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7895	39	Cinq Filles de Mrs Bennet (Orgueil et Préjugés) (Annoté)	fra	\N	Independently Published	2021	9798472496179	\N	\N	OL38142782M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7896	39	Orgueil et préjugés	\N	\N	CreateSpace Independent Publishing Platform	2018	9781986122382	1986122387	https://covers.openlibrary.org/b/id/10866118-M.jpg	OL32227392M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7897	39	Orgull i prejudici	\N	\N	Editorial Bambú	2010	9788483431085	8483431084	https://covers.openlibrary.org/b/id/13568488-M.jpg	OL47160072M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7898	39	Orgull i prejudici	\N	\N	Edicions Bromera, S.L.	2018	9788490268742	8490268746	https://covers.openlibrary.org/b/id/10090390-M.jpg	OL28149465M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7899	39	Orgullo y Prejuicio	spa	\N	Independently Published	2020	9798666135570	\N	\N	OL48763270M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7900	39	Orgullo y Prejuicio	spa	\N	Independently Published	2021	9798537965626	\N	\N	OL48790225M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7901	39	Orgullo y Prejuicio	spa	\N	Independently Published	2020	9798643003359	\N	\N	OL48545788M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7902	39	Orgullo y Prejuicio : Jane Austen, Versión Español	spa	\N	Independently Published	2021	9798732386899	\N	\N	OL48463630M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7903	39	Orgullo y Prejuicio	spa	\N	Independently Published	2021	9798702853567	\N	\N	OL48453792M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7904	39	Orgullo y Prejuicio	spa	\N	Independently Published	2020	9798684291340	\N	\N	OL48348560M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7905	39	Orgullo y prejuicio	\N	\N	Olmak Trade, S.L.	2022	9788416827923	8416827923	\N	OL47642098M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7906	39	ORGULLO Y PREJUICIO	\N	\N	EDIMAT LIBROS	2019	9788497944625	8497944623	https://covers.openlibrary.org/b/id/14083397-M.jpg	OL47476174M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7907	39	ORGULLO Y PREJUICIO	\N	\N	BIBLOCK	2014	9788494411632	8494411632	https://covers.openlibrary.org/b/id/14299988-M.jpg	OL47673119M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7908	39	Orgullo y prejuicio - Edición especial	\N	\N	Alianza Editorial	2020	9788491819981	8491819983	https://covers.openlibrary.org/b/id/14052267-M.jpg	OL47449122M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7909	39	Orgullo y prejuicio	\N	\N	Espasa	2012	9788467009606	8467009608	https://covers.openlibrary.org/b/id/14047828-M.jpg	OL47445258M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7910	39	Orgullo y prejuicio	\N	\N	Molino	2023	9788427236875	8427236875	https://covers.openlibrary.org/b/id/14058063-M.jpg	OL47454059M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7911	39	Orgullo y prejuicio	\N	\N	Edimat Libros	2014	9788497942249	8497942248	https://covers.openlibrary.org/b/id/14083551-M.jpg	OL47476311M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7912	39	Orgullo y Prejuicio ❤️🤑	spa	\N	Independently Published	2021	9798508215835	\N	\N	OL46733440M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7913	39	Orgullo y Prejuicio (con Notas)	spa	\N	Independently Published	2020	9798642615928	\N	\N	OL41878746M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7914	39	Jane Austen - Orgullo y Prejuicio	spa	\N	Independently Published	2019	9781693565373	\N	\N	OL41485865M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7915	39	Orgullo y prejuicio	\N	\N	Editorial Alma	2021	9788417430719	8417430717	https://covers.openlibrary.org/b/id/12335278-M.jpg	OL35628277M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7916	39	Orgullo y prejuicio	\N	\N	MESTAS Ediciones, S.L.	2015	9788416365180	8416365180	https://covers.openlibrary.org/b/id/12336357-M.jpg	OL35629358M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7917	39	Orgullo y prejuicio	\N	\N	Ediciones Lea	2016	9789877183146	9877183145	https://covers.openlibrary.org/b/id/12340805-M.jpg	OL35633853M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7918	39	Orgullo y prejuicio	\N	\N	Plutón Ediciones	2013	9788415089438	8415089430	https://covers.openlibrary.org/b/id/12343215-M.jpg	OL35636285M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7919	39	Orgullo y prejuicio	\N	\N	Edimat Libros	2013	9788497941846	8497941845	https://covers.openlibrary.org/b/id/12343222-M.jpg	OL35636292M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7920	39	Orgullo y Prejuicio	spa	\N	El Cid Editor Incorporated	2014	9781449264253	\N	\N	OL34872353M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7921	39	ORGULLO Y PREJUICIO	spa	\N	Ediciones B	2016	9788490702383	\N	https://covers.openlibrary.org/b/id/13225056-M.jpg	OL34892003M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7922	39	Orgullo y Prejuicio	spa	\N	Independently Published	2021	9798509439056	\N	\N	OL34282906M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7923	39	Orgullo y Prejuicio	spa	\N	Independently Published	2020	9798667666837	\N	\N	OL34237335M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7924	39	Orgullo y Prejuicio	\N	\N	Createspace Independent Publishing Platform	2015	9781517503390	1517503396	https://covers.openlibrary.org/b/id/12028905-M.jpg	OL34245094M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7925	39	Orgullo y Prejuicio	\N	\N	Independently published	2019	9781093718157	1093718153	https://covers.openlibrary.org/b/id/11328765-M.jpg	OL32704350M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7926	39	Orgullo y Prejuicio	spa	\N	Independently Published	2019	9781091453784	\N	\N	OL41014415M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7927	39	Orgullo y prejuicio	\N	\N	Editorial Alma	2021	9788418008399	8418008393	https://covers.openlibrary.org/b/id/11045790-M.jpg	OL32381491M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7928	39	Orgullo y prejuicio	\N	\N	Austral	2015	9788467045642	8467045647	https://covers.openlibrary.org/b/id/10540217-M.jpg	OL31848779M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7929	39	Orgullo y prejuicio	\N	\N	Alfaguara	2017	9788420485331	8420485330	https://covers.openlibrary.org/b/id/10650701-M.jpg	OL31972942M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7930	39	Orgullo y prejuicio	\N	\N	Norma Editorial	2016	9788467923629	8467923628	https://covers.openlibrary.org/b/id/10837186-M.jpg	OL32181533M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7931	39	Orgullo y Prejuicio	spa	\N	Independently Published	2020	9798667015291	\N	\N	OL30330413M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7932	39	Orgullo y Prejuicio	spa	\N	Independently Published	2020	9798656339377	\N	\N	OL30262544M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7933	39	Orgullo y Prejuicio	spa	\N	Independently Published	2020	9798633264166	\N	\N	OL29982427M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7934	39	Orgullo y Prejuicio	spa	\N	Independently Published	2020	9798666134795	\N	\N	OL30276554M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7935	39	Orgullo y Prejuicio	spa	\N	Independently Published	2020	9798667005230	\N	\N	OL30333609M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7936	39	ORGULLO Y PREJUICIO	spa	\N	Penguin Random House Grupo Editorial	2011	9788499089195	\N	\N	OL29604429M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7937	39	Pride and Prejudice	eng	\N	Independently Published	2021	9798707883590	\N	\N	OL48475859M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7938	39	Prejudice and Pride	eng	\N	Independently Published	2021	9798745654305	\N	\N	OL48384674M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7939	39	Pride and Prejudice	eng	\N	Independently Published	2021	9798730359147	\N	\N	OL48354290M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7940	39	Pride@Prejudice	eng	\N	Playscripts, Incorporated	2013	9781623842864	\N	\N	OL34019147M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7941	39	Pride and Prejudice	eng	\N	Independently Published	2021	9798479492716	\N	\N	OL49170574M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7942	39	Pride and prejudice	\N	\N	Collier Books	1962	\N	\N	\N	OL49218999M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7943	39	Pride and Prejudice	tam	\N	Prakash Book Depot	2023	9789354406997	\N	\N	OL49323974M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7944	39	Pride and Prejudice	hin	\N	Prakash Book Depot	2023	9789354406980	\N	\N	OL49331875M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7945	39	Pride and Prejudice Paperback	eng	\N	Independently Published	2021	9798486728853	\N	\N	OL49146440M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7946	39	Pride and Prejudice	eng	\N	Independently Published	2021	9798452484295	\N	\N	OL49001546M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7947	39	Pride and Prejudice	eng	\N	Independently Published	2021	9798469192503	\N	\N	OL49012901M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7948	39	Pride and Prejudice	eng	\N	Independently Published	2021	9798476346654	\N	\N	OL49021656M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7949	39	Pride and Prejudice	eng	\N	Independently Published	2021	9798479464836	\N	\N	OL49041703M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7950	39	Pride and Prejudice	eng	\N	Independently Published	2021	9798477140879	\N	\N	OL49064198M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7951	39	Pride and Prejudice	eng	\N	Independently Published	2021	9798455294822	\N	\N	OL49075731M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7952	39	Pride and Prejudice	eng	\N	Independently Published	2021	9798548654908	\N	\N	OL49087070M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7953	39	Pride and Prejudice	eng	\N	Independently Published	2021	9798493646973	\N	\N	OL49087447M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7954	39	Pride and Prejudice	eng	\N	Independently Published	2020	9798562498816	\N	\N	OL49106064M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7955	39	Pride and Prejudice	eng	\N	Independently Published	2021	9798707652455	\N	\N	OL49117996M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7956	39	Pride and Prejudice	eng	\N	Independently Published	2021	9798749036930	\N	\N	OL49118297M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7957	39	Pride and Prejudice	eng	\N	Independently Published	2020	9798635942222	\N	\N	OL49118329M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7958	39	Pride and Prejudice	eng	\N	Independently Published	2021	9798526025317	\N	\N	OL49118454M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7959	39	Pride and Prejudice	eng	\N	Independently Published	2021	9798537832232	\N	\N	OL49149146M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7960	39	Pride and Prejudice	eng	\N	Independently Published	2021	9798452205043	\N	\N	OL48912255M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7961	39	Pride and Prejudice	eng	\N	Independently Published	2021	9798465662277	\N	\N	OL48921816M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7962	39	Pride and Prejudice	eng	\N	Independently Published	2021	9798718735925	\N	\N	OL48922686M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7963	39	Pride and Prejudice	eng	\N	Independently Published	2021	9798452742043	\N	\N	OL48949747M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7964	39	Pride and Prejudice	eng	\N	Independently Published	2021	9798466270921	\N	\N	OL48950388M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7965	39	Pride and Prejudice	eng	\N	Independently Published	2021	9798469028406	\N	\N	OL48964674M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7966	39	Pride and Prejudice	eng	\N	Independently Published	2021	9798478787141	\N	\N	OL48989531M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7967	39	Pride and Prejudice	eng	\N	Independently Published	2021	9798475421697	\N	\N	OL48992581M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7968	39	Pride and Prejudice	eng	\N	Independently Published	2021	9798478640668	\N	\N	OL48992953M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7969	39	Pride and Prejudice	eng	\N	Independently Published	2021	9798519953894	\N	\N	OL48800210M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7970	39	Pride and Prejudice	eng	\N	Independently Published	2021	9798501166264	\N	\N	OL48809602M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7971	39	Pride and Prejudice	eng	\N	Independently Published	2021	9798528178110	\N	\N	OL48875871M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7972	39	Pride and Prejudice	\N	\N	Independently Published	2020	\N	\N	\N	OL48595077M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7973	39	Pride and Prejudice	eng	\N	Independently Published	2021	9798450669656	\N	\N	OL48772601M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7974	39	Pride and Prejudice	eng	\N	Sterling Publishing Co., Inc.	2023	9781435173064	\N	\N	OL48774716M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7975	39	Pride and Prejudice	eng	\N	Independently Published	2021	9798519659956	\N	\N	OL48792027M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7976	39	Pride and Prejudice by Jane Austen	eng	\N	Independently Published	2021	9798709666009	\N	\N	OL48369217M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7977	39	Pride and Prejudice by Jane Austen	eng	\N	Independently Published	2021	9798749073850	\N	\N	OL48388147M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7978	39	Pride and Prejudice by Jane Austen	eng	\N	Independently Published	2021	9798749076059	\N	\N	OL48398816M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7979	39	Pride and Prejudice by Jane Austen	eng	\N	Independently Published	2021	9798540387804	\N	\N	OL48792090M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7980	39	Pride and Prejudice by Jane Austen	eng	\N	Independently Published	2021	9798542130934	\N	\N	OL48792839M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7981	39	Pride and Prejudice by Jane Austen	eng	\N	Independently Published	2021	9798540388252	\N	\N	OL48823738M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7982	39	Pride and Prejudice by Jane Austen	eng	\N	Independently Published	2021	9798543650837	\N	\N	OL48833930M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7983	39	Pride and Prejudice by Jane Austen	eng	\N	Independently Published	2021	9798511506159	\N	\N	OL48839709M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7984	39	Pride and Prejudice by Jane Austen	eng	\N	Independently Published	2021	9798542130958	\N	\N	OL48843831M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7985	39	Pride and Prejudice by Jane Austen	eng	\N	Independently Published	2021	9798722909565	\N	\N	OL48843885M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7986	39	Pride and Prejudice (Note-Taker's Edition with Interleaved Blank Pages)	eng	\N	Independently Published	2021	9798740952147	\N	\N	OL48345801M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7987	39	Pride and Prejudice	eng	\N	Independently Published	2021	9798731563505	\N	\N	OL48240613M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7988	39	Pride and Prejudice	eng	\N	Independently Published	2021	9798706663162	\N	\N	OL48415924M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7989	39	Pride and Prejudice	eng	\N	Independently Published	2021	9798523830891	\N	\N	OL48487943M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7990	39	PRIDE and PREJUDICE	eng	\N	Independently Published	2021	9798531114020	\N	https://covers.openlibrary.org/b/id/15131639-M.jpg	OL48492406M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7991	39	Pride and Prejudice	eng	\N	Independently Published	2021	9798598419427	\N	\N	OL48493126M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7992	39	Pride and Prejudice	eng	\N	Independently Published	2021	9798721265860	\N	\N	OL48495244M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7993	39	Pride and Prejudice	eng	\N	Independently Published	2021	9798593030436	\N	\N	OL48529315M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7994	39	Pride and Prejudice	eng	\N	Independently Published	2021	9798533008488	\N	\N	OL48560770M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7995	39	Pride and Prejudice	eng	\N	Independently Published	2021	9798517845276	\N	\N	OL48560804M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7996	39	Pride and Prejudice	\N	\N	Dell Pub Co	1979	9780440371069	0440371066	\N	OL48564759M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7997	39	Pride and Prejudice Annotate	eng	\N	Independently Published	2021	9798530391392	\N	\N	OL48532834M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7998	39	Pride and Prejudice	eng	\N	Independently Published	2021	9798718726961	\N	\N	OL48476336M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7999	39	Pride and Prejudice	eng	\N	Independently Published	2021	9798737444419	\N	\N	OL48477489M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8000	39	Pride and Prejudice	eng	\N	Independently Published	2021	9798538566334	\N	\N	OL48482838M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8001	39	Pride and Prejudice in 3 Volumes	eng	\N	Independently Published	2021	9798740980089	\N	\N	OL42296275M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8002	39	THE NOVELS OF JANE AUSTEN. THIRD EDITION VOLUME II. PRIDE & PREJUDICE	\N	\N	OXFORD	1946	\N	\N	\N	OL43204107M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8003	39	Pride and Prejudice	eng	\N	Independently Published	2022	9798445773313	\N	\N	OL46633012M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8004	39	Pride and Prejudice	eng	\N	Independently Published	2022	9798428733082	\N	\N	OL46637188M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8005	39	Pride and Prejudice	eng	\N	Independently Published	2022	9798803830016	\N	\N	OL46644336M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8006	39	Pride and Prejudice	eng	\N	Independently Published	2022	9798372091238	\N	\N	OL46645767M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8007	39	Pride and Prejudice	eng	\N	Independently Published	2023	9798373150774	\N	\N	OL46647517M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8008	39	Pride and Prejudice	eng	\N	Independently Published	2022	9798849390031	\N	\N	OL46652369M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8009	39	Pride and Prejudice	eng	\N	Independently Published	2022	9798445198833	\N	\N	OL46659217M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8010	39	Pride and Prejudice	eng	\N	Independently Published	2022	9798355212711	\N	\N	OL46109268M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8011	39	Pride and Prejudice	eng	\N	Independently Published	2022	9798845629227	\N	\N	OL46156720M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8012	39	Pride and Prejudice	eng	\N	Independently Published	2021	9798452064930	\N	\N	OL46159822M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8013	39	Pride and Prejudice	eng	\N	Independently Published	2021	9798775805012	\N	\N	OL46180118M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8014	39	Pride and Prejudice	eng	\N	Independently Published	2022	9798364513762	\N	\N	OL46205645M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8015	39	Pride and Prejudice	eng	\N	Lulu Press, Inc.	2019	9780359863648	\N	\N	OL46209207M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8016	39	Pride and Prejudice	eng	\N	Independently Published	2022	9798844149436	\N	\N	OL46233172M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8017	39	Pride and Prejudice	eng	\N	Creative Media Partners, LLC	2022	9781015402423	\N	\N	OL46245215M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8018	39	Pride and Prejudice	eng	\N	Independently Published	2022	9798842671694	\N	\N	OL46280729M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8019	39	Pride and Prejudice	eng	\N	Independently Published	2022	9798362345594	\N	\N	OL46281865M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8020	39	Pride and Prejudice	eng	\N	Creative Media Partners, LLC	2022	9781015397019	\N	\N	OL46322866M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8021	39	Pride and Prejudice	eng	\N	Independently Published	2022	9798806076275	\N	\N	OL46356297M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8022	39	Pride and Prejudice	eng	\N	Read Books	2022	9781528771665	\N	\N	OL46373847M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8023	39	Pride and Prejudice	eng	\N	Independently Published	2022	9798823757126	\N	\N	OL46381176M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8024	39	Pride and Prejudice	eng	\N	Independently Published	2022	9798842851690	\N	\N	OL46400155M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8025	39	Pride and Prejudice	eng	\N	Independently Published	2022	9798352775332	\N	\N	OL46401287M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8026	39	Pride and Prejudice	eng	\N	Independently Published	2022	9798849215921	\N	\N	OL46401516M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8027	39	Pride an Prejudice	eng	\N	Independently Published	2020	9798674506263	\N	\N	OL42063852M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8028	39	Pride and Prejudice	eng	\N	Independently Published	2019	9781708316013	\N	\N	OL41547744M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8029	39	Pride and Prejudice	eng	\N	Independently Published	2019	9781691581863	\N	\N	OL41582330M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8030	39	PRIDE and PREJUDICE	eng	\N	Independently Published	2019	9781090648303	\N	\N	OL41584051M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8031	39	Pride and Prejudice	eng	\N	Independently Published	2019	9781089425564	\N	\N	OL41602886M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8032	39	Pride and Prejudice	eng	\N	Independently Published	2019	9781797039930	\N	\N	OL41625725M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8033	39	Pride and Prejudice [large Print]	eng	\N	Independently Published	2019	9781677196364	\N	\N	OL41643576M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8034	39	Pride and Prejudice	eng	\N	Independently Published	2019	9781688700765	\N	\N	OL41657295M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8035	39	Pride and Prejudice	eng	\N	Independently Published	2020	9781656078360	\N	\N	OL41658644M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8036	39	Pride and Prejudice	eng	\N	Independently Published	2019	9781708248420	\N	\N	OL41676029M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8037	39	Pride and Prejudice	eng	\N	Independently Published	2019	9781677389070	\N	\N	OL41684034M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8038	39	Pride and Prejudice	eng	\N	Independently Published	2019	9781676523406	\N	\N	OL41694027M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8039	39	Pride and Prejudice	eng	\N	Independently Published	2019	9781676550839	\N	\N	OL41694066M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8040	39	PRIDE and PREJUDICE	eng	\N	Independently Published	2019	9781090584922	\N	\N	OL41707984M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8041	39	Pride and Prejudice	eng	\N	Teratak Publishing	2019	9781677198412	\N	\N	OL41720533M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8042	39	Pride and Prejudice	eng	\N	Teratak Publishing	2019	9781677203659	\N	\N	OL41720538M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8043	39	Pride and Prejudice	eng	\N	Teratak Publishing	2019	9781677212712	\N	\N	OL41772033M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8044	39	Pride and Prejudice	eng	\N	Independently Published	2019	9781707205080	\N	\N	OL41777607M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8045	39	Pride and Prejudice	eng	\N	Independently Published	2019	9781709366079	\N	\N	OL41783967M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8046	39	Pride and Prejudice	eng	\N	Independently Published	2019	9781676297277	\N	https://covers.openlibrary.org/b/id/13290989-M.jpg	OL41796439M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8047	39	Pride & Prejudice	eng	\N	Independently Published	2020	9781660241248	\N	\N	OL41841694M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8048	39	Pride and Prejudice	eng	\N	Independently Published	2020	9798614554880	\N	\N	OL41871840M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8049	39	Pride and Prejudice	eng	\N	Independently Published	2020	9798627523620	\N	\N	OL41872849M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8050	39	Pride and Prejudice	eng	\N	Independently Published	2020	9781679944949	\N	\N	OL41878497M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8051	39	Pride and Prejudice	eng	\N	Independently Published	2019	9781091785816	\N	\N	OL41394462M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8052	39	Pride and Prejudice	eng	\N	Independently Published	2019	9781690883166	\N	https://covers.openlibrary.org/b/id/13306851-M.jpg	OL41835913M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8053	39	Pride and Prejudice	eng	\N	Independently Published	2019	9781672100359	\N	\N	OL41904144M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8054	39	Pride and Prejudice	eng	\N	Independently Published	2020	9798665333564	\N	\N	OL42088340M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8055	39	Pride and Prejudice	eng	\N	Independently Published	2019	9781794609174	\N	\N	OL40943931M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8056	39	Pride and Prejudice	eng	\N	Independently Published	2018	9781723978074	\N	\N	OL40946422M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8057	39	Pride and Prejudice	eng	\N	Independently Published	2019	9781090837035	\N	\N	OL40950563M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8058	39	Pride and Prejudice	eng	\N	Independently Published	2019	9781093183597	\N	\N	OL40974638M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8059	39	Pride and Prejudice	eng	\N	Independently Published	2019	9781098913731	\N	\N	OL40978626M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8060	39	Pride and Prejudice	eng	\N	Independently Published	2019	9781093216219	\N	\N	OL40990475M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8061	39	Pride and Prejudice	eng	\N	Independently Published	2019	9781092850834	\N	\N	OL40999513M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8062	39	Pride and Prejudice	eng	\N	Independently Published	2018	9781730969171	\N	\N	OL41011298M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8063	39	Pride and Prejudice	eng	\N	Independently Published	2018	9781731487667	\N	\N	OL41011980M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8064	39	Pride and Prejudice	eng	\N	Independently Published	2019	9781799290308	\N	\N	OL41024430M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8065	39	PRIDE and PREJUDICE	eng	\N	Independently Published	2019	9781090581952	\N	\N	OL41032563M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8066	39	Pride and Prejudice	eng	\N	Independently Published	2019	9781098567101	\N	\N	OL41041091M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8067	39	Pride and Prejudice	eng	\N	Independently Published	2019	9781090852120	\N	\N	OL41076453M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8068	39	Pride and Prejudice	eng	\N	Independently Published	2019	9781090406439	\N	\N	OL41087050M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8069	39	Pride and Prejudice	eng	\N	Independently Published	2018	9781791613174	\N	\N	OL41111041M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8070	39	Pride and Prejudice	eng	\N	Independently Published	2019	9781798443620	\N	\N	OL41118766M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8071	39	Pride and Prejudice	eng	\N	Independently Published	2019	9781091449954	\N	\N	OL41130717M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8072	39	Pride and Prejudice	eng	\N	Independently Published	2019	9781096603795	\N	\N	OL41164707M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8073	39	Pride and Prejudice	eng	\N	Independently Published	2017	9781520484150	\N	\N	OL40845755M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8074	39	Pride and Prejudice	eng	\N	Independently Published	2017	9781521900833	\N	\N	OL40856972M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8075	39	Pride and Prejudice	fra	\N	Independently Published	2017	9781549649172	\N	\N	OL40859253M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8076	39	Pride and Prejudice	eng	\N	Independently Published	2018	9781720026600	\N	\N	OL40714589M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8077	39	Pride and Prejudice	eng	\N	Independently Published	2018	9781731241214	\N	\N	OL40720777M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8078	39	Pride and Prejudice	eng	\N	Independently Published	2017	9781520691312	\N	https://covers.openlibrary.org/b/id/15269716-M.jpg	OL40738384M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8079	39	Pride and Prejudice	eng	\N	Independently Published	2018	9781980882770	\N	\N	OL40598154M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8080	39	Pride and Prejudice	eng	\N	Independently Published	2018	9781717873606	\N	\N	OL40607911M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8081	39	Pride and Prejudice	eng	\N	Independently Published	2018	9781731266705	\N	\N	OL40609253M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8082	39	Pride and Prejudice	eng	\N	Independently Published	2017	9781520982953	\N	\N	OL40631171M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8083	39	Pride and Prejudice	eng	\N	Independently Published	2017	9781521223468	\N	\N	OL40633255M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8084	39	Pride and Prejudice	eng	\N	Independently Published	2017	9781973117735	\N	https://covers.openlibrary.org/b/id/13283996-M.jpg	OL40644196M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8085	39	Pride and Prejudice	eng	\N	Independently Published	2022	9798837662638	\N	\N	OL39413803M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8086	39	Pride and Prejudice	eng	\N	Independently Published	2018	9781980399018	\N	\N	OL40817474M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8087	39	Pride and Prejudice	eng	\N	Independently Published	2019	9781097220823	\N	\N	OL41102710M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8088	39	Pride and Prejudice	eng	\N	Independently Published	2019	9781696076357	\N	https://covers.openlibrary.org/b/id/13714918-M.jpg	OL41565761M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8089	39	Pride and Prejudice	eng	\N	Independently Published	2020	9798565411881	\N	\N	OL42185344M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8090	39	Pride and Prejudice	eng	\N	Project Gutenberg/Microsoft	2023	\N	\N	https://covers.openlibrary.org/b/id/13440880-M.jpg	OL47079597M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8091	39	Pride and Prejudice	eng	\N	Oxford University Press	1967	\N	\N	https://covers.openlibrary.org/b/id/14601367-M.jpg	OL47079587M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8092	39	Pride and Prejudice	eng	\N	Independently Published	2019	9781700479341	\N	\N	OL46787259M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8093	39	Pride and Prejudice	eng	\N	Independently Published	2020	9798622911743	\N	\N	OL46791138M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8094	39	Pride and Prejudice	eng	\N	Independently Published	2020	9798614275945	\N	\N	OL46805225M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8095	39	Pride and Prejudice	eng	\N	Independently Published	2022	9798434681599	\N	\N	OL46820310M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8096	39	Pride and Prejudice	eng	\N	Independently Published	2022	9798431747700	\N	\N	OL46827831M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8097	39	Pride and Prejudice	eng	\N	Independently Published	2021	9798753123268	\N	\N	OL46827977M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8098	39	Pride and Prejudice	\N	\N	The Book League of America	1940	\N	\N	\N	OL46856651M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8099	39	Pride and Prejudice	\N	\N	The Book League of America	1931	\N	\N	\N	OL46923929M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8100	39	Pride and Prejudice	\N	\N	Guild Publishing	1986	\N	\N	\N	OL46947240M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8101	39	Pride & Prejudice	\N	\N	Blackie	1954	\N	\N	\N	OL46951586M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8102	39	Pride and Prejudice	eng	\N	Guild Publishing	1979	\N	\N	https://covers.openlibrary.org/b/id/13440856-M.jpg	OL46851157M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8103	39	Duma i uprzedzenie	pol	\N	Prószynski i S-ka	2005	9788374692113	8374692111	https://covers.openlibrary.org/b/id/13440843-M.jpg	OL46948603M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8104	39	Pride and Prejudice	eng	\N	Amsco School Publications	1989	9780877208471	0877208476	https://covers.openlibrary.org/b/id/13440850-M.jpg	OL46964446M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8105	39	Pride and prejudice	\N	\N	Macmillan	1962	\N	\N	\N	OL46988436M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8106	39	Pride and Prejudice	\N	\N	Walter J Black	1965	\N	\N	\N	OL47017057M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8107	39	Pride and Prejudice	eng	\N	Dover Publications	1995	9780486453941	0486453944	https://covers.openlibrary.org/b/id/14534721-M.jpg	OL47022740M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8108	39	Pride and Prejudice	\N	\N	Washington Square Press / Pocket Books	1971	9780671465636	0671465635	\N	OL47045666M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8109	39	Pride and Prejudice	eng	\N	Independently Published	2019	9781795238168	\N	\N	OL40560630M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8110	39	pride and prejudice	\N	\N	collins clear-type press	1930	\N	\N	\N	OL44782046M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8111	39	Pride Prejudice	eng	\N	Pocket	1982	9780671443894	0671443895	\N	OL11071812M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8112	39	Pride and Prejudice	eng	\N	Independently Published	2019	9781799285755	\N	\N	OL41385872M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8113	39	Pride and Prejudice	eng	\N	Easy Read Press	2020	9798557128193	\N	https://covers.openlibrary.org/b/id/14553952-M.jpg	OL42233963M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8114	39	Jane Austen (Great Writers)	eng	\N	Aurum Press	1995	9781854102607	1854102605	\N	OL8982638M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8115	39	Pride and Prejudice	eng	\N	HarperCollins Canada, Limited	1983	9780004244112	\N	\N	OL36183985M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8116	39	Pride and Prejudice	eng	\N	Hodder & Stoughton	1995	9780340657874	\N	\N	OL36183986M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8117	39	Pride and Prejudice	eng	\N	Toby Press LLC, The	2003	9781592640003	\N	\N	OL36184408M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8118	39	Pride and Prejudice	eng	\N	Toby Press LLC, The	2003	9781592640010	\N	\N	OL36184409M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8119	39	Pride and Prejudice	eng	\N	IndyPublish.com	2002	9781404324848	\N	\N	OL36184717M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8120	39	Pride and Prejudice	eng	\N	IndyPublish.com	2002	9781404324855	\N	\N	OL36184718M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8121	39	Pride and Prejudice	eng	\N	Wildside Press, LLC	2004	9780809596300	\N	\N	OL36184749M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8122	39	Pride and Prejudice	eng	\N	Back-in-Print Books, Limited	2001	9781903552216	\N	\N	OL36184750M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8123	39	Pride and Prejudice	eng	\N	Glasgow Publications, Mary	2007	9781905775101	\N	\N	OL36186847M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8124	39	Pride and Prejudice	eng	\N	Pearson Education, Limited	2006	9780132435673	\N	\N	OL36187020M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8125	39	Pride and Prejudice	eng	\N	New Dawn Press, Incorporated	2004	9781932705355	\N	\N	OL36187700M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8126	39	Pride and Prejudice	eng	\N	IndyPublish.com	2005	9781421926360	\N	\N	OL36187817M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8127	39	Pride and Prejudice	eng	\N	Creative Media Partners, LLC	2007	9781426455087	\N	\N	OL36187868M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8128	39	Pride and Prejudice	eng	\N	Standard Publications, Inc.	2007	9781604240252	\N	\N	OL36187911M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8129	39	Pride and Prejudice	eng	\N	Macmillan Education, Limited	1982	9780333348819	\N	\N	OL36188212M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8130	39	Pride and Prejudice	eng	\N	Octopus Publishing Group	2011	9780753722725	\N	\N	OL36195246M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8131	39	Pride and Prejudice	eng	\N	Pan Macmillan	2013	9781907360879	\N	\N	OL36201157M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8132	39	Pride and Prejudice	eng	\N	Arcturus Publishing	2013	9781782122760	\N	\N	OL36202138M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8133	39	Pride and Prejudice	eng	\N	HardPress	2013	9781314269352	\N	\N	OL36203837M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8134	39	Pride and Prejudice	eng	\N	Kalyani Navyug Media Pty. Ltd.	2013	9789380741826	\N	\N	OL36204341M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8135	39	Pride and Prejudice	eng	\N	Bottom of the Hill Publishing	2013	9781483703329	\N	\N	OL36205198M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8136	39	Pride and Prejudice	eng	\N	Global Media	2011	9781281359087	\N	\N	OL36205209M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8137	39	Pride and Prejudice	eng	\N	Lulu Press, Inc.	2013	9781291417142	\N	\N	OL36205717M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8138	39	Pride and Prejudice	eng	\N	Scholastic, Incorporated	1996	9780590085762	\N	\N	OL36205930M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8139	39	Pride and Prejudice	eng	\N	Oldcastle Books, Limited	2013	9781306027717	\N	\N	OL36206096M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8140	39	Pride and Prejudice	eng	\N	Atlantic Publishing	2014	9781909242135	\N	\N	OL36206792M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8141	39	Pride and Prejudice	eng	\N	Howes Limited, W. F.	2013	9781408402078	\N	\N	OL36206892M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8142	39	Pride and Prejudice	eng	\N	Dover Publications, Incorporated	2012	9781306352031	\N	\N	OL36206895M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
7008	20	Harry Potter and the Philosopher's Stone	eng	\N	BBC Audiobooks	1999	9781855499843	1855499843	https://covers.openlibrary.org/b/id/3005712-M.jpg	OL11999828M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7009	20	Harry Potter and the Philosopher's Stone	eng	\N	Cover to Cover Cassettes	1999	9781855494985	1855494981	https://covers.openlibrary.org/b/id/906272-M.jpg	OL8993477M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7010	20	Harry Potter and the Philosopher's Stone	eng	\N	Raincoast Books	1997	9781551927046	1551927047	\N	OL22595027M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
8143	39	Pride and Prejudice	eng	\N	Dover Publications, Incorporated	2012	9781306346627	\N	\N	OL36206896M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8144	39	Pride and Prejudice	eng	\N	Simon & Schuster, Limited	2016	9781471142512	\N	\N	OL36208472M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
5869	1	Dune	ron	\N	Nemira Publishing House	2021	9786064312617	\N	https://covers.openlibrary.org/b/id/15246488-M.jpg	OL62445412M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5870	1	Ḥolit	heb	\N	ʻAm-ʻoved	1989	\N	\N	\N	OL58201616M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5871	1	Dune Ebook Collection	eng	\N	Orion Publishing Group, Limited	2012	9780575122796	\N	\N	OL48154015M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5872	1	Dune	eng	\N	Chilton Book Company	1965	\N	\N	\N	OL58816437M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5873	1	Dune	eng	\N	Chilton Book Company	1965	\N	\N	https://covers.openlibrary.org/b/id/15244952-M.jpg	OL43283259M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5874	1	Dune	eng	\N	Ace	1965	9780450035692	0450035697	\N	OL38247617M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5875	1	Dune	eng	\N	Chilton Book Company	1965	9789997516787	9997516788	https://covers.openlibrary.org/b/id/15247496-M.jpg	OL39220318M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5876	1	Dune	eng	\N	Orion Publishing Group, Limited	2022	9781399611176	\N	https://covers.openlibrary.org/b/id/15270053-M.jpg	OL39551956M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5877	1	Dune	eng	\N	Hodder	2005	9780340765906	0340765909	\N	OL10630547M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5878	1	Dune - Collector	fra	\N	Pocket	2020	9782266307307	2266307304	https://covers.openlibrary.org/b/id/14841443-M.jpg	OL57671241M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5879	1	Duna	por	BR	Aleph	2021	9788576574941	\N	https://covers.openlibrary.org/b/id/15228531-M.jpg	OL62085090M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5880	1	Duna	por	BR	Aleph	2021	9786586064698	\N	https://covers.openlibrary.org/b/id/15228506-M.jpg	OL62085058M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5881	1	Dune / Dune	spa	\N	Penguin Random House Grupo Editorial	2024	9788466363402	\N	https://covers.openlibrary.org/b/id/15278237-M.jpg	OL50732450M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5882	1	Dune #1	eng	\N	Orion Publishing Group, Limited	2010	9780575104419	\N	https://covers.openlibrary.org/b/id/15278270-M.jpg	OL48138703M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5883	1	Dune (Unabridged Audio CD)	eng	\N	Books on Tape, inc.	2003	9780736692403	0736692401	https://covers.openlibrary.org/b/id/14020316-M.jpg	OL7893461M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5884	1	Dune	eng	\N	Debolsillo	2020	9788466356954	8466356959	https://covers.openlibrary.org/b/id/14092069-M.jpg	OL47483482M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5885	1	Dune	eng	\N	Nha Nam - Hoi Nha Van	2009	8936024912741	\N	\N	OL47693473M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5886	1	Dune / Duna	spa	\N	MAIMÉS	2021	9788412363357	8412363353	https://covers.openlibrary.org/b/id/13934500-M.jpg	OL47345006M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5887	1	Diuna	pol	\N	Rebis	2020	9788381880572	8381880572	https://covers.openlibrary.org/b/id/13916320-M.jpg	OL47330344M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5888	1	Dune. Seria Dune, Vol. 1	ron	\N	Nemira Publishing House	2019	9786064304834	6064304839	https://covers.openlibrary.org/b/id/13816755-M.jpg	OL47317022M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5889	1	Dune	eng	\N	Chilton	1965	\N	\N	\N	OL46913349M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5890	1	Dune	spa	\N	DEBOLSILLO	2022	9788466362818	8466362819	https://covers.openlibrary.org/b/id/13556124-M.jpg	OL47152294M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5891	1	Dune - Exclusive Gold Cover	eng	\N	Penguin Proprietary	2018	9781101948712	110194871X	\N	OL42921531M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5892	1	dune : i archi tou thrylikou epous / dune	ell	\N	Anubis	2006	9789603063957	9603063959	\N	OL40225407M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5893	1	Dune (Dune by Frank Herbert, Narrated by George Guidall)	eng	\N	Recorded Books, LLC	1965	9781402523809	1402523807	\N	OL8373842M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5894	1	Dune	eng	\N	Chilton Book Company	1965	\N	\N	\N	OL43012960M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5895	1	Dune	eng	\N	Macmillan Audio	2006	\N	\N	\N	OL43013026M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5896	1	Дюна	ukr	\N	Клуб Сімейного Дозвілля	2020	9786171276895	\N	https://covers.openlibrary.org/b/id/12981475-M.jpg	OL40212545M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5897	1	Dune	eng	\N	Raig Verd Editorial	2021	9788412363371	\N	https://covers.openlibrary.org/b/id/12819203-M.jpg	OL38237349M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5898	1	Dune	eng	\N	Hodder	2021	9781529347869	\N	https://covers.openlibrary.org/b/id/12804560-M.jpg	OL38566665M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5899	1	Dune - tome 1	eng	\N	POCKET	2021	9782266320481	2266320483	https://covers.openlibrary.org/b/id/13823878-M.jpg	OL39811097M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5900	1	Dyuna	rus	\N	AST	2005	9785170103560	5170103565	https://covers.openlibrary.org/b/id/12575304-M.jpg	OL9039841M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5901	1	Dune – Der Wüstenplanet	deu	\N	Heyne Verlag	2021	9783453321229	3453321227	https://covers.openlibrary.org/b/id/12410029-M.jpg	OL35704536M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5902	1	Dune - tome 1 - NE 2021	fra	\N	ROBERT LAFFONT	2021	9782221252055	2221252055	https://covers.openlibrary.org/b/id/10565022-M.jpg	OL31884887M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5903	1	Duin	nld	\N	Meulenhoff	\N	9789029002578	9029002573	https://covers.openlibrary.org/b/id/8763616-M.jpg	OL27281911M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5904	1	Dune	eng	\N	Thorndike Press	2015	9781410477736	1410477738	https://covers.openlibrary.org/b/id/8741528-M.jpg	OL27104381M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5905	1	Dune	eng	\N	Ace Trade	2005	9780441013593	0441013597	https://covers.openlibrary.org/b/id/14565843-M.jpg	OL7524304M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5906	1	Dune (A Borders Audio Exclusive Presentation: Unabridged on 13 Cassettes)	eng	\N	Borders	2002	9781402523601	1402523602	https://covers.openlibrary.org/b/id/15202649-M.jpg	OL11636763M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5907	1	Dune Aus Special Promo	eng	\N	New English Library Ltd	2001	9780340822548	0340822546	\N	OL10676668M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5908	1	Dune	eng	\N	Gollancz	2001	9780575073340	0575073349	https://covers.openlibrary.org/b/id/380097-M.jpg	OL7878673M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5909	1	DUNE	eng	\N	Ace Books, Inc.	1967	\N	0441176208	https://covers.openlibrary.org/b/id/15250487-M.jpg	OL10256517M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5910	1	Dune	eng	\N	Putnam Adult	1984	9780399128967	0399128964	https://covers.openlibrary.org/b/id/258358-M.jpg	OL7470646M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5911	1	Dune	eng	\N	Tandem Library	1999	9780881036367	0881036366	https://covers.openlibrary.org/b/id/677696-M.jpg	OL8136410M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5912	1	Dune	eng	\N	Berkley	1978	9780425038918	0425038912	https://covers.openlibrary.org/b/id/9705237-M.jpg	OL7500941M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5913	1	Illustrated Dune	eng	\N	Perigee Trade	1979	9780426038917	0426038916	\N	OL9309587M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5914	1	Dune	eng	\N	Berkley	1987	9780425103814	0425103811	https://covers.openlibrary.org/b/id/15257424-M.jpg	OL7502823M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5915	1	Dune	eng	\N	Ace Books	1987	9780441172665	0441172660	\N	OL7525228M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5916	1	Dune	eng	\N	Berkley	1984	9780425071601	042507160X	https://covers.openlibrary.org/b/id/9499649-M.jpg	OL7501953M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5917	1	Dune	eng	\N	Ace Books	1974	\N	\N	\N	OL28415017M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5918	1	Dune 2	fra	\N	Presse Poket	1984	9782266008560	\N	https://covers.openlibrary.org/b/id/8638619-M.jpg	OL27031626M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5919	1	Dune	eng	\N	Ace Books	2010	9780441172719	\N	https://covers.openlibrary.org/b/id/15245289-M.jpg	OL26790943M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5920	1	Dune	eng	\N	Ace Books	1967	\N	\N	\N	OL26627491M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5921	1	Dune	eng	\N	New English Library	1976	\N	0450031462	https://covers.openlibrary.org/b/id/10208978-M.jpg	OL7569255M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5922	1	Dune	eng	\N	Sound Library	2007	9780792748663	0792748662	https://covers.openlibrary.org/b/id/15202647-M.jpg	OL9385813M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5923	1	Dune	eng	\N	The Berkley Publishing Group	2002	9780441010622	0441010628	https://covers.openlibrary.org/b/id/9692762-M.jpg	OL7524214M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5924	1	Dune	eng	\N	Ace Books	2005	\N	0441013597	https://covers.openlibrary.org/b/id/14856017-M.jpg	OL17952222M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5925	1	Dune	eng	\N	Berkley	1980	9780425046876	0425046877	\N	OL7501231M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5926	1	Dune	spa	\N	Plaza & Janés	1995	9788401469312	8401469317	https://covers.openlibrary.org/b/id/15202652-M.jpg	OL9112090M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5927	1	Dune	eng	\N	Ace Books	1999	\N	\N	\N	OL118251M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5928	1	Dune	eng	\N	Berkley Books	1984	\N	0399128964	\N	OL21963593M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5929	1	Dune	eng	\N	Putnam	1965	\N	0399128964	https://covers.openlibrary.org/b/id/15277583-M.jpg	OL20171394M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5930	1	Dune	eng	\N	Audio Renaissance	2007	9781427201430	1427201439	https://covers.openlibrary.org/b/id/1847148-M.jpg	OL8536852M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5931	1	Dune	eng	\N	Chilton Books	1965	\N	\N	https://covers.openlibrary.org/b/id/12375564-M.jpg	OL13634897M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5932	1	Dune	eng	\N	Berkley	1977	9780425036983	0425036987	https://covers.openlibrary.org/b/id/5723834-M.jpg	OL7500872M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5933	1	Dune	eng	\N	Chilton Book Company	1972	\N	0801950775	https://covers.openlibrary.org/b/id/10183307-M.jpg	OL20665557M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5934	1	Dune	eng	\N	Berkley	1983	9780425064344	0425064344	https://covers.openlibrary.org/b/id/9697727-M.jpg	OL7501754M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5935	1	Dune	eng	\N	New English Library	1968	\N	0450042308	https://covers.openlibrary.org/b/id/13206065-M.jpg	OL21445672M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5936	1	Dune	eng	\N	Ace	1987	\N	0441172660	\N	OL22213678M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5937	1	Dune	eng	\N	Hodder and Stoughton	1968	\N	0450011844	https://covers.openlibrary.org/b/id/15278245-M.jpg	OL22041443M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5938	1	Dune	eng	\N	New English Library	1969	\N	0450000893	https://covers.openlibrary.org/b/id/10091006-M.jpg	OL21444121M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5939	1	Dune	eng	\N	Hodder & Stoughton	2006	9780340839935	0340839937	https://covers.openlibrary.org/b/id/2402172-M.jpg	OL10677120M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5940	1	Dune	eng	\N	Caedmon	1977	\N	\N	\N	OL20729653M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5941	1	DUNE	eng	\N	Ace	\N	\N	\N	\N	OL18383188M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5942	1	Dune	eng	\N	Gollancz	1966	\N	0575035404	https://covers.openlibrary.org/b/id/15202639-M.jpg	OL22497443M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5943	1	Dune	eng	\N	New English Library	1978	\N	0450051722	https://covers.openlibrary.org/b/id/9256648-M.jpg	OL22316662M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5944	1	Dune	eng	\N	Putnam	1984	\N	0399128964	https://covers.openlibrary.org/b/id/9719751-M.jpg	OL22275832M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5945	1	Dune	eng	\N	Gollancz	1974	\N	057501864X	https://covers.openlibrary.org/b/id/13969950-M.jpg	OL22347514M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5946	1	Dune	eng	\N	Berkley Books	1982	\N	\N	\N	OL23743739M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5947	1	Dune.	eng	\N	New English Library	1972	\N	\N	\N	OL13715426M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5948	1	Der Wüstenplanet	deu	\N	Wilhelm Heyne Verlag	2001	9783453186835	3453186834	https://covers.openlibrary.org/b/id/6390607-M.jpg	OL24235819M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5949	1	Dune	spa	\N	Acervo	1975	9788470021817	8470021818	https://covers.openlibrary.org/b/id/14538254-M.jpg	OL9134534M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5950	1	Dune.	eng	\N	Chilton Books	1965	\N	\N	https://covers.openlibrary.org/b/id/10535009-M.jpg	OL5949994M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5951	1	Dune	eng	\N	Berkley	1977	9780425043769	0425043762	\N	OL7501101M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5952	1	Dune	eng	\N	Ace Books	1987	\N	0441172660	https://covers.openlibrary.org/b/id/15166231-M.jpg	OL22597282M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5953	1	Dune	eng	\N	Hodder & Stoughton Ltd	1982	9780450011849	0450011844	https://covers.openlibrary.org/b/id/291296-M.jpg	OL7569171M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5954	1	Dune	eng	\N	Berkley	1982	9780425054710	0425054713	https://covers.openlibrary.org/b/id/13236726-M.jpg	OL7501460M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5955	1	Dune	eng	\N	Berkley Trade	1982	9780425053133	042505313X	https://covers.openlibrary.org/b/id/15279362-M.jpg	OL7501408M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5956	1	Dune	eng	\N	Putnam	1984	\N	0399128964	https://covers.openlibrary.org/b/id/258357-M.jpg	OL3173729M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5957	1	Dune	eng	\N	Recorded Books Inc	1993	9781556909337	1556909330	https://covers.openlibrary.org/b/id/15202653-M.jpg	OL8597269M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5958	1	Dune	eng	\N	Penguin USA, Inc.	2009	9781436233286	\N	https://covers.openlibrary.org/b/id/6399933-M.jpg	OL24275728M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5959	1	Dune	eng	\N	Books on Tape, Inc.	1997	9780736637633	073663763X	https://covers.openlibrary.org/b/id/463238-M.jpg	OL7893239M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5960	1	Dune	eng	\N	Berkley	1975	9780425027066	0425027066	https://covers.openlibrary.org/b/id/11157826-M.jpg	OL7500578M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5961	1	Dune	eng	\N	Ace Books	1965	\N	\N	https://covers.openlibrary.org/b/id/15092781-M.jpg	OL26242482M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5962	1	Dune (S.F. Masterworks)	eng	\N	Gollancz Paperback	2007	9780575081505	0575081503	https://covers.openlibrary.org/b/id/15263351-M.jpg	OL26787281M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5963	1	Dune	eng	\N	Berkley	1984	9780425080023	0425080021	https://covers.openlibrary.org/b/id/8535871-M.jpg	OL26843308M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5964	1	Dune	eng	\N	Gollancz	2011	9780575116788	0575116781	https://covers.openlibrary.org/b/id/8570801-M.jpg	OL26876865M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5965	1	Dune	tur	\N	Kabalci Yayinevi	2017	9789759971175	9759971178	https://covers.openlibrary.org/b/id/8741978-M.jpg	OL27105455M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5966	1	Dune: Deluxe Edition	eng	\N	Ace	2019	9780593099322	059309932X	https://covers.openlibrary.org/b/id/8792030-M.jpg	OL27326597M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5967	1	Dune (Spanish Edition)	spa	\N	Penguin Random House Grupo Editorial (USA) LLC	2020	9786073194648	\N	https://covers.openlibrary.org/b/id/15202641-M.jpg	OL30043985M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
8145	39	Pride and Prejudice	eng	\N	Scholastic	2015	9781407158518	\N	\N	OL36212364M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
5968	1	Dune	eng	\N	Ace Books	1987	\N	0441172660	https://covers.openlibrary.org/b/id/7885536-M.jpg	OL24981555M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5969	1	Dune	eng	\N	Turtleback Books Distributed by Demco Media	2003	9780606031110	0606031111	\N	OL9477357M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5970	1	Diuna	pol	\N	Phantom Press International	1992	\N	8385432167	\N	OL19610870M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5971	1	Di︠u︡na	rus	\N	AST	2000	\N	5237030777	https://covers.openlibrary.org/b/id/15202650-M.jpg	OL23051194M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5972	1	Dune - Der Wüstenplanet. Der Roman zum grossen TV- Event auf ProSieben.	deu	\N	Heyne	2001	9783453185678	3453185676	https://covers.openlibrary.org/b/id/1009408-M.jpg	OL9041222M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5973	1	Dune - Der Wüstenplanet.	deu	\N	Heyne	2001	9783453187047	3453187040	https://covers.openlibrary.org/b/id/1009426-M.jpg	OL9041237M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5974	1	Dune	spa	\N	Debolsillo	2020	9788466353779	8466353771	https://covers.openlibrary.org/b/id/10471208-M.jpg	OL30550827M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5975	1	Dune	spa	\N	Nova	2019	9788417347628	8417347623	https://covers.openlibrary.org/b/id/10448201-M.jpg	OL30192937M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5976	1	Dune	eng	\N	Hodder & Stoughton	2020	9781529347852	\N	https://covers.openlibrary.org/b/id/14706323-M.jpg	OL29517192M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5977	1	Dune	eng	\N	Hodder Paperback	2015	9780340960196	0340960191	https://covers.openlibrary.org/b/id/10358100-M.jpg	OL28794919M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5978	1	Dune	spa	\N	Debolsillo	2005	9788497596824	849759682X	https://covers.openlibrary.org/b/id/4917636-M.jpg	OL9154477M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5979	1	Dune (Movie Tie-In)	eng	\N	Penguin Publishing Group	2020	9780593200117	\N	https://covers.openlibrary.org/b/id/15202643-M.jpg	OL30201741M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5980	1	Dune (Movie Tie-In)	eng	\N	Penguin Publishing Group	2020	9780593200100	\N	https://covers.openlibrary.org/b/id/15202640-M.jpg	OL30192477M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5981	1	Der Wüstenplanet	deu	\N	Heyne Verlag	2016	9783453317178	3453317173	https://covers.openlibrary.org/b/id/15247677-M.jpg	OL32663508M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5982	1	Dune A Novel	eng	\N	Ace Books	1999	9780441005901	\N	https://covers.openlibrary.org/b/id/7508904-M.jpg	OL25984167M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5983	1	Dune	eng	\N	Berkley T2706	1975	9780450027277	0450027279	https://covers.openlibrary.org/b/id/8740512-M.jpg	OL27102570M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5984	1	Dune	eng	\N	Orion Pub Co	1999	9780575068568	0575068566	https://covers.openlibrary.org/b/id/8740672-M.jpg	OL27102726M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5985	1	Dune (Penguin Galaxy)	eng	\N	Penguin Classics	2016	9780143111580	0143111582	https://covers.openlibrary.org/b/id/8742737-M.jpg	OL27106944M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5986	1	Dune	eng	\N	Ace Books	2013	9781435140745	1435140745	https://covers.openlibrary.org/b/id/8771989-M.jpg	OL27292842M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5987	1	Dune	eng	\N	Barnes & Noble	2013	9780425266540	0425266540	https://covers.openlibrary.org/b/id/14426686-M.jpg	OL30105510M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5988	1	Dune	fra	\N	Robert Laffont	2020	9782221249482	2221249488	https://covers.openlibrary.org/b/id/10500426-M.jpg	OL30776646M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5989	1	Duna	por	BR	Editora Aleph	2010	9788576571018	8576571013	https://covers.openlibrary.org/b/id/8200322-M.jpg	OL26466621M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5990	1	Diuna	pol	\N	Dom Wydawniczy REBIS Sp. z o.o.	2011	9788373017238	\N	https://covers.openlibrary.org/b/id/15202644-M.jpg	OL24650675M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5991	1	Der Wüstenplanet	deu	\N	Heyne	1985	9783453305236	345330523X	https://covers.openlibrary.org/b/id/9500604-M.jpg	OL25569691M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5992	1	Diuna	pol	\N	Rebis	2020	9788381881654	838188165X	https://covers.openlibrary.org/b/id/10488703-M.jpg	OL30691242M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5993	1	Dune	tur	\N	Ithaki Yayinlari	2015	9786053754794	605375479X	https://covers.openlibrary.org/b/id/12227029-M.jpg	OL35384350M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5994	1	Dune	eng	\N	Orion Publishing Group, Limited	2021	9781473233959	\N	https://covers.openlibrary.org/b/id/13550896-M.jpg	OL34693694M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5995	1	Dune	ita	\N	Fanucci	2012	9788834718452	8834718453	https://covers.openlibrary.org/b/id/11943467-M.jpg	OL33245052M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5996	1	Dune	eng	\N	Recorded Books	1993	9781402553240	1402553242	https://covers.openlibrary.org/b/id/11481411-M.jpg	OL32848896M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5997	1	Dune	eng	\N	Hodder	2006	9781444738209	1444738208	https://covers.openlibrary.org/b/id/11481354-M.jpg	OL32848840M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5998	1	Dune	eng	\N	Ace	2021	9780593438374	059343837X	https://covers.openlibrary.org/b/id/11481333-M.jpg	OL32848819M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
5999	1	Dune	eng	\N	Ace Books	1965	9780441172610	044117261X	https://covers.openlibrary.org/b/id/11481225-M.jpg	OL32848711M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
6000	1	Dune	eng	\N	Ace	1974	9780441172634	0441172636	https://covers.openlibrary.org/b/id/11481224-M.jpg	OL32848710M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
6001	1	Dune	eng	\N	NEL / New English Library	1970	9780450054655	0450054659	https://covers.openlibrary.org/b/id/11481211-M.jpg	OL32848697M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
6002	1	Dune	eng	\N	Ace	2021	9780593438367	0593438361	https://covers.openlibrary.org/b/id/11481200-M.jpg	OL32848688M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
6003	1	Dune	eng	\N	Perfection Learning	2003	9780812417241	0812417240	https://covers.openlibrary.org/b/id/15278729-M.jpg	OL32848675M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
6004	1	Dune	eng	\N	Paw Prints 2008-06-26	2008	9781439501665	1439501661	https://covers.openlibrary.org/b/id/11481180-M.jpg	OL32848668M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
6005	1	Der Wüstenplanet	deu	\N	Wilhelm Heyne Verlag	1987	\N	345330523X	https://covers.openlibrary.org/b/id/12698758-M.jpg	OL37791926M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
6006	1	Dune	spa	\N	P&J	1995	\N	840100912X	https://covers.openlibrary.org/b/id/12794170-M.jpg	OL38247253M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
6007	1	Diuna	pol	\N	Dom wydawniczy Rebis	2020	9788381887533	\N	https://covers.openlibrary.org/b/id/14563320-M.jpg	OL50530390M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
6008	1	Dune	eng	\N	Hodder Paperbacks	2015	9781473696211	\N	https://covers.openlibrary.org/b/id/14636170-M.jpg	OL51750372M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
6009	1	Dune	spa	\N	Debolsillo	2020	9789877254112	9877254115	https://covers.openlibrary.org/b/id/14636513-M.jpg	OL38630050M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
6010	1	Dune	fra	\N	Pocket	2021	9782266320542	2266320548	https://covers.openlibrary.org/b/id/14896631-M.jpg	OL33260759M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
6011	1	Dune	ell	\N	Εκδόσεις Anubis	2020	9789606232237	\N	https://covers.openlibrary.org/b/id/15116693-M.jpg	OL59923094M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
6012	1	Dune	eng	\N	Ace	2003	9781101658055	\N	https://covers.openlibrary.org/b/id/15122397-M.jpg	OL60102991M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
8146	39	Pride and Prejudice	eng	\N	Penguin Random House	2009	9781306865371	\N	\N	OL36212620M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
6013	1	Duna	por	BR	Aleph	2017	9788576573135	857657313X	https://covers.openlibrary.org/b/id/10368109-M.jpg	OL28969075M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
6014	1	Dune	eng	\N	Ace	\N	9780441007493	044100749X	\N	OL10256202M	\N	2026-11-25 20:23:23.802005+00	2026-11-25 20:23:23.802005+00
6015	7	Bratovščina prstana	slv	\N	Mladinska knjiga	2002	\N	8611162447	https://covers.openlibrary.org/b/id/15261270-M.jpg	OL62623424M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6016	7	The Lord Of The Rings: The Fellowship of the Ring	eng	\N	The Random House Publishing Group	1954	9780345339706	\N	\N	OL62622770M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6017	7	Gredzenu pavēlnieks. Gredzena brālība	\N	\N	Jumava	2002	9789984055794	\N	\N	OL62453970M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6018	7	The Fellowship of the Ring	eng	\N	HarperCollins Publishers	2022	9780008537722	\N	https://covers.openlibrary.org/b/id/15244480-M.jpg	OL62417661M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6019	7	The Fellowship of the Ring	\N	\N	Arotahi Agency	\N	9780008802370	\N	\N	OL61803720M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6020	7	Fellowship of the Ring	eng	\N	CreateSpace Independent Publishing Platform	2015	9781514296721	\N	\N	OL54863310M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6021	7	The Fellowship of the Ring Part One (U7040, 1968)	\N	\N	Ballantine	1968	\N	\N	\N	OL51499636M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6022	7	Aḥaṿat ha-ṭabaʻat	heb	\N	Zemorah-Bitan	1998	\N	\N	\N	OL59316732M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6023	7	The Fellowship of the ring	eng	\N	Ballantine Books	1978	\N	\N	https://covers.openlibrary.org/b/id/15258060-M.jpg	OL58729461M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6024	7	The Fellowship of the ring 	eng	\N	Ballantine Books, Inc.	1965	\N	\N	https://covers.openlibrary.org/b/id/14921825-M.jpg	OL58694636M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6025	7	The Fellowship of the Ring	eng	\N	\N	1973	\N	\N	\N	OL58675800M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6026	7	The Fellowship of the Ring	eng	\N	Houghton Mifflin Company, Boston	1966	\N	\N	\N	OL58834950M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6027	7	The fellowship of the ring	eng	\N	Ballantine Books, New York	1965	\N	\N	\N	OL58834956M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6028	7	Lord of the Rings	eng	\N	Warwick International Publishing House Ltd	2024	9781917100007	\N	\N	OL57770615M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6029	7	The Fellowship of the Ring	eng	\N	Ballantine Books	1973	\N	\N	\N	OL57683442M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6030	7	The fellowship of the ring	eng	\N	Houghton	1967	\N	\N	\N	OL58151321M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6031	7	The fellowship of the ring	eng	\N	George Allen	1961	\N	\N	\N	OL59346129M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6032	7	Хранители	rus	\N	Detskai͡a literatura	1982	\N	\N	\N	OL54483152M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6033	7	Fellowship of the Ring	eng	\N	Bound to Stay Bound Books	1993	9798855136401	\N	\N	OL53332909M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6034	7	Ḥavurat ha-Ṭabaʻat	heb	\N	Zemorah, Bitan, Modan	1979	\N	\N	\N	OL50255737M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6035	7	The Fellowship of the Ring / Hraniteli : Povest / Хранители	rus	\N	Радуга	1988	9785050022554	505002255X	\N	OL38228908M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6036	7	O Senhor dos Anéis: A Sociedade do Anel	por	PT	HarperCollins	2022	9789897773921	9897773924	https://covers.openlibrary.org/b/id/15120679-M.jpg	OL53723416M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6037	7	旅の仲間 下	jpn	\N	Hyōronsha	1986	9784566020573	4566020576	https://covers.openlibrary.org/b/id/12607063-M.jpg	OL37028360M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6038	7	Wladca Pierscieni t.1/3	\N	\N	Muza	\N	9788373194557	837319455X	https://covers.openlibrary.org/b/id/13915448-M.jpg	OL47329659M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6039	7	senor de los anillos	spa	\N	HarperCollins Publishers	2009	9780061756139	\N	\N	OL37374040M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6040	7	Señor de Los Anillos	spa	\N	Editorial Planeta, S. A.	2012	9786070712722	\N	https://covers.openlibrary.org/b/id/13344549-M.jpg	OL36784291M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6041	7	The Fellowship of the Ring	eng	\N	HarperCollins Publishers	2005	9780007770120	000777012X	https://covers.openlibrary.org/b/id/15173637-M.jpg	OL43079986M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6042	7	Fellowship of the Ring Collector's Edition	eng	\N	HarperCollins Publishers	2024	9780063412613	\N	https://covers.openlibrary.org/b/id/14656497-M.jpg	OL51097690M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6043	7	The Fellowship of the Ring	\N	\N	Houghton Mifflin Company, Boston	1966	\N	\N	\N	OL48117586M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6044	7	La Compagnia dell'Anello	ita	\N	Bompiani	2006	9788845232251	8845232255	https://covers.openlibrary.org/b/id/14627462-M.jpg	OL48101912M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6045	7	The Fellowship of the Ring (BBC Full-Cast Dramatization)	\N	\N	Random House Audio	2001	9780553714784	0553714783	\N	OL47756727M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6046	7	魔戒(第一部)	zho	\N	Yilin	2002	9787806572504	7806572503	https://covers.openlibrary.org/b/id/14627055-M.jpg	OL47715581M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6047	7	El Senyor Dels Anells I	cat	\N	Editorial Vicens Vives	2002	9788431668297	8431668296	https://covers.openlibrary.org/b/id/14031790-M.jpg	OL47431089M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6048	7	El Señor de los Anillos 1. La Comunidad del Anillo	spa	\N	Booket	2022	9788445013953	8445013955	https://covers.openlibrary.org/b/id/13601166-M.jpg	OL47181066M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6049	7	Le Seigneur des anneaux	fra	\N	Christian Bourgois editeur	2003	9782266132374	2266132377	https://covers.openlibrary.org/b/id/14626802-M.jpg	OL47064703M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6050	7	Sagan om Ringen	swe	\N	Norstedts	2001	9789172632189	9172632186	https://covers.openlibrary.org/b/id/14625943-M.jpg	OL47056363M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6051	7	THE FELLOWSHIP OF THE RING	\N	\N	Folio	1977	\N	\N	\N	OL46984527M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6052	7	The Fellowship of the Ring	\N	\N	Brand: Recorded Books	2000	9780788789533	0788789538	https://covers.openlibrary.org/b/id/13530646-M.jpg	OL47134995M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6053	7	The Fellowship of the Ring Being the First Part of the Lord of the Rings	\N	\N	Houghton Mifflin Company	1963	\N	\N	\N	OL45771282M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6054	7	The fellowship of the ring	eng	\N	Houghton Mifflin	1954	\N	\N	\N	OL45329550M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6055	7	El Señor de los Anillos nº 01/03 La Comunidad del Anillo	spa	\N	Minotauro	2022	9788445009598	8445009591	https://covers.openlibrary.org/b/id/13119310-M.jpg	OL44997341M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6056	7	El Señor de los Anillos nº 01/03 La Comunidad del Anillo	\N	\N	Minotauro	2023	9788445013557	8445013556	https://covers.openlibrary.org/b/id/13119311-M.jpg	OL44997342M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6057	7	The Fellowship of the Ring : The Classic Bestselling Fantasy Novel	\N	\N	HarperCollins	2021	9780008487300	0008487308	https://covers.openlibrary.org/b/id/13115590-M.jpg	OL44901349M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6058	7	The Fellowship of the Ring	\N	\N	Ballantine Books	1965	\N	\N	\N	OL43068733M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6059	7	La compagnia dell'anello	ita	\N	Bompiani	2021	9788830105263	8830105260	\N	OL39809261M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
7011	20	Harry Potter and the Philosopher's Stone	eng	\N	BBC Audiobooks	2002	9781855496705	1855496704	https://covers.openlibrary.org/b/id/906285-M.jpg	OL8993487M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6060	7	SEÑor de LOS ANILLOS 1. la Comunidad Del Anillo (TV Tie-In) - the LORD of the RINGS 1. the Fellowship of the Ring (TV Tie-in) (Spanish Edition)	spa	\N	Editorial Planeta, S. A.	2022	9786070792236	\N	https://covers.openlibrary.org/b/id/13599179-M.jpg	OL39403352M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6061	7	La comunidad del anillo	spa	\N	Minotauro	2009	9788445077498	844507749X	https://covers.openlibrary.org/b/id/15252992-M.jpg	OL38225355M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6062	7	Le Seigneur des Anneaux - tome 1 La Fraternité de l'Anneau	\N	\N	POCKET	2017	9782266282390	2266282395	https://covers.openlibrary.org/b/id/13151998-M.jpg	OL37929191M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6063	7	La fraternité de l'anneau	fra	\N	Christian Bourgois Editeur	2014	9782267027419	\N	https://covers.openlibrary.org/b/id/13152002-M.jpg	OL46524873M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6064	7	Le seigneur des anneaux T1 La communiaute de l'anneau	fra	\N	BOURGOIS	1983	9782267000924	226700092X	https://covers.openlibrary.org/b/id/12377434-M.jpg	OL35677531M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6065	7	The Fellowship of the Ring	\N	\N	Recorded Books, Inc.	2021	9781705047606	1705047602	https://covers.openlibrary.org/b/id/12372489-M.jpg	OL35668837M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6066	7	Die Kameraadskap Van Die Ring [AFRIKAANS]	afr	\N	Protea Boekhuis	2019	9781485309758	\N	\N	OL35550955M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6067	7	In de ban van de ring 1	nld	\N	Uitgeverij M	2002	9789022533758	9022533751	https://covers.openlibrary.org/b/id/14625573-M.jpg	OL35331220M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6068	7	La comunidad del anillo	spa	\N	Minotauro	2004	\N	8445073729	https://covers.openlibrary.org/b/id/10612017-M.jpg	OL31929342M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6069	7	El señor de los anillos I : la comunidad del anillo (2019)	spa	\N	Planeta Colombiana Editorial	2019	9789584280336	\N	https://covers.openlibrary.org/b/id/10511328-M.jpg	OL31013469M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6070	7	Drużyna Pierścienia	pol	\N	Muza Warszawskie Wydawnictwo Literackie	2015	9788377583036	\N	https://covers.openlibrary.org/b/id/9159973-M.jpg	OL27740560M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6071	7	Władca Pierścieni	pol	\N	Warszawskie Wydaw. Literackie Muza SA	2002	\N	8373191720	https://covers.openlibrary.org/b/id/14625953-M.jpg	OL51694871M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6072	7	The fellowship of the ring	eng	\N	Houghton Mifflin	1982	\N	0395489318	\N	OL18299598M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6073	7	The Fellowship of the Ring	eng	\N	Houghton Mifflin Company	1994	9780618002221	0618574948	https://covers.openlibrary.org/b/id/6308837-M.jpg	OL23077320M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6074	7	The Fellowship of the Ring	eng	\N	Grafton	1991	\N	0261102354	https://covers.openlibrary.org/b/id/14625938-M.jpg	OL21478444M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6075	7	COMUNIDAD DEL ANILLO, LA - SEÑOR DE LOS ANILLOS I	\N	\N	MINOTAURO	2007	9789505471140	9505471149	https://covers.openlibrary.org/b/id/8763027-M.jpg	OL27281190M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6076	7	Vlastelin Kolet︠s︡	rus	\N	"I︠A︡uza"	2002	\N	5040081766	\N	OL23018944M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6077	7	The Fellowship of the Ring	eng	\N	Unwin Books	1974	9780048231123	0048231126	https://covers.openlibrary.org/b/id/8173065-M.jpg	OL9228705M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6078	7	Fellowship of the Ring	eng	\N	Allen & Unwin	1954	\N	\N	\N	OL13761262M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6079	7	Eventyret om Ringen	dan	\N	Gyldendal Lyd	2010	9788702093698	8702093693	https://covers.openlibrary.org/b/id/8178108-M.jpg	OL26452593M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6080	7	The Fellowship of the Ring	eng	\N	Houghton Mifflin Harcourt	1994	9780544448933	0544448936	https://covers.openlibrary.org/b/id/8178144-M.jpg	OL26452620M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6081	7	Khraniteli Kol'tsa	rus	\N	AST	2004	9785170264155	5170264151	https://covers.openlibrary.org/b/id/13186942-M.jpg	OL12541182M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6082	7	La Compagnia dell'Anello	ita	\N	Bompiani	2000	9788845290404	8845290409	\N	OL24591555M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6083	7	The Fellowship of the Ring	eng	\N	Harper	2018	9780007322497	0007322496	https://covers.openlibrary.org/b/id/8177409-M.jpg	OL26452273M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6084	7	A sociedade do anel	por	BR	Martins Fontes	2013	9788580631012	8580631017	https://covers.openlibrary.org/b/id/8178141-M.jpg	OL26452619M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6085	7	The Fellowship of the Ring	eng	\N	HarperCollins	2012	9780007488315	0007488319	https://covers.openlibrary.org/b/id/10587033-M.jpg	OL26452617M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6086	7	De Reisgenoten	nld	\N	UITGEVERIJ MEULENHOFF	2004	9789460235306	9460235301	https://covers.openlibrary.org/b/id/8178132-M.jpg	OL26452611M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6087	7	El Señor de los Anillos I	\N	\N	Minotauro	1978	\N	8439596200	https://covers.openlibrary.org/b/id/7382799-M.jpg	OL25862969M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6088	7	Druzyna pierscienia	pol	\N	Literackie	2005	\N	8370799736	\N	OL16418946M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6089	7	Die Gefährten	deu	\N	Klett-Cotta	1972	9783608107135	3608107134	https://covers.openlibrary.org/b/id/8178145-M.jpg	OL26452621M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6090	7	The Fellowship of the Ring	eng	\N	Ballantine Books	1989	9789993175315	9993175315	\N	OL9206548M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6091	7	Die Gefährten	deu	\N	Hobbit Presse	2001	9783608955361	3608955364	\N	OL23097541M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6092	7	The Fellowship of the Ring	eng	\N	Houghton Mifflin Company	2003	\N	0618346252	https://covers.openlibrary.org/b/id/14393948-M.jpg	OL26889864M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6093	7	El Señor de los Anillos I	spa	\N	Ediciones Minotauro	2002	9788439596189	8439596200	https://covers.openlibrary.org/b/id/7284662-M.jpg	OL25483907M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6094	7	Le seigneur des anneaux	\N	\N	Folio	1993	9782070334797	2070334791	https://covers.openlibrary.org/b/id/8466848-M.jpg	OL26810132M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6095	7	La Communauté de l'Anneau	fra	\N	xx	2000	\N	\N	\N	OL24584294M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6096	7	The Fellowship of the Ring	eng	\N	Harper-Collins	1994	9780007149216	0007149212	https://covers.openlibrary.org/b/id/14656498-M.jpg	OL20784407M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6097	7	The lord of the rings	eng	\N	Houghton Mifflin Co.	1954	\N	0395082544	https://covers.openlibrary.org/b/id/5306363-M.jpg	OL15327355M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6098	7	La comunidad del anillo	spa	\N	Minotaur	2003	9789706906519	9706906517	\N	OL9179424M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6099	7	Ringens brorskap	nor	\N	Cappelen Damm Lydbok	2010	9788202336400	\N	https://covers.openlibrary.org/b/id/8178112-M.jpg	OL26452597M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6100	7	The Fellowship of the Ring	ind	\N	Gramedia Pustaka Utama	2016	9786020332260	6020332268	https://covers.openlibrary.org/b/id/8178155-M.jpg	OL26452664M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6101	7	Drużyna Pierścienia	pol	\N	Wydawnictwo Amber	2009	9788324132614	\N	https://covers.openlibrary.org/b/id/8457566-M.jpg	OL26801962M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6102	7	Die Gefährten	deu	\N	Hobbit Presse	2012	9783608939811	3608939814	https://covers.openlibrary.org/b/id/8178139-M.jpg	OL26452618M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6103	7	La Comunidad Del Anillo	spa	\N	Minotauro	2006	9788445075739	844507573X	https://covers.openlibrary.org/b/id/1047655-M.jpg	OL9131988M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6104	7	La Compagnia dell'anello	ita	\N	French & European Pubns	2002	9780828839815	0828839816	\N	OL8171920M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6105	7	Die Gefährten	deu	\N	Der Hörverlag	2006	9783899408867	3899408861	\N	OL26451924M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6106	7	The Fellowship of the Ring	eng	\N	Recorded Books	2011	9781461836148	146183614X	https://covers.openlibrary.org/b/id/8178118-M.jpg	OL26452599M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6107	7	La communauté de l'Anneau	fra	\N	Editions Flammarion	1998	9782070339761	2070339769	\N	OL12393325M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6108	7	The Fellowship of the Ring	eng	\N	Houghton Mifflin	1965	\N	\N	https://covers.openlibrary.org/b/id/14951350-M.jpg	OL4883007M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6109	7	די חברותא פון דעם פינגערל	yid	\N	Barry Goldstein	2014	9781500410223	1500410225	https://covers.openlibrary.org/b/id/8178146-M.jpg	OL26452624M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6110	7	Władca pieršcieni.	pol	\N	Zysk i S-Ka Wydawnictwo	2001	\N	8372981566	\N	OL16202631M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6111	7	La Communauté de l'Anneau	fra	\N	Folio Junior	2007	9782070612888	2070612880	https://covers.openlibrary.org/b/id/8177386-M.jpg	OL24298430M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6112	7	The Fellowship of the Ring	eng	\N	Large Print Press	2003	9781594130076	1594130078	https://covers.openlibrary.org/b/id/14573420-M.jpg	OL26451897M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6113	7	La comunidad del anillo	spa	\N	Minotauro	2012	9788445000663	8445000667	https://covers.openlibrary.org/b/id/8178120-M.jpg	OL26384839M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6114	7	The Fellowship of the Ring	eng	\N	Ballantine Books	1988	9780345008626	0345008626	\N	OL9678816M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6115	7	La comunidad del anillo	spa	\N	Minotauro	2001	9788445071403	8445071408	https://covers.openlibrary.org/b/id/8474026-M.jpg	OL9131874M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6116	7	Le Communaute de L'Anneau	fra	\N	Pocket	2003	9782266120999	2266120999	https://covers.openlibrary.org/b/id/980336-M.jpg	OL8890402M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6117	7	The Fellowship of the Ring	eng	\N	HarperCollins	1992	9780261102927	0261102923	https://covers.openlibrary.org/b/id/8174301-M.jpg	OL26450477M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6118	7	The Fellowship of the Rings	eng	\N	Ballantine Books	1999	9780345917430	034591743X	\N	OL10686522M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6119	7	The Fellowship of the Ring	eng	\N	Recorded Books	1990	9780788789816	0788789813	https://covers.openlibrary.org/b/id/7475863-M.jpg	OL25966404M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6120	7	Die Gefahrten	deu	\N	Klett-Cotta	2001	9783608933512	3608933514	https://covers.openlibrary.org/b/id/8175190-M.jpg	OL22054291M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6121	7	La Communauté de l'Anneau	fra	\N	Pocket	2002	9782266128049	2266128043	https://covers.openlibrary.org/b/id/980436-M.jpg	OL8890485M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6122	7	La Communeaute de l'Anneau	fra	\N	French & European Pubns	2000	9780828810548	0828810540	https://covers.openlibrary.org/b/id/14587094-M.jpg	OL8171839M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6123	7	Yüzük Kardeşliği	tur	\N	Metis Yayınları	1996	9789753421638	975342163X	https://covers.openlibrary.org/b/id/13128862-M.jpg	OL17238263M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6124	7	Die Gefahrten	deu	\N	French & European Pubns	2000	9780828865654	0828865655	\N	OL8171979M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6125	7	The Fellowship of the Ring	eng	\N	Recorded Books	1990	9781556903212	1556903219	\N	OL12034181M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6126	7	The Fellowship of the Ring	eng	\N	Houghton Mifflin Company	1993	9780395272237	0395272238	https://covers.openlibrary.org/b/id/8173716-M.jpg	OL26450216M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6127	7	Družina prstena	hrv	\N	Rubikon	2002	\N	8673480671	\N	OL19112575M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6128	7	The Fellowship of the Ring	eng	\N	Harper Collins	2001	9780007117116	0007117116	https://covers.openlibrary.org/b/id/8889-M.jpg	OL7261494M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6129	7	La comunidad del anillo	spa	\N	Turtleback Books Distributed by Demco Media	2001	9780606244237	0606244239	https://covers.openlibrary.org/b/id/4992254-M.jpg	OL9595965M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6130	7	The Fellowship of the Ring	eng	\N	Houghton Mifflin Company	2001	9780618134694	0618134697	\N	OL7603917M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6131	7	The Fellowship of the Ring	eng	\N	Recorded Books	1990	9780788739576	0788739573	https://covers.openlibrary.org/b/id/8174242-M.jpg	OL26450218M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6132	7	Die Gefahrten	deu	\N	Klett-Cotta	2001	9783608935417	360893541X	https://covers.openlibrary.org/b/id/8175144-M.jpg	OL9076610M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6133	7	La communauté de l'anneau	fra	\N	Pocket	1991	9782266046497	2266046497	https://covers.openlibrary.org/b/id/979591-M.jpg	OL8889789M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6134	7	The Fellowship of the Ring	eng	\N	Houghton Mifflin	1991	9780395647387	039564738X	https://covers.openlibrary.org/b/id/8174293-M.jpg	OL7467153M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6135	7	A Irmandade do Anel	por	PT	Europa-America	2002	9789721041028	9721041025	\N	OL18905181M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6136	7	La Communaute de L'Anneaux	fra	\N	Christian Bourgois editeur	2001	9782266115612	2266115618	https://covers.openlibrary.org/b/id/14626833-M.jpg	OL8890347M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6137	7	Die Gefährten	deu	\N	Klett-Cotta	2001	9783608934014	3608934014	\N	OL9076585M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6138	7	A Sociedade do Anel	por	BR	Martins Fontes	2002	9788533615557	8533615558	https://covers.openlibrary.org/b/id/8176050-M.jpg	OL9158225M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6139	7	La compagnia dell'anello	ita	\N	French & European Pubns	2002	9780785907428	0785907424	\N	OL11037701M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6140	7	A Irmandade do Anel	glg	\N	Xerias	2001	9788483026830	848302683X	https://covers.openlibrary.org/b/id/8175181-M.jpg	OL13320799M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6141	7	Comunidad Anillo	spa	\N	French & European Pubns	2000	9780828868990	0828868999	\N	OL11461843M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6142	7	The Fellowship of the Ring	eng	\N	Quality Paperback Book Club	1995	\N	\N	https://covers.openlibrary.org/b/id/8174315-M.jpg	OL26450490M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6143	7	The Fellowship of the Ring	eng	\N	HarperCollins	2001	9780007123827	0007123825	https://covers.openlibrary.org/b/id/8175158-M.jpg	OL22469028M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6144	7	The Fellowship of the Ring	eng	\N	Ballantine Books	1974	9780345235091	0345235096	\N	OL26449477M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6145	7	Die Gefährten	deu	\N	J.G. Cotta'sche, Buchhandlung Nachfolger GmbH	1996	9783608952124	3608952128	\N	OL9076659M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6146	7	The Fellowship of the Ring	eng	\N	Houghton Mifflin Company	1982	9780395489314	0395082544	https://covers.openlibrary.org/b/id/8173121-M.jpg	OL26449826M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
8147	39	Pride and Prejudice	eng	\N	Andrews UK Ltd.	2014	9781783337460	\N	\N	OL36213680M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
6147	7	The Fellowship of the Ring	eng	\N	George Allen and Unwin	1965	\N	\N	https://covers.openlibrary.org/b/id/8172077-M.jpg	OL26449207M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6148	7	The Fellowship of the Ring	eng	\N	Methuen	1972	9780458907502	0458907502	https://covers.openlibrary.org/b/id/8172450-M.jpg	OL26449391M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6149	7	The Fellowship of the Ring	eng	\N	Ballantine Books	1966	\N	\N	https://covers.openlibrary.org/b/id/8172059-M.jpg	OL26449183M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6150	7	The Fellowship of the Ring	eng	\N	Houghton Mifflin Company	1967	9780395082546	0395082544	https://covers.openlibrary.org/b/id/8172086-M.jpg	OL26449227M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6151	7	The Fellowship of the Ring	eng	\N	Turtleback Books	1986	9780808520764	\N	https://covers.openlibrary.org/b/id/7839261-M.jpg	OL26159487M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6152	7	The Fellowship of the Ring	eng	\N	George Allen & Unwin	1974	9780048230454	0048230456	https://covers.openlibrary.org/b/id/8172608-M.jpg	OL26449484M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6153	7	The Fellowship of the Ring	eng	\N	Ballantine Books	1974	9780345240323	0345240324	https://covers.openlibrary.org/b/id/8172604-M.jpg	OL26449483M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6154	7	A Gyuru Szovetsege	hun	\N	Gondolat	1981	9789632809632	9632809637	\N	OL13103887M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6155	7	The Fellowship of the Ring	eng	\N	Allen and Unwin	1968	\N	\N	\N	OL21428276M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6156	7	The Fellowship of the Ring	eng	\N	Houghton Mifflin Company	1967	\N	\N	https://covers.openlibrary.org/b/id/8172082-M.jpg	OL26449223M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6157	7	The Fellowship of the Ring	eng	\N	Ballantine Books	1965	\N	\N	https://covers.openlibrary.org/b/id/8172046-M.jpg	OL26449168M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6158	7	The Fellowship of the Ring	eng	\N	Ballantine Books	1985	9780345332080	0345332083	https://covers.openlibrary.org/b/id/8173644-M.jpg	OL10684788M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6159	7	The Fellowship of the Ring	eng	\N	Ballantine Books	1970	9780345020208	0345020200	https://covers.openlibrary.org/b/id/8172101-M.jpg	OL26449244M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6160	7	The Fellowship of the Ring	eng	\N	Houghton Mifflin	1981	9780395312674	0395312671	https://covers.openlibrary.org/b/id/8173156-M.jpg	OL21485714M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6161	7	La Comunidad del Anillo	spa	\N	Minotauro	2003	9788445070338	8445070339	https://covers.openlibrary.org/b/id/4910660-M.jpg	OL9131846M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6162	7	The Fellowship of the Ring	eng	\N	Unwin Paperbacks	1981	9780048231857	0048231851	https://covers.openlibrary.org/b/id/9262670-M.jpg	OL22837887M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6163	7	The Fellowship of the Ring	eng	\N	Ballantine Books	1973	9780345015334	0345015339	https://covers.openlibrary.org/b/id/8172068-M.jpg	OL26449194M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6164	7	The Fellowship of the Ring	eng	\N	Easton Press	1984	\N	\N	https://covers.openlibrary.org/b/id/8173643-M.jpg	OL26450100M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6165	7	The Fellowship of the Ring	eng	\N	Ballantine Books	1981	9780345296054	0345296052	https://covers.openlibrary.org/b/id/8173162-M.jpg	OL26449841M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6166	7	The Fellowship of the Ring	eng	\N	Folio Society	1977	\N	\N	https://covers.openlibrary.org/b/id/14656506-M.jpg	OL13893006M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6167	7	The Fellowship of the Ring	eng	\N	Ballantine Books	1980	0345272587	\N	https://covers.openlibrary.org/b/id/8173154-M.jpg	OL26449840M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6168	7	The Fellowship of the Ring	eng	\N	Ballantine Books	1966	\N	\N	https://covers.openlibrary.org/b/id/8172062-M.jpg	OL26449186M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6169	7	De Reisgenoten	nld	\N	Het Spectrum	1979	9789027401687	9027401683	https://covers.openlibrary.org/b/id/7070624-M.jpg	OL25209450M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6170	7	The Fellowship of the Ring	eng	\N	Unwin Paperbacks	1979	9780048231550	004823155X	\N	OL20943864M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6171	7	The Fellowship of the Ring	eng	\N	Perfection Learning	1977	9780812415582	0812415582	https://covers.openlibrary.org/b/id/13178482-M.jpg	OL11346299M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6172	7	The Fellowship of the Ring	eng	\N	Ballantine Books	1975	9780345247865	0345247868	https://covers.openlibrary.org/b/id/8172449-M.jpg	OL26449390M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6173	7	The Fellowship of the Ring	eng	\N	George Allen & Unwin	1966	\N	\N	https://covers.openlibrary.org/b/id/8172078-M.jpg	OL26449212M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6174	7	The Fellowship of the Ring	eng	\N	Houghton Mifflin Company	1967	\N	\N	https://covers.openlibrary.org/b/id/8172084-M.jpg	OL26449226M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6175	7	The Fellowship of the Ring	eng	\N	Houghton Mifflin Company	1954	\N	\N	https://covers.openlibrary.org/b/id/8171445-M.jpg	OL26448808M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6176	7	The Fellowship of the Ring	eng	\N	Houghton Mifflin	2001	9780618153985	0618153985	https://covers.openlibrary.org/b/id/393566-M.jpg	OL3969872M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6177	7	The Fellowship of the Ring	eng	\N	George Allen & Unwin	1956	\N	\N	https://covers.openlibrary.org/b/id/8171448-M.jpg	OL26448812M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6178	7	The Fellowship of the Ring	eng	\N	Ballantine Books	1975	9780345248275	0345248279	https://covers.openlibrary.org/b/id/8173084-M.jpg	OL10682347M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6179	7	The Fellowship of the Ring	eng	\N	Thorndike Press	2003	9780786251780	0786251786	https://covers.openlibrary.org/b/id/541024-M.jpg	OL3682825M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6180	7	The Fellowship of the Ring	eng	\N	Allen & Unwin	1954	\N	\N	https://covers.openlibrary.org/b/id/8171428-M.jpg	OL22266040M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6181	7	魔戒首部曲	zho	\N	Lian jing chu ban shi ye gong si	2001	9789570823363	9570823364	https://covers.openlibrary.org/b/id/8175176-M.jpg	OL23041688M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6182	7	The Fellowship of the Ring	eng	\N	HarperCollins Publishers Ltd	1998	9780261102316	0261102311	https://covers.openlibrary.org/b/id/14656499-M.jpg	OL10236387M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6183	7	The Fellowship of the Ring	eng	\N	ISIS Large Print Books	1991	9781850894148	1850894140	\N	OL8969576M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6184	7	The Fellowship of the Ring	eng	\N	HarperCollins	2003	9780007171972	0007171978	https://covers.openlibrary.org/b/id/7074458-M.jpg	OL22069376M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6185	7	The Fellowship of the Ring	eng	\N	George Allen & Unwin	1959	\N	\N	https://covers.openlibrary.org/b/id/8171449-M.jpg	OL26448814M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6186	7	Bractwo pierscienia	pol	\N	Zysk i S-ka	1996	9788371502415	8371502419	\N	OL19685717M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6187	7	The Fellowship of the Ring	eng	\N	Ace	1965	\N	\N	https://covers.openlibrary.org/b/id/8171459-M.jpg	OL26448821M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6188	7	The Fellowship of The Ring	eng	\N	Ballantine Books	1989	9780606006507	0606006508	\N	OL9370678M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6189	7	The Fellowship of the Ring	eng	\N	HarperCollins	2009	9780061917677	0061917672	https://covers.openlibrary.org/b/id/8177405-M.jpg	OL24281996M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6190	7	The Fellowship of the Ring	eng	\N	Houghton Mifflin	2002	9780618260515	061826051X	https://covers.openlibrary.org/b/id/394003-M.jpg	OL3777336M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6191	7	The Fellowship of the Ring	eng	\N	Ballantine Books	1972	9780345215338	0345015339	https://covers.openlibrary.org/b/id/8178163-M.jpg	OL10681593M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6192	7	Gospodar prstenova (dio prvi)	hrv	\N	Algoritam	2002	9789536166114	9536166119	\N	OL26383768M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6193	7	Mo jie shou bu qu	zho	\N	Lian jing chu ban shi ye gu fen you xian gong si	2012	9789570841008	9570841001	\N	OL27194455M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6194	7	De Reisgenoten	nld	\N	Mynx	2008	9789022531938	9022531937	https://covers.openlibrary.org/b/id/8666743-M.jpg	OL27047721M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6195	7	The Fellowship of the Ring	\N	\N	Harpercollins	2008	9780007269709	0007269706	https://covers.openlibrary.org/b/id/9363303-M.jpg	OL27974877M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6196	7	The Fellowship of the Ring	\N	\N	Paw Prints 2008-08-11	2008	9781439518366	143951836X	https://covers.openlibrary.org/b/id/10078899-M.jpg	OL28135328M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6197	7	The Fellowship of the Ring	\N	\N	HarperCollins	2014	9780008108298	0008108293	https://covers.openlibrary.org/b/id/10180804-M.jpg	OL28250998M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6198	7	The Lord of the Rings	\N	\N	Soundelux Audio Pub	1990	9781559350334	1559350334	https://covers.openlibrary.org/b/id/10290749-M.jpg	OL28342498M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6199	7	The Fellowship of the Ring	\N	\N	HarperCollins Publishers Limited	1996	9780261103382	0261103385	https://covers.openlibrary.org/b/id/10290015-M.jpg	OL28341708M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6200	7	Fellowship of the Ring	eng	\N	HarperCollins Publishers Limited	2005	9780007203543	\N	https://covers.openlibrary.org/b/id/14656488-M.jpg	OL28430632M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6201	7	La communauté de l'anneau - tome 1	fra	\N	Pocket	1993	9782266026550	2266026550	https://covers.openlibrary.org/b/id/10290885-M.jpg	OL28342653M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6202	7	指輪物語 第1部 旅の仲間	\N	\N	unknown	1992	9784566023505	4566023508	https://covers.openlibrary.org/b/id/9881510-M.jpg	OL28122232M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6203	7	The Fellowship of the Ring	eng	\N	Ballantine Books	1969	\N	\N	https://covers.openlibrary.org/b/id/10587260-M.jpg	OL31906290M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6204	7	The Fellowship of the Ring	eng	\N	HarperCollins Publishers Limited	2020	9780008376123	0008376123	https://covers.openlibrary.org/b/id/14844407-M.jpg	OL29486343M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6205	7	The Fellowship of the Ring	eng	\N	Collins	2001	9780007680856	0007680856	https://covers.openlibrary.org/b/id/10978060-M.jpg	OL32349039M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6206	7	The Fellowship of the Ring	bul	\N	Barд	2002	\N	9545853468	https://covers.openlibrary.org/b/id/11222993-M.jpg	OL32582177M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6207	7	The Lord of the Rings Fellowship of the Ring	\N	\N	Harpercollins Pub Ltd	2002	9780007136599	0007136595	https://covers.openlibrary.org/b/id/10840420-M.jpg	OL32186890M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6208	7	The Lord of the Rings Fellowship of the Ring	\N	\N	Harpercollins Pub Ltd	2002	9780007136636	0007136633	https://covers.openlibrary.org/b/id/10627914-M.jpg	OL31947153M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6209	7	The Fellowship of the Ring	eng	\N	HarperCollinsPublishers	2011	9780261103573	\N	https://covers.openlibrary.org/b/id/11204800-M.jpg	OL32559371M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6210	7	The Fellowship of the Ring	\N	\N	Brand: Listening Library	2001	9780807207277	0807207276	https://covers.openlibrary.org/b/id/10846319-M.jpg	OL32195088M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6211	7	The Fellowship of the Ring	\N	\N	HighBridge Audio	2021	9781665182706	1665182709	https://covers.openlibrary.org/b/id/10877334-M.jpg	OL32247056M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6212	7	Seigneur anneaux t1	\N	\N	Pocket	1998	9782266017510	2266017519	https://covers.openlibrary.org/b/id/10703594-M.jpg	OL32037680M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6213	7	Die Gefährten	deu	\N	Klett-Cotta	1988	\N	3608952128	https://covers.openlibrary.org/b/id/12568195-M.jpg	OL36684914M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6214	7	Le Seigneur des Anneaux, Tome 1 : La Fraternité de l'Anneau	fra	\N	Christian Bourgois	2014	9782267027006	2267027003	https://covers.openlibrary.org/b/id/12689071-M.jpg	OL37348376M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6215	7	Fellowship of the Ring	eng	\N	Houghton Mifflin Harcourt Publishing Company	2005	9781484482353	\N	\N	OL34101157M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6216	7	Fellowship of the Ring	eng	\N	Houghton Mifflin Harcourt Publishing Company	2012	9780547952017	\N	\N	OL33998433M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6217	7	The Fellowship of the Ring	\N	\N	Highbridge Audio and Blackstone Publishing	2021	9781665182713	1665182717	https://covers.openlibrary.org/b/id/11967033-M.jpg	OL33348132M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6218	7	Fellowship of the Ring	eng	\N	HarperCollins Publishers	2009	9780061917721	\N	https://covers.openlibrary.org/b/id/14656496-M.jpg	OL37371070M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6219	7	Fellowship of the Ring	eng	\N	HarperCollins Publishers	2009	9780061917707	\N	https://covers.openlibrary.org/b/id/14656494-M.jpg	OL37371068M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6220	7	Fellowship of the Ring	eng	\N	HarperCollins Publishers	2009	9780061917691	\N	https://covers.openlibrary.org/b/id/14656493-M.jpg	OL37363401M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6221	7	Fellowship of the Ring	eng	\N	HarperCollins Publishers	2009	9780061917714	\N	https://covers.openlibrary.org/b/id/14656495-M.jpg	OL37363398M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6222	7	Fellowship of the Ring	eng	\N	Houghton Mifflin Harcourt Trade & Reference Publishers	2012	9781299884939	\N	\N	OL37177244M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6223	7	Lord of the Rings Fellowship of the Ring	\N	\N	Bbc Book Pub	2001	9780563536543	0563536543	\N	OL37811625M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6224	7	The Lord of the Rings Fellowship of the Ring	\N	\N	Harpercollins Pub Ltd	2001	9780007127429	0007127421	\N	OL37775722M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6225	7	Fellowship of the Ring	eng	\N	HarperCollins Publishers Limited	2022	9780008567125	\N	https://covers.openlibrary.org/b/id/14656492-M.jpg	OL38343187M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6226	7	Fellowship of the Ring	eng	\N	HarperCollins Publishers Limited	2013	9780007522903	\N	https://covers.openlibrary.org/b/id/14656489-M.jpg	OL37953526M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6227	7	Fellowship of the Ring (the Lord of the Rings, Book 1)	eng	\N	HarperCollins Publishers Limited	2022	9780008537777	\N	https://covers.openlibrary.org/b/id/14656491-M.jpg	OL38792905M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6228	7	The Fellowship of the Ring	eng	\N	Houghton Mifflin	2005	9780007203581	0007203586	https://covers.openlibrary.org/b/id/14617433-M.jpg	OL37659928M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6229	7	The Fellowship of the Ring	eng	\N	Ballantine Books	2001	\N	0345339703	https://covers.openlibrary.org/b/id/13133784-M.jpg	OL45506127M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6230	7	A Sociedade do Anel	por	BR	HarperCollins Brasil	2022	9786555110968	\N	https://covers.openlibrary.org/b/id/13326883-M.jpg	OL46835757M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6231	7	The Fellowship of the Ring	eng	\N	Ballantine Books	1976	9780345253439	0345253434	https://covers.openlibrary.org/b/id/14624299-M.jpg	OL10682513M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6232	7	The Fellowship of the Ring	eng	\N	Ballantine Books	1977	9780345272584	0345272587	https://covers.openlibrary.org/b/id/14573414-M.jpg	OL10682854M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6233	7	The Fellowship of the Ring	eng	\N	Houghton Mifflin Company	2004	9780618574940	0618574948	https://covers.openlibrary.org/b/id/11387256-M.jpg	OL7605824M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6234	7	The Fellowship of the Ring	eng	\N	HarperCollins Publishers	1999	9780261102354	0261102354	https://covers.openlibrary.org/b/id/14624461-M.jpg	OL10236390M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6235	7	The Fellowship of the Ring	eng	\N	Mariner Books	1994	9780547928210	0547928211	https://covers.openlibrary.org/b/id/12373902-M.jpg	OL26452600M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6236	7	The Fellowship of the Ring	eng	\N	Collins	2001	9780007129706	000712970X	https://covers.openlibrary.org/b/id/8311425-M.jpg	OL7261842M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6237	7	El Señor de los Anillos	spa	\N	Minotauro	2002	9789505470679	9505470673	https://covers.openlibrary.org/b/id/14625729-M.jpg	OL9137998M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6238	7	La Communauté de l'anneau	fra	\N	Christian Bourgois	1972	9782253011392	2253011398	https://covers.openlibrary.org/b/id/9293866-M.jpg	OL27925408M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6239	7	The Fellowship of the Ring	eng	\N	Quality Paperback Book Club	2001	9780965307758	0965307751	https://covers.openlibrary.org/b/id/8259344-M.jpg	OL8529332M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6240	7	La sociedá del aniellu	ast	\N	Trabe	2020	9788418286346	8418286342	https://covers.openlibrary.org/b/id/12639903-M.jpg	OL37069158M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6241	7	Der Herr der Ringe	deu	\N	Hobbit Presse Klett Kotta	1979	9783129081808	3129081801	https://covers.openlibrary.org/b/id/14625548-M.jpg	OL32926426M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6242	7	The Fellowship of the Ring	eng	\N	Mariner Books | Houghton Mifflin Harcourt	2020	9780358380238	0358380235	https://covers.openlibrary.org/b/id/12639909-M.jpg	OL29848958M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6243	7	The Fellowship of the Ring	eng	\N	Ballantine Books	1970	\N	\N	https://covers.openlibrary.org/b/id/10654746-M.jpg	OL24212887M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6244	7	The Fellowship of the Ring	eng	\N	Houghton Mifflin Company	2002	9780618260263	0618260269	https://covers.openlibrary.org/b/id/9293479-M.jpg	OL27925321M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6245	7	Eventyret om ringen	dan	\N	Gyldendal	2021	9788702347036	\N	https://covers.openlibrary.org/b/id/14627047-M.jpg	OL51708578M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6246	7	O Senhor dos Anéis: A Sociedade do Anel	por	BR	Harper Collins	2019	9788595084759	8595084750	https://covers.openlibrary.org/b/id/15129594-M.jpg	OL37925388M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6247	7	魔戒现身	zho	\N	Ylin	2014	9787544730426	7544730425	https://covers.openlibrary.org/b/id/9293519-M.jpg	OL27925331M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6248	7	El Señor de los Anillos	spa	\N	Minotauro	2012	9786070704628	\N	https://covers.openlibrary.org/b/id/14625748-M.jpg	OL51693993M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6249	7	The Fellowship of the Ring	eng	\N	Del Rey	2022	9780593500484	\N	https://covers.openlibrary.org/b/id/14627452-M.jpg	OL38403116M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6250	7	The Fellowship of the Ring	eng	\N	Houghton Mifflin Company	1987	\N	0395489318	https://covers.openlibrary.org/b/id/14624643-M.jpg	OL51688575M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6251	7	The Fellowship of the Ring	eng	\N	Houghton Mifflin Company	1978	\N	0395272238	https://covers.openlibrary.org/b/id/14627526-M.jpg	OL51711327M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6252	7	The Fellowship of the Ring	eng	\N	HarperCollins Publishers	1999	\N	0261102354	https://covers.openlibrary.org/b/id/14625638-M.jpg	OL51693824M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6253	7	The Fellowship of the Ring	eng	\N	William Morrow	2022	9780063270886	\N	https://covers.openlibrary.org/b/id/14627522-M.jpg	OL38060565M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6254	7	The Fellowship of the Ring	eng	\N	George Allen & Unwin Ltd	1970	\N	0048230456	https://covers.openlibrary.org/b/id/14627517-M.jpg	OL51711288M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6255	7	The Fellowship of the Ring	eng	\N	HarperCollins Publishers	2020	9780008376062	\N	https://covers.openlibrary.org/b/id/14625955-M.jpg	OL30164401M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6256	7	The Fellowship of the Ring	eng	\N	Ted Smart	1997	9780007637676	0007637675	https://covers.openlibrary.org/b/id/11387292-M.jpg	OL32760531M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6257	7	The Fellowship of the Ring	eng	\N	HarperCollins Publishers	2012	9780007488308	0007488300	https://covers.openlibrary.org/b/id/14624693-M.jpg	OL27278999M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6258	7	The Fellowship of the Ring	eng	\N	Houghton Mifflin Company	\N	\N	\N	https://covers.openlibrary.org/b/id/10650895-M.jpg	OL31973527M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6259	7	The Fellowship of the Ring	eng	\N	George Allen & Unwin Ltd	1963	\N	\N	https://covers.openlibrary.org/b/id/14627060-M.jpg	OL51708686M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6260	7	The Fellowship of the Ring	eng	\N	George Allen & Unwin Ltd	1967	\N	\N	https://covers.openlibrary.org/b/id/14627465-M.jpg	OL51711135M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6261	7	The Fellowship of the Ring	eng	\N	Ballantine Books	1970	\N	\N	https://covers.openlibrary.org/b/id/14627069-M.jpg	OL51708768M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6262	7	The Fellowship of the Ring	eng	\N	Guild Publishing	1988	\N	\N	https://covers.openlibrary.org/b/id/15207781-M.jpg	OL51711614M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6263	7	The Fellowship of the Ring	spa	\N	Texto Online	2001	\N	\N	\N	OL28162243M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6264	7	The Fellowship of the Ring	eng	\N	Folio Society	2002	\N	\N	https://covers.openlibrary.org/b/id/14626636-M.jpg	OL51696591M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6265	7	O Senhor dos Anéis	por	BR	Martins Fontes	2001	9788533613379	8533613377	https://covers.openlibrary.org/b/id/14628326-M.jpg	OL9158209M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6266	7	In de Ban van de Ring: Eerste Boek	nld	\N	Uitgeverij M	2002	9789022533963	9022533964	https://covers.openlibrary.org/b/id/10977821-M.jpg	OL32348960M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6267	7	Le Seigneur des anneaux	fra	\N	Christian Bourgeois éditeur	2001	9782266070614	2266070614	https://covers.openlibrary.org/b/id/14624671-M.jpg	OL8889882M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6268	7	Le seigneur des anneaux	fra	\N	Christian Bourgois editeur	2001	9782070515790	2070515796	https://covers.openlibrary.org/b/id/14624645-M.jpg	OL8840001M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6269	7	Le Seigneur des Anneaux	fra	\N	Christian Bourgois editeur	2010	9782266154116	2266154117	https://covers.openlibrary.org/b/id/14625520-M.jpg	OL27100714M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6270	7	Le seigneur des anneaux	fra	\N	Christian Bourgois	2000	9782266107983	2266107984	https://covers.openlibrary.org/b/id/10587056-M.jpg	OL18928910M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6271	7	魔戒(指环王)	zho	\N	Yi lin chu ban she	2002	9787806573976	7806573976	https://covers.openlibrary.org/b/id/10210983-M.jpg	OL28255957M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6272	7	The fellowship of the ring	eng	\N	Ballantine Books	1973	\N	0345339703	\N	OL20932268M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6273	7	The Fellowship of the Ring	eng	\N	Houghton Mifflin Company	2001	9780618129034	0618129030	https://covers.openlibrary.org/b/id/8474031-M.jpg	OL13569251M	\N	2026-11-25 20:23:29.329145+00	2026-11-25 20:23:29.329145+00
6274	11	Hobit ali Tja in spet nazaj	slv	\N	Mladinska knjiga	2011	9788611171982	\N	https://covers.openlibrary.org/b/id/15261276-M.jpg	OL62623719M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6275	11	Гобіт, або туди і звідти	ukr	\N	Астролябія	2020	9786176642145	\N	https://covers.openlibrary.org/b/id/15231842-M.jpg	OL62190138M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6276	11	The Hobbit	\N	\N	The Random House Publishing Group	1937	9780345339683	\N	https://covers.openlibrary.org/b/id/15214278-M.jpg	OL61641547M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6277	11	De hobbit	nld	\N	Uitgeverij Meulenhoff	2003	9789460923821	\N	https://covers.openlibrary.org/b/id/15108076-M.jpg	OL59691274M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6278	11	De Hobbit	nld	\N	Uitgeverij Het Spectrum	1984	\N	9027400431	https://covers.openlibrary.org/b/id/15108065-M.jpg	OL59690711M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6279	11	O Hobbit	por	BR	HarperCollins	2019	9788595084742	\N	https://covers.openlibrary.org/b/id/15027388-M.jpg	OL58964146M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6280	11	The hobbit, or, There and back again	eng	\N	Ballantine Books	1966	\N	\N	\N	OL5526619M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6281	11	Hobbit Deluxe Illustrated Edition	eng	\N	HarperCollins Publishers	2024	9780063417069	\N	\N	OL51388456M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6282	11	Hobbit Collector's Edition	eng	\N	HarperCollins Publishers	2024	9780063396203	\N	\N	OL50965438M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6283	11	Hobbit	eng	\N	HarperCollins Publishers	2024	9780063388468	\N	\N	OL50718853M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6284	11	Hobbit	eng	\N	HarperCollins Publishers	2024	9780063388475	\N	\N	OL50730520M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6285	11	Hobiṭ	heb	\N	Zemorah, Bitan, Modan	1977	\N	\N	\N	OL50255736M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6286	11	Harpercollins The Hobbit (Film Tie-In Edition)	\N	\N	HarperCollins	2014	9780008118044	0008118043	\N	OL50226013M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6287	11	Lo Hobbit annotato	ita	\N	Bompiani	2012	9788845271403	\N	https://covers.openlibrary.org/b/id/14545977-M.jpg	OL49948384M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6288	11	The Hobbit (Ballantine Books, U7039)	\N	\N	Ballantine Books	1968	\N	\N	\N	OL49805819M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6289	11	Hobbit Illustrated by the Author	eng	\N	HarperCollins Publishers	2023	9780063347540	\N	\N	OL48826368M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6290	11	Hobbit	eng	\N	Zondervan	2003	9780007172733	\N	\N	OL48608134M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6291	11	Der hobit	yid	\N	Evertype	2015	9781782011200	178201120X	https://covers.openlibrary.org/b/id/14627535-M.jpg	OL47793582M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6292	11	Le Hobbitt - LIvre audio 2 CD MP3	fra	\N	French and European Publications Inc	2012	9782356414915	2356414916	https://covers.openlibrary.org/b/id/14143350-M.jpg	OL47527256M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6293	11	Хоббит	rus	\N	Olimp	1993	9785878600125	5878600129	https://covers.openlibrary.org/b/id/14626140-M.jpg	OL45667604M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6294	11	Chobbit ili Tuda i obratno	rus	\N	Der Kurier der Zarin	2002	9785170075300	5170075308	\N	OL44428942M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6295	11	O Hobbit	por	BR	HarperCollins	2019	9788595086081	8595086087	https://covers.openlibrary.org/b/id/14849956-M.jpg	OL43069192M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6296	11	Hobbit, czyli tam i z powrotem	pol	\N	Iskry	2004	9788320717501	8320717507	https://covers.openlibrary.org/b/id/14597944-M.jpg	OL42989611M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6297	11	An Hobys, pò, An Fordh Dy ha Tre Arta	cor	\N	Evertype	2014	9781782010890	1782010890	\N	OL40039753M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6298	11	Ka hopita	haw	\N	Evertype	2016	9781782010913	1782010912	https://covers.openlibrary.org/b/id/14842720-M.jpg	OL39202180M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6299	11	Hobbitus Ille	lat	\N	HarperCollins Publishers Limited	2012	9780007485949	\N	\N	OL37948109M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6300	11	Hobbit (1 Year)	eng	\N	Houghton Mifflin Harcourt Publishing Company	1938	9780544120020	\N	\N	OL37398256M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6301	11	Hobbit (Part 1 and 2) Slipcase	eng	\N	HarperCollins Publishers Limited	2012	9780007488513	\N	\N	OL36199536M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6302	11	An Hobad, nó Anonn agus Ar Ais Arís	gle	\N	Evertype	2012	9781904808909	1904808905	https://covers.openlibrary.org/b/id/11352603-M.jpg	OL32725577M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6303	11	An Hobad, nó Anonn Agus ar Ais Arís	\N	\N	Evertype	2013	9781782010333	1782010335	https://covers.openlibrary.org/b/id/12565139-M.jpg	OL36679073M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6304	11	Hobbitul	ron	\N	Editura Rao	2011	9786066093682	6066093681	https://covers.openlibrary.org/b/id/10831713-M.jpg	OL32170262M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6305	11	Hobbit, Ra đi va trở về	vie	\N	Văn hóa-Thông tin	2009	\N	\N	\N	OL30733835M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6306	11	De Hobbit	\N	\N	\N	2008	9789022543207	902254320X	https://covers.openlibrary.org/b/id/10293565-M.jpg	OL28345239M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6307	11	The Hobbit	eng	\N	Mariner Books	1966	\N	054792822X	https://covers.openlibrary.org/b/id/14624642-M.jpg	OL26456609M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6308	11	Hobitti	fin	\N	WSOY	2001	\N	951022359X	https://covers.openlibrary.org/b/id/6392156-M.jpg	OL24244614M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6309	11	The hobbit 50th anniversary 1937-1987	eng	\N	Unwin Hyman	1987	\N	\N	\N	OL13896990M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6310	11	Hobbit, Ili Tuda I Obratno	rus	\N	OLMA PRESS Education	2003	\N	5948490904	https://covers.openlibrary.org/b/id/5203712-M.jpg	OL12617847M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6311	11	El Hobbit	spa	\N	Circulo de Lectores	1983	\N	842261586X	https://covers.openlibrary.org/b/id/7013820-M.jpg	OL25175071M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6312	11	Der Hobbit	deu	\N	Klett-Cotta	2010	9783608938180	\N	https://covers.openlibrary.org/b/id/7002664-M.jpg	OL25159204M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6313	11	ホビットの冒険	jpn	\N	Iwanami Shoten	1999	\N	400026463X	\N	OL23032214M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6314	11	Hobit	ces	\N	Odeon	1991	\N	8020702628	\N	OL22940107M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6315	11	El hobbit	spa	\N	Minotauro	1985	\N	9684460368	\N	OL22942197M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6316	11	Khobbit, ili, Tuda i obratno	rus	\N	Izd-vo AST	2003	\N	5170104936	\N	OL23037147M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6317	11	Bilbo le Hobbit	\N	\N	French & European Pubns	1988	9780785922056	0785922059	https://covers.openlibrary.org/b/id/13810047-M.jpg	OL11038748M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6318	11	El Hobbit / The Hobbit	spa	\N	Minotauro	2005	9789505470631	9505470630	https://covers.openlibrary.org/b/id/1052113-M.jpg	OL9137994M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6319	11	El Hobbit / the Hobbit	spa	\N	Turtleback Books Distributed by Demco Media	2002	9780606244268	0606244263	https://covers.openlibrary.org/b/id/5080667-M.jpg	OL10925422M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6320	11	Bilbo Le Hobbit	fra	\N	Hachette	\N	9782010147807	2010147804	\N	OL9403108M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6321	11	Bilbo le Hobbit	fra	\N	Christian Bourgois	2002	9782267013177	2267013177	https://covers.openlibrary.org/b/id/980929-M.jpg	OL8890613M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6322	11	Hobbito no bōken / J.R.R. Tōrukin saku ; Seta Teiji yaku.	jpn	\N	Iwanami	1979	\N	4001120887	\N	OL23029810M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6323	11	El Hobbit	spa	\N	Ediciones Minotauro	2000	9788445070376	8445070371	https://covers.openlibrary.org/b/id/1047600-M.jpg	OL9131849M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6324	11	Hobbum, ulu Tuda u obramno.	rus	\N	Adelphi Edizioni	2001	\N	5170104936	\N	OL20319069M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6325	11	Bilbo le Hobbit	fra	\N	Stock	1969	\N	2010147804	\N	OL21755817M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6326	11	Khobbit, ili, Tuda i obratno	rus	\N	Azbuka-klassika	2003	\N	5699006001	https://covers.openlibrary.org/b/id/13711613-M.jpg	OL23070303M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6327	11	Hobbit, czyli, Tam i z powrotem	pol	\N	Iskry	1991	\N	8320706149	https://covers.openlibrary.org/b/id/13678785-M.jpg	OL23040293M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6328	11	Der Kleine Hobbit	deu	\N	DTV	\N	\N	3790301337	\N	OL22146871M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6329	11	Khobbit, ili, Tuda i obratno	rus	\N	"Detskai︠a︡ lit-ra"	1991	\N	5080000988	\N	OL22950280M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6330	11	Bilbo le hobbit	fra	\N	Le livre de poche	1989	\N	2253049417	\N	OL22735149M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6331	11	El Hobbit	spa	\N	Public Square Books	2004	9781594970719	1594970718	https://covers.openlibrary.org/b/id/873604-M.jpg	OL8880047M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6332	11	Khobbit, ili, Tuda i obratno	rus	\N	ĖKSMO	2004	\N	5699012907	\N	OL23070273M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6333	11	Der kleine Hobbit	deu	\N	Deutscher Taschenbuch Verlag	1974	\N	3790301337	https://covers.openlibrary.org/b/id/9360580-M.jpg	OL14449234M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6334	11	El hobbit (Spanish Edition)	\N	\N	Rayo	2009	9780061756269	0061756261	https://covers.openlibrary.org/b/id/6300174-M.jpg	OL24085138M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6335	11	Der Kleine Hobbit	deu	\N	Distribooks	2002	9783423071512	3423071516	https://covers.openlibrary.org/b/id/1002701-M.jpg	OL9032161M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6336	11	Der kleine Hobbit	deu	\N	Deutscher Taschenbuch	1974	\N	3423071516	\N	OL21826254M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6337	11	Der Kleine Hobbit	deu	\N	Deutscher Taschenbuch Verlag GmbH & Co.	2004	9783423085595	3423085592	https://covers.openlibrary.org/b/id/1002785-M.jpg	OL9032213M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6338	11	Hobbito no bōken	jpn	\N	Iwanami Shoten	2002	\N	4001140586	https://covers.openlibrary.org/b/id/10291172-M.jpg	OL16355411M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6339	11	Bilbo le Hobbit	fra	\N	Glénat	2001	9782723436106	2723436101	\N	OL9786395M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6340	11	El Hobbit	spa	\N	Minotauro	2002	9788445073803	844507380X	https://covers.openlibrary.org/b/id/10612061-M.jpg	OL9131936M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6341	11	Bilbo le Hobbit	fra	\N	Christian Bourgois	2002	9782267014143	2267014149	https://covers.openlibrary.org/b/id/2154274-M.jpg	OL9604991M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6342	11	Bilbo le Hobbit	\N	\N	Casterman	1999	9782203553934	2203553936	https://covers.openlibrary.org/b/id/2143333-M.jpg	OL9443590M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6343	11	Hobitten eller Ud og hjem igen	dan	\N	Gyldendal	1975	\N	8700050210	\N	OL20889660M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6344	11	The Hobbit	eng	\N	Klett	2001	9783125777705	3125777704	https://covers.openlibrary.org/b/id/996169-M.jpg	OL9018092M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6345	11	The Hobbit	\N	\N	Grafton	1990	9780044408123	0044408129	\N	OL9228308M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6346	11	The annotated hobbit	eng	\N	Houghton Mifflin	2002	\N	0618134700	\N	OL23246795M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6347	11	The hobbit, or, There and back again	eng	\N	Thorndike Press	2003	\N	0786251778	https://covers.openlibrary.org/b/id/541023-M.jpg	OL3567009M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6348	11	The Hobbit [UNABRIDGED]	eng	\N	Recorded Books	2002	9781402536946	1402536941	https://covers.openlibrary.org/b/id/751410-M.jpg	OL8373889M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6349	11	The Hobbit	\N	\N	Grafton	1984	9780048232731	0048232734	https://covers.openlibrary.org/b/id/7010270-M.jpg	OL9228732M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6350	11	The Hobbit	eng	\N	Turtleback Books Distributed by Demco Media	2002	9780606212342	0606212345	https://covers.openlibrary.org/b/id/5080697-M.jpg	OL10925146M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6351	11	The Hobbit	\N	\N	Perfection Learning Prebound	1977	9780812415834	0812415833	https://covers.openlibrary.org/b/id/13518328-M.jpg	OL11346306M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6352	11	The Hobbit	eng	\N	Ulverscroft Large Print	1982	9780708980651	0708980651	\N	OL9386429M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6353	11	Hobbit	eng	\N	Tandem Library	2001	9780613881654	0613881656	\N	OL7602066M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6354	11	The hobbit, or, There and back again	eng	\N	Houghton Mifflin Co.	1997	\N	0395071224	\N	OL18360267M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6355	11	The Hobbit	\N	\N	Ballantine Books	1988	9780345008619	0345008618	\N	OL10680912M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6356	11	The hobbit	eng	\N	CollinsEducational	1993	\N	0003300900	https://covers.openlibrary.org/b/id/9261037-M.jpg	OL22452236M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6357	11	The Hobbit	eng	\N	HarperFestival	1999	9780694014361	0694014362	https://covers.openlibrary.org/b/id/444682-M.jpg	OL7759555M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6358	11	The Hobbit	\N	\N	HarperCollins Audio	1993	9780001046764	0001046764	https://covers.openlibrary.org/b/id/28-M.jpg	OL9209105M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6359	11	The Hobbit	eng	\N	BBS Publishing Corporation	1993	9780883657461	0883657465	https://covers.openlibrary.org/b/id/13742224-M.jpg	OL8181272M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6360	11	Hobbit or There and Back Again	eng	\N	Eclipse Books	1989	9780913035801	0913035807	\N	OL8321425M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6361	11	Hobbit	eng	\N	Tandem Library	2003	9780613536844	0613536843	https://covers.openlibrary.org/b/id/5082430-M.jpg	OL10952411M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6362	11	The hobbit	eng	\N	Longmans	1968	\N	0582186552	\N	OL22788094M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6363	11	The Hobbit	rus	\N	AST	2006	9785170162710	5170162715	https://covers.openlibrary.org/b/id/13943210-M.jpg	OL12538901M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6364	11	Bilbo	swe	\N	PAN/Rabén & Sjögren	2000	\N	917263071X	https://covers.openlibrary.org/b/id/6671651-M.jpg	OL24486716M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6365	11	The hobbit, or, There and back again	eng	\N	H. N. Abrams	1977	\N	0810910608	https://covers.openlibrary.org/b/id/10290623-M.jpg	OL4564473M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6366	11	Der kleine Hobbit	deu	\N	dtv	2001	\N	3423071516	https://covers.openlibrary.org/b/id/6617573-M.jpg	OL24374464M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6367	11	The Hobbit, or, There and back again	eng	\N	Eclipse Books	1990	\N	0345368584	\N	OL18565780M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6368	11	The Hobbit	eng	\N	Soundelux Audio Publishing	1982	9785550277683	5550277689	\N	OL12552002M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6369	11	The Hobbit	eng	\N	DH Audio	1994	9780886463564	0886463564	https://covers.openlibrary.org/b/id/683157-M.jpg	OL8195345M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6370	11	The Hobbit	eng	\N	Houghton Mifflin	2012	9780618968633	0618968636	https://covers.openlibrary.org/b/id/9261044-M.jpg	OL18291983M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6371	11	The Hobbit	eng	\N	Listening Library	2001	9780807205266	0807205265	\N	OL7946036M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6372	11	The Hobbit	eng	\N	Houghton Mifflin Company	1987	9780395454022	0395454026	\N	OL7466434M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6373	11	The Hobbit	eng	\N	Houghton Mifflin	2000	9780618087853	0618087850	https://covers.openlibrary.org/b/id/1324456-M.jpg	OL7603640M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6374	11	Hobbit	eng	\N	Tandem Library	1999	9780613870665	0613870662	\N	OL10977379M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6375	11	Hobbit	eng	\N	Tandem Library	1989	9780613827355	061382735X	\N	OL7601880M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6376	11	The hobbit, or, There and back again	eng	\N	Houghton Mifflin	1938	\N	\N	\N	OL6366662M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6377	11	The Hobbit	eng	\N	Recorded Books	2001	9780788789823	0788789821	https://covers.openlibrary.org/b/id/549860-M.jpg	OL8151617M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6378	11	Hobbit	\N	\N	World Pubns	1990	9780792443483	0792443489	\N	OL11152615M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6379	11	The Hobbit	eng	\N	Houghton Mifflin	2021	9780618260300	0618260307	https://covers.openlibrary.org/b/id/394001-M.jpg	OL7604539M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6380	11	The Hobbit	eng	\N	ISIS Large Print Books	1991	9781850898054	1850898057	\N	OL9652680M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6381	11	The Hobbit	eng	\N	Large Print Press	2003	9781594130052	1594130051	https://covers.openlibrary.org/b/id/871993-M.jpg	OL8875466M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6382	11	The Hobbit	eng	\N	Highbridge Audio	2002	9781565116726	1565116720	https://covers.openlibrary.org/b/id/802992-M.jpg	OL8663969M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6383	11	The Hobbit	eng	\N	Recorded Books	2001	9780788789564	0788789562	https://covers.openlibrary.org/b/id/549855-M.jpg	OL8151615M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6384	11	O Hobbit	spa	\N	Grupo Anaya Comercial	2003	9788483024959	8483024950	https://covers.openlibrary.org/b/id/4914878-M.jpg	OL9143965M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6385	11	O Hobbit	por	BR	Martins Fontes	1998	9788533608818	8533608810	https://covers.openlibrary.org/b/id/13010202-M.jpg	OL22105270M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6386	11	The Hobbit	eng	\N	Random House	1967	\N	\N	\N	OL24821416M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6387	11	El Hobbit	spa	\N	Minotauro	1995	9789505470075	950547007X	\N	OL9137990M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6388	11	The Hobbit	eng	\N	Houghton Mifflin Harcourt	2014	9780544445796	0544445791	https://covers.openlibrary.org/b/id/7987909-M.jpg	OL26313936M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6389	11	The Hobbit	eng	\N	Ballantine Books	1965	\N	\N	\N	OL24595247M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6390	11	The Hobbit	eng	\N	Houghtin Mifflin	1999	9781306430715	\N	https://covers.openlibrary.org/b/id/6386931-M.jpg	OL24225231M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6391	11	El Hobbit	spa	\N	Ediciones Minotauro	1990	9788445071533	844507153X	https://covers.openlibrary.org/b/id/3327789-M.jpg	OL13268184M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6392	11	El Hobbit	spa	\N	Planeta DeAgostini	2002	9788439596264	843959626X	https://covers.openlibrary.org/b/id/7276058-M.jpg	OL25441857M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6393	11	Der Hobbit	deu	\N	Carlsen Comics	2001	9783551761019	3551761019	https://covers.openlibrary.org/b/id/3235166-M.jpg	OL12815020M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6394	11	The Hobbit	eng	\N	HarperCollins	2012	9780547951973	0547951973	https://covers.openlibrary.org/b/id/8406760-M.jpg	OL26757363M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6395	11	The Hobbit	eng	\N	HarperCollins	2009	9780007322602	0007322607	https://covers.openlibrary.org/b/id/8406761-M.jpg	OL26757374M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6396	11	The Hobbit	eng	\N	Houghton Mifflin Harcourt	2012	9780547951966	0547951965	https://covers.openlibrary.org/b/id/8406780-M.jpg	OL26757518M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6397	11	Hobbit, there and back. Vlastelin Kolec (3 parts) / Hobbit, ili Tuda i Obratno. Vlastelin Kolec	rus	\N	AZBOOKA	2006	\N	5352001849	https://covers.openlibrary.org/b/id/13167866-M.jpg	OL12545383M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6398	11	The Hobbit.  50 Anniversary Edition.	\N	\N	Longman	1966	9780582348882	0582348889	https://covers.openlibrary.org/b/id/13731113-M.jpg	OL7880665M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6399	11	Hobbit/Dc340 Cassette	\N	\N	Hotho & Co	1986	9789997018229	9997018222	\N	OL13349152M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6400	11	Annotated Hobbit	eng	\N	Houghton Mifflin Company	1988	9785552438310	5552438310	https://covers.openlibrary.org/b/id/13845295-M.jpg	OL9045059M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6401	11	El Hobbit/ the Hobbit (Señor de los Anilos)	spa	\N	Booket	2006	9788445075760	8445075764	https://covers.openlibrary.org/b/id/5267429-M.jpg	OL13268310M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6402	11	El Hobbit (Ilustrado)	spa	\N	Minotauro	1997	9788445072820	844507282X	https://covers.openlibrary.org/b/id/1047646-M.jpg	OL9131905M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6403	11	An Hobbit (en breton)	\N	\N	Arda	2001	9782911979033	2911979036	https://covers.openlibrary.org/b/id/994399-M.jpg	OL9011370M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6404	11	De hobbit, of Daarheen en weer terug	nld	\N	Het Spectrum	1976	\N	9027483965	https://covers.openlibrary.org/b/id/6578005-M.jpg	OL24353783M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6405	11	Lo hobbit ; o, La riconquista del tesoro	ita	\N	Bompiani	2000	\N	8845290638	\N	OL15950279M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6406	11	El Hobbit	\N	\N	Minotauro	2012	\N	9788445074855	https://covers.openlibrary.org/b/id/7249145-M.jpg	OL25421650M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6407	11	El Hobbit	\N	\N	Minotauro	1991	\N	8445070371	https://covers.openlibrary.org/b/id/7384244-M.jpg	OL25874285M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6408	11	De Hobbit, of Daarheen en weer terug	nld	\N	Het Spectrum	2001	\N	9027473838	https://covers.openlibrary.org/b/id/8059158-M.jpg	OL26371117M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6409	11	Lo Hobbit	ita	\N	Bompiani	2012	9788845268342	\N	https://covers.openlibrary.org/b/id/14562961-M.jpg	OL26676168M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6410	11	El hobbit	\N	\N	Minotauro	2015	9789584242983	\N	https://covers.openlibrary.org/b/id/8064298-M.jpg	OL26374869M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6411	11	Hobbit czyli tam i z powrotem	pol	\N	Iskry	2017	9788324403875	\N	https://covers.openlibrary.org/b/id/8353407-M.jpg	OL26677939M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6412	11	Der kleine Hobbit	deu	\N	dtv Verlagsgesellschaft	2012	9783423214131	3423214139	https://covers.openlibrary.org/b/id/8944905-M.jpg	OL27487330M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6413	11	Der kleine Hobbit	deu	\N	dtv Verlagsgesellschaft	2013	9783423715669	3423715669	https://covers.openlibrary.org/b/id/9032244-M.jpg	OL27577965M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6414	11	Hobbit	vie	\N	NXB Văn hóa-Thông tin	2009	\N	\N	\N	OL27117818M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6415	11	Anh chàng Hobbit	vie	\N	Nhà xuất bản Hội nhà văn	2010	\N	\N	\N	OL27192455M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6416	11	Der Hobbit	deu	\N	Klett-Cotta	2010	9783608101386	3608101381	https://covers.openlibrary.org/b/id/9261022-M.jpg	OL27906277M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6417	11	Hobbit, El - Version Infantil	spa	\N	Minotauro	2004	9788445075333	8445075330	https://covers.openlibrary.org/b/id/4910648-M.jpg	OL9131981M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6418	11	El Hobbit Ne	\N	\N	Planeta	2012	9786070712715	\N	https://covers.openlibrary.org/b/id/7792679-M.jpg	OL26135539M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6419	11	The Hobbit, Prequel to the Lord of the Rings Trilogy (The Lord of the Rings Trilogy)	eng	\N	Recorded Books, LLC	1991	9780788737275	0788737279	https://covers.openlibrary.org/b/id/13503579-M.jpg	OL8151461M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6420	11	Hobbitus Ille	lat	\N	HarperCollins Publishers	2012	9780007445219	0007445210	https://covers.openlibrary.org/b/id/9293867-M.jpg	OL26118399M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6421	11	La hobito	epo	\N	Sezonoj	2000	\N	\N	\N	OL25422102M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6422	11	Mo jie qian zhuan	\N	\N	Tsai Fong Books, Inc	2001	9789570823349	9570823348	\N	OL9149753M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6423	11	Habi ren	zho	\N	Lian jing chu ban shi ye gu fen you xian gong si	2012	9789570841039	9570841036	\N	OL27141752M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6424	11	Khobbit, ili Tuda i obratno	rus	\N	AST	2005	\N	5170267096	\N	OL12541260M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6425	11	Khobbit (Zolotaya biblioteka)	rus	\N	Oniks 21 vek	2004	\N	5329011000	https://covers.openlibrary.org/b/id/13834848-M.jpg	OL12545269M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6426	11	Khobbit (Lyubimoe chtenie)	rus	\N	AST	2004	\N	517024116X	https://covers.openlibrary.org/b/id/13174446-M.jpg	OL12540649M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6427	11	Hobbit	\N	\N	AST - Terra Fantastica	2000	9785170004065	5170004060	\N	OL9039804M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6428	11	The Hobbit	eng	\N	Recorded Books	2011	9781461836179	1461836174	https://covers.openlibrary.org/b/id/9386601-M.jpg	OL28001875M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6429	11	The Hobbit	\N	\N	Recorded Books, Inc.	2006	9781428127333	142812733X	https://covers.openlibrary.org/b/id/10116768-M.jpg	OL28179924M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6430	11	The Hobbit	\N	\N	Paw Prints 2008-08-11	2008	9781439527269	1439527261	https://covers.openlibrary.org/b/id/10186401-M.jpg	OL28257655M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6431	11	The Hobbit	\N	\N	Del Rey	2012	9780345534835	0345534832	https://covers.openlibrary.org/b/id/10203049-M.jpg	OL28276001M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6432	11	The Hobbit	\N	\N	Brand: BBC Audiobooks America	2008	9781602834545	1602834547	https://covers.openlibrary.org/b/id/10150015-M.jpg	OL28216573M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6433	11	The Hobbit	\N	\N	Eclipse Books	1990	9780913035818	0913035815	https://covers.openlibrary.org/b/id/10194833-M.jpg	OL28266934M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6434	11	Der Kleine Hobbit	deu	\N	French & European Pubns	2000	9780828811934	0828811938	\N	OL9796768M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6435	11	The Hobbit or There and Back Again	\N	\N	Houghton Mifflin	2007	9780739410745	0739410741	https://covers.openlibrary.org/b/id/10198384-M.jpg	OL28270808M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6436	11	Der kleine Hobbit	\N	\N	Deutscher Taschenbuch Verlag GmbH & Co.	2012	9783423715003	3423715006	https://covers.openlibrary.org/b/id/10293478-M.jpg	OL28345116M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6437	11	La Hobito, aŭ, Tien kaj Reen	\N	\N	Evertype	2015	9781782011095	1782011099	https://covers.openlibrary.org/b/id/10230577-M.jpg	OL28303498M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6438	11	The Hobbit	\N	\N	Soundelux Audio Pub	1990	9781559350327	1559350326	https://covers.openlibrary.org/b/id/10290747-M.jpg	OL28342496M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6439	11	The Hobbit	\N	\N	Listening Library	2000	9780807288832	0807288837	https://covers.openlibrary.org/b/id/10509368-M.jpg	OL30932989M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6440	11	The Hobbit	\N	\N	Young Readers Paperback Tolkien	2001	9780618150823	061815082X	https://covers.openlibrary.org/b/id/10401951-M.jpg	OL29596077M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6441	11	Hobbit (T. D)	cat	\N	Edicions de La Magrana	2001	9788482643526	\N	\N	OL28941526M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6442	11	Chombit - the Hobbit	\N	\N	Kedros Publishers	1999	9789600403084	9600403082	\N	OL30194212M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6443	11	El Hobbit	\N	\N	Booket	2014	9788445001417	8445001418	https://covers.openlibrary.org/b/id/10587915-M.jpg	OL31907481M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6444	11	El Hobbit	\N	\N	Booket	2012	9788445000656	8445000659	https://covers.openlibrary.org/b/id/10506394-M.jpg	OL30903255M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6445	11	Der Hobbit	\N	\N	Klett-Cotta	2012	9783608939774	3608939776	https://covers.openlibrary.org/b/id/10293504-M.jpg	OL28345147M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6446	11	The Hobbit	bul	\N	Bard	1999	\N	9545850167	https://covers.openlibrary.org/b/id/11218652-M.jpg	OL32576905M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6447	11	The Hobbit	\N	\N	Brand: BBC Audiobooks	2012	9781620641132	1620641135	https://covers.openlibrary.org/b/id/10841867-M.jpg	OL32189451M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6448	11	El hobbit	spa	\N	Minotauro	1985	\N	8445070371	https://covers.openlibrary.org/b/id/12388832-M.jpg	OL35688432M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6449	11	Lo Hobbit	\N	\N	Adelphi Edizioni S.p.A.	2013	9788845927553	8845927555	https://covers.openlibrary.org/b/id/10709051-M.jpg	OL32042736M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6450	11	Hobbit Ciltli	\N	\N	Ithaki Yayinlari	2017	9786053757351	6053757357	https://covers.openlibrary.org/b/id/10849175-M.jpg	OL32199959M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6451	11	Hobbit	eng	\N	Houghton Mifflin Harcourt Publishing Company	2001	9781536427899	\N	\N	OL34110984M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6452	11	Hobbit	\N	\N	Ithaki Yayinlari	2008	9789752733732	9752733735	https://covers.openlibrary.org/b/id/12105054-M.jpg	OL35293374M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6453	11	Hobbit	tur	\N	Ithaki Yayinlari	2000	9789756902271	9756902272	https://covers.openlibrary.org/b/id/12283424-M.jpg	OL35442263M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6454	11	Hobbit	\N	\N	Ithaki Yayinlari	2013	9786053752547	6053752541	https://covers.openlibrary.org/b/id/12226906-M.jpg	OL35384227M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6455	11	Aciklamali Notlariyla Hobbit	\N	\N	Ithaki	2014	9786053753964	6053753963	https://covers.openlibrary.org/b/id/12226981-M.jpg	OL35384302M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6456	11	HOBBIT, EL	spa	\N	Minotauro	2014	9789505472079	9505472072	https://covers.openlibrary.org/b/id/14855711-M.jpg	OL35627303M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6457	11	El Hobbit	\N	\N	Minotauro	2019	9788445005903	8445005901	https://covers.openlibrary.org/b/id/12334324-M.jpg	OL35627326M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6458	11	El Hobbit	\N	\N	Booket	2014	9788445002322	8445002325	https://covers.openlibrary.org/b/id/12334311-M.jpg	OL35627315M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6459	11	El hobbit	spa	\N	Minotauro	1991	\N	8445071416	https://covers.openlibrary.org/b/id/12521736-M.jpg	OL36628255M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6460	11	Der kleine Hobbit	deu	\N	dtv junior	1994	\N	3790301337	https://covers.openlibrary.org/b/id/14850791-M.jpg	OL37508438M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6461	11	Hobit	ces	\N	Argo	2012	9788025707418	\N	\N	OL37785369M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6462	11	Bilbo, Le Hobbit	fra	\N	Le Livre de Poche	2012	9782253049418	\N	https://covers.openlibrary.org/b/id/13199388-M.jpg	OL46532061M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6463	11	Le Hobbit	fra	\N	Christian Bourgois éditeur	2012	9782267024203	\N	https://covers.openlibrary.org/b/id/13219706-M.jpg	OL46534316M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6464	11	O Hobbit	por	BR	HarperCollins Brasil	2022	9786555110913	\N	https://covers.openlibrary.org/b/id/13326886-M.jpg	OL46835767M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6465	11	The Hobbit Lib/E	\N	\N	HighBridge Audio	2021	9781665165419	1665165413	https://covers.openlibrary.org/b/id/10724529-M.jpg	OL32071915M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6466	11	An Hobbit, pe, Eno ha Distro	\N	\N	Evertype	2020	9781782012689	1782012680	https://covers.openlibrary.org/b/id/10866008-M.jpg	OL32226758M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6467	11	O Hobbit anotado	por	BR	Harper Collins Brasil	2021	9786555111507	\N	https://covers.openlibrary.org/b/id/12749897-M.jpg	OL37925417M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6468	11	Hobbit, The	\N	\N	Recorded Books, Inc.	2020	9781705009079	1705009077	https://covers.openlibrary.org/b/id/12374898-M.jpg	OL35672737M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6469	11	LE HOBBIT ILLUSTRE	\N	\N	BOURGOIS	2012	9782267024029	2267024020	https://covers.openlibrary.org/b/id/12377428-M.jpg	OL35677526M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6470	11	Le Hobbit	\N	\N	Christian Bourgois Editeur	2012	9782267024012	2267024012	https://covers.openlibrary.org/b/id/12389723-M.jpg	OL35690489M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6471	11	Hobbit	eng	\N	Houghton Mifflin Harcourt Trade & Reference Publishers	2012	9781299884946	\N	\N	OL37175787M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6472	11	The Hobbit	\N	\N	Blackstone Audiobooks	2014	9781483034577	1483034577	https://covers.openlibrary.org/b/id/12565415-M.jpg	OL36679625M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6473	11	The Hobbit	\N	\N	Recorded Books	\N	9781436148894	1436148898	\N	OL37810255M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6474	11	Annotated Hobbit, Third Edition	eng	\N	Houghton Mifflin Harcourt Publishing Company	\N	9781328497598	\N	\N	OL37469809M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6475	11	The Hobbit	\N	\N	George Allen & Unwin	1937	\N	9780547928227	https://covers.openlibrary.org/b/id/12750530-M.jpg	OL37933229M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6476	11	An Hobbit	bre	\N	Evertype	2020	9781782012696	\N	https://covers.openlibrary.org/b/id/13192845-M.jpg	OL39545905M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6477	11	O Hobbit	\N	\N	Sushi Books	2018	9788416884117	8416884110	\N	OL39810193M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6478	11	Bilbo le Hobbit - Edition film 2014	\N	\N	LGF	2014	9782253183518	2253183512	\N	OL40205364M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6479	11	El hobbit	\N	\N	Minotauro	1991	9788435003506	8435003507	\N	OL42865600M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6480	11	Hobbit, czyli tam i z powrotem	\N	\N	Iskry	2021	9788324410996	8324410996	https://covers.openlibrary.org/b/id/13214502-M.jpg	OL42989594M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6481	11	Lo Hobbit o La riconquista del tesoro	\N	\N	Adelphi	\N	9788845900815	8845900819	https://covers.openlibrary.org/b/id/13697762-M.jpg	OL43004047M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6482	11	The Hobbit	\N	\N	Highbridge Audio and Blackstone Publishing	2021	9781665165433	166516543X	https://covers.openlibrary.org/b/id/13161816-M.jpg	OL46528814M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6483	11	De Hobbit - Luxe versie	\N	\N	Meulenhoff Boekerij B.V.	2013	9789022567722	9022567729	https://covers.openlibrary.org/b/id/13345684-M.jpg	OL46849279M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6484	11	El Hobbit	\N	\N	Minotauro	2019	9788445007693	8445007696	https://covers.openlibrary.org/b/id/14122118-M.jpg	OL47508610M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6485	11	El Hobbit	\N	\N	Booket	2022	9788445013946	8445013947	https://covers.openlibrary.org/b/id/13601170-M.jpg	OL47181067M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6486	11	El Hobbit. Ilustrado por Jemima Catlin	\N	\N	MINOTAURO	2020	9788445007938	8445007939	https://covers.openlibrary.org/b/id/13479304-M.jpg	OL47104127M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6487	11	O hobbit	\N	\N	Edicións Xerais	2007	9788497825412	8497825411	https://covers.openlibrary.org/b/id/13539318-M.jpg	OL47141237M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6488	11	El hòbbit	\N	\N	RBA La Magrana	2012	9788482645957	8482645951	https://covers.openlibrary.org/b/id/13754577-M.jpg	OL47293092M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6489	11	Bilbo le hobbit	\N	\N	BOURGOIS	1993	9782267011272	2267011271	https://covers.openlibrary.org/b/id/13774287-M.jpg	OL47309617M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6490	11	Bilbon lo Hòbbit	\N	\N	REGIONALISMES	2018	9782824009179	2824009179	https://covers.openlibrary.org/b/id/13861379-M.jpg	OL47322347M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6491	11	Estuche El Hobbit	\N	\N	Timun Mas Narrativa	2013	9788445001646	8445001647	https://covers.openlibrary.org/b/id/14097096-M.jpg	OL47487707M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6492	11	El Hobbit edición especial 75 aniversario	\N	\N	Timun Mas Narrativa	2012	9788445000649	8445000640	https://covers.openlibrary.org/b/id/14097112-M.jpg	OL47487718M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6493	11	Le Hobbit, illustré par Alan Lee	\N	\N	BOURGOIS	2023	9782267051315	2267051311	https://covers.openlibrary.org/b/id/14143349-M.jpg	OL47527257M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6494	11	Der Hobbit	deu	\N	Büchergilde Gutenberg	1998	\N	3763252088	https://covers.openlibrary.org/b/id/14393819-M.jpg	OL49215460M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6495	11	The Hobbit	\N	\N	Christian Bourgois Éditeur	1995	\N	2267013177	https://covers.openlibrary.org/b/id/14552711-M.jpg	OL50293443M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6496	11	Hobbiten eller ditut og attende	\N	\N	Tiden norsk forlag	2008	9788210050381	\N	https://covers.openlibrary.org/b/id/14557929-M.jpg	OL50514240M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6497	11	Hobbiten	nob	\N	Tiden Norsk Forlag	2023	9788210059544	\N	https://covers.openlibrary.org/b/id/14595177-M.jpg	OL51231576M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6498	11	Hobbit czyli tam i z powrotem	pol	\N	Iskry	2013	9788324403240	\N	https://covers.openlibrary.org/b/id/14606609-M.jpg	OL51534711M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6499	11	The Hobbit	\N	\N	Houghton Mifflin Harcourt	2002	\N	0618134700	https://covers.openlibrary.org/b/id/13446467-M.jpg	OL24606821M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6500	11	The Hobbit	\N	\N	BBC Books	2002	9780563528807	056352880X	\N	OL37442482M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6501	11	The Hobbit	eng	\N	Random House Audio	1992	9780553745054	0553745050	\N	OL7850230M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6502	11	The Hobbit	eng	\N	Random House Audio	1992	9780553700251	0553700251	https://covers.openlibrary.org/b/id/373566-M.jpg	OL7850059M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6503	11	The Hobbit	eng	\N	Random House Audio	1997	9780553471076	0553471074	https://covers.openlibrary.org/b/id/370511-M.jpg	OL7827594M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6504	11	The Hobbit	\N	\N	Houghton Mifflin Harcourt	2012	9780547928241	0547928246	https://covers.openlibrary.org/b/id/9055221-M.jpg	OL27605004M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6505	11	The Hobbit	eng	\N	Houghton Mifflin Harcourt	1995	9780547536736	0547536739	\N	OL32927039M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6506	11	Hobbit	eng	\N	Houghton Mifflin Harcourt Publishing Company	2013	9780544239555	\N	\N	OL29678394M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6507	11	The Hobbit	eng	\N	Houghton Mifflin Harcourt	2013	9780544174221	0544174224	https://covers.openlibrary.org/b/id/7322677-M.jpg	OL25652067M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6508	11	Hobbit	eng	\N	Houghton Mifflin Harcourt Publishing Company	2012	9780544115552	\N	\N	OL33999104M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6509	11	The Hobbit: Deluxe Pocket Edition	\N	\N	Houghton Mifflin Harcourt	2012	9780544045521	0544045521	https://covers.openlibrary.org/b/id/8770026-M.jpg	OL27290135M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6510	11	The Annotated Hobbit	eng	\N	Random House Value Publishing	1990	9780517029350	0517029359	\N	OL7672902M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6511	11	The Hobbit or There and Back Again	eng	\N	Methuen	1978	9780458938803	0458938807	https://covers.openlibrary.org/b/id/13237583-M.jpg	OL7591523M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6512	11	The hobbit, or, There and back again	eng	\N	Houghton Mifflin Co.	1997	\N	0395873460	https://covers.openlibrary.org/b/id/257294-M.jpg	OL402765M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6513	11	The hobbit, or, There and back again	eng	\N	Houghton Mifflin	1984	\N	0395362903	https://covers.openlibrary.org/b/id/255666-M.jpg	OL2846909M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6514	11	The Hobbit	\N	\N	Houghton Mifflin	1973	9780395177112	\N	\N	OL44095139M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6515	11	The hobbit, or, There and back again	eng	\N	Houghton Mifflin	1987	\N	0395177111	https://covers.openlibrary.org/b/id/9364214-M.jpg	OL18639215M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6516	11	The Hobbit	eng	\N	Houghton Mifflin	1938	9780395071229	0395071224	https://covers.openlibrary.org/b/id/255382-M.jpg	OL7465523M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6517	11	The hobbit, or, There and back again	eng	\N	Houghton Mifflin	1966	\N	0395071224	\N	OL17911508M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6518	11	The Hobbit	eng	\N	Ballantine Books	1999	9780345917423	0345917421	\N	OL10686521M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6519	11	The Hobbit, or, There and back again	eng	\N	Ballantine Books	1982	\N	0345339681	https://covers.openlibrary.org/b/id/14840068-M.jpg	OL16794971M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6520	11	The Hobbit	eng	\N	Ballantine Books	1985	9780345332073	0345332075	\N	OL10684787M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6521	11	The Hobbit	eng	\N	Ballantine Books	1984	9780345318589	0345318587	\N	OL10684408M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6522	11	The Hobbit and The Lord of the Rings	eng	\N	Ballantine Books	1984	9780345296078	0345296079	\N	OL10683697M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6523	11	The Hobbit	eng	\N	Ballantine Books	1978	9780345277114	0345277112	https://covers.openlibrary.org/b/id/13560277-M.jpg	OL10683016M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6524	11	HOBBIT	eng	\N	Ballantine Books	1972	9780345215321	034521532X	https://covers.openlibrary.org/b/id/6278297-M.jpg	OL10681592M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6525	11	THE HOBBIT - or There and Back Again	\N	\N	Ballantine Books	1973	9780345015327	0345015320	https://covers.openlibrary.org/b/id/13804001-M.jpg	OL47315806M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6526	11	El Hobbit (Spanish language version)	\N	\N	French & European Pubns	2000	9780320036873	0320036871	\N	OL10457133M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6527	11	Hobbit	eng	\N	HarperCollins Publishers Limited	1997	9780261103498	\N	\N	OL44095999M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6528	11	The Hobbit	\N	\N	HarperCollins Publishers Ltd	2000	9780261103313	0261103318	https://covers.openlibrary.org/b/id/2341310-M.jpg	OL10236413M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6529	11	The Hobbit	eng	\N	HarperCollins Publishers Ltd	1997	9780261103306	026110330X	https://covers.openlibrary.org/b/id/2341309-M.jpg	OL10236412M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6530	11	The hobbit	eng	\N	HarperCollins	2020	9780261103283	\N	https://covers.openlibrary.org/b/id/149276-M.jpg	OL9786619M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6531	11	The Hobbit	\N	\N	Harper Collins	2000	9780261102668	0007611625	\N	OL10236401M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6532	11	The hobbit	eng	\N	Harper	2006	\N	0261102664	\N	OL22738196M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6533	11	The Hobbit	eng	\N	Harper Collins	1999	9780261102576	0261102575	https://covers.openlibrary.org/b/id/2341300-M.jpg	OL10236397M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6534	11	Annotated Hobbit	\N	\N	HarperCollins	1991	9780261102514	0261102516	\N	OL10236396M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6535	11	The illustrated Hobbit	eng	\N	Grafton	1992	\N	0261102508	\N	OL14975006M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6536	11	The hobbit or, There and back again.	eng	\N	HarperCollins	1990	\N	0261102494	https://covers.openlibrary.org/b/id/13787703-M.jpg	OL21217150M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6537	11	The Hobbit	eng	\N	HarperCollinsPublishers	1999	9780261102217	0261102214	https://covers.openlibrary.org/b/id/6929796-M.jpg	OL24992840M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6538	11	The Hobbit.	\N	\N	Book Club Association	1992	9780261102002	0261102001	https://covers.openlibrary.org/b/id/13443517-M.jpg	OL10236379M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6539	11	The Hobbit	eng	\N	Addison Wesley Publishing Company	1985	9780201111583	0201111586	https://covers.openlibrary.org/b/id/14009492-M.jpg	OL7406702M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6540	11	The Hobbit	eng	\N	Prentice Hall	1991	9780137171668	0137171668	\N	OL9298426M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6541	11	Hobbit Illustrated by the Author	eng	\N	HarperCollins Publishers	2023	9780063347533	\N	\N	OL48231435M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6542	11	Hobbit	eng	\N	HarperCollins Publishers	2009	9780061917783	\N	\N	OL37363399M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6543	11	Hobbit	eng	\N	HarperCollins Publishers	2009	9780061917776	\N	\N	OL37382503M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6544	11	Hobbit	eng	\N	HarperCollins Publishers	2009	9780061917769	\N	\N	OL37378697M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6545	11	Hobbit	eng	\N	HarperCollins Publishers	2009	9780061917752	\N	\N	OL37355894M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6546	11	The Hobbit	eng	\N	HarperCollins	2009	9780061917738	\N	https://covers.openlibrary.org/b/id/6402763-M.jpg	OL24276117M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6547	11	The hobbit, or, There and back again	eng	\N	Unwin Hyman	1987	\N	0048233862	https://covers.openlibrary.org/b/id/10183103-M.jpg	OL2105246M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6548	11	The hobbit and the Lord of the rings	eng	\N	Unwin Publishers	1981	\N	0048232165	https://covers.openlibrary.org/b/id/13330760-M.jpg	OL20943873M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6549	11	The Hobbit	\N	\N	HarperCollins Publishers Ltd	1987	9780048232168	0048232165	\N	OL9228719M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6550	11	The Hobbit, or, There and back again	eng	\N	Unwin Paperbacks	1984	\N	0048231886	\N	OL22400371M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6551	11	The Hobbit, or There and Back Again	eng	\N	Unwin Paperbacks	1986	\N	0048231886	https://covers.openlibrary.org/b/id/7348930-M.jpg	OL21968605M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6552	11	The Hobbit	\N	\N	Unwin	1979	\N	0048231541	https://covers.openlibrary.org/b/id/9262669-M.jpg	OL27908061M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6553	11	The Hobbit	\N	\N	Allen & Unwin	1978	9780048231475	0048231479	\N	OL9228710M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6554	11	The Hobbit	\N	\N	Harper Collins Publishers  Stock Account	\N	9780048231277	0048231274	\N	OL9228706M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6555	11	The hobbit, or, There and back again	eng	\N	Allen and Unwin	1976	\N	0048231274	\N	OL20943857M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6556	11	The hobbit, or, There and back again	eng	\N	Unwin Books	1975	\N	0048231266	https://covers.openlibrary.org/b/id/10139736-M.jpg	OL20943855M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6557	11	The hobbit	eng	\N	Allen and Unwin	1972	\N	0048231053	https://covers.openlibrary.org/b/id/13830250-M.jpg	OL20943852M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6558	11	The Hobbit	\N	\N	Ballantine Books	1966	9780048230706	0048230707	\N	OL7273993M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6559	11	The Hobbit	eng	\N	Allen and Unwin	1966	\N	0048230707	https://covers.openlibrary.org/b/id/14367780-M.jpg	OL22368666M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6560	11	The Hobbit	\N	\N	Allen & Unwin	1966	\N	0048230707	https://covers.openlibrary.org/b/id/14367784-M.jpg	OL48587863M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6561	11	The hobbit, or, There and back again	eng	\N	George Allen &Unwin	1966	\N	0048230693	\N	OL22761592M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6562	11	The hobbit	eng	\N	Allen & Unwin	1971	\N	0048230693	https://covers.openlibrary.org/b/id/13200669-M.jpg	OL22369858M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6563	11	The annotated Hobbit	eng	\N	Unwin Hyman	1979	\N	0044403372	https://covers.openlibrary.org/b/id/10103525-M.jpg	OL14732029M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6564	11	The annotated Hobbit	eng	\N	Unwin Hyman	1988	\N	0044403372	\N	OL20943433M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6565	11	THE  HOBBIT	\N	\N	Harper Collins Publishers  Stock Account	\N	9780044400912	0044400918	\N	OL9228183M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6566	11	Hobbit	eng	\N	HarperCollins Publishers Limited	2023	9780008627843	\N	\N	OL48198543M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6567	11	Hobbit	eng	\N	HarperCollins Publishers Limited	2023	9780008627836	\N	\N	OL48192292M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6568	11	Hobbit	eng	\N	HarperCollins Publishers Limited	2023	9780008627782	\N	\N	OL48180928M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6569	11	The Hobbit	\N	\N	HarperCollins	2020	9780008439415	0008439419	https://covers.openlibrary.org/b/id/11458751-M.jpg	OL32826973M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6570	11	Hobbit	eng	\N	HarperCollins Publishers Limited	2020	9780008376116	\N	https://covers.openlibrary.org/b/id/14844408-M.jpg	OL29486372M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6571	11	Annotated Hobbit	eng	\N	HarperCollins Publishers Limited	2019	9780008323332	\N	\N	OL34715833M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6572	11	Hobbit Facsimile Gift Edition [Lenticular Cover]	eng	\N	HarperCollins Publishers Limited	2018	9780008259549	\N	https://covers.openlibrary.org/b/id/15201788-M.jpg	OL35522235M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6573	11	The Hobbit	\N	\N	HarperCollins	2014	9780008108281	0008108285	https://covers.openlibrary.org/b/id/10291618-M.jpg	OL28343210M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6574	11	Hobbit, or, There and Back Again	\N	\N	\N	\N	9780007926671	0007926677	\N	OL43694454M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6575	11	Hobbit, or, There and Back Again	eng	\N	HarperCollins Publishers Limited	2012	9780007926664	\N	\N	OL44147230M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6576	11	Hobbit	eng	\N	HarperCollins Publishers Limited	2010	9780007887705	\N	\N	OL44125156M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6577	11	Harpercollins The Hobbit	\N	\N	HarperCollins	2013	9780007555222	0007555229	\N	OL39225649M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6578	11	The Hobbit	\N	\N	Harpercollins	2013	9780007525539	0007525532	https://covers.openlibrary.org/b/id/10291597-M.jpg	OL28343198M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6579	11	The Hobbit	\N	\N	Harper Collins Promotion	2013	9780007525508	0007525508	https://covers.openlibrary.org/b/id/10291593-M.jpg	OL28343196M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6580	11	The Colour Illustrated Hobbit	\N	\N	HarperCollins	2017	9780007497935	0007497938	https://covers.openlibrary.org/b/id/8567569-M.jpg	OL26872121M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6581	11	Hobbit	\N	\N	HarperCollins UK	2013	9780007497911	0007497911	https://covers.openlibrary.org/b/id/8445395-M.jpg	OL26791871M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6582	11	The Hobbit	\N	\N	HarperCollins Publishers	2001	9780007497904	0007497903	https://covers.openlibrary.org/b/id/8780193-M.jpg	OL27307624M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6583	11	The Hobbit	eng	\N	HarperCollins Publishers Limited	2012	9780007487318	\N	https://covers.openlibrary.org/b/id/15244617-M.jpg	OL37952096M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6584	11	The Hobbit	eng	\N	HarperCollins Publishers	2012	9780007487301	\N	https://covers.openlibrary.org/b/id/12631967-M.jpg	OL34601210M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6585	11	The Hobbit	\N	\N	HarperCollins	2012	9780007487295	0007487290	https://covers.openlibrary.org/b/id/10291546-M.jpg	OL28343163M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6586	11	The Hobbit	\N	\N	HarperCollins UK	2011	9780007460441	0007460449	https://covers.openlibrary.org/b/id/8598609-M.jpg	OL27007020M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6587	11	The Hobbit	\N	\N	HarperCollins Publishers	2012	9780007458424	0007458428	https://covers.openlibrary.org/b/id/8458080-M.jpg	OL26803637M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6588	11	Hobbit	eng	\N	HarperCollins Publishers Limited	2019	9780007457823	\N	\N	OL44151308M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6589	11	Hobbit (Enhanced Edition)	eng	\N	HarperCollins Publishers Limited	2011	9780007446339	\N	\N	OL37969152M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6590	11	The Pocket Hobbit	\N	\N	HarperCollins	2011	9780007440849	\N	https://covers.openlibrary.org/b/id/7688710-M.jpg	OL26080609M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6591	11	Hobbit	eng	\N	HarperCollins Publishers Limited	2016	9780007440832	\N	https://covers.openlibrary.org/b/id/12378674-M.jpg	OL28472226M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6592	11	Hobbit (Enhanced Edition)	eng	\N	HarperCollins Publishers Limited	2011	9780007425389	\N	\N	OL37948377M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6593	11	The Hobbit (Modern Classics on Tape)	\N	\N	Collins Audio	2003	9780007158775	0007158777	https://covers.openlibrary.org/b/id/11370-M.jpg	OL9217454M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6594	11	The Hobbit	\N	\N	HarperCollins Publishers Ltd	2003	9780007156993	0007156995	https://covers.openlibrary.org/b/id/11257-M.jpg	OL9217399M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6595	11	The Hobbit	\N	\N	HarperCollins Publishers Ltd	2003	9780007156986	0007156987	https://covers.openlibrary.org/b/id/11255-M.jpg	OL9217398M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6596	11	The Hobbit	\N	\N	HarperCollins Audio	2002	9780007146901	0007146906	https://covers.openlibrary.org/b/id/1058808-M.jpg	OL9217079M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6597	11	The Hobbit	\N	\N	HarperCollins Audio	2002	9780007141821	0007141823	https://covers.openlibrary.org/b/id/1058705-M.jpg	OL9216889M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6598	11	The Annotated Hobbit	\N	\N	HarperCollins Publishers Ltd	2003	9780007137275	0007137273	https://covers.openlibrary.org/b/id/10066-M.jpg	OL9216764M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6599	11	Hobbit	eng	\N	HarperCollins Publishers Limited	2004	9780007118359	\N	https://covers.openlibrary.org/b/id/13949819-M.jpg	OL28429751M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6600	11	The Hobbit	eng	\N	HarperCollins Publishers Ltd	2001	9780007115440	000711544X	https://covers.openlibrary.org/b/id/8769-M.jpg	OL9216158M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6601	11	The Hobbit	\N	\N	HarperCollins Audio	2000	9780007106776	0007106777	https://covers.openlibrary.org/b/id/8230-M.jpg	OL9215889M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6602	11	The Hobbit	\N	\N	HarperCollins Publishers Ltd	2001	9780007105090	0007105096	https://covers.openlibrary.org/b/id/8134-M.jpg	OL9215852M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6603	11	The Hobbit (Collins Modern Classics)	eng	\N	HarperCollins	\N	9780006754022	0006754023	https://covers.openlibrary.org/b/id/7430-M.jpg	OL9215156M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6604	11	The Hobbit	\N	\N	The Folio Society	1999	9780001361287	0001361287	https://covers.openlibrary.org/b/id/127-M.jpg	OL9209244M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6605	11	The  hobbit, or, There and back again	eng	\N	G. Allen & Unwin	1937	\N	\N	https://covers.openlibrary.org/b/id/9261035-M.jpg	OL6363476M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6606	11	The hobbit	eng	\N	Allen & Unwin	1946	\N	\N	\N	OL20388227M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6607	11	The hobbit	eng	\N	G. Allen & Unwin	1956	\N	\N	\N	OL20352933M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6608	11	The hobbit	eng	\N	Houghton Mifflin	1957	\N	\N	\N	OL22804790M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6609	11	Kleiner Hobbit und der große Zauberer	deu	\N	Paulus Verlag	1957	\N	\N	https://covers.openlibrary.org/b/id/14561614-M.jpg	OL50527403M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6610	11	The Hobbit Or There And Back Again	\N	\N	George Allen & Unwin	1961	\N	\N	\N	OL43184577M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6611	11	The Hobbit	eng	\N	George Allen & Unwin	1966	\N	\N	\N	OL26477626M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6612	11	The hobbit, or, There and back again	eng	\N	Houghton Mifflin	1966	\N	\N	\N	OL5550061M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6613	11	The hobbit	eng	\N	Allen & Unwin	1966	\N	\N	\N	OL13875540M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6614	11	The hobbit, or, There and back again	\N	\N	Houghton Mifflin	1966	\N	\N	\N	OL43536682M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6615	11	The Hobbit	\N	\N	Unwin Books	1967	\N	\N	\N	OL47864226M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6616	11	Bilbo le hobbit	fra	\N	J'ai lu	1969	\N	\N	https://covers.openlibrary.org/b/id/6622014-M.jpg	OL24375966M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6617	11	Hobitten eller Ud og hjem igen	dan	\N	Gyldendal	1969	\N	\N	\N	OL21080822M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6618	11	Bilbo le hobbit	\N	\N	J'ai Lu	1969	\N	\N	\N	OL47780716M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6619	11	The hobbit	eng	\N	Allen & Unwin	1971	\N	\N	\N	OL21563144M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6620	11	Bilbo Le Hobbit	\N	\N	J'Ai Lu	1974	\N	\N	\N	OL47780212M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6621	11	The hobbit.	eng	\N	BBC	1974	\N	\N	\N	OL13816361M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6622	11	The hobbit	eng	\N	Allen & Unwin	1974	\N	\N	\N	OL21392107M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6623	11	The Hobbit	eng	\N	Unwin	1975	\N	\N	\N	OL13931725M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6624	11	The Hobbit	heb	\N	Zmora-Bitan	1977	\N	\N	https://covers.openlibrary.org/b/id/7366396-M.jpg	OL25769448M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6625	11	The Hobbit	\N	\N	GUILD PUBLISHING	1978	\N	\N	\N	OL47813859M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6626	11	THE HOBBIT, THE ENCHANTING PRELUDE TO THE LORD OF THE RINGS	\N	\N	BALLANTINE / FANTASY	1978	\N	\N	\N	OL46855735M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6627	11	The hobbit, or, There and back again	eng	\N	Houghton Mifflin	1978	\N	\N	\N	OL18005904M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6628	11	The hobbit, or, There and back again	eng	\N	Folio Society	1979	\N	\N	\N	OL13704499M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6629	11	Bilbo le hobbit	fra	\N	Hachette	1980	\N	\N	\N	OL20184901M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6630	11	Lo hobbit,o, La riconquista del tesoro.	ita	\N	Tascabili Bompiani	1981	\N	\N	\N	OL13647849M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6631	11	The Hobbit	\N	\N	Unwin Paperbacks	1981	\N	\N	\N	OL47712472M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6632	11	The Hobbit	\N	\N	NEW YORK Del Rey	1986	\N	\N	\N	OL46852958M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6633	11	The Hobbit	eng	\N	Del Rey Books	1986	\N	\N	https://covers.openlibrary.org/b/id/10578705-M.jpg	OL31891889M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6634	11	The Hobbit	eng	\N	Turtleback	1986	\N	\N	https://covers.openlibrary.org/b/id/592158-M.jpg	OL7973618M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6635	11	The hobbit; or; There and back again	eng	\N	Unwin Hyman	1987	\N	\N	\N	OL13904400M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6636	11	The hobbit, or, There and back again	eng	\N	Easton Press	1990	\N	\N	\N	OL1937352M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6637	11	THE HOBBIT (GUILD PUBLISHING)	\N	\N	GUILD PUBLISHING BY ARRANGEMENT WITH GEORGE ALLEN & UNWIN	1990	\N	\N	\N	OL47708935M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6638	11	Hobbit	tur	\N	Altikirbes Yayin	1997	\N	\N	\N	OL17487312M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6639	11	La hobito	epo	\N	Sezonoj	2005	\N	\N	https://covers.openlibrary.org/b/id/7250143-M.jpg	OL25422103M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6640	11	The Hobbit	eng	\N	Mariner Books	2012	9780547928227	054792822X	https://covers.openlibrary.org/b/id/14624653-M.jpg	OL26757521M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6641	11	The Hobbit	eng	\N	HarperCollins Publishers	2011	9780261103344	0261103342	https://covers.openlibrary.org/b/id/10522108-M.jpg	OL10236414M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6642	11	Le Hobbit	fra	\N	Livre de Poche	2012	9782253183822	2253183822	https://covers.openlibrary.org/b/id/14625980-M.jpg	OL28345057M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6643	11	The Hobbit	eng	\N	HarperCollins Publishers	2014	9780007591855	0007591853	https://covers.openlibrary.org/b/id/10326817-M.jpg	OL28374591M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6644	11	The Hobbit	eng	\N	Ballantine Books	1983	9780345296047	0345296044	https://covers.openlibrary.org/b/id/14624309-M.jpg	OL10683695M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6645	11	The Hobbit or There and Back Again	eng	\N	Mariner Books	2013	9780544422841	0544422848	https://covers.openlibrary.org/b/id/9261029-M.jpg	OL27906299M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6646	11	The Hobbit	eng	\N	Harper Collins Publishers	2013	9780007525492	0007525494	https://covers.openlibrary.org/b/id/10326849-M.jpg	OL26389331M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6647	11	霍比特人	zho	\N	Shanghai ren min chu ban she	2013	9787208111028	7208111022	https://covers.openlibrary.org/b/id/9158669-M.jpg	OL27144426M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6648	11	The Hobbit	eng	\N	HarperCollins Publishers	2012	9780007487288	0007487282	https://covers.openlibrary.org/b/id/10584475-M.jpg	OL26780182M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6649	11	El Hobbit	spa	\N	Minotauro	2001	9788445071410	8445071416	https://covers.openlibrary.org/b/id/8406767-M.jpg	OL9131875M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6650	11	Bilbo, le Hobbit	fra	\N	Hachette Jeunesse	2000	9782010199073	2010199073	https://covers.openlibrary.org/b/id/10516257-M.jpg	OL8833408M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6651	11	The Hobbit	eng	\N	Unwin Paperbacks	1987	9780048233806	0048233803	https://covers.openlibrary.org/b/id/14625514-M.jpg	OL9228757M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6652	11	魔戒	zho	\N	Yi lin chu ban she	2002	9787806571903	7806571906	https://covers.openlibrary.org/b/id/10695930-M.jpg	OL32009549M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6653	11	魔戒前傳：哈比人歷險記	zho	\N	Lian jing chu ban shi ye gong si	2002	\N	9570823348	https://covers.openlibrary.org/b/id/8406776-M.jpg	OL23041746M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6654	11	Hobbit Deluxe	eng	\N	HarperCollins Publishers	2025	9780063473423	\N	\N	OL60901920M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6655	11	Hobbit	eng	\N	HarperCollins Publishers Limited	2025	9780008779900	\N	\N	OL60855757M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6656	11	Hobbit, The (Unwin Books) by Tolkien, J. R. R. (June 1, 1966) Paperback	\N	\N	Allen & Unwin	1966	\N	\N	\N	OL60338476M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6657	11	The hobbit, or There and back again	eng	\N	Allen & Unwin	1965	\N	\N	\N	OL59858570M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6658	11	The Hobbit 	eng	\N	BCA	1992	\N	\N	\N	OL58620890M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6659	11	The Hobbit	eng	\N	Ballantine Books	1966	\N	\N	https://covers.openlibrary.org/b/id/15254146-M.jpg	OL58871575M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6660	11	The Hobbit	eng	\N	Houghton Mifflin	1987	\N	\N	\N	OL58447056M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6661	11	El Hobbit	\N	\N	Minotauro	2024	9788445017210	\N	https://covers.openlibrary.org/b/id/14846614-M.jpg	OL57884250M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6662	11	Hobbit	eng	\N	CreateSpace Independent Publishing Platform	2017	9781548547295	\N	\N	OL56447535M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6663	11	Der Hobiṭ	yid	\N	The Translator	2012	\N	\N	\N	OL55159419M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6664	11	ההוביט או לשם ובחזרה	heb	\N	זמורה־ביתן	2012	9789655523980	\N	\N	OL53494329M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6665	11	ההוביט	heb	\N	זמורה־ביתן	1976	\N	\N	\N	OL53212560M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6666	11	The hobbit, or, There and back again	eng	\N	Houghton Mifflin Co.	1960	\N	\N	\N	OL53097899M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6667	11	Hobbit	\N	\N	CreateSpace Independent Publishing Platform	2013	\N	\N	\N	OL46965363M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6668	11	Hobbit	spa	\N	CreateSpace Independent Publishing Platform	2015	9781507624012	\N	\N	OL55289545M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6669	11	Hobbit	spa	\N	CreateSpace Independent Publishing Platform	2015	9781507623893	\N	\N	OL55511415M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6670	11	Hobbit	spa	\N	CreateSpace Independent Publishing Platform	2015	9781507623756	\N	\N	OL56361164M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6671	11	Hobbit	eng	\N	CreateSpace Independent Publishing Platform	2015	9781514309230	\N	\N	OL56477504M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6672	11	The Annotated Hobbit	eng	\N	Houghton Mifflin Co.	1988	9780395476901	0395476909	https://covers.openlibrary.org/b/id/14624654-M.jpg	OL2033157M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6673	11	The Hobbit	eng	\N	HarperCollins Publishers	1993	\N	0261102214	https://covers.openlibrary.org/b/id/14627588-M.jpg	OL18565795M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6674	11	Bilbo le hobbit	fra	\N	Stock	1980	9782253032939	225303293X	https://covers.openlibrary.org/b/id/10522111-M.jpg	OL31452592M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6675	11	The Hobbitt	eng	\N	Ballantine Books	1973	9780345235121	0345235126	https://covers.openlibrary.org/b/id/14626628-M.jpg	OL9893405M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6676	11	Хоббит	rus	\N	Azbuka	1997	9785768404734	5768404732	\N	OL27167680M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6677	11	The Hobbit or There and Back Again	eng	\N	Ballantine Books	1976	9780345253422	0345253426	https://covers.openlibrary.org/b/id/14624000-M.jpg	OL10682512M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6678	11	The Hobbit	eng	\N	Houghton Mifflin Company	1997	9780618002214	0618002219	https://covers.openlibrary.org/b/id/12003120-M.jpg	OL33891772M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6679	11	The Hobbit	eng	\N	HarperCollins Publishers	2008	9780007270613	0007270615	https://covers.openlibrary.org/b/id/14625971-M.jpg	OL31834369M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6680	11	De hobbit	nld	\N	Bookerij	2021	9789022591406	9022591409	https://covers.openlibrary.org/b/id/14625651-M.jpg	OL43025896M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6681	11	Lo Hobbit	ita	\N	Adelphi	2008	9788845906886	8845906884	https://covers.openlibrary.org/b/id/14625577-M.jpg	OL9188443M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6682	11	El Hobbit	spa	\N	Minotauro	2022	9788445012802	8445012800	https://covers.openlibrary.org/b/id/14626854-M.jpg	OL47104122M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6683	11	Hobbit	pol	\N	Iskry	1970	\N	8320714745	https://covers.openlibrary.org/b/id/14626648-M.jpg	OL51696707M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6684	11	Hobbit	pol	\N	ISKRY	1997	\N	8320714745	https://covers.openlibrary.org/b/id/9261041-M.jpg	OL16197261M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6685	11	Der Hobbit	deu	\N	Klett-Cotta	2001	9783608938050	3608938052	https://covers.openlibrary.org/b/id/14627559-M.jpg	OL9076623M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6686	11	Der kleine Hobbit	deu	\N	Deutscher Taschenbuch Verlag	2013	9783423214124	3423214120	https://covers.openlibrary.org/b/id/14626841-M.jpg	OL28345113M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6687	11	Bilbo le Hobbit	fra	\N	Livre de Poche	2012	9782013235327	\N	https://covers.openlibrary.org/b/id/14627198-M.jpg	OL51709243M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6688	11	Bilbo, Le Hobbit	fra	\N	Livre de Poche Jeunesse	2012	9782013218818	2013218818	https://covers.openlibrary.org/b/id/14627557-M.jpg	OL12384893M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6689	11	Bilbo le Hobbit	eng	\N	Hachette	2013	9782012039339	2012039332	https://covers.openlibrary.org/b/id/14627455-M.jpg	OL30496901M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6690	11	Bilbo le hobbit	fra	\N	Hachette Jeunesse	2006	9782012010857	2012010857	https://covers.openlibrary.org/b/id/14627041-M.jpg	OL44795696M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6691	11	The annotated hobbit	eng	\N	Houghton Mifflin Company	2002	\N	0618134700	https://covers.openlibrary.org/b/id/14624394-M.jpg	OL3571142M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6692	11	The Hobbit	eng	\N	Turtleback Books	2012	9780606262408	0606262407	https://covers.openlibrary.org/b/id/14627504-M.jpg	OL28343578M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6693	11	Hobbit	eng	\N	Mariner Books	2012	9780547844978	\N	https://covers.openlibrary.org/b/id/14627238-M.jpg	OL37390792M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6694	11	The Hobbit	eng	\N	Houghton Mifflin Company	1984	9780395520215	0395520215	https://covers.openlibrary.org/b/id/15223072-M.jpg	OL51709286M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6695	11	The annotated Hobbit	eng	\N	Houghton Mifflin Company	1988	\N	0395476909	https://covers.openlibrary.org/b/id/14627226-M.jpg	OL51709289M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6696	11	The Hobbit	eng	\N	Houghton Mifflin Company	1979	9780395282656	\N	https://covers.openlibrary.org/b/id/14627536-M.jpg	OL51711358M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6697	11	The Hobbit	eng	\N	Ballantine Books	1979	9780345272577	0345272579	https://covers.openlibrary.org/b/id/8291598-M.jpg	OL10682853M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6698	11	The Hobbit	eng	\N	Ballantine Books	1976	\N	0345253426	https://covers.openlibrary.org/b/id/14624448-M.jpg	OL51687692M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6699	11	The Hobbit	eng	\N	Ballantine Books	1975	9780345248268	0345248260	https://covers.openlibrary.org/b/id/14624617-M.jpg	OL10682346M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6700	11	The Hobbit	eng	\N	Unwin Paperbacks	1984	9780048231888	0048231886	https://covers.openlibrary.org/b/id/14625516-M.jpg	OL9228714M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6701	11	The Hobbit	eng	\N	HarperCollins Publishers	2020	9780008376055	\N	https://covers.openlibrary.org/b/id/14626631-M.jpg	OL35836365M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6702	11	The Hobbit	eng	\N	HarperCollins Publishers	2012	9780007927043	0007927045	https://covers.openlibrary.org/b/id/14625976-M.jpg	OL42634958M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6703	11	The Hobbit	eng	\N	Ted Smart	1996	9780007637706	0007637705	https://covers.openlibrary.org/b/id/10584451-M.jpg	OL31900303M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6704	11	The Hobbit	eng	\N	HarperCollins Publishers	2014	9780007591862	0007591861	https://covers.openlibrary.org/b/id/14627203-M.jpg	OL27531863M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6705	11	The Hobbit	eng	\N	George Allen & Unwin	1951	\N	\N	https://covers.openlibrary.org/b/id/14626075-M.jpg	OL22306424M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6706	11	The Hobbit	eng	\N	Ballantine Books	1967	\N	\N	https://covers.openlibrary.org/b/id/14627509-M.jpg	OL51711263M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6707	11	The Hobbit	eng	\N	Ballantine Books	1970	\N	\N	https://covers.openlibrary.org/b/id/14626151-M.jpg	OL51695380M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6708	11	The Hobbit	eng	\N	Ballantine Books	1976	\N	\N	https://covers.openlibrary.org/b/id/14626678-M.jpg	OL51696766M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6709	11	The Hobbit	eng	\N	Guild Publishing	1978	\N	\N	https://covers.openlibrary.org/b/id/14626119-M.jpg	OL43007626M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6710	11	The Hobbit	eng	\N	Guild Publishing	1980	\N	\N	https://covers.openlibrary.org/b/id/14626124-M.jpg	OL47012885M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6711	11	The Hobbit	spa	\N	Texto Online	2011	\N	\N	\N	OL28162167M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6712	11	The Hobbit	eng	\N	Mariner Books	2013	9780544164222	0544164229	https://covers.openlibrary.org/b/id/12003282-M.jpg	OL33891934M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6713	11	Hobbit	pol	\N	Amber	2007	9788324129492	8324129499	https://covers.openlibrary.org/b/id/11387212-M.jpg	OL32760447M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6714	11	Der Kleine Hobbit	deu	\N	Deutscher Taschenbuch Verlag	2004	9783423202770	3423202777	https://covers.openlibrary.org/b/id/14626130-M.jpg	OL9032793M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6715	11	El Hobbit	spa	\N	Minotauro	2013	9788445074855	8445074857	https://covers.openlibrary.org/b/id/14831764-M.jpg	OL13268284M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6716	11	Chúa tể của những chiếc nhẫn	vie	\N	Nhà xuá̂t bản Hội nhà văn	2002	\N	\N	https://covers.openlibrary.org/b/id/10650974-M.jpg	OL23042414M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6717	11	El Hobbit	spa	\N	Minotauro	2007	9788445076736	8445076736	https://covers.openlibrary.org/b/id/15146094-M.jpg	OL31935416M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6718	11	Bilbo	swe	\N	Rabén & Sjögren	2001	\N	9172632224	https://covers.openlibrary.org/b/id/14625950-M.jpg	OL24486835M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6719	11	The Hobbit	eng	\N	Methuen Publications	1977	9780458920303	0458920304	https://covers.openlibrary.org/b/id/12639817-M.jpg	OL27289715M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6720	11	De hobbit	nld	\N	Uitgeverij M	2002	9789022531921	9022531929	https://covers.openlibrary.org/b/id/14625546-M.jpg	OL43505854M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6721	11	Hobbit	pol	\N	Wydawnictwo Iskry	2002	\N	8320716810	https://covers.openlibrary.org/b/id/14625711-M.jpg	OL26801941M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6722	11	El Hobbit	spa	\N	Minotauro	2017	9786070724145	6070724143	https://covers.openlibrary.org/b/id/14625970-M.jpg	OL30561216M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6723	11	Bilbo le Hobbit	fra	\N	Le Livre de Poche	2013	9782253177104	2253177105	https://covers.openlibrary.org/b/id/10584480-M.jpg	OL31900393M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6724	11	The hobbit	eng	\N	Houghton Mifflin Company	1973	\N	0395177111	https://covers.openlibrary.org/b/id/14627505-M.jpg	OL5416735M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6725	11	The Hobbit	eng	\N	Ballantine Books	1974	\N	0345240316	https://covers.openlibrary.org/b/id/14627077-M.jpg	OL10682118M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6726	11	Bilbo le Hobbit	fra	\N	J'ai Lu	1977	\N	\N	https://covers.openlibrary.org/b/id/14627209-M.jpg	OL51709257M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6727	11	The hobbit	eng	\N	Houghton Mifflin Company	2001	\N	0618162216	https://covers.openlibrary.org/b/id/14627187-M.jpg	OL3969888M	\N	2026-11-25 20:23:33.019298+00	2026-11-25 20:23:33.019298+00
6728	12	Последнее желание	\N	\N	АСТ	2016	9785170730520	\N	https://covers.openlibrary.org/b/id/15265515-M.jpg	OL62675333M	\N	2026-11-25 20:23:38.709912+00	2026-11-25 20:23:38.709912+00
6729	12	Der Letzte Wunsch	deu	\N	dtv Verlagsgesellschaft	2020	9783423262644	\N	https://covers.openlibrary.org/b/id/15239396-M.jpg	OL62330730M	\N	2026-11-25 20:23:38.709912+00	2026-11-25 20:23:38.709912+00
6730	12	The Last Wish	\N	\N	Orbit	2022	9780316452465	0316452467	https://covers.openlibrary.org/b/id/12855306-M.jpg	OL37765857M	\N	2026-11-25 20:23:38.709912+00	2026-11-25 20:23:38.709912+00
6731	12	Last Wish	eng	\N	Orion Publishing Group, Limited	2023	9781399611398	\N	\N	OL46573642M	\N	2026-11-25 20:23:38.709912+00	2026-11-25 20:23:38.709912+00
6732	12	The Last Wish: Introducing the Witcher	\N	\N	Orbit	2017	9780316438964	0316438960	https://covers.openlibrary.org/b/id/8458308-M.jpg	OL26803794M	\N	2026-11-25 20:23:38.709912+00	2026-11-25 20:23:38.709912+00
6733	12	Ostatnie życzenie	pol	\N	superNOWA	2014	9788375780819	\N	https://covers.openlibrary.org/b/id/14843000-M.jpg	OL57703673M	\N	2026-11-25 20:23:38.709912+00	2026-11-25 20:23:38.709912+00
6734	12	Poslední přání	ces	\N	Leonardo	2022	9788074770791	\N	https://covers.openlibrary.org/b/id/14548200-M.jpg	OL49953066M	\N	2026-11-25 20:23:38.709912+00	2026-11-25 20:23:38.709912+00
6735	12	Der letzte Wunsch (Hexer)	\N	\N	\N	\N	9783453140264	3453140265	https://covers.openlibrary.org/b/id/8769871-M.jpg	OL27289989M	\N	2026-11-25 20:23:38.709912+00	2026-11-25 20:23:38.709912+00
6736	12	Der letzte Wunsch	deu	\N	Deutscher Taschenbuch Verlag	2007	9783423209939	3423209933	https://covers.openlibrary.org/b/id/9624739-M.jpg	OL25553718M	\N	2026-11-25 20:23:38.709912+00	2026-11-25 20:23:38.709912+00
6737	12	Il guardiano degli innocenti	ita	\N	Editrice Nord	2019	9788842932413	\N	https://covers.openlibrary.org/b/id/12649101-M.jpg	OL37412991M	\N	2026-11-25 20:23:38.709912+00	2026-11-25 20:23:38.709912+00
6738	12	Der letzte Wunsch	deu	\N	Deutcher Taschenbuch Verlag	2020	\N	\N	\N	OL36620849M	\N	2026-11-25 20:23:38.709912+00	2026-11-25 20:23:38.709912+00
6739	12	Le Dernier Voeu	fra	\N	Bragelonne	2003	9782914370493	2914370490	https://covers.openlibrary.org/b/id/994695-M.jpg	OL9011718M	\N	2026-11-25 20:23:38.709912+00	2026-11-25 20:23:38.709912+00
6740	12	Last Wish	eng	\N	Orion Publishing Group	2021	9781473235090	\N	\N	OL33944684M	\N	2026-11-25 20:23:38.709912+00	2026-11-25 20:23:38.709912+00
6741	12	The Last Wish	eng	\N	Orbit	2015	9781478933335	147893333X	https://covers.openlibrary.org/b/id/10657689-M.jpg	OL31983675M	\N	2026-11-25 20:23:38.709912+00	2026-11-25 20:23:38.709912+00
6742	12	The Last Wish	eng	\N	Orbit	2021	9780316333528	0316333522	https://covers.openlibrary.org/b/id/12455224-M.jpg	OL32404880M	\N	2026-11-25 20:23:38.709912+00	2026-11-25 20:23:38.709912+00
6743	12	Last Wish	eng	\N	Orion Publishing Group	2010	9780575099913	\N	\N	OL34447223M	\N	2026-11-25 20:23:38.709912+00	2026-11-25 20:23:38.709912+00
6744	12	El último deseo	spa	\N	Bibiópolis	2007	\N	9788493283698	https://covers.openlibrary.org/b/id/13113366-M.jpg	OL25838520M	\N	2026-11-25 20:23:38.709912+00	2026-11-25 20:23:38.709912+00
6745	12	El último deseo	spa	\N	Alamut	2009	9788498890259	\N	https://covers.openlibrary.org/b/id/8078079-M.jpg	OL26384832M	\N	2026-11-25 20:23:38.709912+00	2026-11-25 20:23:38.709912+00
6746	12	El último deseo	spa	\N	Alamut	2008	9788498890037	\N	https://covers.openlibrary.org/b/id/7274842-M.jpg	OL25440786M	\N	2026-11-25 20:23:38.709912+00	2026-11-25 20:23:38.709912+00
6747	12	Ostatnie życzenie	pol	\N	SuperNOWA - Niezależna Oficyna Wydawnicza	2016	9788375781250	\N	https://covers.openlibrary.org/b/id/9295550-M.jpg	OL27925775M	\N	2026-11-25 20:23:38.709912+00	2026-11-25 20:23:38.709912+00
6748	12	Ostatnie życzenie	pol	\N	SuperNOWA	1995	\N	\N	https://covers.openlibrary.org/b/id/14593168-M.jpg	OL625782M	\N	2026-11-25 20:23:38.709912+00	2026-11-25 20:23:38.709912+00
6749	12	Ostatnie życzenie	pol	\N	SuperNOWA	2001	\N	8370540619	https://covers.openlibrary.org/b/id/14533296-M.jpg	OL3617709M	\N	2026-11-25 20:23:38.709912+00	2026-11-25 20:23:38.709912+00
6750	12	Ostatnie życzenie	\N	\N	SuperNOWA	1993	\N	\N	https://covers.openlibrary.org/b/id/14533295-M.jpg	OL24650532M	\N	2026-11-25 20:23:38.709912+00	2026-11-25 20:23:38.709912+00
6751	12	Last Wish	eng	\N	Orbit	2008	9781306768481	\N	\N	OL34507768M	\N	2026-11-25 20:23:38.709912+00	2026-11-25 20:23:38.709912+00
6752	12	The Last Wish	eng	\N	Orbit	2019	9780316497541	\N	https://covers.openlibrary.org/b/id/9122187-M.jpg	OL27681775M	\N	2026-11-25 20:23:38.709912+00	2026-11-25 20:23:38.709912+00
6753	12	Der letzte Wunsch	deu	\N	Helmut Lingen Verlag	2012	\N	\N	https://covers.openlibrary.org/b/id/10582337-M.jpg	OL31896464M	\N	2026-11-25 20:23:38.709912+00	2026-11-25 20:23:38.709912+00
6754	12	Last Wish	eng	\N	Orbit	2020	9780316495967	\N	\N	OL29823876M	\N	2026-11-25 20:23:38.709912+00	2026-11-25 20:23:38.709912+00
6755	12	Last Wish	eng	\N	Orion Publishing Group, Limited	2020	9781473231061	\N	https://covers.openlibrary.org/b/id/14648782-M.jpg	OL29485067M	\N	2026-11-25 20:23:38.709912+00	2026-11-25 20:23:38.709912+00
6756	12	Last Wish	eng	\N	Orion Publishing Group, Limited	2019	9781473226401	\N	\N	OL28731729M	\N	2026-11-25 20:23:38.709912+00	2026-11-25 20:23:38.709912+00
6757	12	The Last Wish Lib/E	\N	\N	Blackstone Audio Inc	2015	9781478933304	1478933305	https://covers.openlibrary.org/b/id/8964191-M.jpg	OL27507443M	\N	2026-11-25 20:23:38.709912+00	2026-11-25 20:23:38.709912+00
6758	12	The last wish	eng	\N	Gollancz	2008	9780575082441	0575082445	https://covers.openlibrary.org/b/id/9612275-M.jpg	OL25566366M	\N	2026-11-25 20:23:38.709912+00	2026-11-25 20:23:38.709912+00
6759	12	The Last Wish	eng	\N	Orbit	1993	9780316029186	0316029181	https://covers.openlibrary.org/b/id/12848705-M.jpg	OL10426195M	\N	2026-11-25 20:23:38.709912+00	2026-11-25 20:23:38.709912+00
6760	12	The Last Wish	eng	\N	Gollancz	2007	9780575077836	0575077832	https://covers.openlibrary.org/b/id/8747762-M.jpg	OL19970603M	\N	2026-11-25 20:23:38.709912+00	2026-11-25 20:23:38.709912+00
6761	12	The Last Wish	eng	\N	Orbit	2008	9780316055086	\N	https://covers.openlibrary.org/b/id/8747763-M.jpg	OL24271596M	\N	2026-11-25 20:23:38.709912+00	2026-11-25 20:23:38.709912+00
6762	20	Harry Potter and the Philosopher's Stone	\N	\N	Media Rodzina	2025	9788384160558	\N	\N	OL63130975M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6763	20	ہیری پوٹر	urd	\N	Ummat Group of Publications	2002	\N	\N	https://covers.openlibrary.org/b/id/15251294-M.jpg	OL62514708M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6764	20	Harry Potter and the Philosopher's Stone	eng	\N	Raincoast Books	2004	9781551927282	\N	https://covers.openlibrary.org/b/id/15263570-M.jpg	OL62439119M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6765	20	Harry Potter and the Sorcerer's Stone	eng	\N	Pottermore Publishing	2025	\N	\N	https://covers.openlibrary.org/b/id/15216547-M.jpg	OL61716306M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6766	20	Harry Potter y la piedra filosofal	\N	\N	Salamandra	2019	\N	\N	https://covers.openlibrary.org/b/id/15172427-M.jpg	OL61362155M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6767	20	Harry Potter e a Pedra Filosofal	por	BR	Rocco	2025	9786586733501	6555325372	https://covers.openlibrary.org/b/id/15168707-M.jpg	OL61281195M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6768	20	Harry Potter e a Pedra Filosofal	por	BR	Pottermore Publishing	2023	9781781103234	1781103232	https://covers.openlibrary.org/b/id/15168421-M.jpg	OL61274876M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6769	20	Harry Potter e a Pedra Filosofal	\N	\N	Pottermore Publishing	2015	9781781103685	\N	https://covers.openlibrary.org/b/id/15168420-M.jpg	OL61274798M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6770	20	Harry Potter ve felsefe taşı	tur	\N	YKY	2002	\N	9750802942	https://covers.openlibrary.org/b/id/15163706-M.jpg	OL61162613M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6771	20	Harry Potter og De vises stein	nor	\N	Cappelen Damm	2011	9788204086600	8204086601	https://covers.openlibrary.org/b/id/15160588-M.jpg	OL60413146M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6772	20	Harry Potter and the Sorcerer's Stone	\N	\N	Mun-hag Sucheob Publishing Company	2014	9788983925329	8983925329	\N	OL60375367M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6773	20	Harry Potter and the Sorcerers Stone	\N	\N	Random House	1999	9780807281185	0807281182	\N	OL60346015M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6774	20	Harry Potter and the Sorcerer's Stone (Harry Potters) by Rowling, J.K. (1999) Paperback	\N	\N	Scholastic Paperbacks,1999.	1999	\N	\N	\N	OL60331364M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6775	20	Harry Potter un der filosofisher shteyn	yid	\N	Olniansky Tekst	2020	\N	\N	\N	OL59391421M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6776	20	Harry Potter and the Philosopher's Stone	eng	\N	Bloomsbury	2014	9781408855652	1408855658	https://covers.openlibrary.org/b/id/15159585-M.jpg	OL59004869M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6777	20	Harry Potter and the Sorcerer's Stone	eng	\N	Arthur A. Levine Books	1998	\N	0590353403	https://covers.openlibrary.org/b/id/15235364-M.jpg	OL58730299M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6778	20	Hyārī Poṭara ra pārasamaṇi	nep	\N	Sanabarḍa Pablisiṅa Hāusa	2009	9789937813709	9937813700	\N	OL53497028M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6779	20	Harry Potter and the Sorcerer's Stone (il. Ed. )	eng	\N	Bound to Stay Bound Books	2015	9798855115574	\N	\N	OL53345945M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6780	20	Harry Potter and the Sorcerer's Stone (Stenciled Edges) (Harry Potter, Book 1)	eng	\N	Scholastic, Incorporated	2024	9781546148500	\N	https://covers.openlibrary.org/b/id/14744999-M.jpg	OL53326469M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6781	20	Harry Potter und der Stein der Weisen	deu	\N	Carlsen	2013	9783551313119	3551313113	https://covers.openlibrary.org/b/id/15157474-M.jpg	OL47682314M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6782	20	Harry Potter och de vises sten	swe	\N	Rabén & Sjögren	2015	9789129675351	9129675359	https://covers.openlibrary.org/b/id/15284498-M.jpg	OL47682303M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6783	20	Harijs Poters un Filozofu akmens	lav	\N	Jumava	2012	9789934112249	9934112248	https://covers.openlibrary.org/b/id/15157560-M.jpg	OL47682279M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6784	20	哈利. 波特与魔法石	zho	\N	Ren min wen xue chu ban she	2005	9787020052936	7020052932	https://covers.openlibrary.org/b/id/15212346-M.jpg	OL39471692M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6785	20	Harry Potter i kamień filozoficzny	pol	\N	Media Rodzina	2003	\N	8372780005	https://covers.openlibrary.org/b/id/8477955-M.jpg	OL26818282M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6786	20	Harry Potter i kamień filozoficzny	\N	\N	Media Rodzina	2020	9788380087590	8380087593	https://covers.openlibrary.org/b/id/13952106-M.jpg	OL47359726M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6787	20	Harry Potter i Kamień Filozoficzny	\N	\N	Media Rodzina	2023	9788382655636	\N	https://covers.openlibrary.org/b/id/14420592-M.jpg	OL49371344M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6788	20	Harry Potter i kamień filozoficzny	eng	\N	Media Rodzina	2000	\N	8372780005	https://covers.openlibrary.org/b/id/15159968-M.jpg	OL61068165M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6789	20	Harry Potter und der Stein der Weisen	deu	\N	Carlsen	2018	9783551317254	\N	https://covers.openlibrary.org/b/id/15160730-M.jpg	OL61090737M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6790	20	Harry Potter a kámen mudrců	ces	\N	Albatros	2000	9788000007885	\N	https://covers.openlibrary.org/b/id/15160587-M.jpg	OL61088926M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6791	20	Harry Potter and the Sorcerer's Stone	eng	\N	Scholastic Inc.	1999	\N	059035342X	https://covers.openlibrary.org/b/id/15160586-M.jpg	OL61088892M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6792	20	Harry Potter büyülü taş	tur	\N	D	1999	9757501956008	\N	https://covers.openlibrary.org/b/id/15158675-M.jpg	OL61057835M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
8148	39	Pride and Prejudice	eng	\N	Palmera Publishing	2015	9781943862009	\N	\N	OL36216282M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
6793	20	Harry Potter und der Stein der Weisen	deu	\N	Carlsen	2002	9783551553003	3551553009	https://covers.openlibrary.org/b/id/15158575-M.jpg	OL9064566M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6794	20	Harry Potter and the Sorcerer's Stone	eng	\N	Midwest Tape	2008	9780807281956	\N	https://covers.openlibrary.org/b/id/15156818-M.jpg	OL61041706M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6795	20	Harry Potter and the Sorcerer’s Stone	eng	\N	Listening Library	2000	\N	0807281956	https://covers.openlibrary.org/b/id/15156816-M.jpg	OL61041705M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6796	20	Harry Potter and the Sorcerer’s Stone	eng	\N	Listening Library	1999	9781524721251	\N	https://covers.openlibrary.org/b/id/15156773-M.jpg	OL61041678M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6797	20	Harry Potter and the Sorcerer's Stone	eng	\N	Listening Library	2000	9780807286005	\N	https://covers.openlibrary.org/b/id/15156766-M.jpg	OL61041672M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6798	20	Harry Potter and the Sorcerer’s Stone	eng	\N	Listening Library	1999	\N	\N	https://covers.openlibrary.org/b/id/15156764-M.jpg	OL61041671M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6799	20	Harry Potter and the Sorcerer's Stone	eng	\N	Listening Library	1999	\N	\N	https://covers.openlibrary.org/b/id/15156301-M.jpg	OL61038029M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6800	20	Harry Potter a l'ecole des sorciers	eng	\N	Gallimard Jeuness	2021	9782070584628	\N	https://covers.openlibrary.org/b/id/15155844-M.jpg	OL61027605M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6801	20	Harry Potter y la piedra filosofal	spa	\N	Letras de Bolsillo	2018	\N	8498384389	https://covers.openlibrary.org/b/id/15155841-M.jpg	OL61027604M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6802	20	Harry Potter and the Philosopher's Stone	eng	\N	Bloomsbury	1997	\N	0747532745	https://covers.openlibrary.org/b/id/15155835-M.jpg	OL61027603M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6803	20	Harry Potter and the Philosopher's Stone	eng	\N	Bloomsbury	1997	\N	0747532745	https://covers.openlibrary.org/b/id/15155834-M.jpg	OL61027602M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6804	20	Harry Potter and the Philosopher's Stone	eng	\N	Bloomsbury	1997	\N	0747532745	https://covers.openlibrary.org/b/id/15155833-M.jpg	OL61027601M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6805	20	Harry Potter y la piedra filosofal	spa	\N	Pottermore Publishing	2015	9781781101315	\N	https://covers.openlibrary.org/b/id/15116676-M.jpg	OL59922337M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6806	20	Harry Potter a Kámen mudrců	ces	\N	Albatros	2003	\N	8000011085	\N	OL56375531M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6807	20	Harry Potter and the Sorcerer's Stone	eng	\N	Bound to Stay Bound Books	1998	9798855115550	\N	\N	OL53332934M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6808	20	Harry Potter e la pietra filosofale	ita	\N	French and European Publishing, Inc.	2011	9788862561686	8862561687	https://covers.openlibrary.org/b/id/15091534-M.jpg	OL52369838M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6809	20	Harry Potter y la Piedra Filosofal / Harry Potter and the Sorcerer's Stone	spa	\N	Publicaciones y Ediciones Salamandra, S.A.	2024	9798890981882	\N	\N	OL52227733M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6810	20	Harry Potter y la Piedra Filosofal (Harry Potter and the Sorcerer's Stone)	spa	\N	Publicaciones y Ediciones Salamandra, S.A.	2024	9781536489378	\N	\N	OL53327594M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6811	20	Harry Potter y la piedra filosofal ( Harry Potter 1 )	\N	\N	Salamandra	2020	9786073800280	\N	\N	OL50528577M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6812	20	Harry Potter y la piedra filosofal	spa	\N	Salamandra Bolsillo	2020	9788418173004	8418173009	https://covers.openlibrary.org/b/id/15091493-M.jpg	OL43846173M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6813	20	Harry Potter e a Pedra Filosofal	por	PT	Editorial Presença	2020	9789722365543	9722365541	https://covers.openlibrary.org/b/id/15091495-M.jpg	OL40229551M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6814	20	Harry Potter e a Pedra Filosofal	por	BR	EDITORA ROCCO LTDA.	2000	9788532511010	8532511015	https://covers.openlibrary.org/b/id/14512053-M.jpg	OL49810015M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6815	20	Harry Potter i la pedra filosofal	\N	\N	Editorial Empúries	2015	9788416367122	8416367124	https://covers.openlibrary.org/b/id/13926593-M.jpg	OL47338193M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6816	20	Harry Potter i la pedra filosofal	cat	\N	Editorial Empúries	2001	9788475966410	8475966411	https://covers.openlibrary.org/b/id/15154903-M.jpg	OL47338145M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6817	20	Harry Potter i la pedra filosofal	\N	\N	Editorial Empúries	2001	9788475968339	8475968333	https://covers.openlibrary.org/b/id/13925921-M.jpg	OL47337632M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6818	20	Harry Potter i la pedra filosofal	\N	\N	Editorial Empúries	2018	9788417016678	8417016678	https://covers.openlibrary.org/b/id/13925749-M.jpg	OL47337475M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6819	20	Harry Potter i la pedra filosofal	\N	\N	Editorial Empúries	2018	9788417016685	8417016686	https://covers.openlibrary.org/b/id/13925745-M.jpg	OL47337471M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6820	20	Harry Potter i la pedra filosofal	\N	\N	Editorial Empúries	2018	9788417016708	8417016708	https://covers.openlibrary.org/b/id/13925744-M.jpg	OL47337470M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6821	20	Harry Potter i la pedra filosofal	\N	\N	Editorial Empúries	2018	9788417016692	8417016694	https://covers.openlibrary.org/b/id/13925742-M.jpg	OL47337468M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6822	20	Harry Potter i la pedra filosofal	\N	\N	labutxaca	2016	9788499301518	8499301517	https://covers.openlibrary.org/b/id/13526834-M.jpg	OL47132792M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6823	20	Harry Potter i la pedra filosofal	\N	\N	labutxaca	2020	9788417420734	8417420738	https://covers.openlibrary.org/b/id/13523564-M.jpg	OL47130834M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6824	20	Harry Potter e a Pedra Filosofal	\N	\N	Rocco	2017	\N	\N	\N	OL51723233M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6825	20	Harry Potter and Philospher's Stone	\N	\N	Bloomsbury Publishing (IN)	1997	9780590353403	\N	https://covers.openlibrary.org/b/id/14348601-M.jpg	OL48118497M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6826	20	Harry Potter y la piedra filosofal	\N	\N	Salamandra Infantil y Juvenil	2019	9788498389395	8498389399	https://covers.openlibrary.org/b/id/14171595-M.jpg	OL47552677M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6827	20	Harry Potter y la piedra filosofal	spa	\N	Salamandra Infantil y Juvenil	2014	9788498386318	8498386314	https://covers.openlibrary.org/b/id/14171624-M.jpg	OL47552701M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6828	20	Harry Potter	ita	\N	Salani Editore	2023	\N	\N	https://covers.openlibrary.org/b/id/14812238-M.jpg	OL53613995M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6829	20	Harry Potter and the Philosopher's Stone	\N	\N	Salani Editore	2023	\N	\N	\N	OL53613994M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6830	20	Harry Potter y la piedra filosofal	\N	\N	Salamandra	2020	9789878000107	\N	https://covers.openlibrary.org/b/id/14811037-M.jpg	OL53546557M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6831	20	Ο Χάρι Πότερ και η Φιλοσοφική Λίθος	\N	\N	Ψυχογιός	2020	9789604533084	\N	\N	OL51489344M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6832	20	Harry Potter und der Stein der Weisen	deu	\N	Carlsen	2000	9783551354013	3551354014	https://covers.openlibrary.org/b/id/14573304-M.jpg	OL50716172M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
8149	39	Pride and Prejudice	eng	\N	SmartBookBinders	2015	9781944531010	\N	\N	OL36218014M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
6833	20	Harry Potter à l’École des sorciers	fra	\N	Pottermore Publishing	2015	9781781101032	\N	https://covers.openlibrary.org/b/id/14564094-M.jpg	OL50533832M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6834	20	Harry Potter and the Philosopher's Stone	eng	\N	Bloomsbury Publishing Plc	1998	9780747541189	\N	\N	OL48612222M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6835	20	Harry Potter and the Philosopher's Stone	eng	\N	Bloomsbury Publishing Plc	2015	9781408865606	\N	\N	OL48661486M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6836	20	Harry Potter And The Sorcer's Stone (The Sorcerer's Stone)	eng	\N	Random House Books On Tape	1999	9780736690003	073669000X	https://covers.openlibrary.org/b/id/13741661-M.jpg	OL7893441M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6837	20	Harry Potter e la pietra filosofale vol. 1 [ Harry Potter and the Sorcerer's Stone - Italian ]	\N	\N	French and European Publications Inc	2017	9780320094200	0320094200	https://covers.openlibrary.org/b/id/13297866-M.jpg	OL46543230M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6838	20	Harry Potter and the Sorcerer's Stone	\N	\N	Scholastic Paperbacks	1999	9780939173341	0939173344	https://covers.openlibrary.org/b/id/13174593-M.jpg	OL46529583M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6839	20	Harry Potter and the Sorcerers Stone	kor	\N	Munhaksuchup	2014	9788983925312	8983925310	https://covers.openlibrary.org/b/id/13188354-M.jpg	OL44048966M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6840	20	Harry Potter and the Sorcerer's Stone	eng	\N	Scholastic, Incorporated	2023	9781338878929	\N	\N	OL39466674M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6841	20	Harry Potter and the Philosopher`s Stone	eng	\N	Bloomsbury	2014	\N	\N	https://covers.openlibrary.org/b/id/14532860-M.jpg	OL49812360M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6842	20	Harry Potter and the Philosopher's Stone	\N	\N	Bloomsbury	2017	9781408883730	\N	https://covers.openlibrary.org/b/id/14367783-M.jpg	OL48587862M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6843	20	Harry Potter and the Philosopher's Stone	\N	\N	BBC Audiobooks	2010	9781907545016	1907545018	https://covers.openlibrary.org/b/id/13642116-M.jpg	OL47210308M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6844	20	Harry Potter a me ka Pōhaku Akeakamai	\N	\N	Evertype	2018	9781782012061	1782012060	https://covers.openlibrary.org/b/id/13119111-M.jpg	OL44989153M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6845	20	Harry Potter and the Philosopher's Stone 1	\N	\N	People's Literature Press	2015	9787020103294	7020103294	https://covers.openlibrary.org/b/id/13168448-M.jpg	OL41455994M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6846	20	Harry Potter and the Sorcerer's Stone	eng	\N	Lulu Press, Inc.	2010	9780557741250	\N	\N	OL39850991M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6847	20	Harry Potter and the Sorcerer's Stone	eng	\N	Lulu Press, Inc.	2010	9780557944880	\N	\N	OL39855430M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6848	20	Harry Potter and the Sorcerer's Stone	eng	\N	Lulu Press, Inc.	2010	9780557911769	\N	\N	OL39859241M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6849	20	Harry Potter and the Sorcerer's Stone	eng	\N	Lulu Press, Inc.	2011	9780557986873	\N	\N	OL39874637M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6850	20	Harry Potter and the sorcerer's stone	eng	\N	J.K. Rowling	2022	9783161484100	\N	\N	OL46835778M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6851	20	Harry Potter y la piedra filosofal	spa	\N	Salamandra	2001	9788478886548	8478886540	\N	OL24368924M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6852	20	הארי פוטר וחדר הסודות	heb	\N	Yediʻot Aḥronot	2001	9789654487658	9654487659	https://covers.openlibrary.org/b/id/14844703-M.jpg	OL23979009M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6853	20	Harī Pottā to kenja no ishi =	jpn	\N	Seizansha	1999	\N	4915512371	\N	OL16355404M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6854	20	哈利・波特与魔法石	zho	\N	Ren min wen xue chu ban she	2009	9787020033430	7020033431	https://covers.openlibrary.org/b/id/14320056-M.jpg	OL47774304M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6855	20	Harry Potter und der Stein der Weisen	deu	\N	Carlsen	2002	\N	\N	\N	OL20176009M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6856	20	Ο Χάρι Πότερ και η Φιλοσοφική Λίθος	ell	\N	Psychogios	2001	\N	9602743484	https://covers.openlibrary.org/b/id/14320054-M.jpg	OL47774298M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6857	20	Hō Chari Poter kai hē philosophikē lithos	ell	\N	Psychogios	1998	\N	9602743484	\N	OL23024432M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6858	20	Harry Potter y la piedra filosofal	eng	\N	Salamandra	2012	9788498384376	\N	https://covers.openlibrary.org/b/id/7280601-M.jpg	OL25445781M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6859	20	Harry potter Philosopher's Stone	\N	\N	Bloomsbury	1997	\N	\N	\N	OL38229579M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6860	20	Harry Potter à l'école des sorcierS	\N	\N	Gallimard	1999	\N	\N	\N	OL26666573M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6861	20	Harry Potter and the Philosopher's Stone  [Adult Edition]	\N	\N	Raincoast Book Distribution	2004	9781551927008	1551927004	https://covers.openlibrary.org/b/id/13707308-M.jpg	OL39810184M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6862	20	Harry Potter and the Philosopher's Stone	eng	\N	Raincoast Books	2003	9781551926674	1551926679	https://covers.openlibrary.org/b/id/15154899-M.jpg	OL40235949M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6863	20	Harry Potter e la pietra filosofale	\N	\N	Salani	2015	9788869183157	8869183157	\N	OL37861696M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6864	20	Harry Potter e la pietra filosofale. Il libro magico lenticular	\N	\N	Magazzini Salani	2018	9788893672610	8893672618	https://covers.openlibrary.org/b/id/12566067-M.jpg	OL36680597M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6865	20	Harry Potter I Kamie Filozoficzny	\N	\N	Media Rodzina	2000	9788380082113	8380082117	https://covers.openlibrary.org/b/id/10846904-M.jpg	OL32196167M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6866	20	Harry Potter i kamien filozoficzny	\N	\N	Media Rodzina	2018	9788380082335	8380082338	https://covers.openlibrary.org/b/id/11302510-M.jpg	OL32675091M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6867	20	Harry Potter i kamien filozoficzny	\N	\N	Media Rodzina	2018	9788380082328	838008232X	https://covers.openlibrary.org/b/id/11302513-M.jpg	OL32675094M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6868	20	Harry Potter e la pietra filosofale	\N	\N	Salani	2018	9788893814508	8893814501	https://covers.openlibrary.org/b/id/10540109-M.jpg	OL31848668M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6869	20	Harry Potter e la pietra filosofale	ita	\N	Salani Editore S.p.A.	2020	9788831003384	8831003380	https://covers.openlibrary.org/b/id/10869291-M.jpg	OL32234378M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6870	20	Harry Potter y la Piedra Filosofal (Harry Potter and the Sorcerer's Stone)	spa	\N	Penguin Random House Grupo Editorial	2015	9781484474068	\N	\N	OL39697681M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6871	20	Harry Potter e a Pedra Filosofal	por	BR	ROCCO	2016	9788532530271	8532530273	https://covers.openlibrary.org/b/id/15168419-M.jpg	OL39484442M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6872	20	HARRY POTTER A L'ECOLE DES SORCIERS	\N	\N	FERYANE	2005	9782840116462	2840116464	\N	OL38228892M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6873	20	Harry Potter Kamen Modrosti	\N	\N	EPTA	1999	9789616018753	9616018752	https://covers.openlibrary.org/b/id/12518635-M.jpg	OL36624500M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6874	20	Harry Potter i la pedra filosofal	\N	\N	Editorial Empúries	2016	9788416367801	8416367809	https://covers.openlibrary.org/b/id/12454756-M.jpg	OL35719102M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7090	20	Harry Potter e la pietra filosofale	\N	\N	\N	2018	9788893817028	8893817020	https://covers.openlibrary.org/b/id/10485032-M.jpg	OL30681024M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6875	20	Harry Potter e a Pedra Filosofal - Edicao Comemorativa dos 20 anos da Colecao Harry Potter	\N	\N	Rocco	2019	9788532531766	8532531768	https://covers.openlibrary.org/b/id/12369746-M.jpg	OL35664021M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6876	20	HARRY POTTER Y LA PIEDRA FILOSOFAL 20 ANIVERSARIO	\N	\N	SALAMANDRA	2014	9788498388947	8498388945	https://covers.openlibrary.org/b/id/12325291-M.jpg	OL35618111M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6877	20	HARRY POTTER Y LA PIEDRA FILOSOFAL 20 ANIVERSARIO	\N	\N	SALAMANDRA	2014	9788498388923	8498388929	https://covers.openlibrary.org/b/id/12331327-M.jpg	OL35624253M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6878	20	HARRY POTTER Y LA PIEDRA FILOSOFAL 20 ANIVERSARIO	\N	\N	SALAMANDRA	2014	9788498388909	8498388902	https://covers.openlibrary.org/b/id/12331334-M.jpg	OL35624260M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6879	20	Harry Potter ve Felsefe Tasi - Resimli Özel Baski	\N	\N	Yapi Kredi Yayinlari	2015	9789750834660	9750834666	https://covers.openlibrary.org/b/id/12297739-M.jpg	OL35586645M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6880	20	Harry Potter à l'école des sorciers	\N	\N	GALLIMARD JEUNE	2018	9782075094504	2075094500	https://covers.openlibrary.org/b/id/12023653-M.jpg	OL34102204M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6881	20	Harry Potter à l'école des sorciers	\N	\N	GALLIMARD JEUNE	2018	9782075094450	2075094454	https://covers.openlibrary.org/b/id/12023659-M.jpg	OL34102436M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6882	20	Harry Potter à l'école des sorciers	\N	\N	GALLIMARD JEUNE	2018	9782075094016	2075094012	https://covers.openlibrary.org/b/id/12023660-M.jpg	OL34102437M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6883	20	Harry Potter à l'école des sorciers	fra	\N	Gallimard jeunesse	2020	9782075145930	\N	https://covers.openlibrary.org/b/id/12499091-M.jpg	OL36005096M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6884	20	Harry Potter a l'ecole des sorciers	\N	\N	GALLIMARD JEUNE	2018	9782075094559	2075094551	https://covers.openlibrary.org/b/id/12023652-M.jpg	OL34102203M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6885	20	Harry Potter, Tome 1	\N	\N	French and European Publications Inc	2011	9780320081064	0320081060	https://covers.openlibrary.org/b/id/11974714-M.jpg	OL33448179M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6886	20	Harry Potter, Tome 1	\N	\N	GALLIMARD JEUNE	2008	9782070619177	2070619176	https://covers.openlibrary.org/b/id/11540348-M.jpg	OL32914963M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6887	20	Harry Potter e a Pedra Filosofal	por	PT	Editorial Presença	2022	9789722365598	9722365592	https://covers.openlibrary.org/b/id/15155851-M.jpg	OL32172820M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6888	20	Harry Potter i la pedra filosofal	\N	\N	Tandem Edicions, S.L.	2001	9788481312775	8481312770	https://covers.openlibrary.org/b/id/11064377-M.jpg	OL32402193M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6889	20	Harry Potter y la piedra filosofal	\N	\N	Valley View, Pottermore	2012	9781781101179	\N	https://covers.openlibrary.org/b/id/10515167-M.jpg	OL31402170M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6890	20	Harry Potter y la piedra filosofal	\N	\N	Salamandra Bolsillo	2010	9788498382662	8498382661	https://covers.openlibrary.org/b/id/10517813-M.jpg	OL31421523M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6891	20	Garri Potter i filosofskiy kamen. Griffindor	\N	\N	Mahaon	2017	9785389136212	5389136217	https://covers.openlibrary.org/b/id/10289945-M.jpg	OL28341610M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6892	20	Harry Potter ve Felsefe Tasi. Harry Potter und der Stein der Weisen. Türkische Ausgabe.	deu	\N	Bertelsmann, München	2001	9783570211014	3570211010	https://covers.openlibrary.org/b/id/3236136-M.jpg	OL12816316M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6893	20	Harry Potter og De Vises Sten	dan	\N	Gyldendal	2016	9788702113990	8702113996	https://covers.openlibrary.org/b/id/12917614-M.jpg	OL39797842M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6894	20	Harry Potter a kámen mudrců	ces	\N	Albatros	2001	9788000009957	8000009951	https://covers.openlibrary.org/b/id/15154788-M.jpg	OL38569863M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6895	20	Harry Potter y la piedra filosofal	spa	\N	Emecé Editores	2000	9788478885619	8478885617	https://covers.openlibrary.org/b/id/14925450-M.jpg	OL38565767M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6896	20	Harry Potter and the Sorcerer's Stone	eng	\N	Scholastic Inc.	1999	9780590353427	059035342X	https://covers.openlibrary.org/b/id/15154727-M.jpg	OL39793700M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6897	20	ハリー. ポッターと賢者の石	jpn	\N	Seizansha	2003	9784915512490	4915512495	https://covers.openlibrary.org/b/id/15155757-M.jpg	OL39220465M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6898	20	Harry Potter and the Sorcerers Stone	\N	\N	\N	2014	9788983925541	898392554X	\N	OL38582288M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6899	20	Harry Potter à l'école des sorciers	\N	\N	French and European Publications Inc	\N	9781547904761	1547904763	\N	OL38568005M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6900	20	Harry Potter and the Sorcerer's Stone	\N	\N	Harry Potter	1999	9780807281758	0807281751	\N	OL38242047M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6901	20	Harry Potter And The Sorcerer's Stone	\N	\N	Turtleback Books	2001	9780613959926	0613959922	\N	OL39219851M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6902	20	Harry Potter and the Sorcerers Stone	\N	\N	\N	2008	9781439520031	1439520038	https://covers.openlibrary.org/b/id/12584120-M.jpg	OL36696129M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6903	20	Harry Potter and the Sorcerer's Stone	eng	\N	Scholastic, Incorporated	1999	9781484465479	\N	\N	OL36345036M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6904	20	Harry Potter and the Sorcerer's Stone	eng	\N	Scholastic, Incorporated	2018	9781536443721	\N	\N	OL36345043M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6905	20	Harry Potter e la Pietra Filosofale	ita	\N	Adriano Salani Editore	2020	9788831004169	\N	https://covers.openlibrary.org/b/id/12728008-M.jpg	OL37844840M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6906	20	Harry Potter e la Pietra Filosofale	ita	\N	Salani Editore	2002	\N	8877827025	https://covers.openlibrary.org/b/id/12726690-M.jpg	OL37829388M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6907	20	해리 포터 시리즈	kor	\N	Munhak Suchʻŏp	1999	9788983920676	898392067X	\N	OL23038810M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6908	20	Гаррі Поттер і філософський камінь	ukr	\N	А-ба-ба-га-ла-ма-га	2017	9789667047399	\N	https://covers.openlibrary.org/b/id/12649038-M.jpg	OL37389561M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6909	20	Harry Potter Y La Piedra Filosofal	\N	\N	Círculo de Lectores	1999	9788422679875	8422679876	https://covers.openlibrary.org/b/id/12498982-M.jpg	OL35992755M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6910	20	Harry Potter y la piedra filosofal	\N	\N	Salamandra Infantil y Juvenil	2018	9788498388886	8498388880	https://covers.openlibrary.org/b/id/12331331-M.jpg	OL35624257M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6911	20	HARRY POTTER Y LA PIEDRA FILOSOFAL / BOLSILLO	\N	\N	SALAMANDRA DE BOLSILLO	2020	9786073193009	6073193009	https://covers.openlibrary.org/b/id/10657636-M.jpg	OL31983499M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6912	20	Harry Potter and the Philosopher's Stone	\N	\N	Bloomsbury Pub Ltd	2000	9781551923987	155192398X	https://covers.openlibrary.org/b/id/12584121-M.jpg	OL36696130M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6913	20	Harry Potter és a bölcsek köve	hun	\N	Animus Kiadó	2002	9789639307223	963930722X	https://covers.openlibrary.org/b/id/15154781-M.jpg	OL37045177M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
8150	39	Pride and Prejudice	eng	\N	Little Tiger Press Group	2016	9781848693265	\N	\N	OL36219147M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
6914	20	Harry Potter and the Sorcerer's Stone	eng	\N	Paw Prints	2008	9781435238138	1435238133	https://covers.openlibrary.org/b/id/12460253-M.jpg	OL35723750M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6915	20	Harry Potter y la Piedra Filosofal / Harry Potter and the Sorcerer's Stone	spa	\N	Salamandra	2021	9786073193894	\N	https://covers.openlibrary.org/b/id/13546068-M.jpg	OL34171817M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6916	20	Harry Potter y la Piedra Filosofal	spa	\N	Salamandra	2018	9788498388916	\N	https://covers.openlibrary.org/b/id/12878077-M.jpg	OL34086917M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6917	20	Harry Potter y la Piedra Filosofal. Edición Slytherin / Harry Potter and the Sorcerer's Stone	spa	\N	Publicaciones y Ediciones Salamandra, S.A.	2018	9788498388930	\N	https://covers.openlibrary.org/b/id/13895436-M.jpg	OL34081944M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6918	20	Harry Potter y la Piedra Filosofal	spa	\N	Salamandra	2016	9788498387094	8498387094	https://covers.openlibrary.org/b/id/15154789-M.jpg	OL34023955M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6919	20	Harry Potter y la Piedra Filosofal. Edición Ilustrada / Harry Potter and the Sorcerer's Stone	spa	\N	Publicaciones y Ediciones Salamandra, S.A.	2019	9788498389487	\N	\N	OL34103282M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6920	20	Harry Potter and the Sorcerer's Stone	\N	\N	Seizansha	2020	9784863895669	4863895666	https://covers.openlibrary.org/b/id/10705714-M.jpg	OL32038910M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6921	20	Harry Potter and the Sorcerer's Stone	\N	\N	Turtleback Books	2018	9780606415200	0606415203	https://covers.openlibrary.org/b/id/10955284-M.jpg	OL32332933M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6922	20	Harry Potter y la piedra filosofal  / Harry Potter and the Sorcerer's Stone	\N	\N	Salamandra Infantil y Juvenil	2021	9788418174070	8418174072	https://covers.openlibrary.org/b/id/10550239-M.jpg	OL31871274M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6923	20	Harry Potter y la piedra filosofal. Edición Gryffindor / Harry Potter and the Sorcerer's Stone	\N	\N	Salamandra Infantil y Juvenil	2018	9788498388879	8498388872	https://covers.openlibrary.org/b/id/10533160-M.jpg	OL31834713M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6924	20	Harry Potter and the Philosopher's Stone	eng	\N	Bloomsbury	2013	9781408849927	1408849925	https://covers.openlibrary.org/b/id/12376736-M.jpg	OL35676065M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6925	20	Harry Potter and the Philosopher's Stone - 25th Anniversary Edition	eng	\N	Bloomsbury Publishing Plc	2022	9781526646651	\N	https://covers.openlibrary.org/b/id/13123209-M.jpg	OL34791070M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6926	20	Harry Potter à l'école des sorciers	fra	\N	Gallimard Jeunesse	2013	9782070643028	2070643026	https://covers.openlibrary.org/b/id/15254226-M.jpg	OL26142480M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6927	20	Harry Potter and the Philosopher's Stone	\N	\N	BBC Audiobooks	2010	9781907545009	190754500X	https://covers.openlibrary.org/b/id/10864265-M.jpg	OL32222457M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6928	20	Harry Potter and the Philosopher's Stone	bul	\N	Егмонт	2001	\N	9544464689	https://covers.openlibrary.org/b/id/11223032-M.jpg	OL32582210M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6929	20	Harry Potter and the philosopher's stone	\N	\N	Scholastic press	1997	\N	\N	\N	OL29468910M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6930	20	Harry Potter and the Sorcerer's Stone	eng	\N	Scholastic Inc.	2020	9781338596700	1338596705	https://covers.openlibrary.org/b/id/12878079-M.jpg	OL30167068M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6931	20	Harry Potter and the Sorcerer's Stone	\N	\N	Demco Media	1998	9780606170970	0606170979	https://covers.openlibrary.org/b/id/10447992-M.jpg	OL30189840M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6932	20	Harry Potter and the Sorcerer's Stone	eng	\N	Scholastic	2013	9780545582889	0545582881	https://covers.openlibrary.org/b/id/15277787-M.jpg	OL30621390M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6933	20	Harry Potter y la piedra filosofal. Edición Hufflepuff / Harry Potter and the Sorcerer's Stone	\N	\N	Salamandra Infantil y Juvenil	2018	9788498388893	8498388899	https://covers.openlibrary.org/b/id/10515101-M.jpg	OL31401961M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6934	20	Harry Potter y la Piedra Filosofal / Harry Potter and the Sorcerer's Stone	spa	\N	Penguin Random House Grupo Editorial (USA) LLC	2020	9781644732076	\N	https://covers.openlibrary.org/b/id/14605749-M.jpg	OL29882031M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6935	20	Harry Potter y la Piedra Filosofal / Harry Potter and the Sorcerer's Stone	spa	\N	Publicaciones y Ediciones Salamandra, S.A.	2020	9788498389234	\N	\N	OL30014180M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6936	20	Harry Potter y la Piedra Filosofal	spa	\N	Salamandra	2015	9788498386943	\N	https://covers.openlibrary.org/b/id/15154900-M.jpg	OL29723715M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6937	20	Harry Potter ujaraallu inuunartoq	kal	\N	Atuakkiorfik	2002	9788755817685	8755817688	https://covers.openlibrary.org/b/id/10521215-M.jpg	OL31445670M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6938	20	Harry Potter and the Philosopher's Stone	\N	\N	People's Literature Publishing House	2018	9787020144532	7020144535	https://covers.openlibrary.org/b/id/10484590-M.jpg	OL30679781M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6939	20	Harry Potter & the Philosopher's Stone	eng	\N	Bloomsbury	2018	9781408894620	\N	https://covers.openlibrary.org/b/id/15154784-M.jpg	OL28696529M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6940	20	Harry Potter and the Philosopher's Stone	eng	\N	Bloomsbury Publishing Plc	2020	9781526626585	\N	https://covers.openlibrary.org/b/id/15277213-M.jpg	OL29496285M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6941	20	Den Harry Potter an den Alchimistesteen	ltz	\N	Kairos	2009	9782919771011	\N	\N	OL30494726M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6942	20	Harry Potter and the Philosopher's Stone	eng	\N	Bloomsbury	2017	9781408883778	1408883775	https://covers.openlibrary.org/b/id/15259457-M.jpg	OL28619596M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6943	20	Harry Potter and the Philosopher's Stone (Irish)	eng	\N	Bloomsbury Publishing Plc	2015	9781408866191	\N	https://covers.openlibrary.org/b/id/13649142-M.jpg	OL29260077M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6944	20	Harry Potter and the Philosopher's Stone	cym	\N	Bloomsbury Publishing Plc	2016	9781408871591	\N	https://covers.openlibrary.org/b/id/13449410-M.jpg	OL29278359M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6945	20	Harry Potter and the Philosopher's Stone	eng	\N	Bloomsbury Publishing PLC	2010	9781408817674	1408817675	https://covers.openlibrary.org/b/id/10374295-M.jpg	OL29106843M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
8151	39	Pride and Prejudice	eng	\N	Hyde Park Editions Limited	2016	9781911060130	\N	\N	OL36220301M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8152	39	Pride and Prejudice	eng	\N	HarperCollins Publishers Limited	2021	9780008481995	\N	\N	OL36261428M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8153	39	Pride and Prejudice	eng	\N	Airmont Publishing Company, Incorporated	1962	9780804900010	\N	\N	OL36285836M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8154	39	Pride and Prejudice	eng	\N	Steck-Vaughn	1988	9780817221881	\N	\N	OL36285837M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8155	39	Pride and Prejudice	eng	\N	Acclaim Books	1998	9781578402007	\N	\N	OL36285862M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8156	39	Pride and Prejudice	eng	\N	JMW Group, Incorporated	2002	9780924967696	\N	\N	OL36286004M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8157	39	Pride and Prejudice	eng	\N	Toby Press LLC, The	2003	9781592640027	\N	\N	OL36286015M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8158	39	Pride and Prejudice	eng	\N	Penguin Publishing Group	1961	9780451513960	\N	\N	OL36286021M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8159	39	Pride and Prejudice	eng	\N	Penguin Publishing Group	2004	9780786511303	\N	\N	OL36286034M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8160	39	Pride and Prejudice	eng	\N	Quiet Vision Publishing	2000	9781576463512	\N	\N	OL36286183M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8161	39	Pride and Prejudice	eng	\N	Penguin Publishing Group	1961	9780451500823	\N	\N	OL36286344M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8162	39	Pride and Prejudice	eng	\N	Penguin Publishing Group	1961	9780451507211	\N	\N	OL36286345M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8163	39	Pride and Prejudice	eng	\N	Penguin Publishing Group	1961	9780451509772	\N	\N	OL36286346M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8164	39	Pride and Prejudice	eng	\N	Penguin Publishing Group	1961	9780451512536	\N	\N	OL36286347M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8165	39	Pride and Prejudice	eng	\N	Polyglot Press, Incorporated	2002	9781931927437	\N	\N	OL36286349M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8166	39	Pride and Prejudice	eng	\N	Pavilion Press, Incorporated	2004	9781414500201	\N	\N	OL36286358M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8167	39	Pride and Prejudice	eng	\N	Beekman Books, Incorporated	1980	9780846410713	\N	\N	OL36286502M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8168	39	Pride and Prejudice	eng	\N	Savvas Learning Company	2000	9780130237019	\N	\N	OL36286701M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8169	39	Pride and Prejudice	eng	\N	Penguin Publishing Group	1961	9780451514912	\N	\N	OL36286710M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8170	39	Pride and Prejudice	eng	\N	Penguin Publishing Group	1961	9780451519160	\N	\N	OL36286711M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8171	39	Pride and Prejudice	eng	\N	Econo-Clad Books	1994	9780785754879	\N	https://covers.openlibrary.org/b/id/14552707-M.jpg	OL36286727M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8172	39	Pride and Prejudice	eng	\N	Ann Arbor Editions LLC	2006	9781587263507	\N	\N	OL36286782M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8173	39	Pride and Prejudice	eng	\N	Quiet Vision Publishing	2000	9781576463505	\N	\N	OL36286863M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8174	39	Pride and Prejudice	eng	\N	Classic Books	2001	9780742670716	\N	\N	OL36287001M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8175	39	Pride and Prejudice	eng	\N	Ann Arbor Editions LLC	2008	9781587263514	\N	\N	OL36287063M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8176	39	Pride and Prejudice	eng	\N	Baen Books	1900	9780671542276	\N	\N	OL36287154M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8177	39	Pride and Prejudice	eng	\N	IP Data Corporation	2000	9781588530226	\N	\N	OL36287157M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8178	39	Pride and Prejudice	eng	\N	Penguin Publishing Group	1961	9780451516626	\N	\N	OL36287312M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8179	39	Pride and Prejudice	eng	\N	Pavilion Press, Incorporated	2004	9781414500065	\N	\N	OL36287326M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8180	39	Pride and Prejudice	eng	\N	Turtleback	1995	9780613639781	\N	\N	OL36287328M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8181	39	Pride and Prejudice	eng	\N	Turtleback	2000	9780613667258	\N	\N	OL36287329M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8182	39	Pride and Prejudice	eng	\N	Ann Arbor Editions LLC	2003	9781587260490	\N	\N	OL36287332M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8183	39	Pride and Prejudice	eng	\N	Kessinger Publishing, LLC	2004	9781419242908	\N	\N	OL36287338M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8184	39	Pride and Prejudice	eng	\N	DIANE Publishing Company	2008	9781422394304	\N	\N	OL36287403M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8185	39	Pride and Prejudice	eng	\N	Penguin Publishing Group	1985	9780525183815	\N	\N	OL36287433M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8186	39	Pride and Prejudice	eng	\N	Quiet Vision Publishing	2000	9781576462676	\N	\N	OL36287467M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8187	39	Orgulho e Preconceito	por	BR	José Olympio	2019	9788503013734	8503013738	https://covers.openlibrary.org/b/id/15253181-M.jpg	OL62539297M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8188	39	Orgoglio e pregiudizio	ita	\N	Mondadori	2016	9788804671404	\N	https://covers.openlibrary.org/b/id/15248984-M.jpg	OL62492181M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8189	39	Stolz und Vorurteil	deu	\N	Fischer Taschenbuch Verlag	2005	9783596222056	\N	https://covers.openlibrary.org/b/id/15246891-M.jpg	OL62450377M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8190	39	Stolz und Vorurteil / Pride and Prejudice	deu	\N	Anaconda	2012	9783866478893	\N	https://covers.openlibrary.org/b/id/15238092-M.jpg	OL62302206M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8191	39	Mândrie și prejudecată	ron	\N	Litera	2024	9786303196381	\N	https://covers.openlibrary.org/b/id/15172656-M.jpg	OL61365152M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8192	39	Stolz und Vorurteil	deu	\N	Insel Verlag	1997	\N	3458324879	https://covers.openlibrary.org/b/id/15172095-M.jpg	OL61357305M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8193	39	Pride and Prejudice	\N	\N	Everyman's Library	1991	9781857150018	\N	https://covers.openlibrary.org/b/id/15088630-M.jpg	OL59166471M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8194	39	Pride and prejudice	eng	\N	Methuen & Co.	1900	\N	\N	\N	OL53693054M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8195	39	Pride and prejudice	eng	\N	Musson Book Co.	\N	\N	\N	\N	OL53649908M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8196	39	Pride and prejudice	eng	\N	Dent	1955	\N	\N	\N	OL53080481M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8197	39	Orgullo y Prejuicio	spa	\N	Editorial Alma	2024	9788419599216	\N	\N	OL51612183M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8198	39	Pride and Prejudice	\N	\N	Macmillan and Co	1914	\N	\N	\N	OL51495338M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8199	39	Pride and Prejudice	eng	\N	Printers Row Publishing Group	2024	9781645176237	\N	\N	OL51585850M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8200	39	Pride and Prejudice	eng	\N	Sterling Publishing Co., Inc.	2024	9781454957539	\N	\N	OL51629060M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8201	39	Pride and Prejudice (Riverside Editions)	eng	\N	Houghton Mifflin	1956	\N	\N	https://covers.openlibrary.org/b/id/15043412-M.jpg	OL51161897M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8202	39	Pride and Prejudice (Great Illustrated Classics)	eng	\N	Dodd, Mead & Company	1945	\N	\N	https://covers.openlibrary.org/b/id/15043395-M.jpg	OL50521355M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8203	39	Pride And Prejudice	\N	\N	Signet	1963	\N	\N	\N	OL50495501M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8204	39	Pride and prejudice	\N	\N	Doubleday, Doran & company, inc.	1945	\N	\N	\N	OL50512985M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8205	39	Pride and Prejudice	eng	\N	Pan Macmillan	2024	9781035040445	\N	\N	OL50644053M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8206	39	Pride and Prejudice	eng	\N	Liese. Outside The Box, Andreas	2015	9783956760235	\N	\N	OL50685216M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8207	39	Pride and Prejudice	eng	\N	Penguin Young Readers Group	2024	9780593622452	\N	https://covers.openlibrary.org/b/id/15223895-M.jpg	OL50705738M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8208	39	Pride and Prejudice	eng	\N	Dover Publications, Incorporated	2024	9780486852966	\N	\N	OL50711690M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8209	39	Pride and Prejudice	eng	\N	Garden Strawberry	2023	9798989445615	\N	\N	OL50719670M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8210	39	Pride and Prejudice	eng	\N	Garden Strawberry	2024	9798989445622	\N	\N	OL50735125M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8211	39	Pride and Prejudice	eng	\N	Creative Media Partners, LLC	2023	9781020456480	\N	\N	OL50767107M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8212	39	PRIDE & PREJUDICE Easton Press	eng	\N	Easton Press	1996	\N	\N	https://covers.openlibrary.org/b/id/15043391-M.jpg	OL50066260M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8213	39	Pride and Prejudice - Great Reads Series	\N	\N	\N	2013	\N	\N	\N	OL49944305M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8214	39	Pride and Prejudice	\N	\N	Oxford	2006	9780199209217	0199209219	\N	OL49822800M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8215	39	Orgueil et Préjugés	fra	\N	Lulu Press, Inc.	2018	9780244739638	\N	\N	OL49715499M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8216	39	Pride and Prejudice (Note-Taker's Extra Small Size Edition with Interleaved Blank Pages)	eng	\N	Independently Published	2021	9798740956947	\N	\N	OL48314454M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8217	39	Pride and Predujice.	\N	\N	Createspace Independent Publishing Platform	2015	9781519674586	1519674589	https://covers.openlibrary.org/b/id/13893906-M.jpg	OL47325801M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8218	39	Orgullo y Prejuicio  --2022--	spa	\N	Independently Published	2022	9798409477950	\N	\N	OL42628912M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8219	39	Orgueil et Préjugés (1813)	fra	\N	Independently Published	2017	9781521901397	\N	\N	OL40856369M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8220	39	Pride and Pejudice	eng	\N	Independently Published	2018	9781980843665	\N	\N	OL40820793M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8221	39	Orgueil et Préjugé (4 TOMES)	fra	\N	Independently Published	2017	9781549784255	\N	\N	OL40533473M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8222	39	Orgullo y Perjuicio	\N	\N	Fonolibro on Brilliance Audio	2018	9781543675535	1543675530	https://covers.openlibrary.org/b/id/13979933-M.jpg	OL37301015M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8223	39	Pride & Prejudice (100 Copy Collector's Edition)	eng	\N	AD Classic	2019	9781772268805	\N	\N	OL36359707M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8224	39	Pride & Prejudice (100 Copy Limited Edition)	eng	\N	Engage Books	2018	9781772265590	\N	\N	OL36340104M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8225	39	Pride & Prejudice (100 Copy Limited Edition)	eng	\N	Engage Books	2019	9781772267181	\N	\N	OL36340168M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8226	39	ORGULLO Y PREJUICIO Debols!llo	\N	\N	Debolsillo	2014	9789875669932	9875669938	https://covers.openlibrary.org/b/id/12342982-M.jpg	OL35636052M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8227	39	Orgueil et préjugés	\N	\N	Books on Demand	2021	9782322182510	2322182516	https://covers.openlibrary.org/b/id/11303419-M.jpg	OL32676496M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8228	39	Orgueil et Préjugés	\N	\N	Books on Demand	2020	9782322273614	2322273619	https://covers.openlibrary.org/b/id/10538086-M.jpg	OL31844232M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8229	39	Pride & Prejudice Annotated	eng	\N	Independently Published	2019	9781704721460	\N	\N	OL29868651M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8230	39	Pride & Prejudice Annotated	eng	\N	Independently Published	2019	9781706091929	\N	\N	OL29869304M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8231	39	Pride and Prejudice	eng	\N	Turtleback	1994	9780606186513	\N	\N	OL36287481M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8232	39	Pride and Prejudice	eng	\N	Ebsco Publishing	1990	9780585377612	\N	\N	OL36287611M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8233	39	Pride and Prejudice	eng	\N	Penguin Publishing Group	1961	9780451508430	\N	\N	OL36287625M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8234	39	Pride and Prejudice	eng	\N	Turtleback	1998	9780613760195	\N	\N	OL36287636M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8235	39	Pride and Prejudice	eng	\N	Eighteen Hundred Seventy Three Press	2000	9780594053132	\N	\N	OL36287811M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8236	39	Pride and Prejudice	eng	\N	Savvas Learning Company	2000	9780130237316	\N	\N	OL36287918M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8237	39	Pride and Prejudice	eng	\N	Savvas Learning Company	2000	9780130236937	\N	\N	OL36287919M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8238	39	Pride and Prejudice	eng	\N	Penguin Publishing Group	1961	9780451511119	\N	\N	OL36287935M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8239	39	Pride and Prejudice	eng	\N	Polyglot Press, Incorporated	2002	9781931927017	\N	\N	OL36287937M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8240	39	Pride and Prejudice	eng	\N	Polyglot Press, Incorporated	2002	9781931927420	\N	\N	OL36287938M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8241	39	Pride and Prejudice	eng	\N	Turtleback	2002	9780613640954	\N	https://covers.openlibrary.org/b/id/14328422-M.jpg	OL36287948M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8242	39	Pride and Prejudice	eng	\N	Wiley & Sons, Incorporated, John	2000	9780822071723	\N	\N	OL36288077M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8243	39	Pride and Prejudice	eng	\N	Quiet Vision Publishing	2000	9781576463529	\N	\N	OL36288079M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8244	39	Pride and Prejudice	eng	\N	Ebsco Publishing	1992	9780585258164	\N	\N	OL36288156M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8245	39	Pride and Prejudice	eng	\N	Polyglot Press, Incorporated	2002	9781931927413	\N	\N	OL36288219M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8246	39	Pride and Prejudice	eng	\N	Pavilion Press, Incorporated	2004	9781414500348	\N	\N	OL36288228M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8247	39	Pride and Prejudice	eng	\N	Ann Arbor Editions LLC	2007	9781587265150	\N	\N	OL36288280M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8248	39	Pride and Prejudice	eng	\N	Prestwick House, Incorporated	2005	9781608438358	\N	\N	OL36288686M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8249	39	Pride and Prejudice	eng	\N	CreateSpace Independent Publishing Platform	2009	9781448646333	\N	\N	OL36288725M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8250	39	Pride and Prejudice	eng	\N	Barnes & Noble, Incorporated	2011	9781435136557	\N	\N	OL36289106M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
9626	9	Return of the King	eng	\N	HarperCollins Publishers	2009	9780061917882	\N	\N	OL37355893M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9627	9	Return of the King	eng	\N	HarperCollins Publishers	2009	9780061917905	\N	\N	OL37371069M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9628	9	Return of the King	eng	\N	HarperCollins Publishers	2009	9780061917912	\N	\N	OL37374819M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9629	9	Return of the King	eng	\N	HarperCollins Publishers	2009	9780061917899	\N	\N	OL37378699M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9630	9	The Lord of the Rings Return of the King	\N	\N	Harpercollins Pub Ltd	2001	9780007127443	0007127448	https://covers.openlibrary.org/b/id/12568910-M.jpg	OL36686271M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9631	9	Return of the King	eng	\N	HarperCollins Publishers Limited	2020	9780008376086	\N	https://covers.openlibrary.org/b/id/14694384-M.jpg	OL35850496M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
8251	39	Pride and Prejudice	eng	\N	Adegi Graphics LLC	1999	9780543737106	\N	\N	OL36289171M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8252	39	Pride and Prejudice	eng	\N	CreateSpace Independent Publishing Platform	2011	9781463792770	\N	\N	OL36289223M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8253	39	Pride and Prejudice	eng	\N	CreateSpace Independent Publishing Platform	2011	9781456510053	\N	\N	OL36289297M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8254	39	Pride and Prejudice	eng	\N	CreateSpace Independent Publishing Platform	2009	9781449557867	\N	\N	OL36289754M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8255	39	Pride and Prejudice	eng	\N	Mizzou Publishing - The Mizzou Store	2009	9781616000080	\N	\N	OL36289766M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8256	39	Pride and Prejudice	eng	\N	CreateSpace Independent Publishing Platform	2010	9781452824468	\N	\N	OL36289863M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
9632	9	Return of the King	eng	\N	Houghton Mifflin Harcourt Trade & Reference Publishers	2012	9781299884915	\N	\N	OL37177363M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9633	9	Return of the King	eng	\N	HarperCollins Publishers Limited	2022	9780008537746	\N	\N	OL37341944M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9634	9	El señor de los anillos III : el retorno del rey (2019)	spa	\N	Planeta Colombiana Editorial	2019	9789584280350	\N	https://covers.openlibrary.org/b/id/10511331-M.jpg	OL31013785M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9635	9	Retorno Del Rey	spa	\N	Minotauro Ediciones	2002	9788445073742	\N	https://covers.openlibrary.org/b/id/13744980-M.jpg	OL28941325M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9636	9	Retorno Del Rey	\N	\N	Minotauro	2004	\N	8445073745	https://covers.openlibrary.org/b/id/10612096-M.jpg	OL31929499M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9637	9	王者再臨	zho	\N	聯經	2001	\N	9570823380	https://covers.openlibrary.org/b/id/12664496-M.jpg	OL23041749M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9638	9	O regresso do rei	por	PT	Europa-America	2002	9789721041547	9721041548	\N	OL21569651M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9639	9	Die Wiederkehr des Königs	deu	\N	Klett-Cotta	2000	9783608935431	3608935436	https://covers.openlibrary.org/b/id/8142468-M.jpg	OL22106818M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9640	9	Le retour du roi	fra	\N	Christian Bourgois	1973	9782266118026	2266118021	\N	OL23134821M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9641	9	The Return of the King	eng	\N	Ballantine Books	2003	9780345339737	0345339738	https://covers.openlibrary.org/b/id/14626842-M.jpg	OL24934077M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9642	9	The Return of The King	eng	\N	Ballantine Books	1984	9780345296085	0345296087	https://covers.openlibrary.org/b/id/9249723-M.jpg	OL24935110M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9643	9	The Return of the King	eng	\N	Ballantine Books	1970	\N	\N	https://covers.openlibrary.org/b/id/9249715-M.jpg	OL24373736M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9644	9	The Return of the King	eng	\N	ISIS Large Print Books	1991	9781850894247	1850894248	\N	OL9406818M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9645	9	The Return of the King	eng	\N	Houghton Mifflin	1994	9780618002245	0618002243	https://covers.openlibrary.org/b/id/14951359-M.jpg	OL24610193M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9646	9	The Return of The King	eng	\N	HarperCollins	1997	9780261103597	0261103598	https://covers.openlibrary.org/b/id/8461498-M.jpg	OL22640311M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9647	9	The Return of The King	eng	\N	Houghton Mifflin	2002	9780618260553	0618260552	https://covers.openlibrary.org/b/id/8461536-M.jpg	OL3777334M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9648	9	The Return of The King	eng	\N	Houghton Mifflin	1981	9780395312681	039531268X	https://covers.openlibrary.org/b/id/14624635-M.jpg	OL3848674M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9649	9	The Return of the King	eng	\N	Ballantine Books	1975	9780345248299	0345248295	\N	OL10682349M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9650	9	The return of the king	eng	\N	HarperCollins Publishers	1991	9780261102330	0261102338	https://covers.openlibrary.org/b/id/14625524-M.jpg	OL10236389M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9651	9	The Return of the King	eng	\N	Ballantine Books	1978	9780345272607	0345272609	https://covers.openlibrary.org/b/id/9249710-M.jpg	OL10682856M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9652	9	The Return of the King	eng	\N	Ballantine Books	1985	9780345332097	0345332091	\N	OL10684789M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9653	9	The Return of the King	eng	\N	Ted Smart	1997	9780007637683	0007637683	https://covers.openlibrary.org/b/id/12003374-M.jpg	OL19634003M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9654	9	The Return of the King	eng	\N	Ballantine Books	1974	9780345240347	0345240340	https://covers.openlibrary.org/b/id/15236304-M.jpg	OL10682120M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9655	9	The return of the king	eng	\N	Houghton Mifflin Co.	1986	\N	039548930X	https://covers.openlibrary.org/b/id/255846-M.jpg	OL2131720M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9656	9	The Return of the King	eng	\N	HarperCollins	2009	9780007322558	\N	https://covers.openlibrary.org/b/id/6423686-M.jpg	OL24279131M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9657	9	The Return of The King	eng	\N	G. Allen & Unwin	1966	9780048230478	0048230472	https://covers.openlibrary.org/b/id/8141314-M.jpg	OL16007731M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9658	9	The Return of the King	eng	\N	Houghton Mifflin Company	2001	9780618154005	0618154000	https://covers.openlibrary.org/b/id/8461563-M.jpg	OL3970931M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9659	9	The return of the king	\N	\N	Houghton Mifflin	1965	\N	039548930X	\N	OL18361532M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9660	9	The Return of the King	eng	\N	HarperCollins	2009	9780061917868	\N	\N	OL24287586M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9661	9	The Return of the King	eng	\N	HarperCollins	2001	9780007123803	0007123809	https://covers.openlibrary.org/b/id/9255336-M.jpg	OL20392464M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9662	9	The Return of The King	eng	\N	Easton Press	1990	\N	\N	https://covers.openlibrary.org/b/id/8141433-M.jpg	OL1937606M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9663	9	The Return of The King	eng	\N	HarperCollins	1993	9780261102378	0261102370	\N	OL19519472M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9664	9	The Return of the King	eng	\N	Houghton Mifflin	2005	9780618574971	0618574972	https://covers.openlibrary.org/b/id/394945-M.jpg	OL7605826M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9665	9	The Return of the King	eng	\N	Ballantine Books	1999	9780345917454	0345917456	\N	OL10686524M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9666	9	The return of the king	eng	\N	Houghton Mifflin	1965	\N	0395082560	https://covers.openlibrary.org/b/id/5306366-M.jpg	OL15350852M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9667	9	The Return of the King	eng	\N	George Allen & Unwin	1955	\N	\N	https://covers.openlibrary.org/b/id/8140846-M.jpg	OL17427263M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9668	9	The Return of The King	eng	\N	Allen and Unwin	1969	\N	\N	\N	OL19740972M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9669	9	The Return of the King	eng	\N	Thorndike Press	2003	9780786251766	078625176X	https://covers.openlibrary.org/b/id/4308419-M.jpg	OL3682839M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9670	9	The Return of The King	eng	\N	Houghton Mifflin Company	1956	\N	\N	https://covers.openlibrary.org/b/id/14624660-M.jpg	OL15270768M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9671	9	The Return of The King	eng	\N	George Allen & Unwin	1965	\N	\N	https://covers.openlibrary.org/b/id/8141315-M.jpg	OL26430463M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9672	9	The Return of The King	eng	\N	Houghton Mifflin Company	1967	9780395082560	0395082560	https://covers.openlibrary.org/b/id/8140855-M.jpg	OL7465585M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9673	9	The Return of the King	eng	\N	Readers Union / George Allen & Unwin	1960	\N	\N	https://covers.openlibrary.org/b/id/8141316-M.jpg	OL26430813M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9674	9	De Terugkeer van de Koning	nld	\N	Het Spectrum	1979	9789027401700	9027401705	https://covers.openlibrary.org/b/id/7070723-M.jpg	OL25209462M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9675	9	The Return of The King	eng	\N	Folio Society	1979	\N	\N	https://covers.openlibrary.org/b/id/8141363-M.jpg	OL26430837M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9676	9	The Return of The King	eng	\N	Folio Society	1977	\N	\N	https://covers.openlibrary.org/b/id/8141369-M.jpg	OL26430842M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9677	9	The Return of the King	eng	\N	Ballantine Books	1972	\N	\N	https://covers.openlibrary.org/b/id/9255340-M.jpg	OL24374051M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9678	9	El Retorno del Rey	spa	\N	George Allen and Unwin	1984	9789684460461	9684460465	\N	OL13122341M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9679	9	The Return of the King	\N	\N	Unwin Paperbacks	1981	9780048231871	0048231878	https://covers.openlibrary.org/b/id/8141985-M.jpg	OL7274004M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9680	9	The Return of the King	eng	\N	Perfection Learning	1978	9780812417678	0812417674	https://covers.openlibrary.org/b/id/13495268-M.jpg	OL11346368M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9681	9	The Return of the King	eng	\N	Tandem Library	1999	9780808520856	0808520857	https://covers.openlibrary.org/b/id/4963419-M.jpg	OL9314449M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9682	9	The Return of the King	eng	\N	Ballantine Books	1988	9780345008640	0345008642	https://covers.openlibrary.org/b/id/8142009-M.jpg	OL10680913M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9683	9	The Return of the King	eng	\N	Soundelux Audio Publishing	1990	9781559350358	1559350350	\N	OL8610134M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9684	9	Powrót Króla	pol	\N	Czytelnik	1990	9788385100089	8385100083	https://covers.openlibrary.org/b/id/8142014-M.jpg	OL19685534M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9685	9	Le seigneur des anneaux: Tome III	fra	\N	Christian Bourgois editeur	2001	9782266070591	2266070592	https://covers.openlibrary.org/b/id/14626826-M.jpg	OL8889880M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9686	9	The Return of the King	eng	\N	Houghton Mifflin	1992	9780395647400	0395647401	https://covers.openlibrary.org/b/id/8142024-M.jpg	OL7467155M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9687	9	The Return of the King	eng	\N	Houghton Mifflin Company	1983	9780395272213	0395272211	https://covers.openlibrary.org/b/id/14624618-M.jpg	OL26431318M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9688	9	El Señor de los Anillos III	spa	\N	Minotauro	1995	\N	8445070355	https://covers.openlibrary.org/b/id/14630068-M.jpg	OL9131848M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9689	9	The Return of the King	eng	\N	HarperCollins	1996	9780261103405	0261103407	https://covers.openlibrary.org/b/id/2341314-M.jpg	OL10236415M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9690	9	El Señor de los Anillos	spa	\N	Minotauro	2004	9789505470662	9505470665	https://covers.openlibrary.org/b/id/12451464-M.jpg	OL9137997M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9691	9	The Return of the King	eng	\N	Recorded Books	1997	9781556903205	1556903200	\N	OL9395060M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9692	9	Il Ritorno del Re	ita	\N	French & European Pubns	2000	9780828868297	0828868298	https://covers.openlibrary.org/b/id/8142465-M.jpg	OL11461793M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9693	9	Il ritorno del re	ita	\N	Tascabili Bompiani	2002	9788845290411	8845290417	\N	OL15950144M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9694	9	Le Retour du Roi	fra	\N	French & European Publications	2000	9780828816489	0828816484	https://covers.openlibrary.org/b/id/1574813-M.jpg	OL8171854M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9695	9	Le seigneur des anneaux	fra	\N	Christian Bourgois	1991	9782266046510	2266046519	https://covers.openlibrary.org/b/id/14624314-M.jpg	OL8889791M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9696	9	Der Herr der Ringe	deu	\N	Klett-Cotta	2002	9783608955385	3608955380	https://covers.openlibrary.org/b/id/13133756-M.jpg	OL26431626M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9697	9	The Return of the King	eng	\N	Recorded Books	2001	9780788789557	0788789554	https://covers.openlibrary.org/b/id/549854-M.jpg	OL8151614M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9698	9	The Return of the King	eng	\N	Recorded Books	2001	9780788789847	0788789848	https://covers.openlibrary.org/b/id/8142501-M.jpg	OL8151619M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9699	9	王者再臨	zho	\N	Tsai Fong Books, Inc	2001	9789570823387	9570823380	\N	OL9149755M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9700	9	O Senhor dos Anéis	por	BR	Martins Fontes	2002	9788533613393	8533613393	https://covers.openlibrary.org/b/id/14836843-M.jpg	OL9158211M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9701	9	The Return of the King	eng	\N	Houghton Mifflin	2001	9780618129119	0618129111	https://covers.openlibrary.org/b/id/8461463-M.jpg	OL7603875M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9702	9	The Return of the King	eng	\N	Voyager Classics	2001	9780007119561	0007119569	https://covers.openlibrary.org/b/id/8142981-M.jpg	OL26432012M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9703	9	The Return of the King	eng	\N	Quality Paperback Book Club	2001	9780965307796	0965307794	https://covers.openlibrary.org/b/id/10519465-M.jpg	OL8529333M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9704	9	Kralın Dönüşü	tur	\N	Metis Yayınları	1999	9789753422024	9753422024	https://covers.openlibrary.org/b/id/14627083-M.jpg	OL18116053M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9705	9	Povratak kralja	srp	\N	Rubikon	2002	\N	8673480698	\N	OL19112578M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9706	9	El Retorno del Rey	spa	\N	Turtleback Books Distributed by Demco Media	2002	9780606244251	0606244255	https://covers.openlibrary.org/b/id/4990350-M.jpg	OL9577682M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9707	9	O Retorno do Rei	por	BR	Martins Fontes	2002	9788533615571	8533615574	https://covers.openlibrary.org/b/id/8143010-M.jpg	OL9158227M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9708	9	El Retorno del Rey	spa	\N	Minotauro	2002	9788445071779	8445071777	https://covers.openlibrary.org/b/id/12786188-M.jpg	OL9131887M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9709	9	The Return of the King	eng	\N	Collins	2001	9780007129720	0007129726	https://covers.openlibrary.org/b/id/9634-M.jpg	OL7261844M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9710	9	Die Wiederkehr des Königs	deu	\N	Klett-Cotta	2002	9783608934038	3608934030	https://covers.openlibrary.org/b/id/3240708-M.jpg	OL12823839M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9711	9	Le Retour du Roi III	fra	\N	Distribooks	1973	9782266127912	2266127918	https://covers.openlibrary.org/b/id/980435-M.jpg	OL8890484M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9712	9	The Return of the King	eng	\N	HarperCollins	2002	9780007149230	0007149239	https://covers.openlibrary.org/b/id/8143027-M.jpg	OL26432043M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9713	9	The Return of the King	eng	\N	Houghton Mifflin Company	1983	9780618260287	0618260285	\N	OL25645426M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9714	9	O Regreso Do Rei	por	\N	Edicións Xerais de Galicia	2002	9788483029169	8483029162	https://covers.openlibrary.org/b/id/8143293-M.jpg	OL13320906M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9715	9	Le Retour du Roi	fra	\N	Gallimard Jeunesse	1999	9782070522699	2070522695	https://covers.openlibrary.org/b/id/969328-M.jpg	OL8840040M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9716	9	Le Seigneur des Anneaux	fra	\N	Christian Bourgois	2002	9782266120975	2266120972	https://covers.openlibrary.org/b/id/10511215-M.jpg	OL8890400M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9717	9	El retorno del Rey	spa	\N	Ediciones Minotauro	2002	9788439596240	8439596243	https://covers.openlibrary.org/b/id/7284726-M.jpg	OL25492730M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9718	9	De terugkeer van de koning	nld	\N	Uitgeverij M	2002	9789022533772	9022533778	https://covers.openlibrary.org/b/id/8143303-M.jpg	OL26432248M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9719	9	魔戒	zho	\N	Yilin Chu Ban She	2002	9787806572672	7806572678	https://covers.openlibrary.org/b/id/9293871-M.jpg	OL9786977M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9720	9	Erregearen itzulera	eus	\N	Txalaparta	2003	9788481362619	8481362611	https://covers.openlibrary.org/b/id/8143315-M.jpg	OL26432259M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9721	9	The Return of the King	eng	\N	Large Print Press	2003	9781594130045	1594130043	https://covers.openlibrary.org/b/id/8069763-M.jpg	OL8875465M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9722	9	Возвращение государя	rus	\N	ACT	2003	9785170162659	5170162650	\N	OL12538900M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9723	9	The Return of the King	eng	\N	HarperCollins	2003	9780007171996	0007171994	\N	OL22818250M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9724	9	El Señor de los Anillos	spa	\N	Planeta	2003	9789706906533	9706906533	https://covers.openlibrary.org/b/id/14627562-M.jpg	OL9179425M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9725	9	The Return of the King	eng	\N	Houghton Mifflin	2003	9780618346271	0618346279	https://covers.openlibrary.org/b/id/14393947-M.jpg	OL26432266M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9726	9	Návrat krále	ces	\N	Mladá fronta	2002	9788020409652	8020409653	\N	OL26418562M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9727	9	The Return of the King	eng	\N	Tandem Library	2003	9781417747207	141774720X	\N	OL11763334M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9728	9	Il Ritorno del Re	ita	\N	French & European Pubns	2003	9780785913986	078591398X	\N	OL11038174M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9729	9	Povratak kralja	hrv	\N	Algoritam	2005	9789532202816	\N	https://covers.openlibrary.org/b/id/8076558-M.jpg	OL26383686M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9730	9	Le seigneur des anneaux	fra	\N	Christian Bourgois editeur	2012	9782266154123	2266154125	https://covers.openlibrary.org/b/id/14625511-M.jpg	OL8890550M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9731	9	The Return of the King	\N	\N	Houghton Mifflin Harcourt	2004	9780547952048	054795204X	https://covers.openlibrary.org/b/id/8069661-M.jpg	OL26378841M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9732	9	El Retorno del Rey	spa	\N	Minotauro	2006	9788445075753	8445075756	https://covers.openlibrary.org/b/id/2270622-M.jpg	OL9540560M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9733	9	El Retorno del Rey	spa	\N	Planeta Pub Corp	2004	9789703701704	9703701701	\N	OL13152179M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9734	9	El Retorno del Rey	spa	\N	minotauro	2010	9788445077931	8445077937	https://covers.openlibrary.org/b/id/8143387-M.jpg	OL26432325M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9735	9	The Return of the King	eng	\N	The Folio Society	1977	\N	\N	https://covers.openlibrary.org/b/id/8143391-M.jpg	OL17186574M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9736	9	The Return of the King	eng	\N	Folio Society	2001	\N	\N	https://covers.openlibrary.org/b/id/8143749-M.jpg	OL26432328M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9737	9	The Return of the King	eng	\N	Recorded Books	2011	9781461836162	1461836166	https://covers.openlibrary.org/b/id/8143395-M.jpg	OL26432329M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9738	9	The Return of the King	eng	\N	HarperCollins	2012	9780007488353	0007488351	https://covers.openlibrary.org/b/id/10555538-M.jpg	OL26432335M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9739	9	O retorno do rei	por	BR	Martins Fontes / Selo Martins	2013	9788580631036	8580631033	https://covers.openlibrary.org/b/id/8143750-M.jpg	OL26432435M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
8257	39	Pride and Prejudice	eng	\N	CreateSpace Independent Publishing Platform	2010	9781453623855	\N	\N	OL36289873M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8258	39	Pride and Prejudice	eng	\N	Kessinger Publishing, LLC	2010	9781161449426	\N	\N	OL36289893M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8259	39	Pride and Prejudice	eng	\N	CreateSpace Independent Publishing Platform	2011	9781466267763	\N	\N	OL36290294M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8260	39	Pride and Prejudice	eng	\N	CreateSpace Independent Publishing Platform	2011	9781456379360	\N	\N	OL36290322M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8261	39	Pride and Prejudice	eng	\N	Turtleback	2000	9781417647750	\N	\N	OL36290700M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8262	39	Pride and Prejudice	eng	\N	CreateSpace Independent Publishing Platform	2014	9781499584837	\N	\N	OL36307190M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8263	39	Pride and Prejudice	eng	\N	CreateSpace Independent Publishing Platform	2014	9781497504141	\N	\N	OL36307197M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8264	39	Pride and Prejudice	eng	\N	CreateSpace Independent Publishing Platform	2014	9781499728187	\N	\N	OL36308445M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8265	39	Pride and Prejudice	eng	\N	CreateSpace Independent Publishing Platform	2014	9781500112783	\N	\N	OL36308523M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8266	39	Pride and Prejudice	eng	\N	CreateSpace Independent Publishing Platform	2014	9781500250669	\N	\N	OL36308684M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8267	39	Pride and Prejudice	eng	\N	CreateSpace Independent Publishing Platform	2014	9781500242787	\N	\N	OL36308687M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8268	39	Pride and Prejudice	eng	\N	CreateSpace Independent Publishing Platform	2014	9781500286194	\N	\N	OL36308689M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8269	39	Pride and Prejudice	eng	\N	CreateSpace Independent Publishing Platform	2014	9781500255411	\N	\N	OL36308836M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8270	39	Pride and Prejudice	eng	\N	CreateSpace Independent Publishing Platform	2014	9781500478711	\N	\N	OL36308909M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8271	39	Pride and Prejudice	eng	\N	CreateSpace Independent Publishing Platform	2014	9781500478803	\N	\N	OL36308910M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8272	39	Pride and Prejudice	eng	\N	CreateSpace Independent Publishing Platform	2014	9781500478780	\N	\N	OL36308911M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8273	39	Pride and Prejudice	eng	\N	CreateSpace Independent Publishing Platform	2014	9781500489700	\N	\N	OL36308912M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8274	39	Pride and Prejudice	eng	\N	CreateSpace Independent Publishing Platform	2014	9781500489601	\N	\N	OL36308913M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8275	39	Pride and Prejudice	eng	\N	CreateSpace Independent Publishing Platform	2014	9781500493967	\N	\N	OL36308914M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8276	39	Pride and Prejudice	eng	\N	CreateSpace Independent Publishing Platform	2014	9781500492489	\N	\N	OL36308915M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8277	39	Pride and Prejudice	eng	\N	CreateSpace Independent Publishing Platform	2014	9781500478773	\N	\N	OL36308916M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8278	39	Pride and Prejudice	eng	\N	CreateSpace Independent Publishing Platform	2014	9781500501242	\N	\N	OL36308917M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8279	39	Pride and Prejudice	eng	\N	CreateSpace Independent Publishing Platform	2014	9781500478766	\N	\N	OL36308918M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8280	39	Pride and Prejudice	eng	\N	CreateSpace Independent Publishing Platform	2014	9781500478735	\N	\N	OL36308919M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8281	39	Pride and Prejudice	eng	\N	CreateSpace Independent Publishing Platform	2014	9781500478728	\N	\N	OL36308920M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8282	39	Pride and Prejudice	eng	\N	CreateSpace Independent Publishing Platform	2014	9781500490997	\N	\N	OL36308921M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8283	39	Pride and Prejudice	eng	\N	CreateSpace Independent Publishing Platform	2014	9781500478759	\N	\N	OL36308922M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8284	39	Pride and Prejudice	eng	\N	CreateSpace Independent Publishing Platform	2014	9781500478865	\N	\N	OL36308923M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8285	39	Pride and Prejudice	eng	\N	CreateSpace Independent Publishing Platform	2014	9781500478742	\N	\N	OL36308924M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8286	39	Pride and Prejudice	eng	\N	CreateSpace Independent Publishing Platform	2014	9781500478834	\N	\N	OL36308925M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8287	39	Pride and Prejudice	eng	\N	CreateSpace Independent Publishing Platform	2014	9781500478841	\N	\N	OL36308926M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8288	39	Pride and Prejudice	eng	\N	CreateSpace Independent Publishing Platform	2014	9781500478810	\N	\N	OL36308927M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8289	39	Pride and Prejudice	eng	\N	CreateSpace Independent Publishing Platform	2014	9781500491024	\N	\N	OL36308928M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8290	39	Pride and Prejudice	eng	\N	CreateSpace Independent Publishing Platform	2014	9781500478797	\N	\N	OL36308929M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8291	39	Pride and Prejudice	eng	\N	CreateSpace Independent Publishing Platform	2014	9781500516840	\N	\N	OL36308932M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8292	39	Pride and Prejudice	eng	\N	CreateSpace Independent Publishing Platform	2014	9781500599508	\N	\N	OL36309273M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8293	39	Pride and Prejudice	eng	\N	CreateSpace Independent Publishing Platform	2014	9781500597214	\N	\N	OL36309284M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8294	39	Pride and Prejudice	eng	\N	CreateSpace Independent Publishing Platform	2014	9781500733032	\N	\N	OL36309457M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8295	39	Pride and Prejudice	eng	\N	CreateSpace Independent Publishing Platform	2014	9781500802004	\N	\N	OL36309528M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8296	39	Pride and Prejudice	eng	\N	CreateSpace Independent Publishing Platform	2014	9781500761844	\N	\N	OL36309531M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8297	39	Pride and Prejudice	eng	\N	CreateSpace Independent Publishing Platform	2014	9781500846527	\N	\N	OL36309693M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8298	39	Pride and Prejudice	eng	\N	CreateSpace Independent Publishing Platform	2014	9781500899097	\N	\N	OL36309752M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8299	39	Pride and Prejudice	eng	\N	CreateSpace Independent Publishing Platform	2014	9781502301345	\N	\N	OL36309858M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8300	39	Pride and Prejudice	eng	\N	CreateSpace Independent Publishing Platform	2014	9781502365941	\N	\N	OL36310262M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8301	39	Pride and Prejudice	eng	\N	CreateSpace Independent Publishing Platform	2014	9781502423276	\N	\N	OL36311245M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8302	39	Pride and Prejudice	eng	\N	CreateSpace Independent Publishing Platform	2014	9781502487513	\N	\N	OL36311248M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8303	39	Pride and Prejudice	eng	\N	CreateSpace Independent Publishing Platform	2014	9781502501738	\N	\N	OL36311304M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8304	39	Pride and Prejudice	eng	\N	CreateSpace Independent Publishing Platform	2014	9781502490599	\N	\N	OL36311305M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8305	39	Pride and Prejudice	eng	\N	CreateSpace Independent Publishing Platform	2014	9781502354310	\N	\N	OL36311402M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8306	39	Pride and Prejudice	eng	\N	Literati Press	2014	9780985798512	\N	\N	OL36311441M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8307	39	Pride and Prejudice	eng	\N	CreateSpace Independent Publishing Platform	2014	9781502793775	\N	\N	OL36311464M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8308	39	Pride and Prejudice	eng	\N	Blurb, Incorporated	2014	9781320163026	\N	\N	OL36311485M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8309	39	Pride and Prejudice	eng	\N	Xist Publishing	2014	9781623957292	\N	\N	OL36311531M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8310	39	Pride and Prejudice	eng	\N	CreateSpace Independent Publishing Platform	2014	9781503057043	\N	\N	OL36311921M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8311	39	Pride and Prejudice	eng	\N	CreateSpace Independent Publishing Platform	2014	9781505225174	\N	\N	OL36312157M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8312	39	Pride and Prejudice	eng	\N	CreateSpace Independent Publishing Platform	2014	9781502831682	\N	\N	OL36312263M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8313	39	Pride and Prejudice	eng	\N	CreateSpace Independent Publishing Platform	2015	9781507746561	\N	\N	OL36312617M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8314	39	Pride and Prejudice	eng	\N	Hamish Hamilton	1949	\N	\N	https://covers.openlibrary.org/b/id/13148523-M.jpg	OL46523934M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8315	39	Pride and Prejudice	eng	\N	Wordsworth Classics	1992	9781573353861	1573353868	https://covers.openlibrary.org/b/id/13147279-M.jpg	OL46523609M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8316	39	Pride and Prejudice, with an Afterword By Joann Morse, Revised and Updated Bibliography (Signet Classic)	\N	\N	Signet Classics	1980	\N	\N	\N	OL43032120M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8317	39	Pride and Prejudice	eng	\N	Books, Inc.	\N	\N	\N	https://covers.openlibrary.org/b/id/14347974-M.jpg	OL45619217M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8318	39	Pride and Prejudice. Art-Type Edition. The World's Popular Classics Series	\N	\N	Books, Inc.	1930	\N	\N	\N	OL42887370M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8319	39	Pride and Prejudice by Jane Austen	eng	\N	Independently Published	2019	9781090659064	\N	\N	OL41180263M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8320	39	Pride and Prejudice by Jane Austen	eng	\N	Independently Published	2019	9781095275818	\N	\N	OL41188348M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8321	39	Pride and Prejudice by Jane Austen	eng	\N	Independently Published	2019	9781082545580	\N	\N	OL41324627M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8322	39	Pride and Prejudice	eng	\N	FINE EDITIONS PRESS	1946	\N	\N	https://covers.openlibrary.org/b/id/14619675-M.jpg	OL45817044M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8323	39	Pride and prejudice (The works of Jane Austen)	\N	\N	J.M. Dent & sons, ltd	1933	\N	\N	\N	OL44778589M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8324	39	Pride and Prejudice, 1945 grey hardback, ex-library	\N	\N	DODD, MEAD & CO	1945	\N	\N	\N	OL43093404M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8325	39	Pride and Prejudice. Heron de-luxe Jane Austen Collection	\N	\N	Heron Books	1970	\N	\N	\N	OL43018613M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8326	39	Pride and Prejudice (Minimalist Edition, 8. 5 X 11 )	eng	\N	Independently Published	2021	9798704467090	\N	\N	OL42389849M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8327	39	Pride and Prejudice -- Edited By Mark Schorer	\N	\N	Houghton Mifflin; The Riverside Press	1956	\N	\N	\N	OL45788635M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8328	39	Pride and Prejudice; Introduction By Robert Daniel	\N	\N	Holt, rinehart and Winston	1960	\N	\N	\N	OL45661117M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8329	39	Pride and Prejudice (The Laurel Jane Austen)	\N	\N	Dell Publishing Co.	1962	\N	\N	\N	OL43447079M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8330	39	Pride and Prejudice, Brock, Nelson, 1940 HB	\N	\N	THOMAS NELSON & SONS, LTD	\N	\N	\N	\N	OL43135305M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8331	39	Pride and Prejudice Novel by Jane Austen	eng	\N	Independently Published	2022	9798819941782	\N	\N	OL42750946M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8332	39	Pride and Prejudice Book by Jane Austen	eng	\N	Independently Published	2022	9798799506407	\N	\N	OL42668752M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8333	39	Pride and Prejudice Book by Jane Austen	eng	\N	Independently Published	2022	9798403034418	\N	\N	OL42633829M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8334	39	Pride and Prejudice : (Originally Titled : « First Impression »)	eng	\N	Independently Published	2018	9781980505808	\N	\N	OL40762962M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8335	39	Pride and Prejudice by Jane Austen	eng	\N	Independently Published	2022	9798357002778	\N	\N	OL46380121M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8336	39	Pride and Prejudice	eng	\N	Magnum Easy Eye Books/Lancer Books	1968	\N	\N	https://covers.openlibrary.org/b/id/14429708-M.jpg	OL45783191M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8337	39	Pride and Prejudice by Jane Austen	\N	\N	Independently published	2020	9798565519051	\N	\N	OL43502348M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8338	39	PRIDE AND PREJUDICE. (A Bancroft Classic)	\N	\N	Bancroft &amp; Co	\N	\N	\N	\N	OL43326063M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8339	39	Pride and Prejudice Single leather volume	\N	\N	The Easton Press	1996	\N	\N	\N	OL42984867M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8340	39	Pride and Prejudice by Jane Austen	eng	\N	Independently Published	2020	9798559594569	\N	\N	OL42240692M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8341	39	Pride and Prejudice (Illustrated and Annotated)	eng	\N	Independently Published	2017	9781973359692	\N	\N	OL40755354M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8342	39	Pride and Prejudice by Jane Austen	eng	\N	Independently Published	2018	9781980932246	\N	\N	OL40656137M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8343	39	Pride and Prejudice by Jane Austen	eng	\N	Independently Published	2020	9798656846981	\N	\N	OL42130851M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8344	39	Pride and Prejudice : NEW EDITION 2019	eng	\N	Independently Published	2019	9781671772861	\N	\N	OL41663620M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8345	39	Pride and Prejudice by Jane Austen	eng	\N	Independently Published	2019	9781795179089	\N	\N	OL41515808M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8346	39	Pride and Prejudice by Jane Austen	eng	\N	Independently Published	2019	9781699339664	\N	\N	OL41569825M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8347	39	Pride and Prejudice by Jane Austen	eng	\N	Independently Published	2019	9781699702895	\N	\N	OL41596116M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8348	39	Pride and Prejudice (Modern English Translation)	eng	\N	Independently Published	2019	9781096552857	\N	\N	OL41064514M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8349	39	Pride and Prejudice by Jane Austen	eng	\N	Independently Published	2019	9781795396073	\N	\N	OL40781569M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8350	39	Pride and Prejudice by Jane Austen	eng	\N	Independently Published	2018	9781726756457	\N	\N	OL40783212M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8351	39	Pride and Prejudice by Jane Austen	eng	\N	Independently Published	2018	9781719993654	\N	\N	OL40824058M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8352	39	Jane Austen - Pride and Prejudice (Annotated)	eng	\N	Independently Published	2017	9781520578774	\N	\N	OL40519166M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8353	39	Pride and Prejudice : (Aberdeen Classics Collection)	eng	\N	Aberdeen Press	2020	9798671623901	\N	\N	OL38134607M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8354	39	Pride and Prejudice : (Aberdeen Classics Collection)	eng	\N	Aberdeen Press	2020	9798671623826	\N	\N	OL38046346M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8355	39	Pride and Prejudice (Shavian Alphabet Edition)	eng	\N	Shavian.info	2019	9780648570509	\N	\N	OL28734674M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8356	39	Pride and Prejudice (Annotated Keynote Classics)	eng	\N	MMW Books, LLC	2020	9781949611250	\N	\N	OL28080826M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8357	39	Pride and Prejudice (Annotated Keynote Classics)	eng	\N	MMW Books, LLC	2020	9781949611243	\N	\N	OL28080827M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8358	39	GREAT READS - PRIDE AND PREJUDICE	\N	\N	PLANET THREE PUBLISHING NETWORK LTD	2003	9780017417497	001741749X	\N	OL43532255M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8359	39	Pride and Prejudice Jane Austen	eng	\N	Independently Published	2022	9798410572996	\N	\N	OL42672877M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8360	39	Pride and Prejudice / Jane Austen	eng	\N	Independently Published	2021	9798749154399	\N	\N	OL42616076M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8361	39	Emma with Pride and Prejudice	eng	\N	Independently Published	2021	9798712031795	\N	\N	OL42282594M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8362	39	Pride and Prejudice (with Illustrations)	eng	\N	Independently Published	2018	9781723985188	\N	\N	OL40825589M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8363	39	Pride and Prejudice for Teens	eng	\N	Lulu Press, Inc.	2015	9781329702059	\N	\N	OL40031115M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8364	39	Pride and Prejudice	eng	\N	Publications International, Limited	2022	9781503762534	\N	https://covers.openlibrary.org/b/id/14728085-M.jpg	OL38806452M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8365	39	Pride and Prejudice	eng	\N	Independently Published	2022	9798447578268	\N	\N	OL38912098M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8366	39	Pride and Prejudice	eng	\N	Independently Published	2021	9798751526252	\N	\N	OL38944110M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8367	39	Pride and Prejudice and Emojis	eng	\N	Ebury Publishing	2017	9781473552296	\N	\N	OL38753302M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8368	39	Pride and Prejudice (Keynote Classics)	eng	\N	MMW Books, LLC	2018	9781949611052	\N	\N	OL34403269M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8369	39	Pride and Prejudice	eng	\N	Bancroft Books	1970	9780430000955	0430000952	https://covers.openlibrary.org/b/id/13440884-M.jpg	OL43575679M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8370	39	Pride and Prejudice in 3 Volumes	eng	\N	Independently Published	2021	9798740988696	\N	\N	OL42263778M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8371	39	Pride and Prejudice Annotated	eng	\N	Independently Published	2017	9798675013203	\N	\N	OL42221803M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8372	39	Pride and Prejudice	eng	\N	Independently Published	2017	9781973108672	\N	\N	OL40807669M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8373	39	Pride and Prejudice	eng	\N	Independently Published	2017	9781973432722	\N	\N	OL40810110M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8374	39	Pride and Prejudice	eng	\N	Independently Published	2018	9781730806223	\N	\N	OL40829493M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8375	39	Pride and Prejudice (Annotated)	eng	\N	Independently Published	2017	9781521031957	\N	\N	OL40795370M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8376	39	Pride and Prejudice (illustrated)	eng	\N	Independently Published	2017	9781520715650	\N	\N	OL40629377M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8377	39	Pride and Prejudice by Jane Austen	eng	\N	Independently Published	2018	9781976932656	\N	\N	OL40593732M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8378	39	Pride and Prejudice (Illustrated)	eng	\N	Independently Published	2017	9781973159346	\N	\N	OL40535486M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8379	39	Pride and Prejudice (Deluxe Edition)	eng	\N	Sterling Publishing Co., Inc.	2022	9781454947547	\N	\N	OL38059856M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8380	39	Pride and Prejudice (Deluxe Edition)	eng	\N	Sterling Publishing Co., Inc.	2022	9781454947554	\N	\N	OL38441585M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8381	39	Pride and Prejudice	eng	\N	Independently Published	2022	9798364688170	\N	\N	OL46121197M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8382	39	Pride and prejudice	\N	\N	Dent	1950	\N	\N	\N	OL43582415M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8383	39	Pride and Prejudice	eng	\N	Headline Review	2006	9780755339419	075533941X	https://covers.openlibrary.org/b/id/14534654-M.jpg	OL43566123M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8384	39	Pride and Prejudice	\N	\N	Holt,Rinehart & Winston of Canada Ltd	1949	9780030082306	0030082307	\N	OL43658784M	\N	2026-11-25 20:23:59.907351+00	2026-11-25 20:23:59.907351+00
8385	40	Os Maias	por	\N	Independently Published	2021	9798738724442	\N	\N	OL48308443M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8386	40	Maias	eng	\N	Dedalus Books Limited	2011	9781907650338	\N	\N	OL48149291M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8387	40	Os Maias	por	\N	Neolivros	2001	\N	\N	https://covers.openlibrary.org/b/id/13846488-M.jpg	OL47319953M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8388	40	Els Maia	\N	\N	Editorial Funambulista S.L.	2007	9788496601468	8496601463	https://covers.openlibrary.org/b/id/13725213-M.jpg	OL47270840M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8389	40	Os Maias	por	\N	Independently Published	2020	9798631002050	\N	\N	OL41950948M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8390	40	Maya yi jia	zho	\N	Aomen wen hua si shu	1995	\N	7806112634	\N	OL31454617M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8391	40	Os Maias	por	\N	Independently Published	2018	9781718115798	\N	\N	OL40768598M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8392	40	Os Maias	por	\N	Independently Published	2017	9781976700125	\N	\N	OL40540422M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8393	40	Os Maias	por	\N	Project Gutenberg	2012	\N	\N	https://covers.openlibrary.org/b/id/13157707-M.jpg	OL46526703M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8394	40	Os Maias	por	\N	Luso Livros	2012	\N	\N	https://covers.openlibrary.org/b/id/13156118-M.jpg	OL46526020M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8395	40	Maias	eng	\N	Dedalus Books Limited	2016	9781910213445	\N	https://covers.openlibrary.org/b/id/13552706-M.jpg	OL44177087M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8396	40	Os Maias	por	\N	Independently Published	2019	9781795614924	\N	https://covers.openlibrary.org/b/id/13823314-M.jpg	OL41248746M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8397	40	Os Maias	por	\N	Independently Published	2019	9781070254524	\N	\N	OL41004552M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8398	40	Os Maias (Ilustrado)	por	\N	Independently Published	2017	9781521586273	\N	\N	OL40909407M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8399	40	Los Maia	\N	\N	PRETEXTOS	2013	9788415576730	8415576730	\N	OL40269557M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8400	40	Les Maia	fra	\N	Michel Chandeigne	2000	9782906462748	2906462748	https://covers.openlibrary.org/b/id/3159725-M.jpg	OL12650327M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8401	40	The Maias [by] Eça de Queiroz.	eng	\N	Bodley Head	1965	\N	\N	\N	OL15542164M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8402	40	The Maias (Aspects of Portugal)	eng	\N	Carcanet Press,	1993	9781857540338	1857540336	https://covers.openlibrary.org/b/id/2057116-M.jpg	OL9335081M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8403	40	Os Maias	por	\N	Lulu Press, Inc.	2020	9781716550669	\N	\N	OL40108961M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8404	40	Os Maias: Episódios da vida romântica	por	BR	Zahar	\N	9788537816851	853781685X	https://covers.openlibrary.org/b/id/12919398-M.jpg	OL39484479M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8405	40	Os Maias	\N	\N	Outlook Verlag	2022	9783752493382	3752493380	\N	OL37056373M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8406	40	Los Maia	\N	\N	PENGUIN CLASICOS	2021	9788491054573	849105457X	https://covers.openlibrary.org/b/id/10660162-M.jpg	OL31986757M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8407	40	Os maias	por	PT	Clube do Autor	2013	9789897240546	9897240543	\N	OL27203904M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8408	40	Os Maias	por	PT	Edição "Livros do Brasil"	2003	\N	\N	\N	OL31588867M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8409	40	Os maias	por	PT	Lello & Irmõa	1900	\N	\N	\N	OL26909643M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8410	40	Os Maias	por	BR	Sá Editora	2001	9788588193024	8588193027	https://covers.openlibrary.org/b/id/8524536-M.jpg	OL9165721M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8411	40	Os Maias	por	\N	Independently Published	2021	9798537541790	\N	\N	OL35185723M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8412	40	Os Maias	por	PT	Livros de Brasil	1975	\N	\N	\N	OL17856351M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8413	40	Os Maias	por	PT	Lello and Irmão	1965	\N	\N	\N	OL17856343M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8414	40	Os Maias	por	PT	Biblioteca Ulisseia de autores Portugueses	1984	\N	\N	\N	OL16541474M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8415	40	The Maias.	eng	\N	Bodley Head	1965	\N	\N	\N	OL21642160M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8416	40	Os maias	por	PT	Lello & irmão; [etc., etc.]	1945	\N	\N	\N	OL17980555M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8417	40	Os Maias	por	PT	Edicão "Livros do Brasil"	1900	\N	\N	\N	OL16600891M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8418	40	Os Maias	por	PT	Lello & Irmão	1951	\N	\N	\N	OL21085953M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8419	40	Os Maias	por	PT	Lello & Irmão	1951	\N	\N	\N	OL21085973M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8420	40	Os Maias	por	PT	Lello & Irmão	1951	\N	\N	\N	OL21113847M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8421	40	The Maias	eng	\N	Dent	1986	\N	0460014331	\N	OL21452691M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8422	40	The Maias	eng	\N	Bodley Head	1965	\N	\N	\N	OL18806019M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8423	40	Os Maias	por	PT	Livros do Brasil	1970	\N	\N	\N	OL13758159M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8424	40	Os Maias	por	PT	Lello & Irmão	1938	\N	\N	\N	OL15312532M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8425	40	Os maias	por	PT	Lello [e] Irmão	1936	\N	\N	\N	OL14934440M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8426	40	Os maias	por	PT	Lello & Irmão	1945	\N	\N	\N	OL17142761M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8427	40	Os Maias	por	PT	Livros de Brasil	1960	\N	\N	\N	OL18757867M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8428	40	Os maias	por	PT	Lello & Irmõa	1900	\N	\N	\N	OL22937857M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8429	40	Os Maias	por	PT	Lello	1951	\N	\N	\N	OL18093513M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8430	40	Os Maias	por	PT	Lello & Irmão	1927	\N	\N	\N	OL17463170M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8431	40	Os Maias	por	\N	Nulla Publishing	2015	9780993856815	\N	https://covers.openlibrary.org/b/id/7423454-M.jpg	OL25921937M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8432	40	The Maias	eng	\N	New Directions	2007	9780811216494	0811216497	\N	OL22760439M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8433	40	Roteiro de "Os maias" de Eça de Queiroz e de todas as comidas e bebidas no romance	por	PT	Hugin	2001	\N	9727940331	\N	OL19512731M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8434	40	Os Maias	\N	\N	Editora Ulisseia	\N	9789725681367	9725681363	\N	OL9181332M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8435	40	The Maias	eng	\N	Bodley Head	\N	\N	\N	\N	OL17055686M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8436	40	Os Maias	por	PT	Porto Editora	1999	9789720040206	9720040203	https://covers.openlibrary.org/b/id/13156084-M.jpg	OL9181038M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8437	40	Os Maias	\N	\N	Publicacoes Europa-America	\N	9789721013414	9721013412	\N	OL9181063M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8438	40	The Maias	\N	\N	The Bodley Head Ltd	1965	9780370005577	0370005570	\N	OL9567660M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8439	40	The Maias	eng	\N	Penguin Classics	1999	9780140446944	014044694X	https://covers.openlibrary.org/b/id/104217-M.jpg	OL7355378M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8440	40	The Maias	eng	\N	Carcanet Press Ltd.	2003	9781857546088	1857546083	https://covers.openlibrary.org/b/id/909792-M.jpg	OL9000283M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8441	40	The Maias	eng	\N	Dent	1986	\N	0460014331	\N	OL2450803M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8442	40	The Maias (Everyman's Classics)	eng	\N	J M Dent & Sons Ltd	1987	9780460014335	0460014331	\N	OL7592006M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8443	40	The Maias	eng	\N	St. Martin's Press	1965	\N	\N	\N	OL5951618M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8444	40	The Maias	eng	\N	Penguin Books	1998	\N	014044694X	https://covers.openlibrary.org/b/id/104218-M.jpg	OL109054M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8445	40	The Maias.	eng	\N	Bodley Head	1965	\N	\N	\N	OL5688981M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8446	40	The Maias	eng	\N	St. Martin's Press	1965	\N	\N	\N	OL16486971M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8447	40	Os Maias	\N	\N	Porto Editora	2003	9789720049575	\N	https://covers.openlibrary.org/b/id/6956143-M.jpg	OL25083060M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8448	40	Os Maias	por	PT	Livros do Brasil	1900	\N	\N	\N	OL2795526M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8449	40	Os maias	por	PT	Lello & Irmão	1912	\N	\N	\N	OL19923903M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8450	40	Os Maias	por	PT	Lello & irmão	1900	\N	\N	\N	OL6627676M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8451	40	Les Maia	fra	\N	Presses universitaires de France	1971	\N	\N	\N	OL5365599M	\N	2026-11-25 20:24:02.166456+00	2026-11-25 20:24:02.166456+00
8452	41	Peri typhlotētos	ell	\N	Ekdoseis Kastaniōtē	1998	\N	9600323232	\N	OL59337676M	\N	2026-11-25 20:24:06.224924+00	2026-11-25 20:24:06.224924+00
8453	41	Blindness	\N	\N	Houghton Mifflin Harcourt	1999	\N	\N	\N	OL25431806M	\N	2026-11-25 20:24:06.224924+00	2026-11-25 20:24:06.224924+00
8454	41	Blindness	eng	\N	Houghton Mifflin Harcourt	2011	9780547554884	\N	\N	OL25075441M	\N	2026-11-25 20:24:06.224924+00	2026-11-25 20:24:06.224924+00
8455	41	Ensayo sobre la ceguera	\N	\N	Punto de Lectura	2009	9788466321495	\N	https://covers.openlibrary.org/b/id/15182904-M.jpg	OL61412784M	\N	2026-11-25 20:24:06.224924+00	2026-11-25 20:24:06.224924+00
8456	41	L'Aveuglement	fra	\N	Seuil	1997	9782020289528	2020289520	https://covers.openlibrary.org/b/id/963960-M.jpg	OL8834647M	\N	2026-11-25 20:24:06.224924+00	2026-11-25 20:24:06.224924+00
8457	41	L'aveuglement	fra	\N	Seuil	2000	9782020403436	2020403439	https://covers.openlibrary.org/b/id/964350-M.jpg	OL8835006M	\N	2026-11-25 20:24:06.224924+00	2026-11-25 20:24:06.224924+00
8458	41	Ensaio Sobre a Cegueira	por	BR	Companhia das Letras	2013	9788543801216	8543801214	https://covers.openlibrary.org/b/id/14618040-M.jpg	OL51656284M	\N	2026-11-25 20:24:06.224924+00	2026-11-25 20:24:06.224924+00
8459	41	Ensayo sobre la ceguera	spa	\N	Punto de Lectura	2010	9788466306430	8466306439	https://covers.openlibrary.org/b/id/15137565-M.jpg	OL26384858M	\N	2026-11-25 20:24:06.224924+00	2026-11-25 20:24:06.224924+00
8460	41	Körlük	tur	\N	Kırmızı Kedi	2017	9786052980811	6052980818	https://covers.openlibrary.org/b/id/10720848-M.jpg	OL32063393M	\N	2026-11-25 20:24:06.224924+00	2026-11-25 20:24:06.224924+00
8461	41	Blindness	eng	\N	Houghton Mifflin Harcourt Trade & Reference Publishers	2008	9780156035583	\N	\N	OL33329037M	\N	2026-11-25 20:24:06.224924+00	2026-11-25 20:24:06.224924+00
8462	41	Blindness	eng	\N	Houghton Mifflin Harcourt Publishing Company	2013	9780547537597	\N	\N	OL33979271M	\N	2026-11-25 20:24:06.224924+00	2026-11-25 20:24:06.224924+00
8463	41	Ensayo sobre la ceguera	spa	\N	Debolsillo	2020	9788466350976	\N	https://covers.openlibrary.org/b/id/10511209-M.jpg	OL30983927M	\N	2026-11-25 20:24:06.224924+00	2026-11-25 20:24:06.224924+00
8464	41	Die Stadt der Blinden	deu	\N	Rowohlt Taschenbuch Verlag	2000	\N	3499224674	https://covers.openlibrary.org/b/id/12531713-M.jpg	OL36638514M	\N	2026-11-25 20:24:06.224924+00	2026-11-25 20:24:06.224924+00
8465	41	Körlük	tur	\N	Can	1999	9789755109282	9755109285	https://covers.openlibrary.org/b/id/10596342-M.jpg	OL31913883M	\N	2026-11-25 20:24:06.224924+00	2026-11-25 20:24:06.224924+00
8466	41	Nunmŏn chadŭl ŭi tosi	kor	\N	Haenaem	1998	\N	8973372122	\N	OL19483289M	\N	2026-11-25 20:24:06.224924+00	2026-11-25 20:24:06.224924+00
8467	41	Die Stadt der Blinden.	deu	\N	Rowohlt, Reinbek	1997	9783498063184	3498063189	https://covers.openlibrary.org/b/id/1013620-M.jpg	OL9047860M	\N	2026-11-25 20:24:06.224924+00	2026-11-25 20:24:06.224924+00
8468	41	Die Stadt Der Blinden	deu	\N	Rowohlt Taschenbuch Verlag GmbH	1999	9783499224676	3499224674	https://covers.openlibrary.org/b/id/1014299-M.jpg	OL9048533M	\N	2026-11-25 20:24:06.224924+00	2026-11-25 20:24:06.224924+00
8469	41	Blindness	\N	\N	Blackstone on Brilliance Audio	2018	9781721315543	1721315543	https://covers.openlibrary.org/b/id/10655114-M.jpg	OL31979608M	\N	2026-11-25 20:24:06.224924+00	2026-11-25 20:24:06.224924+00
8470	41	Blindness	eng	\N	BBC Audiobooks	2008	9781602834446	160283444X	https://covers.openlibrary.org/b/id/10871028-M.jpg	OL32236992M	\N	2026-11-25 20:24:06.224924+00	2026-11-25 20:24:06.224924+00
8471	41	Ensayo sobre la ceguera / Blindness	\N	\N	Debolsillo	2016	9788490628720	8490628726	https://covers.openlibrary.org/b/id/10584546-M.jpg	OL31900553M	\N	2026-11-25 20:24:06.224924+00	2026-11-25 20:24:06.224924+00
8472	41	Ensaio Sobre a Cegueira	\N	\N	Leya	2016	9789896604011	9896604010	https://covers.openlibrary.org/b/id/10482411-M.jpg	OL30674740M	\N	2026-11-25 20:24:06.224924+00	2026-11-25 20:24:06.224924+00
8473	41	Blindness	eng	\N	Vintage Classics	2017	9780099573586	009957358X	https://covers.openlibrary.org/b/id/8843969-M.jpg	OL27380882M	\N	2026-11-25 20:24:06.224924+00	2026-11-25 20:24:06.224924+00
8474	41	Ensayo Sobre LA Ceguera	spa	\N	Alfaguara Ediciones, S.A. (Spain)	1996	9788420428659	8420428655	https://covers.openlibrary.org/b/id/1046684-M.jpg	OL9116490M	\N	2026-11-25 20:24:06.224924+00	2026-11-25 20:24:06.224924+00
8475	41	Ensaio Sobre a Cegueira	por	BR	Companhia das Letras	1995	9788571644953	8571644950	https://covers.openlibrary.org/b/id/14618693-M.jpg	OL9162940M	\N	2026-11-25 20:24:06.224924+00	2026-11-25 20:24:06.224924+00
8476	41	Ensayo Sobre La Ceguera	spa	\N	Alfaguara	2006	9789870400448	9870400442	\N	OL9199217M	\N	2026-11-25 20:24:06.224924+00	2026-11-25 20:24:06.224924+00
8477	41	Ensayo sobre la ceguera	spa	\N	Aguilar, Altea, Taurus, Alfaguara, S.A. de C.	2000	9789681904548	9681904540	\N	OL13118076M	\N	2026-11-25 20:24:06.224924+00	2026-11-25 20:24:06.224924+00
8478	41	Ensayo Sobre La Ceguera	spa	\N	Alfaguara Ediciones, S.A. (Spain)	2000	9789505116720	9505116721	https://covers.openlibrary.org/b/id/2291120-M.jpg	OL9886860M	\N	2026-11-25 20:24:06.224924+00	2026-11-25 20:24:06.224924+00
8479	41	ensayo sobre la ceguera	\N	\N	Punto de Lectura	2005	\N	8463312161	\N	OL24300584M	\N	2026-11-25 20:24:06.224924+00	2026-11-25 20:24:06.224924+00
8480	41	Ensayo sobre la ceguera	spa	\N	Ediciones Santillana, S.A.	2001	9788495501073	8495501074	https://covers.openlibrary.org/b/id/7912901-M.jpg	OL9153039M	\N	2026-11-25 20:24:06.224924+00	2026-11-25 20:24:06.224924+00
8481	41	Ensayo Sobre La Ceguera	spa	\N	Suma de Letras	2003	9789871106172	9871106173	https://covers.openlibrary.org/b/id/3359411-M.jpg	OL13196051M	\N	2026-11-25 20:24:06.224924+00	2026-11-25 20:24:06.224924+00
8482	41	Blindness	eng	\N	Harvest Books	1999	9780156007757	0156007754	\N	OL26368537M	\N	2026-11-25 20:24:06.224924+00	2026-11-25 20:24:06.224924+00
8483	41	Ensayo sobre la ceguera	spa	\N	Alfaguara	1998	\N	9681904540	\N	OL21503777M	\N	2026-11-25 20:24:06.224924+00	2026-11-25 20:24:06.224924+00
8484	41	Ensayo Sobre La Ceguera (Biblioteca Jose Saramago)	spa	\N	Punto de lectura	2006	9789707311152	\N	https://covers.openlibrary.org/b/id/6591731-M.jpg	OL24362268M	\N	2026-11-25 20:24:06.224924+00	2026-11-25 20:24:06.224924+00
8485	41	Ensayo Sobre La Ceguera (Biblioteca Jose Saramago)	spa	\N	Alfaguara	2002	9789681908713	9681908716	https://covers.openlibrary.org/b/id/15112024-M.jpg	OL9173184M	\N	2026-11-25 20:24:06.224924+00	2026-11-25 20:24:06.224924+00
8486	41	ensayo sobre la ceguera	\N	\N	Punto de Lectura	2005	\N	8463312161	\N	OL24300583M	\N	2026-11-25 20:24:06.224924+00	2026-11-25 20:24:06.224924+00
8487	41	Blindness	eng	\N	Harvill Pr	1999	9781860466854	1860466850	https://covers.openlibrary.org/b/id/914953-M.jpg	OL8626239M	\N	2026-11-25 20:24:06.224924+00	2026-11-25 20:24:06.224924+00
8488	41	Blindness	eng	\N	Harcourt Brace & Co.	1999	\N	0156007754	https://covers.openlibrary.org/b/id/6608769-M.jpg	OL21630365M	\N	2026-11-25 20:24:06.224924+00	2026-11-25 20:24:06.224924+00
8489	41	Ensaio sobre a Cegueira	por	PT	Caminho	1995	9789722110211	9722110217	https://covers.openlibrary.org/b/id/1054349-M.jpg	OL552444M	\N	2026-11-25 20:24:06.224924+00	2026-11-25 20:24:06.224924+00
8490	41	Blindness	eng	\N	Harvill Press	1997	\N	1860462987	https://covers.openlibrary.org/b/id/4540275-M.jpg	OL6854985M	\N	2026-11-25 20:24:06.224924+00	2026-11-25 20:24:06.224924+00
8491	41	Blindness	eng	\N	Thorndike Press	1999	\N	0786218347	https://covers.openlibrary.org/b/id/10428436-M.jpg	OL16431240M	\N	2026-11-25 20:24:06.224924+00	2026-11-25 20:24:06.224924+00
8492	41	Blindness	eng	\N	Harcourt Brace & Company	1998	\N	0151002517	https://covers.openlibrary.org/b/id/15209019-M.jpg	OL352517M	\N	2026-11-25 20:24:06.224924+00	2026-11-25 20:24:06.224924+00
8833	6	Chapterhouse, Dune	eng	\N	Berkley Publishing Group	1987	\N	0441102670	https://covers.openlibrary.org/b/id/6610378-M.jpg	OL16257424M	\N	2026-11-25 20:24:37.596743+00	2026-11-25 20:24:37.596743+00
8834	6	Chapterhouse, Dune	eng	\N	Putnam	1985	\N	0399130276	https://covers.openlibrary.org/b/id/5536140-M.jpg	OL2855494M	\N	2026-11-25 20:24:37.596743+00	2026-11-25 20:24:37.596743+00
8835	6	Chapter House Dune	\N	\N	Orion Publishing Co	1985	9780575035768	0575035765	https://covers.openlibrary.org/b/id/13101111-M.jpg	OL7877932M	\N	2026-11-25 20:24:37.596743+00	2026-11-25 20:24:37.596743+00
8836	6	Chapterhouse, Dune	eng	\N	Putnam	1985	\N	0399130276	https://covers.openlibrary.org/b/id/14816256-M.jpg	OL23257625M	\N	2026-11-25 20:24:37.596743+00	2026-11-25 20:24:37.596743+00
8837	6	Chapter House Dune	\N	\N	Gollancz	2003	9780575075184	057507518X	https://covers.openlibrary.org/b/id/380238-M.jpg	OL7878788M	\N	2026-11-25 20:24:37.596743+00	2026-11-25 20:24:37.596743+00
8873	4	Heretics of Dune	eng	\N	New English Library	1985	\N	0450057771	https://covers.openlibrary.org/b/id/9256383-M.jpg	OL17375170M	\N	2026-11-25 20:24:40.706618+00	2026-11-25 20:24:40.706618+00
8874	4	Heretics of Dune	eng	\N	Penguin Group USA, Inc.	2008	9781436247252	\N	https://covers.openlibrary.org/b/id/6400407-M.jpg	OL24252675M	\N	2026-11-25 20:24:40.706618+00	2026-11-25 20:24:40.706618+00
8875	4	Heretics of dune	eng	\N	Gollancz	1984	\N	0575057777	https://covers.openlibrary.org/b/id/14816247-M.jpg	OL15069377M	\N	2026-11-25 20:24:40.706618+00	2026-11-25 20:24:40.706618+00
8876	4	Heretics of Dune	eng	\N	Putnam	1984	\N	0399128980	https://covers.openlibrary.org/b/id/6637679-M.jpg	OL3173739M	\N	2026-11-25 20:24:40.706618+00	2026-11-25 20:24:40.706618+00
8877	4	Heretics of Dune	\N	\N	Caedmon Audio Cassette	1984	9780898452624	0898452627	\N	OL11334383M	\N	2026-11-25 20:24:40.706618+00	2026-11-25 20:24:40.706618+00
8878	4	Heretics of Dune.	\N	\N	\N	\N	\N	\N	https://covers.openlibrary.org/b/id/14816245-M.jpg	OL14416765M	\N	2026-11-25 20:24:40.706618+00	2026-11-25 20:24:40.706618+00
8879	4	Heretiques De Dunes	\N	\N	Robert Lafont French	1985	9782221046425	2221046420	https://covers.openlibrary.org/b/id/13785942-M.jpg	OL12459195M	\N	2026-11-25 20:24:40.706618+00	2026-11-25 20:24:40.706618+00
8880	4	Heretics of Dune (in Slipcase)	\N	\N	Putnam Pub Group	1984	9780575034235	0575034238	https://covers.openlibrary.org/b/id/14816246-M.jpg	OL7877904M	\N	2026-11-25 20:24:40.706618+00	2026-11-25 20:24:40.706618+00
8881	4	Herejes De Dune/Heretics of Dune	spa	\N	Ultramar Editores	1984	9788473863483	8473863488	\N	OL9136123M	\N	2026-11-25 20:24:40.706618+00	2026-11-25 20:24:40.706618+00
8882	4	Heretics of Dune (Dune Chronicles, Book 5)	eng	\N	Books On Tape	2000	9780736654531	0736654534	https://covers.openlibrary.org/b/id/463309-M.jpg	OL7893355M	\N	2026-11-25 20:24:40.706618+00	2026-11-25 20:24:40.706618+00
8883	4	Heretics of Dune (Dune Chronicles, Book 5)	eng	\N	Bt Bound	2001	9780808570004	0808570005	https://covers.openlibrary.org/b/id/14816249-M.jpg	OL9437080M	\N	2026-11-25 20:24:40.706618+00	2026-11-25 20:24:40.706618+00
8884	4	Heretics of Dune (Dune Chronicles, Book 5)	eng	\N	Ace	1987	9780441328000	0441328008	https://covers.openlibrary.org/b/id/284530-M.jpg	OL7525590M	\N	2026-11-25 20:24:40.706618+00	2026-11-25 20:24:40.706618+00
8885	4	Heretics of Dune (Dune Chronicles, Book 5)	eng	\N	HarperCollins Publishers	1994	9781559949217	155994921X	\N	OL9374364M	\N	2026-11-25 20:24:40.706618+00	2026-11-25 20:24:40.706618+00
8886	8	The Lord of the Rings: The Two Towers	eng	\N	The Random House Publishing Group	1994	9780345339713	\N	\N	OL62841730M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8887	8	Stolpa	slv	\N	Mladinska knjiga	2002	\N	8611163001	https://covers.openlibrary.org/b/id/15261271-M.jpg	OL62623509M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8888	8	Gredzenu pavēlnieks. Divi torņi	\N	\N	Jumava	2003	9789984056265	\N	\N	OL62453996M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8889	8	The Two Towers (Ballantine U7041)	\N	\N	Ballantine	1967	\N	\N	\N	OL60344695M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8890	8	THE TWO TOWERS BIENG THE SECOND PART OF THE LORD OF THE RINGS	eng	\N	BALLANTINE BOOKS	1965	\N	\N	\N	OL59087758M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8891	8	The Lord of the Rings part two The Two Towers 	eng	\N	\N	1973	\N	\N	\N	OL58729469M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8892	8	The Two Towers	eng	\N	\N	1965	\N	\N	\N	OL58723054M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8893	8	The Two Towers	eng	\N	\N	1973	\N	\N	\N	OL58659534M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8894	8	The Two Towers	eng	\N	Ballantine Books, New York	1965	\N	\N	\N	OL59087743M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8895	8	The Lord of the Rings	eng	\N	Ballantine Books	1973	\N	\N	\N	OL57684137M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8896	8	Two Towers	eng	\N	CreateSpace Independent Publishing Platform	2017	9781548547455	\N	\N	OL54879521M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8897	8	Two Towers	eng	\N	Bound to Stay Bound Books	1993	9798855136425	\N	\N	OL53335708M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8898	8	Shene migdalim	heb	\N	Zemorah, Bitan, Modan	1979	\N	\N	\N	OL50255739M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8899	8	O Archontas Ton Dachtylidion 2 : Oi Dyo Pyrgoi - The Lord of the Rings Book 2	ell	\N	Kedros	2002	9789600403671	9600403678	https://covers.openlibrary.org/b/id/13944540-M.jpg	OL39203520M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8900	8	Le Seigneur des Anneaux	fra	\N	Gallimard Jeunesse	2007	9782070612895	2070612899	https://covers.openlibrary.org/b/id/15119677-M.jpg	OL60054984M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8901	8	Wladca Pierscieni tom 2 Dwie Wieze	\N	\N	Amber	\N	9788324144259	8324144250	https://covers.openlibrary.org/b/id/13332782-M.jpg	OL46845567M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8902	8	Señor de los Anillos	spa	\N	Editorial Planeta, S. A.	2012	9786070712739	\N	\N	OL36793088M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8903	8	Der Herr der Ringe, 3 Bde. Kt, Tl.2, Die zwei Türme	deu	\N	n/a	\N	9783608952131	3608952136	\N	OL43718518M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8904	8	Two Towers Collector's Edition	eng	\N	HarperCollins Publishers	2024	9780063412620	\N	\N	OL51123649M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8905	8	The Two Towers - The Lord of the Rings Part 2	\N	\N	Ballantine Books	1973	\N	\N	\N	OL49664796M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8906	8	The two towers	\N	\N	Boston : Houghton Mifflin Company	1965	\N	\N	\N	OL49344016M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8907	8	Lord of the Rings # 2 -- The Two Towers	\N	\N	Allen & Unwin	1966	\N	\N	\N	OL47748448M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8908	8	THE TWO TOWERS - BEING THE SECOND PART OF THE LORD OF THE RINGS - BALLANTINE 01534	\N	\N	Ballantine Books	1969	\N	\N	\N	OL47713712M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8909	8	El Senyor Dels Anells Ii	cat	\N	Editorial Vicens Vives	2002	9788431668303	843166830X	https://covers.openlibrary.org/b/id/14031787-M.jpg	OL47431087M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8910	8	Wladca Pierscieni Tom 2 Dwie wieze	pol	\N	Zysk i S-ka	2018	9788381165204	8381165202	https://covers.openlibrary.org/b/id/13945046-M.jpg	OL47353701M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8911	8	Wladca Pierscieni Tom 2 Dwie wieze	pol	\N	Zysk i S-ka	2011	9788377856819	8377856816	https://covers.openlibrary.org/b/id/13945044-M.jpg	OL47353699M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8912	8	The Two Towers	\N	\N	Brand: Listening Library	2002	9780807209073	0807209074	https://covers.openlibrary.org/b/id/13935017-M.jpg	OL47345638M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8913	8	El Señor de los Anillos	spa	\N	Minotauro	2022	9788445013960	8445013963	https://covers.openlibrary.org/b/id/14626855-M.jpg	OL47181065M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8493	42	Bada Spēles	\N	\N	Zvaigzne ABC	2024	9789934327070	\N	https://covers.openlibrary.org/b/id/15247137-M.jpg	OL62454015M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8494	42	O Jogos Da Fome. Livro I	por	PT	Editorial Presença	2009	9789722342391	9722342398	https://covers.openlibrary.org/b/id/14844157-M.jpg	OL57727932M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8495	42	Los Juegos Del Hambre (Edición Especial) / the Hunger Games (Special Edition)	spa	\N	Penguin Random House Grupo Editorial	2025	9788427248465	\N	\N	OL57588895M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8496	42	Los juegos del hambre	spa	\N	Molino	2025	9788427246003	8427246005	\N	OL57568965M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8497	42	The Hunger Games	eng	\N	Scholastic	2025	9780702342387	0702342386	https://covers.openlibrary.org/b/id/15229595-M.jpg	OL57558534M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8498	42	Hunger Games (Large Print)	eng	\N	Blackstone Audio, Incorporated	2023	9798212979986	\N	\N	OL52188867M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8499	42	Hunger Games (Large Print)	eng	\N	Blackstone Audio, Incorporated	2023	9798212982115	\N	\N	OL52195331M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8500	42	Hunger Games	eng	\N	Scholastic	2023	9780702333026	\N	\N	OL49265200M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8501	42	Hunger Games	eng	\N	Scholastic	2023	9780702332982	\N	\N	OL49269153M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8502	42	Hunger Games	eng	\N	Smashwords	2011	9781466185999	\N	\N	OL54091326M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8503	42	Hunger Games	eng	\N	Bound to Stay Bound Books	2008	9798855026139	\N	\N	OL53337919M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8504	42	Hunger Games	eng	\N	CreateSpace Independent Publishing Platform	2012	9781477409572	\N	\N	OL54574205M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8505	42	Hunger Games	eng	\N	CreateSpace Independent Publishing Platform	2013	9781481903219	\N	\N	OL56764339M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8506	42	Hunger Games	eng	\N	CreateSpace Independent Publishing Platform	2015	9781519480026	\N	\N	OL55622654M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8507	42	Hunger Games	eng	\N	Scholastic	2024	9781339030609	\N	https://covers.openlibrary.org/b/id/14819483-M.jpg	OL51058687M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8508	42	Jocurile Foamei. Trilogia Jocurile Foamei, Vol.1	\N	\N	Nemira	2019	9786064306166	6064306165	https://covers.openlibrary.org/b/id/14846995-M.jpg	OL57901563M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8509	42	The Hunger Games	zho	\N	大塊文化出版股份有限公司	2012	9789862131367	\N	https://covers.openlibrary.org/b/id/15168492-M.jpg	OL61277346M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8510	42	The Hunger Games	eng	\N	Scholastic Inc.	2008	9780439023481	\N	https://covers.openlibrary.org/b/id/15261620-M.jpg	OL61276815M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8511	42	Αγώνες πείνας	ell	\N	Platypus	2009	9789606665806	9606665801	https://covers.openlibrary.org/b/id/15168030-M.jpg	OL60398890M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8512	42	Agones peinas / Αγώνες πείνας	\N	\N	\N	\N	9786180122756	618012275X	\N	OL48579350M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8513	42	饥饿游戏	zho	\N	作家出版社	\N	9787506368513	750636851X	https://covers.openlibrary.org/b/id/15168023-M.jpg	OL50516304M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8514	42	The Hunger Games	dan	\N	Gyldendal	2014	9788702094190	8702094193	https://covers.openlibrary.org/b/id/15168022-M.jpg	OL49225525M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8515	42	The Hunger Games	eng	\N	Scholastic Inc.	2009	\N	0439023521	https://covers.openlibrary.org/b/id/15168021-M.jpg	OL61260120M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8516	42	The Hunger Games	tgl	\N	Precious Pages Corporation	2012	9789710254545	\N	https://covers.openlibrary.org/b/id/15167828-M.jpg	OL61253640M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8517	42	Ðâu trương sinh tư	vie	\N	Văn Học : Nhã Nam	2010	\N	\N	https://covers.openlibrary.org/b/id/15167826-M.jpg	OL42909353M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8518	42	The Hunger Games	eng	\N	Scholastic Press	2008	\N	\N	https://covers.openlibrary.org/b/id/15267399-M.jpg	OL61249009M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8519	42	Jogos Vorazes	por	BR	Rocco	2021	9786555321449	\N	https://covers.openlibrary.org/b/id/15167336-M.jpg	OL60492730M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8520	42	De Hongerspelen	nld	\N	van Goor	2025	9789000399284	9000399289	https://covers.openlibrary.org/b/id/15120650-M.jpg	OL60075974M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8521	42	Los juegos del hambre	spa	\N	RBA	2014	9788427208391	8427208391	https://covers.openlibrary.org/b/id/15168582-M.jpg	OL47350734M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8522	42	Los Juegos del Hambre	spa	\N	B de Bolsillo	2022	9788413144856	841314485X	https://covers.openlibrary.org/b/id/13766461-M.jpg	OL47301842M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8523	42	Los Juegos del Hambre	spa	\N	RBA Bolsillo	2016	9788492966806	8492966807	https://covers.openlibrary.org/b/id/13941003-M.jpg	OL47350660M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8524	42	Els jocs de la fam	cat	\N	labutxaca	2011	9788499303321	8499303323	https://covers.openlibrary.org/b/id/13526322-M.jpg	OL47132492M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8525	42	The Hunger Games	eng	\N	Scholastic	2012	9781407135397	1407135392	https://covers.openlibrary.org/b/id/15236101-M.jpg	OL46874697M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8526	42	De hongerspelen	nld	\N	Unieboek | Het Spectrum	2013	9789000331956	9000331951	https://covers.openlibrary.org/b/id/13188964-M.jpg	OL46531110M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8527	42	משחקי הרעב	heb	\N	כנרת	2010	9789655177183	\N	https://covers.openlibrary.org/b/id/14855537-M.jpg	OL45279990M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8528	42	De Hongerspelen	nld	\N	Van Goor	2012	9789047515975	9047515978	https://covers.openlibrary.org/b/id/15168586-M.jpg	OL43211732M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8529	42	Hungerspelen	swe	\N	Månpocket	2012	9789175030340	9175030349	https://covers.openlibrary.org/b/id/14855536-M.jpg	OL41432901M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8530	42	Die Tribute von Panem	deu	\N	Oetinger	2020	9783789121272	3789121274	https://covers.openlibrary.org/b/id/14564960-M.jpg	OL39811649M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8531	42	The Hunger Games	fra	\N	Pocket	2009	9782298079715	\N	https://covers.openlibrary.org/b/id/14635829-M.jpg	OL51747483M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8532	42	The Hunger Games	\N	\N	Klett Sprachen GmbH	2013	9783125781535	3125781531	https://covers.openlibrary.org/b/id/13944877-M.jpg	OL47353556M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8533	42	Gose jokoak	\N	\N	Alberdania	2009	9788498680614	8498680611	https://covers.openlibrary.org/b/id/14131022-M.jpg	OL47516306M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8534	42	The Hunger Games by Suzanne Collins	\N	\N	scholastic audiobooks	2008	9780545114073	0545114071	https://covers.openlibrary.org/b/id/13575602-M.jpg	OL47161362M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8535	42	Hunger Games	ita	\N	Oscar Mondadori	2014	9788804632238	8804632232	https://covers.openlibrary.org/b/id/15168028-M.jpg	OL40225664M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8536	42	Jogos Vorazes - Portuguese edition of Hunger Games volume 1	\N	\N	Rocco Jovens Leitores	2010	9788579800245	8579800242	\N	OL40222897M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8537	42	Los Juegos Del Hambre (Hunger Games)	spa	\N	Lectorum Publications, Incorporated	2012	9781536425512	\N	\N	OL39650457M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8538	42	Hunger Games	eng	\N	Scholastic, Incorporated	2012	9780545471046	\N	\N	OL44243092M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8539	42	Hunger Games	eng	\N	Sterling Publishing Co., Inc.	2014	9781411471047	\N	\N	OL40478860M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8540	42	Hunger Games	eng	\N	Scholastic	2011	9781407129044	\N	\N	OL44130122M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8541	42	Hunger Games	eng	\N	Scholastic	2011	9781407133171	\N	\N	OL44146236M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8542	42	Hunger Games	swe	\N	Scholastic	2013	9781407136189	\N	\N	OL44152476M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8543	42	饥饿游戏	zho	\N	Zuo jia chu ban she	2012	9787506351539	7506351536	https://covers.openlibrary.org/b/id/12996671-M.jpg	OL40281540M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8544	42	Los juegos del hambre	spa	\N	Molino	2010	9788498675399	8498675391	https://covers.openlibrary.org/b/id/15283934-M.jpg	OL39475933M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8545	42	Los juegos del hambre	spa	\N	Molino	2012	9789876091657	9876091654	https://covers.openlibrary.org/b/id/15167839-M.jpg	OL35570738M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8546	42	Los juegos del hambre	\N	\N	Círculo de Lectores	2009	\N	\N	https://covers.openlibrary.org/b/id/10542865-M.jpg	OL31854446M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8547	42	Los juegos del hambre	\N	\N	Molino	2012	9788427202122	\N	https://covers.openlibrary.org/b/id/7351074-M.jpg	OL25684271M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8548	42	Aclik Oyunlari - Aclik Oyunlari 1	\N	\N	Pegasus	2009	9786055943639	6055943638	https://covers.openlibrary.org/b/id/12238355-M.jpg	OL35395814M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8549	42	Açlık Oyunları	tur	\N	De X	2015	9786050929997	6050929998	https://covers.openlibrary.org/b/id/15168014-M.jpg	OL35302690M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8550	42	Els jocs de la fam	cat	\N	Estrella Polar	2012	9788499327976	8499327974	https://covers.openlibrary.org/b/id/15168016-M.jpg	OL28169129M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8551	42	Los juegos del hambre	spa	\N	Oceano Travesía	2009	9786074001907	6074001901	\N	OL38572216M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8552	42	Los juegos del hambre	\N	\N	Molino	2021	9788427225183	8427225180	\N	OL39202710M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8553	42	Hunger Games	swe	\N	Scholastic	2009	9781407111681	\N	\N	OL37094230M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8554	42	Hunger Games	ita	\N	Mondadori	2017	9788804672623	8804672625	https://covers.openlibrary.org/b/id/15168020-M.jpg	OL37140636M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8555	42	Hunger Games	swe	\N	Turtleback	2010	9781417831739	\N	\N	OL37374985M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8556	42	Hunger Games	eng	\N	Scholastic, Incorporated	2012	9780545452397	\N	\N	OL39288141M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8557	42	The Hunger Games	spa	\N	Penguin Random House Grupo Editorial	2022	9786073807845	\N	https://covers.openlibrary.org/b/id/15116019-M.jpg	OL36929804M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8558	42	Die Tribute von Panem	deu	\N	Oetinger Tasenbuch	2012	9783841501349	3841501346	https://covers.openlibrary.org/b/id/12878037-M.jpg	OL39475512M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8559	42	Hunger Games	fra	\N	Editions France Loisirs	2012	9782298027259	2298027250	https://covers.openlibrary.org/b/id/12876269-M.jpg	OL39474808M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8560	42	Hangā gēmu	jpn	\N	Mediafakutorī	2012	9784840146319	4840146314	\N	OL35338275M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8561	42	The Hunger Games	eng	\N	Scholastic Press	2014	9789351035961	9351035964	https://covers.openlibrary.org/b/id/14807306-M.jpg	OL34391306M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8562	42	Hunger Games - Tome 1 [ edition poche ]	\N	\N	POCKET JEUNESSE	2015	9782266260770	2266260774	https://covers.openlibrary.org/b/id/12024277-M.jpg	OL34118154M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8563	42	Hunger Games - tome 1 -Edition collector-	\N	\N	POCKET JEUNESSE	2014	9782266257220	2266257226	https://covers.openlibrary.org/b/id/12024278-M.jpg	OL34118152M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8564	42	Golodnye igry	rus	\N	AST	2012	9785271257940	5271257940	\N	OL27138267M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8565	42	The Hunger Games	eng	\N	Scholastic Inc.	2009	9780439023528	0439023521	https://covers.openlibrary.org/b/id/12646544-M.jpg	OL37079410M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8566	42	The Hunger Games	eng	\N	Scholastic Inc.	2012	9780545425117	0545425115	https://covers.openlibrary.org/b/id/12646531-M.jpg	OL37079370M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8567	42	Голодные игры	rus	\N	ACT	2012	9785271415203	5271415201	https://covers.openlibrary.org/b/id/12646529-M.jpg	OL37079366M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8568	42	The Hunger Games	eng	\N	CreateSpace Independent Publishing Platform	2013	\N	\N	\N	OL37079352M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8569	42	The Hunger Games	eng	\N	Scholastic	2010	9781407192239	\N	https://covers.openlibrary.org/b/id/15256822-M.jpg	OL37079299M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8570	42	The Hunger Games	eng	\N	Scholastic	2018	9781407192086	1407192086	https://covers.openlibrary.org/b/id/12646484-M.jpg	OL37079289M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8571	42	The Hunger Games	eng	\N	Scholastic	2018	9781407191294	1407191292	https://covers.openlibrary.org/b/id/12646481-M.jpg	OL37079286M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8572	42	The Hunger Games	eng	\N	Scholastic Inc.	2013	9780545626385	0545626382	https://covers.openlibrary.org/b/id/12646476-M.jpg	OL37079238M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8573	42	The Hunger Games	eng	\N	Scholastic	2010	9781407109084	1407109081	https://covers.openlibrary.org/b/id/12646467-M.jpg	OL37079228M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8574	42	Hunger Games	ita	\N	Oscar Mondadori	2020	9788804716709	8804716703	https://covers.openlibrary.org/b/id/15168015-M.jpg	OL34118346M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8575	42	Hunger Games	eng	\N	Scholastic	2019	9781407196183	\N	\N	OL35839735M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8576	42	Hunger Games	eng	\N	Scholastic, Incorporated	2010	9781484476826	\N	\N	OL34154302M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8577	42	The Hunger Games	\N	\N	Large Print Press	2012	9781594135873	1594135878	https://covers.openlibrary.org/b/id/12045564-M.jpg	OL34661487M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8578	42	The Hunger Games	\N	\N	Turtleback	2012	9780606262286	0606262288	https://covers.openlibrary.org/b/id/12045566-M.jpg	OL34661557M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8579	42	The Hunger Games	eng	\N	Scholastic Press	2009	9788184771695	818477169X	https://covers.openlibrary.org/b/id/15168026-M.jpg	OL32735739M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8580	42	The Hunger Games	\N	\N	Scholastic Audio	2018	9781987156584	1987156587	https://covers.openlibrary.org/b/id/10706510-M.jpg	OL32040567M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8581	42	The Hunger Games	eng	\N	Scholastic	2013	9781407139791	1407139797	https://covers.openlibrary.org/b/id/10764523-M.jpg	OL32106780M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8582	42	The Hunger Games	eng	\N	Scholastic Children's Books	2014	9781407153339	1407153331	https://covers.openlibrary.org/b/id/10764525-M.jpg	OL32106782M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8583	42	The Hunger Games	\N	\N	Scholastic Corporation	2008	\N	\N	\N	OL31727288M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8584	42	The Hunger Games	eng	\N	Scholastic	2008	9780545229937	0545229936	https://covers.openlibrary.org/b/id/10511383-M.jpg	OL31073614M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8585	42	The Hunger Games 10th Anniversary	\N	\N	Scholastic	2018	9781407188935	1407188933	https://covers.openlibrary.org/b/id/10358091-M.jpg	OL28794825M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8586	42	Hunger Games	eng	\N	Scholastic	2011	9781407129037	\N	\N	OL29069148M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8587	42	Hunger Games	eng	\N	Scholastic, Incorporated	2018	9781338321913	\N	https://covers.openlibrary.org/b/id/14573157-M.jpg	OL28892755M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8588	42	Hunger Games	eng	\N	Scholastic	2015	9781742835754	\N	\N	OL28497295M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8589	42	The Hunger Games	\N	\N	Perfection Learning	2012	9781627656368	1627656367	https://covers.openlibrary.org/b/id/10181570-M.jpg	OL28251877M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8590	42	The Hunger Games	eng	\N	Scholastic Australia	2014	9781743629857	\N	https://covers.openlibrary.org/b/id/12507372-M.jpg	OL28553300M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8591	42	The Hunger Games	eng	\N	Scholastic	2011	9781407132082	1407132083	https://covers.openlibrary.org/b/id/12646470-M.jpg	OL28477723M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8592	42	Hunger Games Special Edition	eng	\N	Scholastic, Incorporated	2018	9781760662103	\N	\N	OL28709462M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8593	42	Hunger Games	eng	\N	Scholastic	2015	9781407157863	\N	\N	OL29550720M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8594	42	Hunger Games	eng	\N	Scholastic	2012	9781407135281	\N	\N	OL29130417M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8595	42	Hunger games	\N	\N	Mondadori	2009	9788804594109	8804594101	https://covers.openlibrary.org/b/id/9387830-M.jpg	OL28003378M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8596	42	The Hunger Games	eng	\N	Scholastic	2012	9781407132075	1407132075	https://covers.openlibrary.org/b/id/12646473-M.jpg	OL28477332M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8597	42	Hunger Games	\N	\N	Pocket	2020	9782266305754	2266305751	https://covers.openlibrary.org/b/id/10164211-M.jpg	OL28232609M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8598	42	Hunger Games (The Hunger Games #1)	\N	\N	Scholastic	2011	9780545405775	\N	https://covers.openlibrary.org/b/id/9327251-M.jpg	OL27939297M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8599	42	Igrzyska śmierci	pol	\N	Media Rodzina	2009	9788372783578	\N	https://covers.openlibrary.org/b/id/15168031-M.jpg	OL26793516M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8600	42	Igrzyska śmierci	pol	\N	Media Rodzina	2011	9788372786371	8372786372	https://covers.openlibrary.org/b/id/12646533-M.jpg	OL26411753M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8601	42	Die Tribute von Panem 1. Tödliche Spiele	\N	\N	Oetinger Friedrich GmbH	2009	9783789132186	3789132187	\N	OL26760325M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8602	42	hunger games 	\N	\N	carlo moscatiello 	2008	\N	\N	\N	OL27643249M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8603	42	Hunger Games	fra	\N	Pocket Jeunesse	2011	9782266182690	2266182692	https://covers.openlibrary.org/b/id/12646488-M.jpg	OL27099424M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8604	42	The Hunger Games	\N	\N	Scholastic Audio Books	2018	9781338334920	1338334921	https://covers.openlibrary.org/b/id/8830470-M.jpg	OL27367291M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8605	42	The Hunger Games	eng	\N	Scholastic Inc.	2014	9780545791878	0545791871	https://covers.openlibrary.org/b/id/15167833-M.jpg	OL27087973M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8606	42	The Hunger Games	eng	\N	Scholastic Press	2008	9780545310581	054531058X	https://covers.openlibrary.org/b/id/12876308-M.jpg	OL26923666M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8607	42	The Hunger Games                            Hunger Games PB	\N	\N	Perfection Learning	2010	9781606865811	\N	https://covers.openlibrary.org/b/id/7639134-M.jpg	OL26053997M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8608	42	Hunger Games	\N	\N	Scholastic	2009	\N	\N	https://covers.openlibrary.org/b/id/7270868-M.jpg	OL25160105M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8609	42	The Hunger Games	eng	\N	Thorndike Press	2009	9781410419866	141041986X	https://covers.openlibrary.org/b/id/13401476-M.jpg	OL23631365M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8610	42	The Hunger Games	eng	\N	Scholastic	2008	9780545091022	0545091020	https://covers.openlibrary.org/b/id/6376188-M.jpg	OL24196690M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8611	42	The Hunger Games	\N	\N	Scholastic Singapore	2009	\N	9810844514	https://covers.openlibrary.org/b/id/6926822-M.jpg	OL24991601M	\N	2026-11-25 20:24:10.749244+00	2026-11-25 20:24:10.749244+00
8838	4	Kofre Ḥolit	heb	\N	ʻAm ʻoved	1986	\N	9651304219	\N	OL50431600M	\N	2026-11-25 20:24:40.706618+00	2026-11-25 20:24:40.706618+00
8839	4	Heretics of Dune	eng	\N	Orion Publishing Group, Limited	2010	9780575104457	\N	\N	OL48142606M	\N	2026-11-25 20:24:40.706618+00	2026-11-25 20:24:40.706618+00
8840	4	Heretics of Dune	\N	\N	Ace	2009	9780441016778	0441016774	https://covers.openlibrary.org/b/id/12384801-M.jpg	OL35680285M	\N	2026-11-25 20:24:40.706618+00	2026-11-25 20:24:40.706618+00
8841	4	... Roman des Dune-Zyklus	deu	\N	Heyne	1984	9783453310995	3453310993	https://covers.openlibrary.org/b/id/9948205-M.jpg	OL25566533M	\N	2026-11-25 20:24:40.706618+00	2026-11-25 20:24:40.706618+00
8842	4	Heretics of Dune 10cc [Paperback]  by Herbert, Frank	eng	\N	Berkley Publishing Group	1985	9780425080368	0425080366	\N	OL7502194M	\N	2026-11-25 20:24:40.706618+00	2026-11-25 20:24:40.706618+00
8843	4	Heretics of Dune	\N	\N	\N	\N	9781439501672	143950167X	https://covers.openlibrary.org/b/id/13768444-M.jpg	OL47303931M	\N	2026-11-25 20:24:40.706618+00	2026-11-25 20:24:40.706618+00
8844	4	Heretics of Dune	\N	\N	\N	\N	9781436245029	1436245028	\N	OL43618343M	\N	2026-11-25 20:24:40.706618+00	2026-11-25 20:24:40.706618+00
8845	4	Heretics of Dune 16fl	\N	\N	Putnam Adult	1984	9780399129537	0399129537	\N	OL43389237M	\N	2026-11-25 20:24:40.706618+00	2026-11-25 20:24:40.706618+00
8846	4	Dune Sapkinlari	tur	\N	Ithaki Yayinlari	2021	9786257737159	625773715X	https://covers.openlibrary.org/b/id/12258293-M.jpg	OL35416359M	\N	2026-11-25 20:24:40.706618+00	2026-11-25 20:24:40.706618+00
8847	4	Dune Sapkinlari	\N	\N	Kabalci Yayinevi	2011	9789759971656	9759971658	https://covers.openlibrary.org/b/id/12355441-M.jpg	OL35648544M	\N	2026-11-25 20:24:40.706618+00	2026-11-25 20:24:40.706618+00
8848	4	Herejes de Dune / Heretics of Dune	spa	\N	Penguin Random House Grupo Editorial	2022	9788466359399	\N	https://covers.openlibrary.org/b/id/12407863-M.jpg	OL34987064M	\N	2026-11-25 20:24:40.706618+00	2026-11-25 20:24:40.706618+00
8849	4	Heretics of Dune	eng	\N	Orion Publishing Group, Limited	2021	9781473233799	\N	https://covers.openlibrary.org/b/id/14797595-M.jpg	OL34690789M	\N	2026-11-25 20:24:40.706618+00	2026-11-25 20:24:40.706618+00
8850	4	Heretics of Dune	eng	\N	HarperCollins	1988	9780694510221	069451022X	\N	OL11183649M	\N	2026-11-25 20:24:40.706618+00	2026-11-25 20:24:40.706618+00
8851	4	Hereges de Duna	por	BR	Aleph	2020	9788576574026	\N	https://covers.openlibrary.org/b/id/15117938-M.jpg	OL59974704M	\N	2026-11-25 20:24:40.706618+00	2026-11-25 20:24:40.706618+00
8852	4	Les Hérétiques de Dune	fra	\N	Pocket	2025	9782266350242	\N	https://covers.openlibrary.org/b/id/14895998-M.jpg	OL58634982M	\N	2026-11-25 20:24:40.706618+00	2026-11-25 20:24:40.706618+00
8853	4	Les Hérétiques de Dune	fra	\N	Robert Laffont	2023	9782221264577	2221264576	https://covers.openlibrary.org/b/id/14630362-M.jpg	OL51724705M	\N	2026-11-25 20:24:40.706618+00	2026-11-25 20:24:40.706618+00
8854	4	Heretycy Diuny	pol	\N	Dom Wydawniczy Rebis	2020	9788381887793	\N	https://covers.openlibrary.org/b/id/14613133-M.jpg	OL51567306M	\N	2026-11-25 20:24:40.706618+00	2026-11-25 20:24:40.706618+00
8855	4	Les Hérétiques de Dune	fra	\N	Robert Laffont	2021	9782221252338	2221252330	https://covers.openlibrary.org/b/id/12873431-M.jpg	OL39473674M	\N	2026-11-25 20:24:40.706618+00	2026-11-25 20:24:40.706618+00
8856	4	Les Hérétiques de Dune	\N	\N	Pocket	2012	9782266235846	2266235842	https://covers.openlibrary.org/b/id/10512505-M.jpg	OL31380937M	\N	2026-11-25 20:24:40.706618+00	2026-11-25 20:24:40.706618+00
8857	4	Les Hérétiques de Dune	\N	\N	Pocket	2001	9782266114028	2266114026	https://covers.openlibrary.org/b/id/980252-M.jpg	OL8890325M	\N	2026-11-25 20:24:40.706618+00	2026-11-25 20:24:40.706618+00
8612	47	It	\N	\N	Hodder & Stoughton	2023	9781444707861	\N	https://covers.openlibrary.org/b/id/15255912-M.jpg	OL62580344M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8613	47	O	\N	\N	Altin Kitaplar	2000	9789752121768	9752121764	https://covers.openlibrary.org/b/id/12302720-M.jpg	OL35596476M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8614	47	IT	eng	\N	Hodder & Stoughton	2017	9781473666931	\N	https://covers.openlibrary.org/b/id/14765931-M.jpg	OL53254558M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8615	47	It	eng	\N	Hodder & Stoughton	2007	9781848940871	\N	\N	OL53243110M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8616	47	It	eng	\N	Hodder & Stoughton	\N	9780340951644	\N	\N	OL53234997M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8617	47	Ça	\N	\N	J'ai Lu	1999	9782277069041	2277069043	https://covers.openlibrary.org/b/id/15255561-M.jpg	OL51011989M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8618	47	It	eng	\N	New American Library	1987	9780451159274	0451159276	https://covers.openlibrary.org/b/id/15283511-M.jpg	OL7572658M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8619	47	It	eng	\N	Signet	1998	9780451169518	0451169514	https://covers.openlibrary.org/b/id/15141087-M.jpg	OL7573104M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8620	47	It	\N	\N	Simon and Schuster	1986	\N	\N	https://covers.openlibrary.org/b/id/14402464-M.jpg	OL49226358M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8621	47	It	\N	\N	Simon and Schuster	1986	\N	\N	\N	OL49226357M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8622	47	It	\N	\N	Simon and Schuster	1986	\N	\N	\N	OL49226356M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8623	47	To	pol	\N	Albatros	2014	9788378858515	8378858510	https://covers.openlibrary.org/b/id/14655611-M.jpg	OL47698545M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8624	47	It	\N	\N	Debolsillo	2021	9788466357302	8466357300	https://covers.openlibrary.org/b/id/15240944-M.jpg	OL47456555M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8625	47	It	\N	\N	Debolsillo	2014	9786073157063	6073157061	https://covers.openlibrary.org/b/id/13176873-M.jpg	OL40269780M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8626	47	ОНО	rus	\N	Форс	2020	9789669931757	9669931754	\N	OL39811806M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8627	47	It	\N	\N	Overlook Connection Press	2016	9781623300890	1623300894	\N	OL38580715M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8628	47	IT-POCKET	\N	\N	DEBOLSILLO	2014	9789877253191	9877253194	https://covers.openlibrary.org/b/id/10705794-M.jpg	OL32039192M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8629	47	It	eng	\N	New American Library of Canada Limited	1987	\N	\N	https://covers.openlibrary.org/b/id/14656946-M.jpg	OL53222297M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8630	47	It	eng	\N	Guild Publishing	1988	\N	\N	https://covers.openlibrary.org/b/id/14656132-M.jpg	OL53203300M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8631	47	It	eng	\N	New American Library of Canada Limited	1987	\N	\N	https://covers.openlibrary.org/b/id/14655912-M.jpg	OL53199123M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8632	47	Es	deu	\N	Wilhelm Heyne Verlag	1988	9783453129542	\N	https://covers.openlibrary.org/b/id/15102463-M.jpg	OL53182899M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8633	47	It	eng	\N	Scribner	2019	9781982127794	\N	https://covers.openlibrary.org/b/id/14654497-M.jpg	OL53050009M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8634	47	It	eng	\N	Signet	1990	\N	0451169514	https://covers.openlibrary.org/b/id/14654040-M.jpg	OL53037332M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8635	47	It	eng	\N	Signet	1990	\N	0451169514	https://covers.openlibrary.org/b/id/14651807-M.jpg	OL52962675M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8636	47	It	\N	\N	Sperling & Kupfer	2019	9788868365622	8868365626	https://covers.openlibrary.org/b/id/14633309-M.jpg	OL51730245M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8637	47	It	por	BR	Suma de Letras	2014	9788560280940	\N	https://covers.openlibrary.org/b/id/14563910-M.jpg	OL50533719M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8638	47	It	\N	\N	Viking	1986	\N	\N	\N	OL50394663M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8639	47	Ça	\N	\N	LGF	2017	9782253083368	2253083364	https://covers.openlibrary.org/b/id/14131947-M.jpg	OL47517132M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8640	47	It	ita	\N	Sperling & Kupfer	2013	9788873398639	\N	https://covers.openlibrary.org/b/id/14420464-M.jpg	OL49369807M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8641	47	O	tur	\N	Altin Kitaplar	2015	9789752119277	9752119271	https://covers.openlibrary.org/b/id/12275783-M.jpg	OL35434402M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8642	47	It	\N	\N	DEBOLSILLO	2017	9788466345347	8466345345	https://covers.openlibrary.org/b/id/13145497-M.jpg	OL38585599M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8643	47	Es	\N	\N	Heyne Verlag	2019	9783453504080	3453504089	\N	OL37770856M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8644	47	It	\N	\N	Debolsillo	2019	9788466347921	8466347925	https://covers.openlibrary.org/b/id/12325015-M.jpg	OL35617839M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8645	47	It	\N	\N	Simon & Schuster Audio	2019	9781508297123	1508297126	https://covers.openlibrary.org/b/id/11533269-M.jpg	OL32905232M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8646	47	It	\N	\N	Simon & Schuster Audio	2017	9781508244127	150824412X	\N	OL37250363M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8647	47	Het	nld	\N	Uitgeverij Luitingh	1986	9789024516131	9024516137	https://covers.openlibrary.org/b/id/14653632-M.jpg	OL35674803M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8648	47	It	eng	\N	Scribner	2016	\N	\N	https://covers.openlibrary.org/b/id/14853843-M.jpg	OL34024224M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8649	47	It	\N	\N	Debolsillo	2014	9789877250244	9877250241	https://covers.openlibrary.org/b/id/10705796-M.jpg	OL32039210M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8650	47	It	eng	\N	Scribner	2016	9781501142970	\N	https://covers.openlibrary.org/b/id/15138281-M.jpg	OL28838648M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8651	47	It	eng	\N	Pocket Books	\N	9781501168895	\N	\N	OL28867645M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8652	47	It-eso. - 14. ed.	\N	\N	Debolsillo	2003	9788497593793	\N	https://covers.openlibrary.org/b/id/7887548-M.jpg	OL26205507M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8653	47	Eso / It	spa	\N	Downtown Book Center Inc	1986	9789500406970	9500406977	\N	OL12952956M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8654	47	It	eng	\N	Scribner	2017	9781501182099	1501182099	https://covers.openlibrary.org/b/id/14652968-M.jpg	OL32047733M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8655	47	Es	\N	\N	Heyne Verlag	2011	9783453435773	345343577X	https://covers.openlibrary.org/b/id/9346666-M.jpg	OL27958317M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8656	47	Es.	deu	\N	Heyne	1996	9783453099944	345309994X	https://covers.openlibrary.org/b/id/1008737-M.jpg	OL9040804M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8657	47	Es.	deu	\N	Ullstein Tb	2003	9783548256115	3548256112	https://covers.openlibrary.org/b/id/14654117-M.jpg	OL9064160M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8658	47	It	\N	\N	Hodder	2007	9780340951453	0340951451	https://covers.openlibrary.org/b/id/8665233-M.jpg	OL27046958M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8659	47	IT	eng	\N	Simon & Schuster Audio	2016	9781508217114	1508217114	https://covers.openlibrary.org/b/id/9320974-M.jpg	OL27933942M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8660	47	It	spa	\N	Vintage Español	2019	9780525566267	\N	https://covers.openlibrary.org/b/id/14655624-M.jpg	OL27732019M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8661	47	It	\N	\N	Me	2019	\N	6566	\N	OL27852203M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8662	47	It	\N	\N	Pocket Books	2016	9781501156687	1501156683	https://covers.openlibrary.org/b/id/8900355-M.jpg	OL27440341M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8663	47	It (ESO)	spa	\N	Plaza & Janes	1992	9788401498930	8401498937	https://covers.openlibrary.org/b/id/4901835-M.jpg	OL9112160M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8664	47	It	\N	\N	Scribner	2017	\N	1501175467	https://covers.openlibrary.org/b/id/8185010-M.jpg	OL26456630M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8665	47	It (Turtleback School & Library Binding Edition)	\N	\N	Turtleback Books	2016	9780606395748	0606395741	https://covers.openlibrary.org/b/id/8464051-M.jpg	OL26808367M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8666	47	It	ita	\N	Sperling	1990	9788878240810	8878240818	\N	OL13433047M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8667	47	it	\N	\N	i dot knoe	2000	\N	\N	\N	OL25747652M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8668	47	It (eso)	\N	\N	Orbis Fabris	1996	\N	844022060X	https://covers.openlibrary.org/b/id/7401158-M.jpg	OL25898016M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8669	47	It - Eso	\N	\N	Plaza & Janes Editores, S.A.	1996	9788401499968	8401499968	https://covers.openlibrary.org/b/id/5257139-M.jpg	OL13187527M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8670	47	It	\N	\N	Penguin Group	1986	\N	0670813028	https://covers.openlibrary.org/b/id/14642834-M.jpg	OL25629922M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8671	47	It (Eso)	\N	\N	Sudamericana	1999	9788401474637	8401474639	https://covers.openlibrary.org/b/id/4901269-M.jpg	OL9112099M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8672	47	es	deu	\N	Ullstein	2008	9783548263083	3548263089	https://covers.openlibrary.org/b/id/14652380-M.jpg	OL26741971M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8673	47	Ça	fra	\N	France Loisirs	1989	9782724244656	2724244656	https://covers.openlibrary.org/b/id/14656067-M.jpg	OL26630009M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8674	47	To	pol	\N	Wydawnictwo Albatros	2017	9788365781628	\N	https://covers.openlibrary.org/b/id/8155897-M.jpg	OL26439215M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8675	47	It	eng	\N	Hodder & Stoughton General Division	2017	9781473666948	1473666945	https://covers.openlibrary.org/b/id/8458562-M.jpg	OL26804388M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8676	47	IT	eng	\N	Scribner	2017	9781501175466	\N	https://covers.openlibrary.org/b/id/8573184-M.jpg	OL26880915M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8677	47	IT	eng	\N	Viking	1986	9780670813025	0670813028	https://covers.openlibrary.org/b/id/8569851-M.jpg	OL26875448M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8678	47	IT	\N	\N	New England library 	1992	\N	\N	\N	OL26698985M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8679	47	IT	\N	\N	Scribner and Simon & Schuster 	1986	\N	\N	\N	OL26402318M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8680	47	It	spa	\N	Plaza & Janes Editores, S.A.	1989	9788401322150	8401322154	https://covers.openlibrary.org/b/id/8179786-M.jpg	OL9111842M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8681	47	It	\N	\N	\N	1991	9784163128405	4163128409	https://covers.openlibrary.org/b/id/3286314-M.jpg	OL12358971M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8682	47	It	jpn	\N	Bungei Shunjū	1994	\N	4167148072	https://covers.openlibrary.org/b/id/13907126-M.jpg	OL22930298M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8683	47	It	spa	\N	Plaza & Janés	1987	\N	8401491029	https://covers.openlibrary.org/b/id/13537092-M.jpg	OL22951940M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8684	47	It	\N	\N	Perfection Learning Prebound	1987	9780812452242	0812452240	https://covers.openlibrary.org/b/id/4974430-M.jpg	OL9423240M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8685	47	It	eng	\N	Viking	1986	\N	0451169514	\N	OL20930867M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8686	47	It	\N	\N	Penguin Books Canada, Limited	1990	9782890192393	2890192393	\N	OL12646029M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8687	47	It	jpn	\N	Bungei Shunjū	1991	\N	4163128409	\N	OL22914403M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8688	47	It	eng	\N	Viking	1986	\N	0670813028	https://covers.openlibrary.org/b/id/14651711-M.jpg	OL2550667M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8689	47	It	eng	\N	Tandem Library	1999	9780833509451	0833509454	https://covers.openlibrary.org/b/id/634640-M.jpg	OL8188684M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8690	47	It	ita	\N	Sperling	1994	\N	8878240818	\N	OL22126037M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8691	47	It	eng	\N	Penguin USA, Inc.	2009	9781101137918	\N	https://covers.openlibrary.org/b/id/6417848-M.jpg	OL24268737M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8692	47	It	\N	\N	Trafalgar Square	1987	9780450411434	0450411435	https://covers.openlibrary.org/b/id/291381-M.jpg	OL7569442M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8693	47	It	\N	\N	Debolsillo	2004	9788484508564	8484508560	https://covers.openlibrary.org/b/id/14810124-M.jpg	OL9146135M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8694	47	It	eng	\N	Hodder and Stoughton	1986	\N	0340364777	\N	OL22361963M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8695	47	It	\N	\N	Penguin Audio	2010	9780142427873	014242787X	https://covers.openlibrary.org/b/id/6374546-M.jpg	OL24195636M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8696	47	It	eng	\N	Signet	1987	9780451149510	0451149513	\N	OL7572224M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8697	47	To	pol	\N	Zysk i S-ka Wydawnictwo	1997	\N	8371502532	\N	OL21792666M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8698	47	Es	deu	\N	Wilhelm Heyne Verlag	1987	\N	345302253X	\N	OL18962370M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8699	47	It	eng	\N	Cemetary Dance Publications	2011	9781587672705	\N	https://covers.openlibrary.org/b/id/7072555-M.jpg	OL25216530M	\N	2026-11-25 20:24:14.501916+00	2026-11-25 20:24:14.501916+00
8858	4	Die Ketzer des Wüstenplaneten. Der Wüstenplanet. Fünfter Roman.	deu	\N	Heyne	2001	9783453186873	3453186877	https://covers.openlibrary.org/b/id/1009424-M.jpg	OL9041235M	\N	2026-11-25 20:24:40.706618+00	2026-11-25 20:24:40.706618+00
8859	4	Dune, tome 4 	fra	\N	Robert Laffont	1997	9782221086759	2221086759	https://covers.openlibrary.org/b/id/975021-M.jpg	OL8865834M	\N	2026-11-25 20:24:40.706618+00	2026-11-25 20:24:40.706618+00
8860	4	Les hÃ©rÃ©tiques de Dune (French Edition)	\N	\N	POCKET	2005	9782266152518	2266152513	https://covers.openlibrary.org/b/id/8600654-M.jpg	OL27011540M	\N	2026-11-25 20:24:40.706618+00	2026-11-25 20:24:40.706618+00
8861	4	Herejes De Dune	\N	\N	Plaza & Janés	1995	9788401469350	840146935X	https://covers.openlibrary.org/b/id/10445932-M.jpg	OL30153137M	\N	2026-11-25 20:24:40.706618+00	2026-11-25 20:24:40.706618+00
8862	4	Herejes de Dune	\N	\N	Debolsillo	2019	9788497597319	8497597311	https://covers.openlibrary.org/b/id/11234413-M.jpg	OL32595872M	\N	2026-11-25 20:24:40.706618+00	2026-11-25 20:24:40.706618+00
8863	4	Heretics of Dune	\N	\N	Brand: Macmillan Audio	2008	9781427203168	1427203164	https://covers.openlibrary.org/b/id/9977187-M.jpg	OL28127233M	\N	2026-11-25 20:24:40.706618+00	2026-11-25 20:24:40.706618+00
8864	4	Heretics of Dune	eng	\N	Penguin Publishing Group	2020	9780593201763	\N	https://covers.openlibrary.org/b/id/14630302-M.jpg	OL29887746M	\N	2026-11-25 20:24:40.706618+00	2026-11-25 20:24:40.706618+00
8865	4	Heretics of Dune	\N	\N	Ace	1984	9780739446041	0739446045	https://covers.openlibrary.org/b/id/8763009-M.jpg	OL27281172M	\N	2026-11-25 20:24:40.706618+00	2026-11-25 20:24:40.706618+00
8866	4	Heretics of Dune	\N	\N	Berkley Books	1986	9780425087329	0425087328	https://covers.openlibrary.org/b/id/8652259-M.jpg	OL27040347M	\N	2026-11-25 20:24:40.706618+00	2026-11-25 20:24:40.706618+00
9740	9	Die Rückkehr des Königs	deu	\N	Klett-Cotta	2012	9783608939835	3608939830	https://covers.openlibrary.org/b/id/8143751-M.jpg	OL26432437M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
8867	4	Heretics of Dune	\N	\N	Ace	2019	9780593098264	0593098269	https://covers.openlibrary.org/b/id/8597984-M.jpg	OL27005944M	\N	2026-11-25 20:24:40.706618+00	2026-11-25 20:24:40.706618+00
8868	4	Herejes de Dune	\N	\N	Nuevas Ediciones de Bolsillo	2003	\N	2912298229	\N	OL13362151M	\N	2026-11-25 20:24:40.706618+00	2026-11-25 20:24:40.706618+00
8869	4	Eretiki Di︠u︡ny	rus	\N	AST	2002	9785170066254	5170066252	\N	OL23094694M	\N	2026-11-25 20:24:40.706618+00	2026-11-25 20:24:40.706618+00
8700	2	Dune Messiah	eng	\N	Hodder & Stoughton	2008	9780340960202	\N	\N	OL53238344M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8701	2	Dune Messiah	\N	\N	Turtleback	2019	9781690319856	\N	\N	OL61860842M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8702	2	Mesías de Dune / Dune Messiah	spa	\N	Penguin Random House Grupo Editorial	2024	9788466372015	\N	\N	OL50718767M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8703	2	Meshiaḥ ḥolit	heb	\N	Masadah	1981	\N	\N	\N	OL50425219M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8704	2	Dune Messiah	eng	\N	Orion Publishing Group, Limited	2007	9780575081536	\N	\N	OL48129865M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8705	2	Dune Messiah	eng	\N	Orion Publishing Group, Limited	2011	9780575104426	\N	\N	OL48138716M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8706	2	Dune Messiah	eng	\N	Orion Publishing Group, Limited	2023	9781399622912	\N	\N	OL49703351M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8707	2	Dune Messiah [ Berkley Medallion Edition, Sept. 1975 ]	\N	\N	Berkley Medallion	1975	\N	\N	\N	OL47790270M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8708	2	Cycle de Dune, Tome 2	\N	\N	Hodder & Stoughton	2005	9782266157476	2266157477	\N	OL47738451M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8709	2	Mesjasz Diuny	\N	\N	Rebis	2018	9788373017252	8373017259	https://covers.openlibrary.org/b/id/13944180-M.jpg	OL47353014M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8710	2	Kroniki Diuny. Tom 2. Mesjasz Diuny	\N	\N	Rebis	2020	9788381880824	8381880823	https://covers.openlibrary.org/b/id/13944172-M.jpg	OL47353010M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8711	2	Mesjasz Diuny	pol	\N	Dom wydawniczy Rebis	2020	9788381887540	\N	https://covers.openlibrary.org/b/id/14563316-M.jpg	OL50530386M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8712	2	El messies de Dune	spa	\N	Mai Més	2023	9788412614404	8412614402	https://covers.openlibrary.org/b/id/13934483-M.jpg	OL47344989M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8713	2	book in Ukrainian. Mesiya Dyuny / Месія Дюни / Dune Messiah  / World science fiction	\N	\N	«Книжный Клуб «Клуб Семейного Досуга»	2018	9786171249646	6171249645	https://covers.openlibrary.org/b/id/13769308-M.jpg	OL47304814M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8714	2	El mesías de Dune	\N	\N	Nova	2024	9788418037672	8418037679	\N	OL47142104M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8715	2	El mesías de Dune	\N	\N	Debolsillo	2021	9788466356961	8466356967	https://covers.openlibrary.org/b/id/14060987-M.jpg	OL47456632M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8716	2	Duin Messias	\N	\N	Samenw. uitgeverijen Meulenhoff Boekerij	1999	9789029041720	9029041722	\N	OL45929991M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8717	2	Cứu tinh xứ cát	vie	\N	Văn học	2011	\N	\N	\N	OL45367534M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8718	2	Dune - tome 2 Le messie de Dune	fra	\N	POCKET	2021	9782266320498	2266320491	https://covers.openlibrary.org/b/id/13115944-M.jpg	OL44917450M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8719	2	Dune Messiah - N1847	\N	\N	Berkely Medallion Book	1969	\N	\N	\N	OL43350359M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8720	2	Dune Messiah	eng	\N	Penguin Publishing Group	2019	9781804228036	\N	\N	OL38090990M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8721	2	Dune Messiah	eng	\N	Penguin Publishing Group	2023	9780593548448	\N	https://covers.openlibrary.org/b/id/14613344-M.jpg	OL39432757M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8722	2	Messias de Duna	\N	\N	Aleph	2012	9788576571162	8576571161	https://covers.openlibrary.org/b/id/12476637-M.jpg	OL35733966M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8723	2	Dune - tome 2 Le Messie de Dune - NE 2021	fra	\N	ROBERT LAFFONT	2021	9782221252307	2221252306	https://covers.openlibrary.org/b/id/12371348-M.jpg	OL35666321M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8724	2	Dune Mesihi	\N	\N	Kabalci Yayinevi	2017	9789759971298	9759971291	https://covers.openlibrary.org/b/id/12355429-M.jpg	OL35648532M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8725	2	Mesías de Dune / Dune Messiah	spa	\N	Penguin Random House Grupo Editorial	2021	9786073197267	\N	\N	OL34947634M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8726	2	Dune Tome 2 (French Edition)	\N	\N	POCKET	2007	9782266173261	226617326X	https://covers.openlibrary.org/b/id/8742566-M.jpg	OL27106558M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8727	2	Le Cycle De Dune Tome II	\N	\N	Pocket	1972	9782266026642	226602664X	https://covers.openlibrary.org/b/id/8366709-M.jpg	OL26706261M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8728	2	Dune Messiah	eng	\N	New English Library	1978	\N	0450050882	https://covers.openlibrary.org/b/id/14816227-M.jpg	OL25432140M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8729	2	Mesjasz Diuny	pol	\N	Phantom Press International	1992	\N	8385432256	\N	OL19610838M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8730	2	El mesias de Dune	spa	\N	Plaza & Janes Editores	1995	\N	8401469325	\N	OL18263798M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8731	2	Messii︠a︡ Di︠u︡ny ; Deti Di︠u︡ny	rus	\N	AST	1999	\N	5237041485	https://covers.openlibrary.org/b/id/7979797-M.jpg	OL23044495M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8732	2	Dune Messiah	eng	\N	Berkley Books	1975	9780425074985	0425074986	https://covers.openlibrary.org/b/id/6781122-M.jpg	OL24669863M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8733	2	Dune Messiah	eng	\N	Berkley	1975	9780425029527	0425029522	\N	OL7500647M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8734	2	Dune Messiah	eng	\N	Berkley	1982	9780425061732	0425061736	https://covers.openlibrary.org/b/id/13456025-M.jpg	OL7501659M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8735	2	Dune Messiah	eng	\N	Berkley	1979	9780425043462	0425043460	\N	OL7501093M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8736	2	Dune Messiah	eng	\N	Gollancz	1984	\N	0575035412	https://covers.openlibrary.org/b/id/14816231-M.jpg	OL21657939M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8737	2	Dune Messiah	eng	\N	G.P. Putnam's Sons	1969	9780399102264	0399102264	https://covers.openlibrary.org/b/id/14816220-M.jpg	OL18715561M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8738	2	Dune Messiah	eng	\N	Berkley	1981	9780425055038	0425055035	https://covers.openlibrary.org/b/id/14816222-M.jpg	OL7501473M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8739	2	Dune Messiah	eng	\N	Penguin Group USA, Inc.	2008	9781429598910	\N	https://covers.openlibrary.org/b/id/6396126-M.jpg	OL24248845M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8740	2	Dune messiah	eng	\N	Berkley Pub. Co.	1975	\N	\N	https://covers.openlibrary.org/b/id/6493206-M.jpg	OL24226501M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8741	2	Dune Messiah	eng	\N	Gollancz	1971	\N	0575006684	https://covers.openlibrary.org/b/id/14816228-M.jpg	OL15068254M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8742	2	Dune messiah	eng	\N	New English Library	1977	\N	0450032663	https://covers.openlibrary.org/b/id/10194699-M.jpg	OL15048199M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8743	2	Dune messiah	eng	\N	Berkley Books	1980	\N	\N	https://covers.openlibrary.org/b/id/14816214-M.jpg	OL23744116M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8744	2	Dune Messiah	\N	\N	CORONET (HODD)	1972	9780450012297	0450012298	https://covers.openlibrary.org/b/id/13783766-M.jpg	OL7569172M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8745	2	Dune messiah	eng	\N	New English Library	1978	\N	0450041565	https://covers.openlibrary.org/b/id/10201220-M.jpg	OL15048523M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8746	2	Dune Messiah	eng	\N	New English Library	1972	\N	0450050882	https://covers.openlibrary.org/b/id/9256650-M.jpg	OL15048950M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8747	2	Dune messiah	eng	\N	Berkley Pub. Co.	1975	\N	\N	https://covers.openlibrary.org/b/id/6493199-M.jpg	OL24205739M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8748	2	Dune Messiah	eng	\N	New English Library	1975	\N	0450022854	https://covers.openlibrary.org/b/id/14816225-M.jpg	OL22078380M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8749	2	Dune Messiah	eng	\N	Ace Books	2008	9780441015610	\N	https://covers.openlibrary.org/b/id/14816224-M.jpg	OL24057989M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8750	2	Dune messiah.	eng	\N	Berkley Publishing	1975	\N	0425043460	https://covers.openlibrary.org/b/id/14044072-M.jpg	OL21405822M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8751	2	DUNE MESSIAH	\N	\N	\N	\N	\N	\N	https://covers.openlibrary.org/b/id/14816218-M.jpg	OL16181125M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8752	2	Dune Messiah.	eng	\N	New English Library	1982	\N	0450053083	https://covers.openlibrary.org/b/id/13909803-M.jpg	OL15049102M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8753	2	Dune Messiah	eng	\N	Gollancz	1984	\N	0575035412	https://covers.openlibrary.org/b/id/14816229-M.jpg	OL22645961M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8754	2	Dune Messiah	eng	\N	Audio Renaissance	2007	9781427202369	1427202362	https://covers.openlibrary.org/b/id/1847178-M.jpg	OL8536875M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8755	2	Dune Messiah	eng	\N	Berkley	1974	9780425026014	0425026019	\N	OL7500565M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8756	2	Dune Messiah	\N	\N	Hodder & Stoughton Ltd	1972	9780450022852	0450022854	https://covers.openlibrary.org/b/id/291312-M.jpg	OL7569219M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8757	2	Dune Messiah	eng	\N	Berkley	1977	9780425035856	0425035859	https://covers.openlibrary.org/b/id/9531663-M.jpg	OL7500836M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8758	2	Dune Messiah	eng	\N	Putnam	1969	\N	\N	https://covers.openlibrary.org/b/id/15247497-M.jpg	OL4571643M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8759	2	Dune Messiah	eng	\N	Putnam	1969	\N	\N	https://covers.openlibrary.org/b/id/15208095-M.jpg	OL18143783M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8760	2	Dune Messiah	eng	\N	Berkley	1978	9780425039304	0425039307	https://covers.openlibrary.org/b/id/14816221-M.jpg	OL7500957M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8761	2	Der Herr des Wüstenplaneten	deu	\N	Wilhelm Heyne Verlag	2001	9783453186842	3453186842	https://covers.openlibrary.org/b/id/6390608-M.jpg	OL24235829M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8762	2	Dune Messiah	eng	\N	Berkeley	1970	\N	0425018474	https://covers.openlibrary.org/b/id/9342782-M.jpg	OL19824519M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8763	2	Dune Messiah	eng	\N	Berkley	1980	9780425043790	0425043797	\N	OL7501104M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8764	2	Dune messiah	eng	\N	Berkley Pub. Co.	1975	\N	\N	https://covers.openlibrary.org/b/id/14816215-M.jpg	OL17721719M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8765	2	Messiya Dyuny. Deti Dyuny	\N	\N	AST	1999	9785237041484	5237041485	https://covers.openlibrary.org/b/id/13333860-M.jpg	OL12543891M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8766	2	Der Herr des Wüstenplaneten	deu	\N	Wilhelm Heyne Verlag	1985	\N	3453301439	https://covers.openlibrary.org/b/id/10861434-M.jpg	OL32216370M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8767	2	Dune Messiah	\N	\N	Orion Publishing Co	1984	9780575035416	0575035412	https://covers.openlibrary.org/b/id/14816230-M.jpg	OL7877926M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8768	2	El Mesias De Dune/Dune Messiah	spa	\N	Acervo	1976	9788470022005	8470022008	https://covers.openlibrary.org/b/id/14550930-M.jpg	OL13276875M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8769	2	El Mesias De Dune / Dune Messiah	spa	\N	Debolsillo	2003	9788497596671	8497596676	https://covers.openlibrary.org/b/id/5277575-M.jpg	OL13362129M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8770	2	Dune Messiah (Dune Chronicles, Book 2)	eng	\N	Tandem Library	1999	9780808520733	0808520733	https://covers.openlibrary.org/b/id/592156-M.jpg	OL7973614M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8771	2	Dune Messiah (Dune Chronicles, Book 2)	\N	\N	Berkley Trade	1982	9780425053140	0425053148	https://covers.openlibrary.org/b/id/14027304-M.jpg	OL7501409M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8772	2	Dune Messiah	eng	\N	Ace	1987	9780441172696	0441172695	https://covers.openlibrary.org/b/id/15209757-M.jpg	OL7525229M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8773	2	Dune Messiah (Dune Chronicles, Book 2)	eng	\N	Berkley	1983	9780425064368	0425064360	https://covers.openlibrary.org/b/id/14605701-M.jpg	OL7501756M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8774	2	Dune Messiah (Dune Chronicles, Book 2)	\N	\N	Berkley	1984	9780425079010	0425079015	\N	OL7502159M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8775	2	Dune Messiah (Dune Chronicles, Book 2)	eng	\N	Books On Tape	1997	9780736640183	0736640185	https://covers.openlibrary.org/b/id/1365104-M.jpg	OL9537940M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8776	2	Dune Messiah (Dune Chronicles, Book 2)	\N	\N	Berkley	1984	9780425071809	0425071804	\N	OL7501962M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8777	2	Dune Messiah	und	\N	\N	\N	\N	\N	https://covers.openlibrary.org/b/id/8450071-M.jpg	OL20042704M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8778	2	Messie de dune	\N	\N	Editions Robert Laffront, S.A.	1969	9782266008655	226600865X	https://covers.openlibrary.org/b/id/8771464-M.jpg	OL27292024M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8779	2	Le Cycle de Dune Tome 2/Le Messie de Dune	\N	\N	Pocket	2012	9782266235815	2266235818	https://covers.openlibrary.org/b/id/10328275-M.jpg	OL28639494M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8780	2	Dune Messiah	eng	\N	Penguin Publishing Group	2020	9780593201732	\N	https://covers.openlibrary.org/b/id/15126592-M.jpg	OL29887750M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8781	2	Dune Messiah	eng	\N	Hodder & Stoughton	2017	9781473655324	\N	https://covers.openlibrary.org/b/id/11422534-M.jpg	OL29328221M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8782	2	Dune Messiah	eng	\N	Ace	2019	9780593098233	0593098234	https://covers.openlibrary.org/b/id/14322962-M.jpg	OL28914400M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8783	2	Der Herr des Wüstenplaneten	\N	\N	Heyne Verlag	2019	9783453319547	3453319540	https://covers.openlibrary.org/b/id/11290920-M.jpg	OL32663676M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8784	2	Dune mesihi	tur	\N	Sarmal Yayinevi	1997	\N	975576030X	\N	OL17489450M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8785	2	Dune Mesihi	\N	\N	Ithaki Yayinlari	2016	9786053755319	6053755311	https://covers.openlibrary.org/b/id/10849793-M.jpg	OL32200621M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8786	2	Le Cycle de Dune, tome 3 	fra	\N	Pocket	1980	9782266027250	2266027255	https://covers.openlibrary.org/b/id/979507-M.jpg	OL8889705M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8787	2	Cycle de Dune, Tome 3 (French Edition)	\N	\N	POCKET	2005	9782266154512	2266154516	https://covers.openlibrary.org/b/id/8376882-M.jpg	OL26719093M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8788	2	Le Messie de Dune	fra	\N	Robert Laffont	1975	9782221001646	2221001648	https://covers.openlibrary.org/b/id/974774-M.jpg	OL8865577M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8789	2	Duin Messias	nld	\N	Meulenhoff, Amsterdam	1985	\N	\N	https://covers.openlibrary.org/b/id/14369929-M.jpg	OL48591037M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8790	2	Le Messie de Dune	fra	\N	Robert Laffont	2021	9782221255728	2221255720	https://covers.openlibrary.org/b/id/12377554-M.jpg	OL35677936M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8791	2	Le Messie de Dune	fra	\N	Pocket	2023	9782266342001	\N	https://covers.openlibrary.org/b/id/14896401-M.jpg	OL58638876M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8792	2	Messias de Duna	por	BR	Editora Aleph	2017	9788576573821	8576573822	https://covers.openlibrary.org/b/id/10376632-M.jpg	OL29157219M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8793	2	Le Cycle de Dune, tome 2	fra	\N	Pocket	2001	9782266114035	2266114034	https://covers.openlibrary.org/b/id/980253-M.jpg	OL8890326M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8794	2	Le Cycle de Dune, tome 2	fra	\N	PRESSES-POCKET	1985	\N	2266008560	https://covers.openlibrary.org/b/id/7394419-M.jpg	OL25425930M	\N	2026-11-25 20:24:34.222304+00	2026-11-25 20:24:34.222304+00
8870	4	The Heretics of Dune	eng	\N	Gollancz	2003	9780575074897	0575074892	https://covers.openlibrary.org/b/id/380218-M.jpg	OL7878771M	\N	2026-11-25 20:24:40.706618+00	2026-11-25 20:24:40.706618+00
8871	4	Heretics of Dune	eng	\N	Tandem Library	1987	9780613997249	0613997247	https://covers.openlibrary.org/b/id/14816248-M.jpg	OL7602572M	\N	2026-11-25 20:24:40.706618+00	2026-11-25 20:24:40.706618+00
8872	4	Heretics of Dune	eng	\N	Berkley Books	1985	\N	0425076695	https://covers.openlibrary.org/b/id/14612741-M.jpg	OL15569270M	\N	2026-11-25 20:24:40.706618+00	2026-11-25 20:24:40.706618+00
9741	9	The Return of the King	eng	\N	Houghton Miffin Harcourt	1994	9780544449749	0544449746	https://covers.openlibrary.org/b/id/8143753-M.jpg	OL26432439M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9742	9	Die Rückkehr des Königs	deu	\N	Klett-Cotta	1972	9783608107159	3608107150	https://covers.openlibrary.org/b/id/8143754-M.jpg	OL26432440M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9743	9	דער צוריקקער פֿון דעם קיניג	yid	\N	Createspace	2016	9781517654474	1517654475	https://covers.openlibrary.org/b/id/8143755-M.jpg	OL26432442M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9744	9	Le Retour du Roi	fra	\N	Christian Bourgois éditeur	2016	9782267032192	2267032198	https://covers.openlibrary.org/b/id/8143758-M.jpg	OL26432445M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9745	9	The Return of the King	ind	\N	Gramedia Pustaka Utama	2016	9786020332284	6020332284	https://covers.openlibrary.org/b/id/8143759-M.jpg	OL26432446M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9746	9	The Return of the King	eng	\N	Ballantine Books	1969	\N	\N	https://covers.openlibrary.org/b/id/8259272-M.jpg	OL26432448M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9747	9	The Return of the King	eng	\N	HarperCollins	1999	\N	00071233809	\N	OL20140355M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9748	9	The Return of the King	eng	\N	Ballantine Books	1966	\N	\N	https://covers.openlibrary.org/b/id/8302846-M.jpg	OL26435280M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9749	9	The Return of the King	eng	\N	Methuen Publications	1977	9780458907700	0458907707	https://covers.openlibrary.org/b/id/12530135-M.jpg	OL7591511M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9750	9	The Lord of the Rings	eng	\N	\N	\N	9780007702756	0007702752	https://covers.openlibrary.org/b/id/13179392-M.jpg	OL9924431M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9751	9	The Return of the King	eng	\N	Houghton Mifflin Company	2003	\N	0618346279	https://covers.openlibrary.org/b/id/8574450-M.jpg	OL26889866M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9752	9	The Return of the King	eng	\N	Ballantine Books	1973	9780345235114	0345235118	https://covers.openlibrary.org/b/id/15254149-M.jpg	OL27037517M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9753	9	The Return of the King: Being the Third Part of the Lord of the Rings	\N	\N	Mariner Books	2012	9780547928197	054792819X	https://covers.openlibrary.org/b/id/8598377-M.jpg	OL27006595M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9754	9	The Return of the King	\N	\N	HarperCollins	2012	9780007488346	0007488343	https://covers.openlibrary.org/b/id/8647874-M.jpg	OL27037937M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9755	9	The Return of the King	\N	\N	HarperCollins	2013	9780007522927	0007522924	https://covers.openlibrary.org/b/id/8651965-M.jpg	OL27040220M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9756	9	Le retour du roi	fra	\N	Pocket	1979	9782266026574	2266026577	https://covers.openlibrary.org/b/id/8647603-M.jpg	OL27037793M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9757	9	Le seigneur des Anneaux Livre V Le retour du Roi	\N	\N	Editions Gallimard	1988	9782070334834	207033483X	\N	OL27037068M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9758	9	Le seigneur des anneaux, tome 3 - Le Retour du Roi	\N	\N	Le Livre de Poche	1977	9782253013785	2253013781	https://covers.openlibrary.org/b/id/8647605-M.jpg	OL27037795M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9759	9	Powrót Króla	pol	\N	Wydawnictwo Amber	2009	9788324133086	\N	https://covers.openlibrary.org/b/id/8457569-M.jpg	OL26801964M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9760	9	El Señor de los Anillos 3, El retorno del rey (Senor de los Anillos) (Spanish Edition)	\N	\N	Planeta Publishing	2011	9788445077511	8445077511	https://covers.openlibrary.org/b/id/8476543-M.jpg	OL26817102M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9761	9	The Return of the King	zho	\N	Yilin Press	2014	9787544730426	7544730425	https://covers.openlibrary.org/b/id/9158664-M.jpg	OL26846658M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9762	9	Der Herr der Ringe 3. Die Rückkehr des Königs	\N	\N	Hobbit Presse/Klett-Cotta	1979	9783129082003	312908200X	https://covers.openlibrary.org/b/id/8653741-M.jpg	OL27041058M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9763	9	The Return of the King	\N	\N	HARPER COLLINS	1950	9780008108311	0008108315	https://covers.openlibrary.org/b/id/8653331-M.jpg	OL27040882M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9764	9	Возвращение короля	rus	\N	ĖKSMO	1999	9785040019014	5040019017	https://covers.openlibrary.org/b/id/9293483-M.jpg	OL9039627M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9765	9	The Return of the King	eng	\N	Houghton Mifflin Company	1993	9780395489307	039548930X	https://covers.openlibrary.org/b/id/9293882-M.jpg	OL27925417M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9766	9	Powrot krola	pol	\N	Literackie	2004	\N	\N	\N	OL16418963M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9767	9	Chúa tể những chiếc nhẫn	vie	\N	Nhà xuất bản Văn Học	2014	\N	\N	\N	OL26938454M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9768	9	Chúa tể những chiếc nhẫn	vie	\N	Nhà xuất bản Văn Học	2013	\N	\N	\N	OL27192462M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9769	9	Chúa tể những chiếc nhẫn	vie	\N	Nhà xuất bản Văn Học	2014	\N	\N	\N	OL26938453M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9770	9	Mo jie san bu qu	zho	\N	Lian jing chu ban shi ye gu fen you xian gong si	2012	9789570841022	9570841028	\N	OL27194457M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9771	9	The Return of the King	eng	\N	HarperCollins	2005	9780007228409	0007228406	https://covers.openlibrary.org/b/id/9306365-M.jpg	OL27929085M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9772	9	The Return of the King	eng	\N	Houghton Mifflin	1956	\N	\N	https://covers.openlibrary.org/b/id/10523169-M.jpg	OL27928012M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9773	9	The Return of the King	spa	\N	Texto Online	2011	\N	\N	\N	OL28162213M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9774	9	The Return of the King	\N	\N	\N	2008	9781439527313	1439527318	https://covers.openlibrary.org/b/id/10126340-M.jpg	OL28190235M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9775	9	El señor de los anillos III : el retorno del rey	\N	\N	Minotauro	2014	9789584246820	\N	https://covers.openlibrary.org/b/id/8065575-M.jpg	OL26375761M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9776	9	El Retorno Del Rey - Señor De Los Anillos Iii	\N	\N	MINOTAURO	2007	9789505471164	9505471165	https://covers.openlibrary.org/b/id/10291436-M.jpg	OL28343068M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9777	9	Die Rückkehr des Königs. Der Herr der Ringe 03.	\N	\N	\N	2000	9783608952148	3608952144	https://covers.openlibrary.org/b/id/10294404-M.jpg	OL28346254M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9778	9	The Return of the King	eng	\N	Mariner Books | Houghton Mifflin Harcourt	2020	9780358380252	0358380251	https://covers.openlibrary.org/b/id/13092779-M.jpg	OL29848983M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9779	9	Return of the King	eng	\N	HarperCollins Publishers Limited	2005	9780007203567	\N	https://covers.openlibrary.org/b/id/12397231-M.jpg	OL28430633M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9780	9	The Return of the King	eng	\N	HarperCollins Publishers Limited	2020	9780008376147	\N	https://covers.openlibrary.org/b/id/15246805-M.jpg	OL29486344M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9781	9	The Return of the King	\N	\N	Allen & Unwin	1979	9780048231574	0048231576	https://covers.openlibrary.org/b/id/10289928-M.jpg	OL28341598M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9782	9	Pán Prsteňov	slk	\N	Slovart	\N	9788071456087	807145608X	https://covers.openlibrary.org/b/id/10587046-M.jpg	OL31905946M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9783	9	The Return of the King	eng	\N	HarperCollins Publishers	2005	9780007203604	0007203608	https://covers.openlibrary.org/b/id/14625521-M.jpg	OL31906113M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9784	9	The Return of the King	eng	\N	Collins	2001	9780007680832	000768083X	https://covers.openlibrary.org/b/id/10978221-M.jpg	OL32349083M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9785	9	The Return of the King	bul	\N	Bard	2002	\N	9545853484	https://covers.openlibrary.org/b/id/11223001-M.jpg	OL32582183M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9786	9	The Return of the King	\N	\N	HarperCollins	2008	9780007269723	0007269722	https://covers.openlibrary.org/b/id/10548324-M.jpg	OL31867474M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9787	9	The Return of the King	\N	\N	Brand: Listening Library	2002	9780807209103	0807209104	https://covers.openlibrary.org/b/id/11280927-M.jpg	OL32651755M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9788	9	The Lord of the Rings Return of the King	\N	\N	Harpercollins Pub Ltd	2002	9780007136575	0007136579	https://covers.openlibrary.org/b/id/11273693-M.jpg	OL32642284M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9789	9	The Return of the King	\N	\N	Highbridge Audio and Blackstone Publishing	2021	9781665171045	1665171049	https://covers.openlibrary.org/b/id/12061907-M.jpg	OL35034741M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9790	9	Return of the King	eng	\N	Houghton Mifflin Harcourt Publishing Company	2004	9781484493038	\N	\N	OL34110776M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9791	9	Le Seigneur des anneaux	fra	\N	Christian Bourgois editeur	1986	9782266017619	2266017616	https://covers.openlibrary.org/b/id/10779212-M.jpg	OL32118833M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9792	9	Der Herr der Ringe	deu	\N	Klett-Cotta	2002	\N	3608955380	https://covers.openlibrary.org/b/id/13133758-M.jpg	OL45499132M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9793	9	Der Herr der Ringe	deu	\N	Klett-Cotta	2002	\N	3608955380	https://covers.openlibrary.org/b/id/13133761-M.jpg	OL45499373M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9794	9	Der Herr der Ringe	deu	\N	Klett-Cotta	2002	\N	3608955380	https://covers.openlibrary.org/b/id/13133760-M.jpg	OL45499378M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9795	9	Le Seigneur des Anneaux	fra	\N	Gallimard Jeunesse	2007	9782070612901	2070612902	https://covers.openlibrary.org/b/id/15119670-M.jpg	OL40223115M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9796	9	Die Rückkehr des Königs	deu	\N	Klett-Cotta	2002	\N	3608955380	https://covers.openlibrary.org/b/id/14417850-M.jpg	OL49359428M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9797	9	Lord of the Rings	kor	\N	Siat Publishing Company	2010	9788956371832	\N	https://covers.openlibrary.org/b/id/13183063-M.jpg	OL39632748M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9798	9	The Return of the King	eng	\N	Houghton Mifflin Company	2002	\N	0618260552	https://covers.openlibrary.org/b/id/14624622-M.jpg	OL51688469M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9799	9	The Return of the King	eng	\N	Ballantine Books	1973	\N	0345253450	https://covers.openlibrary.org/b/id/14624627-M.jpg	OL51688496M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9800	9	The Return of the King	eng	\N	Ballantine Books	1975	\N	0345247868	https://covers.openlibrary.org/b/id/14624629-M.jpg	OL51688508M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9801	9	The Lord of the Rings	eng	\N	Unwin Books	1974	\N	0048231142	\N	OL21991879M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9802	9	The Return of the King	eng	\N	Unwin Paperbacks	1977	\N	0048231142	https://covers.openlibrary.org/b/id/14624670-M.jpg	OL51688720M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9803	9	O retorno do rei	por	BR	Harper Collins	2019	9788595084773	\N	https://covers.openlibrary.org/b/id/14625722-M.jpg	OL51693965M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9804	9	The Return of the King	eng	\N	Grafton	1991	\N	0261102370	https://covers.openlibrary.org/b/id/14625948-M.jpg	OL51694858M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9805	9	The Return of the King	eng	\N	Unwin Paperbacks	1977	\N	0048231142	https://covers.openlibrary.org/b/id/14625960-M.jpg	OL51694882M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9806	9	The Return of the King	eng	\N	Houghton Mifflin Company	1967	\N	\N	https://covers.openlibrary.org/b/id/14626575-M.jpg	OL51695177M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9807	9	The Return of the King	eng	\N	Ballantine Books	1966	\N	\N	https://covers.openlibrary.org/b/id/14626149-M.jpg	OL51695375M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9808	9	The Return of the King	eng	\N	George Allen & Unwin Ltd	1963	\N	\N	https://covers.openlibrary.org/b/id/14626154-M.jpg	OL51695395M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9809	9	The Return of the King	eng	\N	Ballantine Books	1970	\N	\N	https://covers.openlibrary.org/b/id/14626182-M.jpg	OL51695454M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9810	9	The Return of the King	eng	\N	Ballantine Books	1973	\N	0345235118	https://covers.openlibrary.org/b/id/14626613-M.jpg	OL51696429M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9811	9	Powrót Króla	pol	\N	Zysk i S-ka	1997	9788371502439	8371502435	https://covers.openlibrary.org/b/id/10587099-M.jpg	OL31905992M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9812	9	Le Retour du Roi	fra	\N	Gallimard	1994	9782070501427	2070501426	https://covers.openlibrary.org/b/id/8461417-M.jpg	OL8839922M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9813	9	El Señor de los Anillos	spa	\N	Minotauro	2011	9786070706110	\N	https://covers.openlibrary.org/b/id/14625523-M.jpg	OL51693341M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9814	9	The Return of the King	eng	\N	Ballantine Books	1976	9780345253453	0345253450	https://covers.openlibrary.org/b/id/14624452-M.jpg	OL10682515M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9815	9	Le seigneur des anneaux: Tome III	fra	\N	Christian Bourgois Editeur	2003	9782266132398	\N	https://covers.openlibrary.org/b/id/14627453-M.jpg	OL51711000M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9816	9	The Return of the King	eng	\N	Houghton Mifflin Company	1978	\N	0395272211	https://covers.openlibrary.org/b/id/14627534-M.jpg	OL51711365M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9817	9	The Return of the King	eng	\N	Ballantine Books	1986	\N	0345339738	https://covers.openlibrary.org/b/id/14627081-M.jpg	OL51708836M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9818	9	The Return of the King	eng	\N	Ballantine Books	1973	\N	0345235118	https://covers.openlibrary.org/b/id/14626617-M.jpg	OL51696438M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9819	9	The Return of the King	eng	\N	FollettBound	1994	9780329278052	\N	https://covers.openlibrary.org/b/id/14626618-M.jpg	OL51696448M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9820	9	The Return of the King	eng	\N	Houghton Mifflin Company	\N	\N	\N	https://covers.openlibrary.org/b/id/14627062-M.jpg	OL51708706M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9821	9	The Return of the King	eng	\N	Ballantine Books	1966	\N	\N	https://covers.openlibrary.org/b/id/14626665-M.jpg	OL51696749M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9822	9	The Return of the King	eng	\N	Ballantine Books	1970	\N	\N	https://covers.openlibrary.org/b/id/14627071-M.jpg	OL51708779M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9823	9	The Return of the King	eng	\N	Guild Publishing	1988	\N	\N	https://covers.openlibrary.org/b/id/14627604-M.jpg	OL51711638M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9824	9	Die Koning Keer Terug	afr	\N	Protea Boekhuis	2020	9781485309772	\N	https://covers.openlibrary.org/b/id/14627044-M.jpg	OL29532500M	\N	2026-11-25 20:25:36.197718+00	2026-11-25 20:25:36.197718+00
9825	13	Season of Storms	eng	\N	Orion Publishing Group, Limited	2023	9781399611138	\N	\N	OL39560386M	\N	2026-11-25 20:25:38.743521+00	2026-11-25 20:25:38.743521+00
9826	13	Season of Storms	eng	\N	Orion Publishing Group, Limited	2023	9781399611466	\N	\N	OL46568016M	\N	2026-11-25 20:25:38.743521+00	2026-11-25 20:25:38.743521+00
9827	13	Season of Storms	eng	\N	Orion Publishing Group, Limited	2019	9781473218086	\N	\N	OL46573316M	\N	2026-11-25 20:25:38.743521+00	2026-11-25 20:25:38.743521+00
9828	13	Season of Storms	\N	\N	Hachette Book Group	2018	9781549172250	1549172255	https://covers.openlibrary.org/b/id/10701307-M.jpg	OL32033824M	\N	2026-11-25 20:25:38.743521+00	2026-11-25 20:25:38.743521+00
9829	13	Season of Storms	eng	\N	Orbit	2018	9780316441612	\N	\N	OL34049187M	\N	2026-11-25 20:25:38.743521+00	2026-11-25 20:25:38.743521+00
9830	13	Season of storms	eng	\N	ORBIT	2018	9780316441629	0316441627	https://covers.openlibrary.org/b/id/15213436-M.jpg	OL27970085M	\N	2026-11-25 20:25:38.743521+00	2026-11-25 20:25:38.743521+00
9831	13	Season of Storms	eng	\N	Orion Publishing Group, Limited	2020	9781473231139	\N	https://covers.openlibrary.org/b/id/15213435-M.jpg	OL29485064M	\N	2026-11-25 20:25:38.743521+00	2026-11-25 20:25:38.743521+00
9832	13	Season of Storms	eng	\N	Orbit	2022	9780316453165	\N	https://covers.openlibrary.org/b/id/15235393-M.jpg	OL38065815M	\N	2026-11-25 20:25:38.743521+00	2026-11-25 20:25:38.743521+00
9833	13	Season of Storms	eng	\N	Orbit	2022	9780316457231	\N	https://covers.openlibrary.org/b/id/13886663-M.jpg	OL38153655M	\N	2026-11-25 20:25:38.743521+00	2026-11-25 20:25:38.743521+00
9834	13	Season of storms	eng	\N	\N	2018	9780316441636	0316441635	\N	OL26956791M	\N	2026-11-25 20:25:38.743521+00	2026-11-25 20:25:38.743521+00
9835	13	Sezon Burz	pol	\N	SuperNOWA	2013	9788375780598	\N	https://covers.openlibrary.org/b/id/8457629-M.jpg	OL26802123M	\N	2026-11-25 20:25:38.743521+00	2026-11-25 20:25:38.743521+00
9836	13	Season of Storms	eng	\N	Golancz	2013	9781473218079	\N	https://covers.openlibrary.org/b/id/12848713-M.jpg	OL26619671M	\N	2026-11-25 20:25:38.743521+00	2026-11-25 20:25:38.743521+00
9837	13	La saison des orages	fra	\N	Bragelonne	2019	9791028109301	\N	\N	OL36697490M	\N	2026-11-25 20:25:38.743521+00	2026-11-25 20:25:38.743521+00
9838	13	La stagione delle tempeste	ita	\N	Nord	2016	9788842928539	\N	\N	OL36697514M	\N	2026-11-25 20:25:38.743521+00	2026-11-25 20:25:38.743521+00
9839	13	Zeit des Sturms	deu	\N	Deutscher Taschenbuch Verlag	2015	9783423260572	3423260572	https://covers.openlibrary.org/b/id/10505014-M.jpg	OL30883218M	\N	2026-11-25 20:25:38.743521+00	2026-11-25 20:25:38.743521+00
9840	13	Zeit des Sturms	deu	\N	Deutscher Taschenbuch Verlag	2020	9783423262668	\N	https://covers.openlibrary.org/b/id/13759324-M.jpg	OL47296575M	\N	2026-11-25 20:25:38.743521+00	2026-11-25 20:25:38.743521+00
9841	13	Bouřková sezóna	ces	\N	Leonardo	2022	9788074770838	\N	https://covers.openlibrary.org/b/id/14548213-M.jpg	OL49953075M	\N	2026-11-25 20:25:38.743521+00	2026-11-25 20:25:38.743521+00
9842	13	Sezon burz	pol	\N	SuperNOWA	2014	9788375780888	\N	https://covers.openlibrary.org/b/id/14843295-M.jpg	OL57710004M	\N	2026-11-25 20:25:38.743521+00	2026-11-25 20:25:38.743521+00
9843	14	Tiempo de odio	\N	\N	Alamut	2016	9788498891072	8498891078	https://covers.openlibrary.org/b/id/12325265-M.jpg	OL35618086M	\N	2026-11-25 20:25:43.5082+00	2026-11-25 20:25:43.5082+00
9844	14	Tiempo de odio	\N	\N	Bibliópolis	2011	9788415157069	8415157061	https://covers.openlibrary.org/b/id/13724060-M.jpg	OL47269959M	\N	2026-11-25 20:25:43.5082+00	2026-11-25 20:25:43.5082+00
9845	14	Tiempo de odio	spa	\N	Bibliópolis	2004	9788496173101	8496173100	https://covers.openlibrary.org/b/id/8741591-M.jpg	OL27104610M	\N	2026-11-25 20:25:43.5082+00	2026-11-25 20:25:43.5082+00
9846	14	Tiempo de odio	\N	\N	Alamut	2008	9788498890112	\N	https://covers.openlibrary.org/b/id/8078107-M.jpg	OL26384856M	\N	2026-11-25 20:25:43.5082+00	2026-11-25 20:25:43.5082+00
9847	14	Czas pogardy	pol	\N	superNOWA	2014	9788375780840	\N	https://covers.openlibrary.org/b/id/14843078-M.jpg	OL57704414M	\N	2026-11-25 20:25:43.5082+00	2026-11-25 20:25:43.5082+00
9848	14	Time of Contempt	eng	\N	Orion Publishing Group, Limited	2023	9781399611428	\N	https://covers.openlibrary.org/b/id/15213442-M.jpg	OL46569854M	\N	2026-11-25 20:25:43.5082+00	2026-11-25 20:25:43.5082+00
9849	14	Time of Contempt	eng	\N	Orion Publishing Group, Limited	2023	9781399610926	\N	https://covers.openlibrary.org/b/id/15213440-M.jpg	OL46575746M	\N	2026-11-25 20:25:43.5082+00	2026-11-25 20:25:43.5082+00
9850	14	Time of Contempt	eng	\N	Orion Publishing Group, Limited	2013	9780575088436	\N	\N	OL48138216M	\N	2026-11-25 20:25:43.5082+00	2026-11-25 20:25:43.5082+00
9851	14	The Time of Contempt	eng	\N	Orbit	2023	9780316556514	\N	https://covers.openlibrary.org/b/id/14605124-M.jpg	OL48273758M	\N	2026-11-25 20:25:43.5082+00	2026-11-25 20:25:43.5082+00
9852	14	Time of Contempt	eng	\N	Orbit	2013	9780316452762	\N	https://covers.openlibrary.org/b/id/12823773-M.jpg	OL38065765M	\N	2026-11-25 20:25:43.5082+00	2026-11-25 20:25:43.5082+00
9853	14	Time of Contempt	eng	\N	Orbit	2022	9780316451550	\N	https://covers.openlibrary.org/b/id/14629047-M.jpg	OL38153657M	\N	2026-11-25 20:25:43.5082+00	2026-11-25 20:25:43.5082+00
9854	14	Time of Contempt	eng	\N	Orion Publishing Group, Limited	2023	9781399611091	\N	\N	OL39560385M	\N	2026-11-25 20:25:43.5082+00	2026-11-25 20:25:43.5082+00
9855	14	The Time of Contempt	eng	\N	Gollancz	2013	9780575084957	0575084952	https://covers.openlibrary.org/b/id/15213443-M.jpg	OL33276190M	\N	2026-11-25 20:25:43.5082+00	2026-11-25 20:25:43.5082+00
9856	14	Time of Contempt	eng	\N	HACHETTE INDIA	2020	9781473231092	1473231094	https://covers.openlibrary.org/b/id/13112790-M.jpg	OL44875016M	\N	2026-11-25 20:25:43.5082+00	2026-11-25 20:25:43.5082+00
9857	14	The Time of Contempt (The Witcher Book 2)	\N	\N	Orbit	2013	9780316219143	0316219142	https://covers.openlibrary.org/b/id/8742079-M.jpg	OL27105649M	\N	2026-11-25 20:25:43.5082+00	2026-11-25 20:25:43.5082+00
9858	14	Čas opovržení	ces	\N	Leonardo	2022	9788074770821	\N	https://covers.openlibrary.org/b/id/14548208-M.jpg	OL49953070M	\N	2026-11-25 20:25:43.5082+00	2026-11-25 20:25:43.5082+00
9859	14	Die Zeit der Verachtung	deu	\N	dtv	2020	9783423262453	\N	https://covers.openlibrary.org/b/id/14425809-M.jpg	OL49634212M	\N	2026-11-25 20:25:43.5082+00	2026-11-25 20:25:43.5082+00
9860	14	Time of Contempt	eng	\N	Gollancz	2014	9780575090941	\N	https://covers.openlibrary.org/b/id/12586519-M.jpg	OL29485065M	\N	2026-11-25 20:25:43.5082+00	2026-11-25 20:25:43.5082+00
9861	14	Die Zeit der Verachtung	deu	\N	Deutscher Taschenbuch Verlag	2009	9783423247269	3423247266	https://covers.openlibrary.org/b/id/8772061-M.jpg	OL27292918M	\N	2026-11-25 20:25:43.5082+00	2026-11-25 20:25:43.5082+00
9862	14	Tiempo de odio	spa	\N	Alamut	2016	9788498890532	\N	https://covers.openlibrary.org/b/id/7881015-M.jpg	OL26197241M	\N	2026-11-25 20:25:43.5082+00	2026-11-25 20:25:43.5082+00
9863	14	The Time of Contempt	eng	\N	Orbit	1995	9781478934103	1478934107	https://covers.openlibrary.org/b/id/12848707-M.jpg	OL32011125M	\N	2026-11-25 20:25:43.5082+00	2026-11-25 20:25:43.5082+00
9864	14	The Time of Contempt	eng	\N	Orbit	2012	9780316219136	\N	https://covers.openlibrary.org/b/id/7671681-M.jpg	OL26071473M	\N	2026-11-25 20:25:43.5082+00	2026-11-25 20:25:43.5082+00
9865	14	Czas pogardy	pol	\N	SuperNowa	2014	9788375780666	8375780669	https://covers.openlibrary.org/b/id/10893698-M.jpg	OL32265105M	\N	2026-11-25 20:25:43.5082+00	2026-11-25 20:25:43.5082+00
9866	14	Tempo do Desprezo	por	BR	WMF Martins Fontes	2014	9788578278427	8578278429	https://covers.openlibrary.org/b/id/10394708-M.jpg	OL29539010M	\N	2026-11-25 20:25:43.5082+00	2026-11-25 20:25:43.5082+00
9867	14	Czas pogardy	pol	\N	SuperNOWA	2001	\N	8370540910	https://covers.openlibrary.org/b/id/15213439-M.jpg	OL26802105M	\N	2026-11-25 20:25:43.5082+00	2026-11-25 20:25:43.5082+00
9868	14	Czas pogardy	pol	\N	SuperNOWA	2001	\N	8370540910	https://covers.openlibrary.org/b/id/13272105-M.jpg	OL3617707M	\N	2026-11-25 20:25:43.5082+00	2026-11-25 20:25:43.5082+00
9869	14	Czas pogardy	pol	\N	SuperNOWA	1995	\N	8370540910	\N	OL625794M	\N	2026-11-25 20:25:43.5082+00	2026-11-25 20:25:43.5082+00
9870	22	Harry Potter and the Chamber of Secrets	\N	\N	Raincoast Books	2004	9781551927282	\N	https://covers.openlibrary.org/b/id/15246710-M.jpg	OL62447619M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9871	22	Harry Potter y la cámara secreta	\N	\N	Salamandra	2019	\N	\N	https://covers.openlibrary.org/b/id/15172452-M.jpg	OL61362442M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9872	22	Harry Potter und die Kammer des Schreckens	deu	\N	Carlsen	2002	\N	3551553009	https://covers.openlibrary.org/b/id/15165872-M.jpg	OL61201794M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9873	22	Harry Potter and the Chamber of Secrets	eng	\N	Bloomsbury	1998	\N	0747538484	https://covers.openlibrary.org/b/id/15158664-M.jpg	OL59041259M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9874	22	هري پاتر و حفره اسرارآميز	fas	\N	Kitābsarā-yi Tandīs	2003	9789645757043	9645757045	https://covers.openlibrary.org/b/id/15159980-M.jpg	OL56934655M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9875	22	Hari Poteri da saidumlo otʻaxi	kat	\N	Bakur Sulakauris gamomcʻemloba	2004	\N	9994015915	\N	OL54860712M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9876	22	Harry Potter and the Chamber of Secrets (il. Ed. )	eng	\N	Bound to Stay Bound Books	2016	9798855115482	\N	\N	OL53339152M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9877	22	Harry Potter y la Camara Secreta / Harry Potter and the Chamber of Secrets	spa	\N	Publicaciones y Ediciones Salamandra, S.A.	2024	9798890981899	\N	\N	OL52212077M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9878	22	Harry Potter y la Camara Secreta (Harry Potter and the Chamber of Secrets)	spa	\N	Publicaciones y Ediciones Salamandra, S.A.	2024	9781536489385	\N	\N	OL53329460M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9879	22	Harry Potter och hemligheternas kammare	swe	\N	Tiden	2001	9789188877673	9188877671	https://covers.openlibrary.org/b/id/15157479-M.jpg	OL47682305M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9880	22	Harry Potter i la cambra secreta	cat	\N	Empúries	2001	9788475967752	8475967752	https://covers.openlibrary.org/b/id/15157475-M.jpg	OL47682278M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9881	22	해리포터와비밀의방	kor	\N	문학수첩	2003	9788989708599	8989708591	https://covers.openlibrary.org/b/id/15157542-M.jpg	OL47682248M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9882	22	Harry Potter og Hemmelighedernes Kammer	dan	\N	Gyldendal	2003	9788700459946	8700459941	https://covers.openlibrary.org/b/id/15157651-M.jpg	OL47324321M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9883	22	Harry Potter and the Chamber of Secrets	eng	\N	Arthur A. Levine Books	1999	\N	0758744269	https://covers.openlibrary.org/b/id/15244785-M.jpg	OL23292648M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9884	22	Harry Potter and the Chamber of Secrets	\N	\N	Nahdet Misr Publishing House	\N	9789717008141	9717008140	https://covers.openlibrary.org/b/id/13314528-M.jpg	OL46544917M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9885	22	Harry Potter and The Chamber of Secrets	eng	\N	Bloomsbury	2014	9781408855669	\N	https://covers.openlibrary.org/b/id/15159586-M.jpg	OL59004872M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9886	22	Harry Potter and the Chamber of Secrets	eng	\N	Bloomsbury	2014	9781408855904	\N	https://covers.openlibrary.org/b/id/15162896-M.jpg	OL61090755M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9887	22	Harry Potter i komnata tajemnic	pol	\N	Media Rodzina	2016	9788380082137	\N	https://covers.openlibrary.org/b/id/15160718-M.jpg	OL61090642M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9888	22	Harry Potter y la cámara secreta	spa	\N	Salamandra	2017	9788498386592	\N	https://covers.openlibrary.org/b/id/15159958-M.jpg	OL61067975M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9889	22	Harry Potter and the Chamber of Secrets	eng	\N	FollettBound	2000	\N	0329209744	https://covers.openlibrary.org/b/id/15159946-M.jpg	OL61067860M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9890	22	Harry Potter va Phòng Chú'a Bí Mât	vie	\N	Trẻ	2011	9786041008465	\N	https://covers.openlibrary.org/b/id/15159935-M.jpg	OL61067727M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9891	22	Harry Potter et la chambre des secrets	fra	\N	Gallimard Jeunesse	2017	9782070643035	\N	https://covers.openlibrary.org/b/id/15158614-M.jpg	OL61057398M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9892	22	Harry Potter y la cámara secreta	spa	\N	Emecé Editores	2000	9788478885558	\N	https://covers.openlibrary.org/b/id/15158574-M.jpg	OL61057120M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9893	22	Harry Potter and the Chamber of Secrets	eng	\N	Midwest Tape	2008	\N	0807281948	https://covers.openlibrary.org/b/id/15157053-M.jpg	OL61041808M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9894	22	Harry Potter and the Chamber of Secrets	eng	\N	Listening Library	1999	\N	0807281948	https://covers.openlibrary.org/b/id/15156791-M.jpg	OL61041692M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9895	22	Harry Potter and the Chamber of Secrets	eng	\N	Listening Library	1999	\N	\N	https://covers.openlibrary.org/b/id/15156790-M.jpg	OL61041691M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9896	22	Harry Potter and the Chamber of Secrets	eng	\N	Listening Library	1999	9780807281949	\N	https://covers.openlibrary.org/b/id/15156772-M.jpg	OL61041677M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9897	22	Harry Potter and the Chamber of Secrets	eng	\N	Listening Library	2000	9780807286012	\N	https://covers.openlibrary.org/b/id/15156742-M.jpg	OL61041662M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9898	22	Harry Potter and the Chamber of Secrets	eng	\N	Listening Library	1999	\N	080728601X	https://covers.openlibrary.org/b/id/15156304-M.jpg	OL61038033M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9899	22	Harry Potter and the Chamber of Secrets	eng	\N	Scholastic Inc.	2000	\N	0439064872	https://covers.openlibrary.org/b/id/15253784-M.jpg	OL61032243M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9900	22	Harry Potter y la cámara secreta	spa	\N	Pottermore Publishing	2015	9781781101322	\N	https://covers.openlibrary.org/b/id/15116677-M.jpg	OL59922397M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9901	22	Harry Potter und die Kammer des Schreckens	deu	\N	Carlsen	2022	9783551558329	3551558329	https://covers.openlibrary.org/b/id/15101378-M.jpg	OL59511775M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9902	22	[Harry Potter and the chamber of secrets	hye	\N	\N	\N	\N	\N	\N	OL54860780M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9903	22	Harry Potter e la camera dei segreti	ita	\N	Salani	1998	9788831000154	8831000152	\N	OL37053826M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9904	22	Harry Potter e la camera dei segreti	\N	\N	Salani	1998	\N	\N	\N	OL51162283M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9905	22	Harry Potter and the Chamber of Secrets	eng	\N	Bound to Stay Bound Books	1999	9798855115505	\N	\N	OL53336125M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9906	22	Harry Potter and the Chamber of Secrets	\N	\N	Perfection Learning	2000	9780756903169	0756903165	\N	OL50523330M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9907	22	Harry Potter et la Chambre des secrets	\N	\N	Pottermore Publishing	2015	9781781101049	\N	https://covers.openlibrary.org/b/id/14564146-M.jpg	OL50533834M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9908	22	Harry Potter and the Chamber of Secrets	eng	\N	Bloomsbury Publishing Plc	1999	9780747543930	\N	\N	OL48613641M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9909	22	Harry Potter and the Chamber of Secrets	eng	\N	Bloomsbury Publishing Plc	2015	9781408865613	\N	\N	OL48652658M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9910	22	Harry Potter and the Chamber of Secrets	eng	\N	Scholastic Inc.	2000	9780738301426	0738301426	https://covers.openlibrary.org/b/id/15158266-M.jpg	OL48124905M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9911	22	Harry Potter et la chambre des secrets	fra	\N	Gallimard	2008	9782070619184	2070619184	https://covers.openlibrary.org/b/id/15157896-M.jpg	OL47682322M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9912	22	Harry Potter und die Kammer des Schreckens	deu	\N	Carlsen	2013	9783551313126	3551313121	https://covers.openlibrary.org/b/id/15157620-M.jpg	OL47682294M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9913	22	Harry Potter und die Kammer des Schreckens	deu	\N	Carlsen	2000	9783551551092	355155109X	https://covers.openlibrary.org/b/id/15157471-M.jpg	OL46899607M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9914	22	Harry Potter e la camera dei segreti Vol II	\N	\N	Salani	2019	9788893814515	889381451X	https://covers.openlibrary.org/b/id/13124714-M.jpg	OL45265193M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9915	22	Harry Potter E La Camera Dei Segreti	\N	\N	European Schoolbooks Ltd	2018	9788893817035	8893817039	https://covers.openlibrary.org/b/id/12604696-M.jpg	OL37025521M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9916	22	Harry Potter e a Camara Secreta - Edicao Comemorativa dos 20 anos da Colecao Harry Potter	\N	\N	Rocco	2019	9788532531773	8532531776	https://covers.openlibrary.org/b/id/12392584-M.jpg	OL35697191M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9917	22	Harry Potter e a Camara Secreta - Ilustrado	\N	\N	ROCCO	2017	9788532530554	8532530559	https://covers.openlibrary.org/b/id/12370357-M.jpg	OL35664746M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9918	22	Harry Potter y la Camara Secreta	\N	\N	Salamandra	2012	9788498384390	8498384397	https://covers.openlibrary.org/b/id/12344944-M.jpg	OL35638042M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9919	22	HARRY POTTER Y LA CAMARA SECRETA	\N	\N	SALAMANDRA	2015	9788498389104	8498389100	\N	OL35630389M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9920	22	Harry Potter e a Câmara Secreta	por	BR	Rocco	2017	9788532530790	8532530796	https://covers.openlibrary.org/b/id/12215952-M.jpg	OL35372744M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9921	22	Harry Potter e a Câmara Secreta	por	BR	EDITORA ROCCO LTDA.	2000	9788532511669	853251166X	https://covers.openlibrary.org/b/id/14512121-M.jpg	OL49810020M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9922	22	HARRY POTTER E LA CRAMPA DEUS SECRETS	\N	\N	PER NOSTE	2011	9782868660862	286866086X	https://covers.openlibrary.org/b/id/12023715-M.jpg	OL34104377M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9923	22	Harry Potter a Tajemn Komnata	\N	\N	BRIGHT BOOKS	1999	9788000027814	800002781X	https://covers.openlibrary.org/b/id/10864480-M.jpg	OL32222811M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9924	22	Harry Potter și camera secretelor	ron	\N	Arthur	2016	9786067880045	6067880040	https://covers.openlibrary.org/b/id/14609534-M.jpg	OL31865244M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9925	22	Harry Potter e la camera dei segreti vol. 2	\N	\N	French & European Pubns	2014	9788867158133	8867158139	https://covers.openlibrary.org/b/id/10540111-M.jpg	OL31848669M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9926	22	Гарри Поттер и Тайная комната	rus	\N	Махаон	2014	9785389077812	\N	https://covers.openlibrary.org/b/id/15159924-M.jpg	OL29554503M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9927	22	Harry Potter 02 e la camera dei segreti	\N	\N	Salani Editore S.p.A.	2020	9788831003391	8831003399	https://covers.openlibrary.org/b/id/10135300-M.jpg	OL28199713M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9928	22	Harry Potter and the Chamber of Secrets	eng	\N	Intervisual Books	2002	\N	0439451930	https://covers.openlibrary.org/b/id/13274521-M.jpg	OL23040870M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9929	22	Harry Potter and the Chamber of Secrets	eng	\N	Scholastic, Incorporated	1999	9780439107341	\N	https://covers.openlibrary.org/b/id/13746104-M.jpg	OL44233989M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9930	22	Harry Potter and the Chamber of Secrets	\N	\N	Bloomsbury Publishing PLC	2010	9781408812785	1408812789	https://covers.openlibrary.org/b/id/13129089-M.jpg	OL45358336M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9931	22	Harry Potter a tajemná komnata	ces	\N	Albatros	2002	9788000011622	800001162X	https://covers.openlibrary.org/b/id/15156819-M.jpg	OL40295599M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9932	22	Harry Potter and the Chamber of Secrets	eng	\N	Lulu Press, Inc.	2011	9781435762497	\N	\N	OL39851464M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9933	22	Harry Potter and the Chamber of Secrets	eng	\N	Lulu Press, Inc.	2010	9780557944910	\N	\N	OL39870901M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9934	22	Harry Potter and the Chamber of Secrets	eng	\N	Lulu Press, Inc.	2010	9780557911790	\N	\N	OL39874621M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9935	22	Harry Potter and the Chamber of Secrets	eng	\N	Lulu Press, Inc.	2010	9780557744282	\N	\N	OL39877957M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9936	22	Harry Potter and the Chamber of Secrets	\N	\N	Demco Media	\N	9780606191814	060619181X	\N	OL40431481M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9937	22	Harry Potter and the Chamber of Secrets	eng	\N	Bloomsbury	2004	9780747574484	0747574480	https://covers.openlibrary.org/b/id/15266928-M.jpg	OL48061949M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9938	22	Harry Potter and the Chamber of Secrets	eng	\N	Large Print Press	2021	\N	1594130019	https://covers.openlibrary.org/b/id/14333264-M.jpg	OL48061946M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9939	22	Ο Χάρι Πότερ και η Κάμαρα με τα Μυστικά	ell	\N	Ψυχογιός	2002	\N	9602744014	https://covers.openlibrary.org/b/id/15225241-M.jpg	OL48061942M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9940	22	Harry Potter et la Chambre des Secrets	fra	\N	French and European Publications Inc	2017	9781547904136	1547904135	https://covers.openlibrary.org/b/id/15091480-M.jpg	OL39813929M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9941	22	Harry Potter 2 und die Kammer des Schreckens. Meine Freunde. Ausgabe Illustration.	deu	\N	Carlsen	2002	9783551553164	3551553165	https://covers.openlibrary.org/b/id/3234659-M.jpg	OL12814341M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9942	22	Harry Potter y la Cámara Secreta (Ed. Minalima)	spa	\N	Publicaciones y Ediciones Salamandra, S.A.	2022	9788418637018	\N	\N	OL36055779M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9943	22	Harry Potter y la cámara secreta	spa	\N	Círculo de Lectores	2000	9788422682219	8422682214	https://covers.openlibrary.org/b/id/12879781-M.jpg	OL35992670M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9944	22	Harry Potter y la cámara secreta	spa	\N	Salamandra Infantil y Juvenil	2016	9788498384406	8498384400	\N	OL37808057M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9945	22	Harry Potter y la cámara secreta	spa	\N	Salamandra Infantil y Juvenil	2014	9788498386325	8498386322	https://covers.openlibrary.org/b/id/13128703-M.jpg	OL45347395M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9946	22	Harry Potter y la cámara secreta	spa	\N	Salamandra Bolsillo	2010	9788498382679	849838267X	\N	OL37845695M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9947	22	Harry Potter y la cámara secreta	spa	\N	Salamandra Bolsillo	2020	9788418173127	8418173122	https://covers.openlibrary.org/b/id/10585374-M.jpg	OL31902365M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9948	22	Harry Potter y la cámara secreta	spa	\N	Salamandra Infantil y Juvenil	2013	9788498386585	8498386586	https://covers.openlibrary.org/b/id/12337354-M.jpg	OL35630384M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9949	22	哈利 ・波特与密室	zho	\N	人民文学	2007	9787020033447	702003344X	https://covers.openlibrary.org/b/id/13028501-M.jpg	OL43160726M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9950	22	Harry Potter y la Camara Secreta (Harry Potter and the Chamber of Secrets)	spa	\N	Penguin Random House Grupo Editorial	2015	9781484474075	\N	\N	OL39697696M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9951	22	Harry Potter and the Chamber of Secrets	eng	\N	Scholastic	2023	9781338878936	\N	https://covers.openlibrary.org/b/id/15092956-M.jpg	OL39420725M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9952	22	Harry Potter and the Chamber of Secrets	eng	\N	Scholastic, Incorporated	2016	9781338119862	\N	\N	OL39342247M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9953	22	Harry Potter and the Chamber of Secrets	eng	\N	Raincoast Books	2000	9781551923703	155192370X	https://covers.openlibrary.org/b/id/14452642-M.jpg	OL39215790M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9954	22	Harry Potter and the Chamber of Secrets	\N	\N	Bloomsbury Pub Ltd	2004	9780747573616	0747573611	\N	OL39221283M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9955	22	Harry Potter et la chambre des secrets	fra	\N	Gallimard Jeunesse	2007	9780320048418	\N	https://covers.openlibrary.org/b/id/12903889-M.jpg	OL39794040M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9956	22	Harry Potter, II	\N	\N	GALLIMARD JEUNE	2016	9782070624539	2070624536	\N	OL39221111M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9957	22	Harry Potter Et La Chambre Des Secrets	\N	\N	Gallimard - Educa Books	2019	9782075117395	207511739X	https://covers.openlibrary.org/b/id/12023623-M.jpg	OL34101453M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9958	22	Harry Potter Et La Chambre Des Secrets	fra	\N	Gallimard jeunesse	2021	9782075158886	\N	https://covers.openlibrary.org/b/id/12499096-M.jpg	OL36005393M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9959	22	Harry Potter et la Chambre des Secrets	\N	\N	GALLIMARD JEUNE	2019	9782075117548	2075117543	https://covers.openlibrary.org/b/id/11540339-M.jpg	OL32914954M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9960	22	Harry Potter Et La Chambre Des Secrets	\N	\N	GALLIMARD JEUNE	2017	9782070584642	207058464X	https://covers.openlibrary.org/b/id/10536577-M.jpg	OL31841282M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9961	22	Harry Potter y la Cámara Secreta / Harry Potter and the Chamber of Secrets	spa	\N	Penguin Random House Grupo Editorial (USA) LLC	2020	9781644732083	\N	\N	OL35975716M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9962	22	Harry Potter ja salaisuuksien kammio	fin	\N	Kustannusosakeyhtiö Tammi	2001	9789513114725	9513114724	https://covers.openlibrary.org/b/id/12606939-M.jpg	OL37028318M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9963	22	Harry Potter a Tajemná komnata	ces	\N	Albatros	2000	9788000008981	800000898X	https://covers.openlibrary.org/b/id/12581306-M.jpg	OL13127428M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9964	22	Harry Potter and the Chamber of Secrets	eng	\N	Scholastic, Incorporated	2000	9781484465486	\N	\N	OL36345032M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9965	22	Harry Potter and the Chamber of Secrets	eng	\N	Scholastic, Incorporated	2018	9781536443738	\N	\N	OL36345051M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9966	22	Harry Potter and the Chamber of Secrets	eng	\N	Scholastic, Incorporated	2018	9781549054181	\N	\N	OL36346098M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9967	22	Harry Potter and the Chamber of Secrets	eng	\N	Scholastic, Incorporated	2018	9780780435131	\N	\N	OL36346099M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9968	22	Harry Potter and the Chamber of Secrets	eng	\N	Bloomsbury	2010	9781408810552	1408810557	https://covers.openlibrary.org/b/id/12630813-M.jpg	OL35639677M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9969	22	Harry Potter and the Chamber of Secrets	eng	\N	Bloomsbury	2013	9781408849934	1408849933	https://covers.openlibrary.org/b/id/15156415-M.jpg	OL35676057M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9970	22	Harry Potter and the Chamber of Secrets	eng	\N	Bloomsbury Publishing Plc	2021	9781526637888	\N	https://covers.openlibrary.org/b/id/15277214-M.jpg	OL34770102M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9971	22	Harry Potter y la Cámara Secreta / Harry Potter and the Chamber of Secrets	spa	\N	Salamandra	2020	9788498389241	\N	https://covers.openlibrary.org/b/id/13191418-M.jpg	OL34186235M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9972	22	Harry Potter y la cámara secreta	spa	\N	Salamandra	2019	9788498389739	\N	https://covers.openlibrary.org/b/id/15157473-M.jpg	OL34099113M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9973	22	Harry Potter y la Cámara Secreta. Edición Slytherin / Harry Potter and the Chamber of Secrets	spa	\N	Publicaciones y Ediciones Salamandra, S.A.	2019	9788498389777	\N	\N	OL34089113M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9974	22	Harry Potter y la Camara Secreta / Harry Potter and the Chamber of Secrets	spa	\N	Publicaciones y Ediciones Salamandra, S.A.	2019	9788498389715	\N	\N	OL34084156M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9975	22	Harry Potter y la Cámara Secreta. Edición Ravenclaw / Harry Potter and the Chamber of Secrets	spa	\N	Publicaciones y Ediciones Salamandra, S.A.	2019	9788498389753	\N	\N	OL34079270M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9976	22	Harry Potter y la cámara secreta	spa	\N	Salamandra	2016	9788498387650	\N	https://covers.openlibrary.org/b/id/15158665-M.jpg	OL34058917M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9977	22	Harry Potter y la cámara secreta	spa	\N	Salamandra	2015	9788498386950	\N	https://covers.openlibrary.org/b/id/14333284-M.jpg	OL34010867M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9978	22	Harry Potter y la Cámara Secreta / Harry Potter and the Chamber of Secrets	spa	\N	Publicaciones y Ediciones Salamandra, S.A.	2021	9786073193900	\N	\N	OL34151756M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9979	22	Harry Potter and chamber of secrets	eng	\N	Scholastic	1999	\N	\N	https://covers.openlibrary.org/b/id/11985126-M.jpg	OL33872146M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9980	22	Harry Potter and the Chamber of Secrets	\N	\N	Turtleback Books	2018	9780606415194	060641519X	https://covers.openlibrary.org/b/id/14656860-M.jpg	OL32891303M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9981	22	Harry Potter und die Kammer des Schreckens	deu	\N	Carlsen	2001	9783551551689	3551551685	https://covers.openlibrary.org/b/id/15156409-M.jpg	OL35675863M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9982	22	Harry Potter and the Chamber of Secrets	eng	\N	Arthur A. Levine Books: An Imprint of Scholastic Press	2007	9780439064866	0439064864	https://covers.openlibrary.org/b/id/12025394-M.jpg	OL34149078M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9983	22	Harry Potter and the Chamber of Secrets	\N	\N	Scholastic Inc.	2021	9781338716535	1338716530	https://covers.openlibrary.org/b/id/10722534-M.jpg	OL32067478M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9984	22	Harry Potter and the Chamber of Secrets	eng	\N	Scholastic Inc.	2000	9780439064873	0439064872	https://covers.openlibrary.org/b/id/14333263-M.jpg	OL32784120M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9985	22	Harry Potter and the Chamber of Secrets	\N	\N	Paw Prints 2008-04-03	2008	9781435238107	1435238109	https://covers.openlibrary.org/b/id/10535729-M.jpg	OL31839581M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9986	22	Harry Potter and the Chamber of Secrets	bul	\N	Егмонт	2001	\N	9544464913	https://covers.openlibrary.org/b/id/11223033-M.jpg	OL32582257M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9987	22	Harry Potter and the Chamber of Secrets	eng	\N	Raincoast Books	2004	9781551927022	1551927020	https://covers.openlibrary.org/b/id/11025487-M.jpg	OL32371075M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9988	22	Harry Potter 2 und die Kammer des Schreckens	deu	\N	Carlsen Verlag GmbH	2018	9783551557421	355155742X	https://covers.openlibrary.org/b/id/10487260-M.jpg	OL30688957M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9989	22	Harry Potter und die Kammer des Schreckens	deu	\N	Carlsen	2006	9783551354020	\N	https://covers.openlibrary.org/b/id/9346688-M.jpg	OL27958337M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9990	22	Harry Potter und die Kammer des Schreckens, 8 Cassetten (Tl.2) Sonderausgabe	deu	\N	Dhv der Hörverlag	1999	9783895846090	3895846090	https://covers.openlibrary.org/b/id/2254763-M.jpg	OL9428536M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9991	22	Harry Potter en de geheime kamer	nld	\N	Harmonie, Uitgeverij De	2000	9789076174112	9076174113	https://covers.openlibrary.org/b/id/10413455-M.jpg	OL29895230M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9992	22	Harrius Potter et Camera Secretorum	lat	\N	Bloomsbury Publishing Plc	2016	9781408869116	\N	\N	OL28576279M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9993	22	Harry Potter e a Câmara dos Segredos	\N	\N	Presença	2020	9789722300124	9722300121	https://covers.openlibrary.org/b/id/10471286-M.jpg	OL30551112M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9994	22	Harry Potter and the Chamber of Secrets	eng	\N	Pottermore	2012	9781781100080	178110008X	https://covers.openlibrary.org/b/id/10521236-M.jpg	OL31445691M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9995	22	Harry Potter and the Chamber of Secrets - Gryffindor Edition	eng	\N	Bloomsbury Publishing Plc	2018	9781408898093	\N	https://covers.openlibrary.org/b/id/15259439-M.jpg	OL28648030M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9996	22	Harry Potter and the Chamber of Secrets - Slytherin Edition	eng	\N	Bloomsbury Publishing Plc	2018	9781408898116	\N	https://covers.openlibrary.org/b/id/15259471-M.jpg	OL28648034M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9997	22	Hôrī Pô̄ṭara āṇi rahasyamaya taḷaghara	mar	\N	Manjul Pub. House	1998	9788183220392	\N	\N	OL30630167M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9998	22	Harry Potter and the Chamber of Secrets	eng	\N	Bloomsbury Publishing Plc	2019	9781526609205	\N	\N	OL28901511M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
9999	22	Harry Potter and the Chamber of Secrets	\N	\N	Arthur A. Levine Books	2003	9780439554893	0439554896	https://covers.openlibrary.org/b/id/10301720-M.jpg	OL28361807M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10000	22	Harry Potter and A chamber of secrets	\N	\N	Bloomsbury	1998	\N	\N	https://covers.openlibrary.org/b/id/9423632-M.jpg	OL28039400M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10001	22	Harry Potter and the Chamber of Secrets	\N	\N	pottermore	2015	\N	\N	\N	OL28183809M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10002	22	Harry Potter and the chamber of secrets 	\N	\N	?	1998	\N	\N	\N	OL28002030M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10003	22	Гаррі Поттер і таємна кімната	ukr	\N	A-BA-BA-GA-LA-MA-GA	2014	9789667047344	9667047342	https://covers.openlibrary.org/b/id/8995302-M.jpg	OL27539566M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10004	22	Harry Potter En De Geheime Kamer	nld	\N	Uitgeverij De Harmonie	2002	9789076174129	9076174121	https://covers.openlibrary.org/b/id/8762432-M.jpg	OL27280397M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10005	22	Harry Potter e a Cámara dos Segredos	\N	\N	Editorial Galaxia	2002	9788482885773	8482885774	https://covers.openlibrary.org/b/id/8763821-M.jpg	OL27282374M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10006	22	Harry Potter & Phòng chứa bí mật	vie	\N	NXB Trẻ	2007	\N	\N	\N	OL27109115M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10007	22	Harry Potter i komnata tajemnic	pol	\N	Media Rodzina	2000	\N	8372780072	https://covers.openlibrary.org/b/id/8353396-M.jpg	OL26677913M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10008	22	Harry Potter Y LA Camara Secreta / Harry Potter and the Chamber of Secrets	spa	\N	Emecé Editores	2000	9788478886142	8478885498	\N	OL9142289M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10009	22	Harry Potter y la camara secreta	spa	\N	Salamandra	2004	9788478889037	8478889035	https://covers.openlibrary.org/b/id/3330669-M.jpg	OL13312397M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10010	22	Harry Potter et la Chambre des Secrets	fra	\N	Gallimard Jeunesse	1999	9782070524556	2070524558	https://covers.openlibrary.org/b/id/8457951-M.jpg	OL22723514M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10011	22	हैरी पॉटर और रहस्यमयी तहख़ाना	hin	\N	Mañjula Pabliśiṇga Hāusa	2008	9788183220071	818322007X	https://covers.openlibrary.org/b/id/8237905-M.jpg	OL23679814M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10012	22	Harry Potter a Tajemná komnata	ces	\N	Albatros	2002	9788000010410	8000010410	\N	OL23037595M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10013	22	Herī Poṭar aur rāzon̲ kā kamrah	urd	\N	Oxford University Press	2004	9780195798760	0195798767	https://covers.openlibrary.org/b/id/8237900-M.jpg	OL22113219M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10014	22	הארי פוטר ואבן החכמים	heb	\N	Yediʻot aḥaronot	2000	9789654487658	9654487659	\N	OL22460251M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10015	22	Гарри Поттер и тайная комната	rus	\N	Rosmėn	2001	9785845109477	5845109477	https://covers.openlibrary.org/b/id/8237867-M.jpg	OL23021224M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10016	22	Harry Potter and the Chamber of Secrets	eng	\N	Scholastic	2002	9780439438773	0439438772	\N	OL10251346M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10017	22	Harry Potter and the Chamber of Secrets	eng	\N	Bloomsbury	1998	9780747538486	0747538484	https://covers.openlibrary.org/b/id/7349483-M.jpg	OL23421676M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10018	22	Harry Potter and the Chamber of Secrets	eng	\N	Bloomsbury	1999	9780747545774	0747545774	https://covers.openlibrary.org/b/id/8237640-M.jpg	OL18336648M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10019	22	Harry Potter and the Chamber of Secrets	eng	\N	Bloomsbury	1998	9780747538493	0747538492	https://covers.openlibrary.org/b/id/8237628-M.jpg	OL22596889M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10020	22	Harry Potter and the Chamber of Secrets	eng	\N	Raincoast Books	1999	9781551922447	1551922444	https://covers.openlibrary.org/b/id/8237644-M.jpg	OL21462351M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10021	22	Harry Potter and the Chamber of Secrets	eng	\N	National Braille Press	1999	9780939173358	0939173352	https://covers.openlibrary.org/b/id/8237638-M.jpg	OL18336092M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10022	22	Harrius Potter et Camera Secretorum	lat	\N	Bloomsbury Publishing PLC	2007	9780747588771	0747588775	https://covers.openlibrary.org/b/id/488670-M.jpg	OL7962919M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10023	22	Harry Potter and the Chamber of Secrets	eng	\N	Raincoast Books	2004	9781551927046	1551927047	\N	OL22595025M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10024	22	Harry Potter e la camera dei segreti	ita	\N	Salani	1999	9788877827036	8877827033	https://covers.openlibrary.org/b/id/10721146-M.jpg	OL22032609M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10025	22	Harry Potter och Hemligheternas kammare	swe	\N	Tiden	2000	9789188877215	9188877213	\N	OL23038700M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10026	22	Harry Potter e la camera dei segreti	ita	\N	Salani Editore	2009	9788884516114	8884516110	https://covers.openlibrary.org/b/id/15157477-M.jpg	OL9073668M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10027	22	Harry Potter y la camara secreta	spa	\N	Lectorum Publications	2000	9788478886562	8478886567	https://covers.openlibrary.org/b/id/1048184-M.jpg	OL9142300M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10028	22	Harry Potter y la camara secreta	spa	\N	Salamandra	2006	9788498380187	8498380189	https://covers.openlibrary.org/b/id/1048811-M.jpg	OL9155297M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10029	22	Harry Potter and the Chamber of Secrets	eng	\N	Bloomsbury	2002	9780747560722	0747560722	https://covers.openlibrary.org/b/id/12442896-M.jpg	OL22225462M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10030	22	Harry Potter y la camara secreta	spa	\N	Salamandra	2004	9788478888627	8478888624	https://covers.openlibrary.org/b/id/1048187-M.jpg	OL9142329M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10031	22	Harry Potter y la camara secreta	spa	\N	Turtleback Books Distributed by Demco Media	2001	9780606204910	0606204911	https://covers.openlibrary.org/b/id/4966449-M.jpg	OL9344852M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10032	22	Harry Potter and the Chamber of Secrets	eng	\N	Pottermore Limited	2015	9781781100509	1781100500	https://covers.openlibrary.org/b/id/8070238-M.jpg	OL26379236M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10033	22	Harry Potter y la camara secreta	spa	\N	Salamandra	2001	9788478886180	8478886184	https://covers.openlibrary.org/b/id/4914254-M.jpg	OL9142291M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10034	22	Harry Potter y la camara secreta	spa	\N	Salamandra	2001	9788478884957	8478884955	\N	OL18481478M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10035	22	Hari Patter va Tālār-i Asrār	fas	\N	Intishārāt-i Nāh̤id	2000	9789645757302	9645757304	\N	OL23019684M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10036	22	Harry Potter and the Chamber of Secrets	eng	\N	Thorndike Press	2000	9780786222735	0786222735	https://covers.openlibrary.org/b/id/15156410-M.jpg	OL6895111M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10037	22	Harry Potter y la camara secreta	spa	\N	Tandem Library	2001	9780613359597	0613359593	https://covers.openlibrary.org/b/id/5003485-M.jpg	OL9694197M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10038	22	Harry Potter et la Chambre des Secrets	fra	\N	Gallimard Jeunesse	2016	9782070588268	2070588262	https://covers.openlibrary.org/b/id/7885090-M.jpg	OL26202302M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10039	22	Гарри Поттер и Тайная комната	rus	\N	Росмэн	2002	9785353003090	5353003098	https://covers.openlibrary.org/b/id/15158310-M.jpg	OL22108277M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10040	22	Harry Potter and the Chamber of Secrets	eng	\N	Ted Smart (Bloomsbury)	1998	9781856136129	1856136124	https://covers.openlibrary.org/b/id/8237629-M.jpg	OL22626521M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10041	22	Harry Potter and the Chamber of Secrets	eng	\N	Scholastic	2002	9780439438780	0439438780	\N	OL7512956M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10042	22	ハリー・ポッターと秘密の部屋	jpn	\N	Seizansha	2000	9784915512391	4915512398	https://covers.openlibrary.org/b/id/10716093-M.jpg	OL16355406M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10043	22	Harry Potter and the Chamber of Secrets	eng	\N	Scholastic	2002	9780439420105	0439420105	https://covers.openlibrary.org/b/id/15155919-M.jpg	OL22374742M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10044	22	Harry Potter et la chambre des secrets	fra	\N	Gallimard	2006	9782070541294	2070541290	\N	OL19679479M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10045	22	Harry Potter i komnata tajemnic	pol	\N	Media Rodzina	2000	9788372780126	8372780129	\N	OL16418939M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10046	22	Harry Potter and the Chamber of Secrets	eng	\N	Large Print Press	2003	9781594130014	1594130019	https://covers.openlibrary.org/b/id/4310273-M.jpg	OL3688333M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10047	22	Harry Potter y la camara secreta	spa	\N	Salamandra Publicacions y Edicions	2002	9788478887606	8478887601	https://covers.openlibrary.org/b/id/13173849-M.jpg	OL9142317M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10048	22	Harry Potter and The Chamber of Secrets	\N	\N	Scholastic Paperbacks	1998	\N	\N	\N	OL25426331M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10049	22	Harry Potter et la Chambre des Secrets	fra	\N	French & European Publications	2004	9780320048432	0320048438	https://covers.openlibrary.org/b/id/13779928-M.jpg	OL9307329M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10050	22	Harry Potter et la Chambre des Secrets	fra	\N	French & European Pubns	\N	9780320037788	0320037789	\N	OL9606878M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10051	22	Haris Poteris ir Paslapčių kambarys	lit	\N	Alma Littera	2001	9789955080183	9955080183	https://covers.openlibrary.org/b/id/3363048-M.jpg	OL13209094M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10052	22	Ο Χάρι Πότερ και η κάμαρα με τα μυστικά	ell	\N	Psichogios	1999	9789602744017	9602744014	https://covers.openlibrary.org/b/id/11749983-M.jpg	OL18917003M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10053	22	Harry Potter & Phòng chwua bí muat	vie	\N	NXB Trke	2007	\N	\N	\N	OL23127280M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10054	22	Harry Potter e la Camera dei Segreti	ita	\N	French & European Publications	2002	9780785900115	078590011X	\N	OL9518319M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10055	22	Harry Potter si camera secretelor	ron	\N	Eegremont	2001	9789735832988	9735832984	\N	OL18633379M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10056	22	Harrius Potter et Camera Secretorum	lat	\N	Bloomsbury USA Children's Books	2006	9781599900674	159990067X	https://covers.openlibrary.org/b/id/8237903-M.jpg	OL8902475M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10057	22	哈利波特-鳳凰會的密令	zho	\N	Tsai Fong Books, Inc	2001	9789573317586	9573317583	https://covers.openlibrary.org/b/id/8237856-M.jpg	OL9149801M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10058	22	هاري بوتر وحجرة الاسرار	ara	\N	Naḥḍat Miṣr	2003	9789771421702	9771421700	\N	OL23070494M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10059	22	Harry Potter e la Camera des Segreti	ita	\N	French & European Pubns	1999	9780828877152	0828877157	https://covers.openlibrary.org/b/id/13881559-M.jpg	OL11462248M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10060	22	Harry Potter y la camara secreta	spa	\N	French & European Pubns	\N	9780320037818	0320037819	\N	OL10457204M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10061	22	Harry Potter y la Camara Secreta	spa	\N	Salamandra	2006	9788498380132	8498380138	https://covers.openlibrary.org/b/id/1048807-M.jpg	OL9155293M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10062	22	Harry Potter and the Chamber of Secrets	eng	\N	Bloomsbury	2016	9781408845653	1408845652	https://covers.openlibrary.org/b/id/12703516-M.jpg	OL26386068M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10063	22	Harry Potter & phòng chwua bí muat	vie	\N	NXB Trke	2001	9786041084254	6041084255	\N	OL23024140M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10064	22	Harry Potter and the Chamber of Secrets	eng	\N	Bloomsbury	2000	9780747549604	0747549605	https://covers.openlibrary.org/b/id/7259482-M.jpg	OL25428860M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10065	22	Harry Potter und die Kammer des Schreckens	deu	\N	French & European Publications Inc	2000	9780828841900	082884190X	\N	OL8171926M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10066	22	Harry Potter y la cámara secreta	spa	\N	Emece/Argentina	2000	9789500420686	9500420686	https://covers.openlibrary.org/b/id/3344497-M.jpg	OL12953401M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10067	22	Harry Potter and the Chamber of Secrets	eng	\N	Raincoast Books	2000	9781551926148	1551926148	https://covers.openlibrary.org/b/id/8237647-M.jpg	OL25679355M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10068	22	Harry Potter e a Câmara dos Segredos	por	PT	Editorial Presença	2000	9789722325691	9722325698	https://covers.openlibrary.org/b/id/15145255-M.jpg	OL22032672M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10069	22	Harry Potter y la camara secreta	spa	\N	French & European Pubns	\N	9780320037832	0320037835	\N	OL10457206M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10070	22	Harry Potter und die Kammer des Schreckens	deu	\N	French & European Publications	2001	9780685116326	0685116328	\N	OL7723164M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10071	22	แฮร์รี่ พอตเตอร์กับห้องแห่งความลับ	tha	\N	Bō̜risat Nānmībuk	2000	9789744723635	9744723637	\N	OL23050691M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10072	22	Harry Potter et la Chambre des Secrets	fra	\N	French & European Publication	1999	9780320038495	0320038491	\N	OL9701415M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10073	22	Harry Potter and the Chamber of Secrets	eng	\N	Turtleback Books	2000	9780613287142	0613287142	https://covers.openlibrary.org/b/id/7816310-M.jpg	OL26147740M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10074	22	Harry Potter und die Kammer des Schreckens	deu	\N	French & European Publications	2001	9780685114056	0685114058	\N	OL9862307M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10075	22	Harry Potter og Hemmelighedernes Kammer	dan	\N	Gyldendal	2004	9788702027709	8702027704	\N	OL23064639M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10076	22	Harry Potter and the Chamber of Secrets	eng	\N	Arthur A. Levine Books	2002	9780439203531	0439203538	https://covers.openlibrary.org/b/id/7611188-M.jpg	OL26039149M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10077	22	Harry Potter et la Chambre des Secrets	fra	\N	French & European Publications	2001	9780685360910	0685360911	\N	OL7723261M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10078	22	Harry Potter und die Kammer des Schreckens	deu	\N	French & European Publications	2000	9780828814775	0828814775	https://covers.openlibrary.org/b/id/13283089-M.jpg	OL9603784M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10079	22	Harry Potter et la Chambre des Secrets	fra	\N	Contemporary French Fiction	2007	9782070612376	2070612376	https://covers.openlibrary.org/b/id/2137706-M.jpg	OL8840308M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10080	22	Harry Potter und die Kammer des Schreckens	deu	\N	Dhv der Hörverlag	2002	9783895849602	389584960X	https://covers.openlibrary.org/b/id/1036237-M.jpg	OL9015336M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10081	22	Harry Potter und die Kammer des Schreckens	deu	\N	Carlsen	2016	9783551559029	3551559023	https://covers.openlibrary.org/b/id/8121076-M.jpg	OL26416818M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10082	22	Harry Potter and the Chamber of Secrets	eng	\N	Pottermore	2015	9781781100226	1781100225	https://covers.openlibrary.org/b/id/8121046-M.jpg	OL26416795M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10083	22	Harry Potter Harry Potter and the Chamber of Secrets. Gryffindor Edition	\N	\N	Bloomsbury Childrens Books	2018	9781408898109	1408898101	https://covers.openlibrary.org/b/id/8501212-M.jpg	OL26828066M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10084	22	Harry Potter and the Chamber of Secrets	\N	\N	Arthur A. Levine Books	2018	9781338299151	1338299158	https://covers.openlibrary.org/b/id/14656861-M.jpg	OL26821543M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10085	22	Harry Potter i Komnata Tajemnic	pol	\N	Media Rodzina	2016	9788380082144	8380082141	https://covers.openlibrary.org/b/id/13239789-M.jpg	OL26407865M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10086	22	Harry Potter dhe dhoma e të fshehtave	sqi	\N	Dituria	2002	9789992747834	9992747838	https://covers.openlibrary.org/b/id/14603886-M.jpg	OL19112092M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10087	22	Harry Potter and the Chamber of Secrets	eng	\N	Turtleback Books	2013	9780606323468	0606323465	https://covers.openlibrary.org/b/id/8121041-M.jpg	OL26416792M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10088	22	Harry Potter and the Chamber of Secrets	eng	\N	Arthur A. Levine Books	2016	9780545791328	0545791324	https://covers.openlibrary.org/b/id/12631320-M.jpg	OL26629980M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10089	22	Harry Potter and the Chamber of Secrets	eng	\N	Listening Library	1999	\N	0807281948	https://covers.openlibrary.org/b/id/15156149-M.jpg	OL26913090M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10090	22	Harry Potter and the Chamber of Secrets	eng	\N	Listening Library	2000	9780807281918	0807281913	https://covers.openlibrary.org/b/id/8120094-M.jpg	OL26416267M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10091	22	Harry Potter and the Chamber of Secrets	eng	\N	Scholastic Inc.	2013	9780545582926	054558292X	https://covers.openlibrary.org/b/id/15158684-M.jpg	OL26416791M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10092	22	Harry Potter and the Chamber of Secrets: Deluxe Illustrated Slipcase Edition	\N	\N	Bloomsbury	2016	9781408876831	1408876833	https://covers.openlibrary.org/b/id/8497962-M.jpg	OL26826619M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10093	22	Harry Potter and the Chamber of Secrets: Ravenclaw Edition Blue	\N	\N	Bloomsbury	2018	9781408898130	1408898136	https://covers.openlibrary.org/b/id/15259458-M.jpg	OL27012578M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10094	22	Harry Potter y la camara secreta	spa	\N	salamandra	2016	9788498387636	8498387639	https://covers.openlibrary.org/b/id/7890213-M.jpg	OL26208867M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10095	22	Harry Potter and the Chamber of Secrets	eng	\N	Bloomsbury	1999	9780747544074	0747544077	https://covers.openlibrary.org/b/id/8120507-M.jpg	OL26416536M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10096	22	Harry Potter and the Chamber of Secrets	eng	\N	Listening Library	2006	9780307259936	0307259935	https://covers.openlibrary.org/b/id/13267630-M.jpg	OL10352462M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10097	22	Harry Potter and the Chamber of Secrets	\N	\N	Bloomsbury	2016	9781408869123	1408869128	https://covers.openlibrary.org/b/id/8538523-M.jpg	OL26847075M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10098	22	Harry Potter es a Titkok Kamraja	hun	\N	Animus	2002	9789639307285	9639307289	\N	OL13105798M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10099	22	Harry Potter und die Kammer des Schreckens	deu	\N	der Hörverlag	2000	9783867176521	3867176523	https://covers.openlibrary.org/b/id/8120972-M.jpg	OL26416749M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10100	22	Harry Potter und die Kammer des Schreckens	deu	\N	Carlsen	2002	\N	\N	\N	OL22820037M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10101	22	Harry Potter and the Chamber of Secrets	eng	\N	Bloomsbury	2000	9780747586463	0747586462	https://covers.openlibrary.org/b/id/8120969-M.jpg	OL26416746M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10102	22	แฮร์รี่พอตเตอร์ กับ ห้องแห่งความลับ	tha	\N	แปลนพริ้นท์ติ้ง	2001	9744723637	9744723637	https://covers.openlibrary.org/b/id/6900579-M.jpg	OL24981361M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10103	22	Harry Potter and the Chamber of Secrets: Hufflepuff Edition	\N	\N	Educa Books	2018	9781408898154	1408898152	https://covers.openlibrary.org/b/id/15259449-M.jpg	OL26843732M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10104	22	Harry Potter und die Kammer des Schreckens	deu	\N	Der Hörverlag	2000	9783867173520	3867173524	https://covers.openlibrary.org/b/id/8121120-M.jpg	OL26416852M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10105	22	Harry Potter Harry Potter and the Chamber of Secrets. Hufflepuff Edition	\N	\N	BLOOMSBURY CHILDRENS BOOKS	2018	9781408898161	1408898160	https://covers.openlibrary.org/b/id/8573843-M.jpg	OL26884586M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10106	22	ཧ་རུའེ་ཕོད་ཐར་དང་གསང་བའི་ཁང་པ།	bod	\N	Bod ljongs mi dmangs dpe skrun khang	2009	9787223026246	7223026243	https://covers.openlibrary.org/b/id/8392830-M.jpg	OL26636885M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10107	22	Harry Potter y la camara secreta	spa	\N	Tandem Library	2001	9781417605231	1417605235	\N	OL9867015M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10108	22	Harry Potter i Komnata Tajemnic	pol	\N	Media Rodzina	2016	9788380082489	8380082486	https://covers.openlibrary.org/b/id/8109618-M.jpg	OL26408588M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10109	22	Harry Potter ve Sırlar Odası	tur	\N	Yapı Kredi Yayınları	2019	9783570211021	3570211029	https://covers.openlibrary.org/b/id/3236137-M.jpg	OL12816317M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10110	22	Harry Potter und die Kammer des Schreckens	deu	\N	Carlsen	2000	9783551552099	3551552096	\N	OL9064561M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10111	22	Harry Potter y la cámara secreta	spa	\N	Emecé	2000	9788478885626	8478885625	https://covers.openlibrary.org/b/id/8068667-M.jpg	OL26378150M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10112	22	Harry Potter e la Camera dei Segreti	ita	\N	Magazzini Salani	2002	9788873662471	8873662471	https://covers.openlibrary.org/b/id/8120573-M.jpg	OL26416579M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10113	22	Harry Potter & the Chamber of Secrets	eng	\N	Bloomsbury	2013	9781408834978	1408834979	https://covers.openlibrary.org/b/id/8121036-M.jpg	OL26416790M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10114	22	Harry Potter and the Chamber of Secrets	eng	\N	Bloomsbury Childrens Books	2018	9781408894637	1408894637	https://covers.openlibrary.org/b/id/8538345-M.jpg	OL26846925M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10115	22	Harry Potter and the Chamber of Secrets	eng	\N	Scholastic Canada	2000	9780439988193	0439988195	https://covers.openlibrary.org/b/id/8392798-M.jpg	OL26594474M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10116	22	Harry Potter und die Kammer des Schreckens	deu	\N	Der Hörverlag	2000	9783895848339	3895848336	https://covers.openlibrary.org/b/id/8120560-M.jpg	OL26416571M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10117	22	Harry Potter ve sirlar odasi	tur	\N	YKY	2001	9789750802959	9750802950	https://covers.openlibrary.org/b/id/8148350-M.jpg	OL19317032M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10118	22	Harry Potter ve sirlar odasi	tur	\N	YKY	2001	9789750802928	9750802926	\N	OL19808895M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10119	22	Harry Potter and the Chamber of Secrets	\N	\N	Bloomsbury Childrens Books	2001	9781408882252	1408882256	https://covers.openlibrary.org/b/id/9133767-M.jpg	OL27696701M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10120	22	Harry Potter and the Chamber of Secrets	eng	\N	Bloomsbury Children's Books	2018	9781408898123	1408898128	https://covers.openlibrary.org/b/id/15259462-M.jpg	OL27375715M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10121	22	Harry Potter and the Chamber of Secrets	eng	\N	Bloomsbury Children's Books	2018	9781408898147	1408898144	https://covers.openlibrary.org/b/id/12376745-M.jpg	OL27318285M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10122	22	Harry Potter & the Chamber of Secrets	eng	\N	Bloomsbury	2018	9781408865408	1408865408	https://covers.openlibrary.org/b/id/15277186-M.jpg	OL27506465M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10123	22	Harry Potter and the Chamber of Secrets	eng	\N	Bloomsbury	2008	9780747562184	0747562180	https://covers.openlibrary.org/b/id/15156137-M.jpg	OL27297977M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
10124	22	Harry Potter and the chamber of secrets	\N	\N	Bloomsbury	1998	\N	\N	\N	OL27907917M	\N	2026-11-25 20:25:58.916259+00	2026-11-25 20:25:58.916259+00
6946	20	Harrius Potter et Philosophi Lapis	lat	\N	Bloomsbury	2015	9781408866184	1408866188	https://covers.openlibrary.org/b/id/12578065-M.jpg	OL29259868M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6947	20	Hyāri Paṭāra enḍa di philasaphārasa sṭona	ben	\N	Aṅkura Prakāśanī	2004	\N	9844640911	\N	OL31191351M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6948	20	Hôri pôtara āṇi Parīsa	mar	\N	Manjul Pub. House	2010	9788186775974	\N	\N	OL30630164M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6949	20	Harry Potter and the Philosopher's Stone	eng	\N	Bloomsbury Publishing Plc	2017	9781408883754	\N	https://covers.openlibrary.org/b/id/15259467-M.jpg	OL28619595M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6950	20	Harry Potter and the Philosopher's Stone	eng	\N	Bloomsbury Publishing Plc	2001	9780747554561	\N	\N	OL28425675M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6951	20	Harry Potter and the Philosopher's Stone Ancient Greek	\N	\N	Bloomsbury Publishing PLC	2015	9781408866160	1408866161	https://covers.openlibrary.org/b/id/10217621-M.jpg	OL28292460M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6952	20	Harry Potter and the Philosopher's Stone	eng	\N	Bloomsbury	2007	9780747589945	0747589941	https://covers.openlibrary.org/b/id/11416484-M.jpg	OL28435584M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6953	20	Harry Potter and the Philosopher’s Stone	\N	\N	Bloomsbury Publishing PLC	2016	9781408871874	1408871874	https://covers.openlibrary.org/b/id/10072276-M.jpg	OL28132344M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6954	20	Harry Potter and the Philosopher’s Stone	\N	\N	Bloomsbury	1997	\N	\N	https://covers.openlibrary.org/b/id/9383496-M.jpg	OL27998507M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6955	20	Harry Potter y la piedra filosofal	\N	\N	Salamandra	2014	9788498389166	849838916X	https://covers.openlibrary.org/b/id/9392885-M.jpg	OL28009102M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6956	20	Harry Potter and the Philosopher's Stone	\N	\N	Bloomsbury	1997	\N	\N	\N	OL27974246M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6957	20	Harry Potter and the Philosopher's Stone	\N	\N	Bloomsbury Pub Ltd	2000	9780747549550	0747549559	https://covers.openlibrary.org/b/id/15126486-M.jpg	OL27939879M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6958	20	Harry Potter	\N	\N	Bloomsbury	1999	\N	\N	\N	OL25662679M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6959	20	Harry Potter Illustrated Box Set	\N	\N	Bloomsbury Childrens	\N	9781408885109	1408885107	https://covers.openlibrary.org/b/id/9134059-M.jpg	OL27697074M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6960	20	Harry Potter E a Pedra Filosofal	\N	\N	Editorial-galaxia-s-a-	2002	9788482884967	8482884964	https://covers.openlibrary.org/b/id/8771231-M.jpg	OL27291631M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6961	20	Harry Potter 1 und der Stein der Weisen. Schmuckausgabe (German Edition)	\N	\N	French and European Publications Inc	2015	9783551559012	3551559015	https://covers.openlibrary.org/b/id/8780600-M.jpg	OL27308141M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6962	20	Harry Potter y la piedra filosofal - 1. ed.	\N	\N	Ediciones Salamandra	1999	9788478886135	\N	https://covers.openlibrary.org/b/id/8068665-M.jpg	OL26378148M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6963	20	Harry Potter y la piedra filosofal	\N	\N	Salamandra	2015	9788498386561	849838656X	https://covers.openlibrary.org/b/id/8954874-M.jpg	OL27497553M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6964	20	Harry Potter and the Philosopher's Stane (Scots Language Edition) (Scots Edition)	\N	\N	Black & White Publishing	2018	9781785301544	1785301543	https://covers.openlibrary.org/b/id/8768656-M.jpg	OL27288776M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6965	20	Harry Potter en de steen der wijzen (Dutch Edition)	nld	\N	Harmonie, Uitgeverij De	2000	9789076174105	9076174105	https://covers.openlibrary.org/b/id/8735668-M.jpg	OL27096266M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6966	20	Harry Potter en de steen der wijzen	nld	\N	Harmonie, Uitgeverij De	2011	9789061699767	9061699762	https://covers.openlibrary.org/b/id/9088464-M.jpg	OL27642372M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6967	20	Harry Potter és a bölcsek köve	hun	\N	Animus	2007	9789639715592	963971559X	\N	OL27043019M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
6968	20	Harry Potter and the sorcerer's stone	eng	\N	Scholastic Paperbacks	1999	9780439708180	\N	https://covers.openlibrary.org/b/id/14656855-M.jpg	OL26939404M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
8795	6	Chapterhouse: Dune	\N	\N	Turtleback Books	2019	9781531108496	\N	\N	OL61860840M	\N	2026-11-25 20:24:37.596743+00	2026-11-25 20:24:37.596743+00
7012	20	Harry Potter and the Philosopher's Stone	eng	\N	Bloomsbury	2007	9780747573609	0747573603	https://covers.openlibrary.org/b/id/10580336-M.jpg	OL7962603M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7013	20	Harry Potter agus an Órchloch	gle	\N	Bloomsbury Children's Books	2004	9780747571667	074757166X	https://covers.openlibrary.org/b/id/488201-M.jpg	OL7962550M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7014	20	Harry Potter and the Philosopher's Stone	eng	\N	Bloomsbury Children's Books	2004	9780747574477	0747574472	https://covers.openlibrary.org/b/id/15266927-M.jpg	OL7962629M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7015	20	הארי פוטר וגביע האש	heb	\N	Yediʻot aḥaronot	2001	9789655110289	9655110281	https://covers.openlibrary.org/b/id/13175344-M.jpg	OL23530831M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7016	20	Harry Potter and the Sorcerer's Stone	eng	\N	Thorndike Press	1999	9780786222728	0786222727	https://covers.openlibrary.org/b/id/8266545-M.jpg	OL48544M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7017	20	Harry Potter and the Philosopher's Stone	eng	\N	Ted Smart	1998	9780747543350	0747543356	https://covers.openlibrary.org/b/id/2583771-M.jpg	OL10735289M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7018	20	هاري بوتر وحجر الفيلسوف	ara	\N	Naḥḍat Miṣr	2002	9789771418818	9771418815	\N	OL23070489M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7019	20	Harry Potter and the Philosopher's Stone	eng	\N	Bloomsbury	2001	9780747558194	0747558191	https://covers.openlibrary.org/b/id/487719-M.jpg	OL7962157M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7020	20	Harry Potter y la piedra filosofal	spa	\N	Turtleback Books Distributed by Demco Media	2001	9780606204897	060620489X	https://covers.openlibrary.org/b/id/5018535-M.jpg	OL9831194M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7021	20	Harry Potter and the Philosopher's Stone	eng	\N	BBC Audiobooks	2002	9781855496538	1855496534	https://covers.openlibrary.org/b/id/13262308-M.jpg	OL11999784M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7022	20	Harry Potter ja viisasten kivi	fin	\N	Kustannusosakeyhtiö Tammi	2001	9789513111465	9513111466	\N	OL23024436M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7023	20	Harry Potter and the Philosopher's Stone	eng	\N	Bloomsbury	2000	9780747532743	0747532745	https://covers.openlibrary.org/b/id/10580372-M.jpg	OL7961604M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7024	20	Harry Potter and the Philosopher's Stone	eng	\N	Bloomsbury	1998	9780747542988	0747542988	https://covers.openlibrary.org/b/id/10521270-M.jpg	OL22856696M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7025	20	Harry Potter en de steen der wijzen	nld	\N	De Harmonie	1998	9789076174082	9076174083	https://covers.openlibrary.org/b/id/15128106-M.jpg	OL23018382M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7026	20	Harry Potter and the Sorcerer's Stone	eng	\N	Scholastic	2001	9780439362139	043936213X	https://covers.openlibrary.org/b/id/10200800-M.jpg	OL16180205M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7027	20	Harry Potter y la piedra filosofal	spa	\N	Salamandra	2004	9788478888610	8478888616	https://covers.openlibrary.org/b/id/1048186-M.jpg	OL9142328M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7028	20	Harry Potter y la piedra filosofal	spa	\N	Emecé Editores	2000	9788478886128	847888548X	https://covers.openlibrary.org/b/id/8772331-M.jpg	OL9142288M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7029	20	Harry Potter e la pietra filosofale	ita	\N	Adriano Salani Editore	1998	9788877827029	8877827025	https://covers.openlibrary.org/b/id/12726695-M.jpg	OL21999413M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7030	20	Harijs Poters un filozofu akmens	lav	\N	Jumava	2001	9789984053851	9984053857	https://covers.openlibrary.org/b/id/8267741-M.jpg	OL26336382M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7031	20	Harry Potter y la piedra filosofal	spa	\N	Salamandra Publicacions Y Edicions	2002	9788478887590	8478887598	\N	OL9142316M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7032	20	Harry Potter a l'Ecole des Sorcieres	eng	\N	Editions Flammarion	1999	9782070544875	2070544877	https://covers.openlibrary.org/b/id/3077790-M.jpg	OL12396401M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7033	20	Harry Potter y la piedra filosofal	spa	\N	Salamandra	2006	9788498380125	849838012X	https://covers.openlibrary.org/b/id/1048806-M.jpg	OL9155292M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7034	20	Harry Potter und der Stein der Weisen	deu	\N	Koch, Neff & Oetinger & Co	1998	9783895846670	3895846678	https://covers.openlibrary.org/b/id/2254764-M.jpg	OL9641068M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7035	20	Harry Potter y La Piedra Filosofal	spa	\N	Emecé Editores	2001	9788478886111	8478886117	\N	OL13312284M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7036	20	Harri Potter Maen Yr Athronydd	cym	\N	Bloomsbury Publishing PLC	2005	9780747560975	0747560978	\N	OL10756444M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7037	20	Harrius Potter et Philosophi Lapis	lat	\N	Bloomsbury	2003	9780747561965	0747561966	https://covers.openlibrary.org/b/id/14320051-M.jpg	OL7962285M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7038	20	Harry Potter i la pedra filosofal	cat	\N	Empúries	1999	9788475967745	8475967744	https://covers.openlibrary.org/b/id/13231151-M.jpg	OL9140234M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7039	20	Harry Potter à l'école des sorciers	fra	\N	Gallimard Jeunesse	2001	9782070518425	2070518426	https://covers.openlibrary.org/b/id/13107192-M.jpg	OL22723513M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7040	20	Harry Potter a l'Ecole des Sorcieres	fra	\N	French & European Pubns	1999	9780320038433	0320038432	\N	OL9352591M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7041	20	Harry Potter y la piedra filosofal	spa	\N	French & European Pubns	2005	9780320037825	0320037827	https://covers.openlibrary.org/b/id/13669042-M.jpg	OL10457205M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7042	20	Harry Potter agus an Orchloch	gle	\N	Bloomsbury	2004	9781582348285	1582348286	https://covers.openlibrary.org/b/id/15154751-M.jpg	OL8786539M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7043	20	Harry Potter and the Philosopher's Stone	eng	\N	Cover to Cover Cassettes	2004	9781855496668	1855496666	https://covers.openlibrary.org/b/id/8267761-M.jpg	OL8993486M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7044	20	Harry Potter and the Philosopher's Stone	eng	\N	BBC Audiobooks	2002	9781855496521	1855496526	https://covers.openlibrary.org/b/id/3005676-M.jpg	OL11999783M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7045	20	Harry Potter e a Pedra Filosofal	por	PT	Presença	1999	9789722325332	9722325337	https://covers.openlibrary.org/b/id/15145254-M.jpg	OL15571091M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7046	20	Harry Potter y la piedra filosofal	spa	\N	Salamandra	2006	9788498380170	8498380170	https://covers.openlibrary.org/b/id/1048810-M.jpg	OL9155296M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7047	20	Harry Potter si piatra filozofala	ron	\N	Egremont	2001	\N	9735832941	\N	OL18633382M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7048	20	Harry Potter y la piedra filosofal	\N	\N	French & European Pubns	2003	9780685115299	0685115291	https://covers.openlibrary.org/b/id/13209331-M.jpg	OL7723160M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7049	20	Гарри Поттер и философский камень	rus	\N	Росмэн	2000	9785845105127	5845105129	https://covers.openlibrary.org/b/id/8267739-M.jpg	OL9058508M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7050	20	Harry Potter et l'ecole des Sorciers	fra	\N	French & European Pubns	1999	9780320037801	0320037800	https://covers.openlibrary.org/b/id/5061159-M.jpg	OL10457203M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
8796	6	Bet ha-lishkah	heb	\N	ʻAm-ʻoved	1989	\N	9651305762	\N	OL58208241M	\N	2026-11-25 20:24:37.596743+00	2026-11-25 20:24:37.596743+00
7051	20	Harry Potter and the Philosopher's Stone	eng	\N	Bloomsbury Childrens	2015	9781408845646	1408845644	https://covers.openlibrary.org/b/id/7356030-M.jpg	OL25726816M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7052	20	Harry Potter e la Pietra Filosofale	ita	\N	French & European Pubns	2000	9780828819008	0828819009	\N	OL9307533M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7053	20	Harry Potter à l'école des sorciers	fra	\N	Gallimard Jeunesse	2015	9782070669073	2070669076	https://covers.openlibrary.org/b/id/7882746-M.jpg	OL26199270M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7054	20	Harry Potter y la Pietra Filosofale	ita	\N	French & European Pubns	2002	9780828839983	0828839980	https://covers.openlibrary.org/b/id/13199299-M.jpg	OL8171923M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7055	20	Harry Potter e a Pedra Filosofal	por	BR	Editora Rocco	2012	9788532527844	8532527841	https://covers.openlibrary.org/b/id/7356024-M.jpg	OL25726811M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7056	20	Harry Potter wa hajar al-faylasuf	ara	\N	Nahdat Misr	2000	\N	9771422898	\N	OL22056715M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7057	20	Harry Potter und der Stein der Weisen	deu	\N	Carlsen Verlag	2000	9783551552006	3551552002	https://covers.openlibrary.org/b/id/13028227-M.jpg	OL9064559M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7058	20	Harry Potter a l'ecole des Sorciers	fra	\N	Contemporary French Fiction	2007	9782070612369	2070612368	https://covers.openlibrary.org/b/id/2137705-M.jpg	OL9324407M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7059	20	Harry Potter and the Philosopher's Stone	eng	\N	Bloomsbury Publishing	1997	9780747532699	0747532699	https://covers.openlibrary.org/b/id/7355968-M.jpg	OL25726767M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7060	20	Harry Potter dhe guri filozofal	sqi	\N	Dituria	2001	\N	9992747633	https://covers.openlibrary.org/b/id/15155761-M.jpg	OL19112084M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7061	20	Harry Potter and the Sorcerers Stone	eng	\N	Arthur A. Levine Books	2003	9780439554930	0439554934	https://covers.openlibrary.org/b/id/7572543-M.jpg	OL26018592M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7062	20	Harry Potter y la piedra filosofal	spa	\N	Salamandra	2004	9788478889020	8478889027	https://covers.openlibrary.org/b/id/1048192-M.jpg	OL9142340M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7063	20	Harry Potter i Kamień Filozoficzny	pol	\N	Media Rodzina	2015	9788380081185	8380081188	https://covers.openlibrary.org/b/id/8112465-M.jpg	OL26410525M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7064	20	Harry Potter and the Philosopher's Stone	\N	\N	Bloomsbury Children's Books	2016	9781408882221	1408882221	https://covers.openlibrary.org/b/id/9133782-M.jpg	OL27696722M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7065	20	Harry Potter and the Philosopher's Stone	eng	\N	Bloomsbury Childrens Books	2018	9781526602381	1526602385	https://covers.openlibrary.org/b/id/12460336-M.jpg	OL26775548M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7066	20	Harry Potter and the Philosopher's Stone	\N	\N	Bloomsbury	2010	9781408812846	1408812843	https://covers.openlibrary.org/b/id/9131533-M.jpg	OL27693204M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7067	20	Harry Potter and the Sorcerer's Stone	\N	\N	Turtleback Books	1999	9780613206334	\N	https://covers.openlibrary.org/b/id/7539023-M.jpg	OL26000517M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7068	20	Harry Potter à l'école des sorciers	fra	\N	French & European Pubns	1999	9780320038464	0320038467	https://covers.openlibrary.org/b/id/13200978-M.jpg	OL9891523M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7069	20	Harry Potter and the Philosopher's Stone	\N	\N	HNP	\N	9781907545030	1907545034	https://covers.openlibrary.org/b/id/9056752-M.jpg	OL27606633M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7070	20	Harri Potter a maen yr Athronydd	cym	\N	Bloomsbury Publishing PLC	2003	9780747569305	0747569304	https://covers.openlibrary.org/b/id/8267765-M.jpg	OL7962488M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7071	20	Harry Potter and the Philosopher's Stone	\N	\N	U.S.A.: Bloomsbury Publishing PLC	2015	9781408865262	1408865262	https://covers.openlibrary.org/b/id/8567940-M.jpg	OL26872489M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7072	20	Haris Poteris ir Isminties Akmuo	lit	\N	Alma Littera	2000	9789986029199	9986029198	https://covers.openlibrary.org/b/id/15155855-M.jpg	OL9204120M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7073	20	Harry Potter and the Philosopher's Stone (Harry Potter #1)	eng	\N	bloombury	1997	\N	\N	\N	OL27936637M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7074	20	Harry Potter à l'école des sorciers	fra	\N	French & European Pubns	2001	9780685113912	0685113914	\N	OL7723154M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7075	20	Harry Potter and the Philosopher's Stone	\N	\N	Bloomsbury Publishing PLC	2013	9781408834961	1408834960	https://covers.openlibrary.org/b/id/8565802-M.jpg	OL26869801M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7076	20	Harry Potter y la piedra	spa	\N	Salamandra	2003	9788478888566	847888856X	\N	OL9142327M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7077	20	Harry Potter y la piedra filosofal	spa	\N	Ediciones Salamandra	2014	9788498384383	8498384389	https://covers.openlibrary.org/b/id/8053107-M.jpg	OL26366926M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7078	20	Harry Potter and the Philosopher's Stone	eng	\N	Bloomsbury	2017	9781408883785	1408883783	https://covers.openlibrary.org/b/id/15259456-M.jpg	OL26872110M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7079	20	Harry Potter and the Sorcerer's Stone	eng	\N	Arthur A. Levine Books	2015	9780545919661	0545919665	https://covers.openlibrary.org/b/id/8468882-M.jpg	OL26811362M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7080	20	Harry Potter und der Stein der Weisen	deu	\N	Der HOR Verlag DHV	1999	9783895847011	3895847011	https://covers.openlibrary.org/b/id/13685289-M.jpg	OL23121614M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7081	20	Harry Potter y la piedra filosofal	spa	\N	Salamandra	2015	\N	8498387078	https://covers.openlibrary.org/b/id/7375380-M.jpg	OL25796498M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7082	20	Harry Potter and the Sorcerer's Stone	\N	\N	Arthur A. Levine Books	2018	9781338299144	133829914X	https://covers.openlibrary.org/b/id/8487226-M.jpg	OL26821542M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7083	20	Harry Potter and the Philosopher's Stone	\N	\N	BLOOMSBURY PUBLISHING	2015	9781408865279	1408865270	https://covers.openlibrary.org/b/id/8963307-M.jpg	OL27506554M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7084	20	Harri Potter a Maen yr Athronydd	cym	\N	Bloomsbury	2003	9781582348278	1582348278	https://covers.openlibrary.org/b/id/15155846-M.jpg	OL8786538M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7085	20	Harry Potter and the Philosopher's Stone - Hufflepuff Edition	\N	\N	Educa Books	2018	9781408883808	1408883805	https://covers.openlibrary.org/b/id/15259442-M.jpg	OL27730868M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7086	20	Harry Potter and the Philosopher's Stone	\N	\N	Bloomsbury Juvenile UK	2014	9781408855898	1408855895	https://covers.openlibrary.org/b/id/9016823-M.jpg	OL27561577M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7087	20	ハリー・ポッターと賢者の石 1-2(静山社ペガサス文庫) (ハリー・ポッターシリーズ)	\N	\N	Seizansha.	2014	9784863892316	4863892314	https://covers.openlibrary.org/b/id/8563183-M.jpg	OL26865301M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7088	20	Harry Potter och de vises sten	swe	\N	Tiden	2001	9789188877666	9188877663	\N	OL25544380M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7089	20	Harry Potter and the Philosopher's Stone: Slytherin Edition; Black and Green	\N	\N	Educa Books	2018	9781408883761	1408883767	https://covers.openlibrary.org/b/id/8788413-M.jpg	OL27319792M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7091	20	Harry Potter och De vises sten	swe	\N	Rabén & Sjögren	2015	9789129697704	\N	https://covers.openlibrary.org/b/id/15155854-M.jpg	OL31970533M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7092	20	Harry Potter à l'école des sorciers	fra	\N	Gallimard	2018	9782070624522	2070624528	https://covers.openlibrary.org/b/id/14320086-M.jpg	OL31386308M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7093	20	Harry Potter and the Sorcerer's Stone, 10th Anniversary Edition	\N	\N	Scholastic Inc.	2008	9780545069670	054506967X	https://covers.openlibrary.org/b/id/10469774-M.jpg	OL30546665M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7094	20	Harry Potter and the Sorcerer's Stone	\N	\N	Arthur A. Steven Helton	1997	\N	\N	\N	OL28055021M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7095	20	Harry Potter und der Stein der Weisen	deu	\N	Carlsen	2000	9783551551672	3551551677	https://covers.openlibrary.org/b/id/14320055-M.jpg	OL27958188M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7096	20	Harry Potter und der Stein der Weisen	deu	\N	Der Hörverlag	2002	9783895849596	3895849596	https://covers.openlibrary.org/b/id/15157054-M.jpg	OL9600209M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7097	20	Harry Potter und der Stein der Weisen (German Language 6 Audiocassettes Edition of Harry Potter and the Sorcerer's Stone)	eng	\N	French & European Publications Inc	2002	9780785952855	0785952853	\N	OL9659011M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7098	20	Harry Potter und der Stein der Weisen (German Audio CD Edition of "Harry Potter and the Sorcerer's Stone")	\N	\N	French & European Pubns	2001	9780685360958	0685360954	https://covers.openlibrary.org/b/id/14284862-M.jpg	OL9491201M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7099	20	Harry Potter und der Stein der Weisen (German Audio CD (9 Compact Discs) Edition of "Harry Potter and the Sorcerer's Stone")	\N	\N	French & European Pubns	2000	9780785980643	0785980644	https://covers.openlibrary.org/b/id/13483850-M.jpg	OL11042435M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7100	20	Harry Potter und der Stein der Weisen. Audiobook. 6 Cassetten. Sonderausgabe.	deu	\N	Dhv der Hörverlag	2001	9783895846083	3895846082	https://covers.openlibrary.org/b/id/2254762-M.jpg	OL9898006M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7101	20	Harry Potter i Kamień Filozoficzny	pol	\N	Media Rodzina	2000	9788372780119	8372780110	https://covers.openlibrary.org/b/id/8115069-M.jpg	OL26412608M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7102	20	Harry Potter and the Philosopher's Stone	eng	\N	Bloomsbury	2010	9781408810545	1408810549	https://covers.openlibrary.org/b/id/14320057-M.jpg	OL27281088M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7103	20	Harry Potter och de Vises Sten	swe	\N	Tiden	2000	9789188876652	9188876659	\N	OL12856569M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7104	20	Harry Potter and the Sorcerer's Stone	eng	\N	Arthur A. Levine Books	2016	9780545790352	0545790352	https://covers.openlibrary.org/b/id/15216514-M.jpg	OL26629979M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7105	20	Harry Potter and the Sorcerer's Stone	\N	\N	Perfection Learning Pre Bind	1999	9780780797086	\N	https://covers.openlibrary.org/b/id/7707760-M.jpg	OL26090816M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7106	20	Harry Potter and the Philosopher's Stone	eng	\N	Bloomsbury	2017	9781408883792	1408883791	https://covers.openlibrary.org/b/id/15259447-M.jpg	OL26855047M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7107	20	Harry Potter and the Philosopher's Stone (Book 1): Ancient Greek Edition	\N	\N	Bloomsbury	2004	9780747568971	0747568979	https://covers.openlibrary.org/b/id/8744693-M.jpg	OL27209671M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7108	20	Harry Potter i Kamień Filozoficzny	pol	\N	Media Rodzina	2016	9788380082120	8380082125	https://covers.openlibrary.org/b/id/8108734-M.jpg	OL26407867M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7109	20	Harry Potter and the Philosopher's Stone	eng	\N	Bloomsbury	2017	9781408883747	1408883740	https://covers.openlibrary.org/b/id/15259432-M.jpg	OL26855930M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7110	20	ཧ་རུའེ་ཕོད་ཐར་དང་ཚེ་རྡོ།	bod	\N	Bod ljongs mi dmangs dpe skrun khang	2007	9787223022583	7223022582	https://covers.openlibrary.org/b/id/8392820-M.jpg	OL26636884M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7111	20	Harry Potter à l'école des sorciers	fra	\N	French & European Pubns	2001	9780685284520	0685284522	\N	OL7723222M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7112	20	Harry Potter e a Pedra Filosofal	\N	\N	Rocco	2017	9788532530783	8532530788	https://covers.openlibrary.org/b/id/8436965-M.jpg	OL26784380M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7113	20	Harry Potter und der Stein der Weisen	deu	\N	French & European Pubns	1998	9780828860819	0828860815	https://covers.openlibrary.org/b/id/13171226-M.jpg	OL8171973M	\N	2026-11-25 20:23:43.357383+00	2026-11-25 20:23:43.357383+00
7114	29	A Game of Thrones	\N	\N	Random House Worlds	2025	9780553381689	\N	https://covers.openlibrary.org/b/id/15237705-M.jpg	OL62287051M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7115	29	Joc de Trons	cat	\N	Debutxaca	2022	9788418196508	\N	https://covers.openlibrary.org/b/id/15149225-M.jpg	OL60751857M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7116	29	A Storm of Swords	eng	\N	Voyaer	2003	9780006479901	\N	https://covers.openlibrary.org/b/id/15141362-M.jpg	OL60616966M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7117	29	A Guerra dos Tronos	por	BR	Suma	2019	9788556510785	8556510787	https://covers.openlibrary.org/b/id/15139462-M.jpg	OL60598935M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7118	29	Taht Oyunları	\N	\N	Epsilon Yayınevi	2019	9786051735757	6051735755	https://covers.openlibrary.org/b/id/12115212-M.jpg	OL35304190M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7119	29	Le Trône de fer - L'Intégrale	\N	\N	PYGMALION	2012	9782756408521	2756408522	https://covers.openlibrary.org/b/id/13871375-M.jpg	OL47323528M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7120	29	Le trône de fer	\N	\N	J'AI LU	2015	9782290107096	2290107093	\N	OL40223116M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7121	29	Juego de Tronos	\N	\N	Plaza & Janés	1996	9788401032424	\N	https://covers.openlibrary.org/b/id/15127390-M.jpg	OL60304663M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7122	29	Juego de Tronos	spa	\N	CreateSpace Independent Publishing Platform	2015	9781514256220	\N	\N	OL55390851M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7123	29	Juego de tronos	\N	\N	Gigamesh .	\N	9786073107747	6073107749	\N	OL44834337M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7124	29	Juego de tronos	\N	\N	Ediciones Gigamesh	2011	9788496208919	8496208915	https://covers.openlibrary.org/b/id/12338481-M.jpg	OL35631511M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7125	29	JUEGO DE TRONOS	\N	\N	PLAZA & JANES	2013	9789506442279	9506442274	https://covers.openlibrary.org/b/id/12340614-M.jpg	OL35633662M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7126	29	JUEGO DE TRONOS 3A ED	\N	\N	Plaza & Janés	2016	9786073150477	6073150474	https://covers.openlibrary.org/b/id/12329609-M.jpg	OL35622485M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7127	29	JUEGO DE TRONOS - CANCION DE HIELO Y FUEGO	\N	\N	Debolsillo	2013	9789588886435	9588886430	https://covers.openlibrary.org/b/id/11261391-M.jpg	OL32627112M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7128	29	Juego de tronos	\N	\N	Gigamesh	2011	9788496208490	\N	https://covers.openlibrary.org/b/id/10584235-M.jpg	OL31899941M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7129	29	Juego de tronos	\N	\N	Ediciones Gigamesh	2009	9788496208568	8496208567	https://covers.openlibrary.org/b/id/14637745-M.jpg	OL52099068M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7130	29	Het spel der tronen	\N	\N	Luitingh Fantasy	\N	9789024558858	9024558859	https://covers.openlibrary.org/b/id/9059878-M.jpg	OL27610187M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7131	29	Het Spel Der Tronen (Het Lied van IJs en Vuur, No. 1)	\N	\N	Luitingh Fantasy	2006	9789024556434	9024556430	https://covers.openlibrary.org/b/id/8782363-M.jpg	OL27310799M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7132	29	A Game of Thrones	eng	\N	BCA	2000	\N	\N	https://covers.openlibrary.org/b/id/15128814-M.jpg	OL58636603M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7133	29	A Game of Thrones	eng	\N	Bantam Books	2019	9780593158203	0593158202	https://covers.openlibrary.org/b/id/15126169-M.jpg	OL53214041M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7134	29	A Game of Thrones	eng	\N	Bantam Books	2005	9780553573404	\N	https://covers.openlibrary.org/b/id/15115383-M.jpg	OL48571889M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7135	29	Book in Ukrainian. Hra prestoliv. A Game of Thrones. Pisnya lʹodu y polum'ya. A Song of Ice and Fire. Book 1	\N	\N	КМ-БУКС	2017	9786175381786	6175381785	https://covers.openlibrary.org/b/id/13769298-M.jpg	OL47304804M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7136	29	Гра Престолів	ukr	\N	КМ-БУКС	2020	9789669482716	\N	https://covers.openlibrary.org/b/id/13769326-M.jpg	OL47304835M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7137	29	Game of Thrones	eng	\N	HarperCollins Publishers Limited	1996	9780002246576	\N	https://covers.openlibrary.org/b/id/14148124-M.jpg	OL44111760M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7138	29	Game of Thrones	eng	\N	HarperCollins Publishers Limited	2010	9780007876440	\N	\N	OL44127435M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7139	29	Game of Thrones	eng	\N	HarperCollins Publishers Limited	2015	9780008147785	\N	\N	OL44160112M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7140	29	Le Trône de fer	fra	\N	Pygmalion	2008	9782756402154	275640215X	https://covers.openlibrary.org/b/id/15123760-M.jpg	OL43033560M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7141	29	A Game of Thrones (Song of Ice and Fire)	\N	\N	\N	\N	\N	\N	\N	OL43007492M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7142	29	Le trône de fer : l'intégrale 1	fra	\N	J'ai lu	2019	9782290208878	\N	https://covers.openlibrary.org/b/id/12681341-M.jpg	OL37772492M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7143	29	Game of Thrones (Enhanced Edition)	eng	\N	HarperCollins Publishers	2016	9780008226343	\N	\N	OL37269511M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7144	29	Game of Thrones Enhanced Edition	eng	\N	HarperCollins Publishers	2012	9780007445714	\N	\N	OL37267852M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7145	29	Game of Thrones	eng	\N	HarperCollins Publishers	2013	9780007491575	\N	https://covers.openlibrary.org/b/id/13734880-M.jpg	OL37157277M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7146	29	Game of Thrones	eng	\N	HarperCollins Publishers	2016	9780008220587	\N	\N	OL37267671M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7147	29	Juego de tronos / A Game of Thrones	\N	\N	Vintage Espanol	2022	9781644736135	1644736136	https://covers.openlibrary.org/b/id/12569451-M.jpg	OL36687272M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7148	29	Taht Oyunlari	tur	\N	Epsilon Yayınları	2013	9789944824354	9944824356	https://covers.openlibrary.org/b/id/15125422-M.jpg	OL35651104M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7149	29	Juego de tronos	spa	\N	Debolsillo	2015	9786073128834	6073128835	https://covers.openlibrary.org/b/id/15126196-M.jpg	OL35618079M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7150	29	A Game of Thrones	\N	\N	Akil Çelen Kitaplar	2014	9786055069070	6055069075	https://covers.openlibrary.org/b/id/12233621-M.jpg	OL35391026M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7151	29	A Game Of Thrones	\N	\N	Akilcelen Kitaplar	2013	9786055381592	6055381591	https://covers.openlibrary.org/b/id/12260278-M.jpg	OL35418469M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7152	29	Il Grande Inverno	ita	\N	Mondadori	2000	9788804478027	8804478020	https://covers.openlibrary.org/b/id/15127373-M.jpg	OL27279987M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7153	29	Nawałnica mieczy	pol	\N	Wydawnictwo Zysk i S-ka	2013	9788377852101	\N	https://covers.openlibrary.org/b/id/8289845-M.jpg	OL26605834M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7154	29	A game of thrones	eng	\N	Bantam Books	1997	\N	0553573403	https://covers.openlibrary.org/b/id/15123740-M.jpg	OL20507908M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7155	29	A Game of Thrones	eng	\N	Bantam Books	2002	\N	\N	https://covers.openlibrary.org/b/id/15127384-M.jpg	OL60304555M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7156	29	Le Trône de fer	fra	\N	J'ai Lu	2010	9782290019436	\N	https://covers.openlibrary.org/b/id/15123749-M.jpg	OL60147669M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7157	29	A Game of Thrones	eng	\N	Bantam Books	2011	\N	0553573403	https://covers.openlibrary.org/b/id/15123748-M.jpg	OL60147665M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7158	29	Igra prestola	srp	\N	Laguna	2020	9788652139699	\N	https://covers.openlibrary.org/b/id/14844140-M.jpg	OL57727724M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7159	29	A Game of Thrones	\N	\N	Zysk i S-ka	2011	9788382025866	\N	https://covers.openlibrary.org/b/id/12964086-M.jpg	OL40209111M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7160	29	Mo huan yuan bing	zho	\N	Golden Rich	2002	\N	9574678490	https://covers.openlibrary.org/b/id/15076208-M.jpg	OL19105996M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7161	29	Il trono di spade	\N	\N	Mondadori	2016	9788804662136	8804662131	https://covers.openlibrary.org/b/id/10189242-M.jpg	OL28260671M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7162	29	L'intégrale	\N	\N	J'AI LU	2019	9782290221693	2290221694	https://covers.openlibrary.org/b/id/10451172-M.jpg	OL30371152M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7163	29	Westeros	\N	\N	Penhaligon Verlag	2015	9783764531362	3764531363	https://covers.openlibrary.org/b/id/10525531-M.jpg	OL31521985M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7164	29	Igra prestolov	rus	\N	\N	2016	9785170752508	5170752504	\N	OL27206344M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7165	29	Shichi ōkoku no gyokuza	jpn	\N	Hayakawa Shobō	2006	9784150115739	4150115737	https://covers.openlibrary.org/b/id/11300158-M.jpg	OL27047804M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7166	29	Juego de tronos	spa	\N	Gigamesh.	2005	9788493225049	8493225045	https://covers.openlibrary.org/b/id/10310491-M.jpg	OL28373639M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7167	29	Juego de tronos	spa	\N	Plaza & Janés	2017	9786073113113	6073113110	https://covers.openlibrary.org/b/id/15161210-M.jpg	OL27690313M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7168	29	A Guerra dos Tronos. As Crônicas de Gelo e Fogo - Livro 1	\N	\N	Leya	2015	9788544102923	8544102921	https://covers.openlibrary.org/b/id/10701573-M.jpg	OL32034446M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7169	29	As Crónicas de Gelo e Fogo Vol.1 : A Guerra dos Tronos	\N	\N	Saída de Emergência	2007	9789896370107	9896370109	https://covers.openlibrary.org/b/id/8785829-M.jpg	OL27314892M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7170	29	A Game of Thrones	eng	\N	Harper Voyager	2012	9780007448036	0007448031	https://covers.openlibrary.org/b/id/15119816-M.jpg	OL32670252M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7171	29	Le Trône de fer	fra	\N	Editions France Loisirs	2012	9782298055283	2298055289	https://covers.openlibrary.org/b/id/11299207-M.jpg	OL26855504M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7172	29	A Game of Thrones	eng	\N	Harper Voyager	2011	9780553103540	\N	https://covers.openlibrary.org/b/id/11293305-M.jpg	OL32666278M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7173	29	A Game of Thrones	eng	\N	Bantam Books	2015	9781101965481	1101965487	https://covers.openlibrary.org/b/id/11291818-M.jpg	OL32664646M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7217	29	Juego de tronos	\N	\N	Gigamesh	2011	9788496208964	\N	https://covers.openlibrary.org/b/id/8600049-M.jpg	OL27010745M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7174	29	لعبة العروش  Game thrones	\N	\N	دار التنوير للطباعة والنشر والتوزيع	2015	9789776483576	9776483577	https://covers.openlibrary.org/b/id/9514799-M.jpg	OL28052323M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7175	29	A Game of Thrones	\N	\N	Unknown	1996	9780006482758	0006482759	https://covers.openlibrary.org/b/id/10835972-M.jpg	OL32179316M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7176	29	A guerra dos tronos	por	BR	Leya	2010	9788562936524	8562936529	https://covers.openlibrary.org/b/id/7079752-M.jpg	OL25226226M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7177	29	A Game of Thrones	eng	\N	Bantam Books	2011	9780553386790	0553386794	https://covers.openlibrary.org/b/id/14818007-M.jpg	OL24844227M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7178	29	A Game of Thrones	eng	\N	Books on Tape	2003	9780736695930	0736695931	\N	OL9478797M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7179	29	A Game of Thrones	eng	\N	BCA	1996	\N	\N	https://covers.openlibrary.org/b/id/8132864-M.jpg	OL17217841M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7180	29	A Game of Thrones	eng	\N	Random House Audio	2004	9780739308684	0739308688	https://covers.openlibrary.org/b/id/467746-M.jpg	OL7914095M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7181	29	A Game of Thrones	eng	\N	Random House Publishing Group	2003	9780553897845	0553897845	\N	OL24283280M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7182	29	A Game of Thrones	eng	\N	Bantam Books	2005	9780553588491	0553588494	https://covers.openlibrary.org/b/id/14817997-M.jpg	OL7830296M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7183	29	Cluiche na Corónach	gle	\N	Leabhar Breac	2017	9781909907874	1909907871	https://covers.openlibrary.org/b/id/8056028-M.jpg	OL26368955M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7184	29	A Game of Thrones	eng	\N	Voyager / HarperCollins	1996	9780002245845	0002245841	https://covers.openlibrary.org/b/id/929-M.jpg	OL7255733M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7185	29	A Game of Thrones	\N	\N	Perfection Learning	1997	9781613832776	161383277X	https://covers.openlibrary.org/b/id/7700661-M.jpg	OL26087035M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7186	29	A Game of Thrones	eng	\N	Meisha Merlin Pub (P)	2002	9781892065292	1892065290	https://covers.openlibrary.org/b/id/940837-M.jpg	OL8718362M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7187	29	A Game of Thrones	eng	\N	Voyager	1998	9780006479888	000647988X	https://covers.openlibrary.org/b/id/8133514-M.jpg	OL9213872M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7188	29	A Game of Thrones	eng	\N	Random House Audio	2003	9781415900642	1415900647	https://covers.openlibrary.org/b/id/8133516-M.jpg	OL26425265M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7189	29	A Game of Thrones	eng	\N	Spectra	2005	9780553588484	0553588486	https://covers.openlibrary.org/b/id/373448-M.jpg	OL7830295M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7190	29	A Game of Thrones	eng	\N	Books on Tape	2004	9780739353370	0739353373	https://covers.openlibrary.org/b/id/8133530-M.jpg	OL26425278M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7191	29	A Guerra dos Tronos	por	BR	Leya	2010	9788580442786	8580442788	https://covers.openlibrary.org/b/id/8133582-M.jpg	OL26425327M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7192	29	Gra o tron	pol	\N	Zysk i S-ka Wydawnictwo	2011	9788375068306	8375068306	https://covers.openlibrary.org/b/id/7112944-M.jpg	OL25302821M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7193	29	Kampen om Tronen	dan	\N	Glydendal Lyd	2011	9788702125580	8702125587	https://covers.openlibrary.org/b/id/8133604-M.jpg	OL26425346M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7194	29	Juego de tronos	spa	\N	Vintage Español	2012	9780307951182	0307951189	https://covers.openlibrary.org/b/id/15255545-M.jpg	OL25140747M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7195	29	Kampen om järntronen	swe	\N	Bokförlaget Forum	2015	9789137139623	9137139622	https://covers.openlibrary.org/b/id/8134198-M.jpg	OL26425669M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7196	29	Juego de tronos	spa	\N	Gigamesh, S.L.	2012	9788496208926	8496208923	https://covers.openlibrary.org/b/id/7435075-M.jpg	OL25935251M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7197	29	A Game of Thrones	eng	\N	HarperVoyager	2011	9780007445721	\N	https://covers.openlibrary.org/b/id/8134206-M.jpg	OL26425671M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7198	29	A Game of Thrones	eng	\N	Bantam Books	2016	9780553593716	0553593714	https://covers.openlibrary.org/b/id/8134209-M.jpg	OL26425676M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7199	29	Juego de tronos	spa	\N	Gigamesh Digital	2014	9788416035106	\N	https://covers.openlibrary.org/b/id/8134233-M.jpg	OL26425699M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7200	29	Igra prestola	srp	\N	Laguna	2003	\N	\N	https://covers.openlibrary.org/b/id/8134235-M.jpg	OL26425703M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7201	29	A Game of Thrones	ind	\N	Fantasious	2015	9786020900292	\N	https://covers.openlibrary.org/b/id/8134236-M.jpg	OL26425705M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7202	29	A Game of Thrones	eng	\N	Bantam Books	2016	9780553808049	0553808044	https://covers.openlibrary.org/b/id/12373718-M.jpg	OL26425706M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7203	29	A Game of Thrones	eng	\N	Harper Voyager	2016	9780008209100	0008209103	https://covers.openlibrary.org/b/id/8134240-M.jpg	OL26425709M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7204	29	A Game of Thrones	eng	\N	Harper Voyager	2016	9780008249618	000824961X	https://covers.openlibrary.org/b/id/8134242-M.jpg	OL26425712M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7205	29	A Game of Thrones	eng	\N	Bantam Books	2016	9781101965870	1101965878	https://covers.openlibrary.org/b/id/8134251-M.jpg	OL26425720M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7206	29	Der Winter naht	deu	\N	GRRM by Penhaligon	2016	9783764531522	3764531525	https://covers.openlibrary.org/b/id/8134252-M.jpg	OL26425721M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7207	29	Le Trône de fer	fra	\N	Pygmalion	2012	9782756420363	2756420360	https://covers.openlibrary.org/b/id/8134655-M.jpg	OL26425979M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7208	29	Le Trône de Fer	fra	\N	Pygmalion	2012	9782756408101	2756408107	https://covers.openlibrary.org/b/id/8134658-M.jpg	OL26425980M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7209	29	A Game of Thrones	eng	\N	Harper Voyager	2017	9780007378425	0007378424	https://covers.openlibrary.org/b/id/8134688-M.jpg	OL26426005M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7210	29	A Game of Thrones	eng	\N	Turtleback Books	2013	9780606238434	0606238433	https://covers.openlibrary.org/b/id/14818010-M.jpg	OL26641908M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7211	29	Game of thrones,Book one of a song of ice and fire.	\N	\N	HarperCollins	1996	\N	\N	https://covers.openlibrary.org/b/id/14818004-M.jpg	OL26745451M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7212	29	Game of Thrones (Song of Ice and Fire)	\N	\N	Voyager	2011	9780007428540	0007428545	https://covers.openlibrary.org/b/id/8740396-M.jpg	OL27102457M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7213	29	A Game of Thrones	\N	\N	The Folio Society	2019	\N	\N	https://covers.openlibrary.org/b/id/8574578-M.jpg	OL26894156M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7214	29	Game of thrones	eng	\N	Random House Audio	2011	9780307913098	\N	\N	OL26942180M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7215	29	A Game Of Thrones	eng	\N	Bantam Spectra (US) Voyager Books (UK)	1996	\N	\N	https://covers.openlibrary.org/b/id/8382095-M.jpg	OL26724040M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7216	29	A Game of Thrones	\N	\N	HarperCollins Publishers	2011	9780007459483	0007459483	https://covers.openlibrary.org/b/id/8753464-M.jpg	OL27264224M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7219	29	Game of Thrones	\N	\N	Harper Voyager	2011	9780007441426	0007441428	https://covers.openlibrary.org/b/id/8791584-M.jpg	OL27325765M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7220	29	GAME OF THRONES-SONG OF ICE_HB	\N	\N	HARPER COLLINS PUBLISHERS	2016	9780008115401	0008115400	https://covers.openlibrary.org/b/id/8761441-M.jpg	OL27279185M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7221	29	A Game of Thrones: Book 1 of a Song of Ice and Fire	\N	\N	HarperCollins	2014	9780007548231	0007548230	https://covers.openlibrary.org/b/id/8785690-M.jpg	OL27314790M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7222	29	A Song of Ice and Fire - A Game of Thrones	\N	\N	HarperCollins UK	2013	9780007525980	0007525982	https://covers.openlibrary.org/b/id/9031121-M.jpg	OL27576788M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7223	29	A Game of Thrones: The 20th Anniversary Illustrated Edition [Hardcover] [Jan 01, 2016] George R. R. Martin	\N	\N	HARPER VOYAGER	2015	9780008228569	0008228566	https://covers.openlibrary.org/b/id/8773509-M.jpg	OL27295667M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
7224	29	A Game of Thrones	\N	\N	Gigamesh	2014	\N	\N	\N	OL31979920M	\N	2026-11-25 20:23:47.435492+00	2026-11-25 20:23:47.435492+00
8797	6	Chapter House Dune	eng	\N	Orion Publishing Group, Limited	2011	9780575104396	\N	\N	OL48143699M	\N	2026-11-25 20:24:37.596743+00	2026-11-25 20:24:37.596743+00
8798	6	Chapterhouse Dune (Dune Chronicles, Book 6)	\N	\N	Putnam Publishing Group	1985	9782010106057	2010106059	\N	OL44795338M	\N	2026-11-25 20:24:37.596743+00	2026-11-25 20:24:37.596743+00
8799	6	Dune Rahibeler Meclisi	tur	\N	Ithaki Yayinlari	2020	9786257737593	6257737591	https://covers.openlibrary.org/b/id/12258309-M.jpg	OL35416376M	\N	2026-11-25 20:24:37.596743+00	2026-11-25 20:24:37.596743+00
8800	6	Dune Rahibeler Meclisi	tur	\N	Kabalci Yayinevi	2017	9789759971892	9759971895	https://covers.openlibrary.org/b/id/12355456-M.jpg	OL35648559M	\N	2026-11-25 20:24:37.596743+00	2026-11-25 20:24:37.596743+00
8801	6	Casa Capitular / Chapterhouse Dune	spa	\N	Penguin Random House Grupo Editorial	2022	9788466359450	\N	https://covers.openlibrary.org/b/id/13233436-M.jpg	OL34987066M	\N	2026-11-25 20:24:37.596743+00	2026-11-25 20:24:37.596743+00
8802	6	Chapter House Dune	\N	\N	Orion Publishing Group, Limited	2021	9781473233812	147323381X	https://covers.openlibrary.org/b/id/11245392-M.jpg	OL32608569M	\N	2026-11-25 20:24:37.596743+00	2026-11-25 20:24:37.596743+00
8803	6	Chapterhouse Dune	eng	\N	Easton Press	1987	9780739452721	073945272X	https://covers.openlibrary.org/b/id/15202654-M.jpg	OL7916743M	\N	2026-11-25 20:24:37.596743+00	2026-11-25 20:24:37.596743+00
8804	6	Herdeiras de Duna	por	BR	Aleph	2021	9786586064254	\N	https://covers.openlibrary.org/b/id/15117940-M.jpg	OL59974732M	\N	2026-11-25 20:24:37.596743+00	2026-11-25 20:24:37.596743+00
8805	6	La Maison des mères	fra	\N	Pocket	2025	9782266350259	2266350250	https://covers.openlibrary.org/b/id/14895865-M.jpg	OL58634008M	\N	2026-11-25 20:24:37.596743+00	2026-11-25 20:24:37.596743+00
8806	6	La Maison des mères	fra	\N	Robert Laffont	2023	9782221270004	2221270002	https://covers.openlibrary.org/b/id/14856680-M.jpg	OL58335438M	\N	2026-11-25 20:24:37.596743+00	2026-11-25 20:24:37.596743+00
8807	6	Kapitularz Diuną	pol	\N	Dom Wydawniczy Rebis	2020	9788381887809	\N	https://covers.openlibrary.org/b/id/14613134-M.jpg	OL51567307M	\N	2026-11-25 20:24:37.596743+00	2026-11-25 20:24:37.596743+00
8808	6	La Maison des mères	fra	\N	Robert Laffont	2021	9782221252345	2221252349	https://covers.openlibrary.org/b/id/12873432-M.jpg	OL39473675M	\N	2026-11-25 20:24:37.596743+00	2026-11-25 20:24:37.596743+00
8809	6	La Maison des mères	fra	\N	Pocket	2001	9782266114011	2266114018	https://covers.openlibrary.org/b/id/980251-M.jpg	OL8890324M	\N	2026-11-25 20:24:37.596743+00	2026-11-25 20:24:37.596743+00
8810	6	Dune, tome 5 	fra	\N	Robert Laffont	2000	9782221092385	2221092384	https://covers.openlibrary.org/b/id/975097-M.jpg	OL8865904M	\N	2026-11-25 20:24:37.596743+00	2026-11-25 20:24:37.596743+00
8811	6	Chapterhouse	\N	\N	Demco Media	1999	9780606171045	0606171045	https://covers.openlibrary.org/b/id/14816258-M.jpg	OL32608573M	\N	2026-11-25 20:24:37.596743+00	2026-11-25 20:24:37.596743+00
8812	6	Chapterhouse Dune	\N	\N	Macmillan Audio	2009	9781427203175	1427203172	https://covers.openlibrary.org/b/id/10532957-M.jpg	OL31834378M	\N	2026-11-25 20:24:37.596743+00	2026-11-25 20:24:37.596743+00
8813	6	Chapterhouse Dune	\N	\N	\N	2008	9781439501658	1439501653	https://covers.openlibrary.org/b/id/11245388-M.jpg	OL32608565M	\N	2026-11-25 20:24:37.596743+00	2026-11-25 20:24:37.596743+00
8814	6	La maison des mères	\N	\N	FRONTISPICE <010737	1986	9782221049129	2221049128	https://covers.openlibrary.org/b/id/10486991-M.jpg	OL30688554M	\N	2026-11-25 20:24:37.596743+00	2026-11-25 20:24:37.596743+00
8815	6	Chapterhouse Dune	eng	\N	Penguin Random House	2020	9780593201770	\N	https://covers.openlibrary.org/b/id/14630296-M.jpg	OL29887741M	\N	2026-11-25 20:24:37.596743+00	2026-11-25 20:24:37.596743+00
8816	6	Die Ordensburg des Wüstenplaneten. Dune-Zyklus 6	\N	\N	\N	1985	9783453312227	3453312228	https://covers.openlibrary.org/b/id/10308365-M.jpg	OL28371039M	\N	2026-11-25 20:24:37.596743+00	2026-11-25 20:24:37.596743+00
8817	6	Dune - tome 7 La maison des mères	\N	\N	Pocket	2005	9782266158428	2266158422	https://covers.openlibrary.org/b/id/10211502-M.jpg	OL28286591M	\N	2026-11-25 20:24:37.596743+00	2026-11-25 20:24:37.596743+00
8818	6	Chapterhouse: Dune	\N	\N	Ace	2019	9780593098271	0593098277	https://covers.openlibrary.org/b/id/8580276-M.jpg	OL26973565M	\N	2026-11-25 20:24:37.596743+00	2026-11-25 20:24:37.596743+00
8819	6	Chapterhouse Dune (Dune Chronicles, Book 6)	eng	\N	Ace	1987	9780441102679	0441102670	https://covers.openlibrary.org/b/id/6451285-M.jpg	OL7524861M	\N	2026-11-25 20:24:37.596743+00	2026-11-25 20:24:37.596743+00
8820	6	Chapterhouse Dune (Dune Chronicles, Book 6)	eng	\N	Tandem Library	1999	9780808599623	0808599623	https://covers.openlibrary.org/b/id/4700174-M.jpg	OL7973971M	\N	2026-11-25 20:24:37.596743+00	2026-11-25 20:24:37.596743+00
8821	6	Chapterhouse Dune (Dune Chronicles, Book 6)	\N	\N	Books on Tape	1998	9780736643443	0736643443	https://covers.openlibrary.org/b/id/13167096-M.jpg	OL7893270M	\N	2026-11-25 20:24:37.596743+00	2026-11-25 20:24:37.596743+00
8822	6	Chapterhouse Dune (Dune Chronicles, Book 6)	\N	\N	Berkley Trade	1986	9780425092149	0425092143	https://covers.openlibrary.org/b/id/14816261-M.jpg	OL7502485M	\N	2026-11-25 20:24:37.596743+00	2026-11-25 20:24:37.596743+00
8823	6	Chapterhouse Dune (Dune Chronicles, Book 6)	eng	\N	Putnam Adult	1985	9780399130755	0399130756	https://covers.openlibrary.org/b/id/14816257-M.jpg	OL7470673M	\N	2026-11-25 20:24:37.596743+00	2026-11-25 20:24:37.596743+00
8824	6	Chapterhouse Dune (Dune Chronicles, Book 6)	\N	\N	Putnam Publishing Group	1985	9785550995686	5550995689	https://covers.openlibrary.org/b/id/14816259-M.jpg	OL9044912M	\N	2026-11-25 20:24:37.596743+00	2026-11-25 20:24:37.596743+00
8825	6	Die Ordensburg des Wüstenplaneten.	deu	\N	Heyne	2001	9783453186880	3453186885	https://covers.openlibrary.org/b/id/1009425-M.jpg	OL9041236M	\N	2026-11-25 20:24:37.596743+00	2026-11-25 20:24:37.596743+00
8826	6	Chapterhouse Dune Int	\N	\N	Berkley	\N	9780425086537	0425086534	https://covers.openlibrary.org/b/id/14816262-M.jpg	OL7502329M	\N	2026-11-25 20:24:37.596743+00	2026-11-25 20:24:37.596743+00
8827	6	Chapterhouse Dune36f	eng	\N	Ace	1987	9780441975846	0441975844	https://covers.openlibrary.org/b/id/13655395-M.jpg	OL10257321M	\N	2026-11-25 20:24:37.596743+00	2026-11-25 20:24:37.596743+00
8828	6	Casa Capitular: Dune/Chapterhouse 	spa	\N	Lectorum Pubns Inc (J)	1985	9788473863698	8473863690	\N	OL13280808M	\N	2026-11-25 20:24:37.596743+00	2026-11-25 20:24:37.596743+00
8829	6	Casa Capitular Dune/ Chafterhouse Dune	spa	\N	Debolsillo	2006	9788497597708	8497597702	https://covers.openlibrary.org/b/id/13869617-M.jpg	OL9154491M	\N	2026-11-25 20:24:37.596743+00	2026-11-25 20:24:37.596743+00
8830	6	Chapter house, Dune	eng	\N	Putnam	1985	\N	0399130276	https://covers.openlibrary.org/b/id/15142594-M.jpg	OL20514437M	\N	2026-11-25 20:24:37.596743+00	2026-11-25 20:24:37.596743+00
8831	6	Chapterhouse, Dune	eng	\N	Ace Books	2009	9780441017218	\N	https://covers.openlibrary.org/b/id/14614919-M.jpg	OL23224089M	\N	2026-11-25 20:24:37.596743+00	2026-11-25 20:24:37.596743+00
8832	6	Chapter House Dune	\N	\N	New English Library	1986	9780450058868	0450058867	https://covers.openlibrary.org/b/id/9256178-M.jpg	OL7569409M	\N	2026-11-25 20:24:37.596743+00	2026-11-25 20:24:37.596743+00
8914	8	Señor de los anillos 2 - Las dos torres +	spa	\N	Booket	2015	9789584246752	9584246755	https://covers.openlibrary.org/b/id/13484934-M.jpg	OL47107532M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8915	8	El Señor de los Anillos nº 02/03 Las Dos Torres	spa	\N	MINOTAURO	2022	9788445009604	8445009605	https://covers.openlibrary.org/b/id/13479619-M.jpg	OL47104361M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8916	8	Sagan om de två tornen	swe	\N	Norstedts Pocket	2003	9789172633421	9172633425	\N	OL45914929M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8917	8	Two towers	eng	\N	Houghton Mifflin	1955	\N	\N	https://covers.openlibrary.org/b/id/14349269-M.jpg	OL45329729M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8918	8	The two towers	eng	\N	Ace Books	\N	\N	\N	https://covers.openlibrary.org/b/id/14627082-M.jpg	OL45329737M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8919	8	The Two Towers	eng	\N	Ballantine Books	1969	\N	\N	https://covers.openlibrary.org/b/id/14626670-M.jpg	OL44790407M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8920	8	The Lord of the Rings : The Two Towers	\N	\N	Random House Audio	2002	9780739301180	0739301187	\N	OL44685585M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8921	8	Le seigneur des anneaux	fra	\N	Christian Bourgois editeur	2018	9782266282376	2266282379	https://covers.openlibrary.org/b/id/14625538-M.jpg	OL43511705M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8922	8	The Two Towers : The Classic Bestselling Fantasy Novel	\N	\N	HarperCollins	2021	9780008487317	0008487316	\N	OL43341467M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8923	8	Two Towers Being the Second Part of the Lord of T	\N	\N	Ballantine Books, New York	1965	\N	\N	\N	OL43308325M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8924	8	Two Towers Second Issue Cover By Tolkien	\N	\N	BALLANTINE BOOKS @	1965	\N	\N	\N	OL43039733M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8925	8	Sagan om de två tornen	swe	\N	Norstedts	2001	9789172632196	9172632194	https://covers.openlibrary.org/b/id/14625947-M.jpg	OL42981372M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8926	8	The Two Towers.	eng	\N	Ballantine Books	1965	\N	\N	https://covers.openlibrary.org/b/id/15084479-M.jpg	OL42954766M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8927	8	Le seigneur des anneaux T2 Les deux tours	fra	\N	BOURGOIS	2022	9782267046892	226704689X	https://covers.openlibrary.org/b/id/13481353-M.jpg	OL42950412M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8928	8	The Two Towers	eng	\N	HarperCollins Publishers	2005	9780007770113	0007770111	https://covers.openlibrary.org/b/id/14951352-M.jpg	OL42876459M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8929	8	SEÑor de LOS ANILLOS 2. Las Dos Torres (TV Tie-In). the LORD of the RINGS 2. the Two Towers (TV Tie-in) (Spanish Edition)	spa	\N	Editorial Planeta, S. A.	2022	9786070792397	\N	\N	OL39382835M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8930	8	The Two Towers Being the Second Part of the Lord of the Rings	\N	\N	Demco Media	1986	9780606015219	0606015213	\N	OL39219838M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8931	8	Two Towers (the Lord of the Rings, Book 2)	eng	\N	HarperCollins Publishers Limited	2022	9780008537784	\N	\N	OL38792904M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8932	8	The Two Towers	eng	\N	Del Rey	2022	9780593500491	\N	https://covers.openlibrary.org/b/id/14627524-M.jpg	OL38403115M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8933	8	The Two Towers	eng	\N	HarperCollins Publishers	2022	9780063270893	0008537739	https://covers.openlibrary.org/b/id/15244481-M.jpg	OL38060550M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8934	8	Two Towers	eng	\N	HarperCollins Publishers Limited	2022	9780008567132	\N	\N	OL38343182M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8935	8	Władca pierścieni. T. 2. Dwie wieże	pol	\N	Warszawskie Wydawnictwo Literackie Muza	2002	\N	8373191666	https://covers.openlibrary.org/b/id/12685163-M.jpg	OL37777547M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8936	8	The Lord of the Rings Two Towers	\N	\N	Harpercollins Pub Ltd	2001	9780007127436	000712743X	\N	OL37668404M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8937	8	Les deux tours	fra	\N	Christian Bourgois Editeur	2015	9782267028911	2267028913	https://covers.openlibrary.org/b/id/13258229-M.jpg	OL37348579M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8938	8	Two Towers	eng	\N	Houghton Mifflin Harcourt Trade & Reference Publishers	2012	9781299884922	\N	\N	OL37176888M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8939	8	Two Towers	eng	\N	HarperCollins Publishers Limited	2022	9780008537739	\N	\N	OL37341923M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8940	8	Two Towers	eng	\N	HarperCollins Publishers	2009	9780061917974	\N	\N	OL37359688M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8941	8	Two Towers	eng	\N	HarperCollins Publishers	2009	9780061917967	\N	\N	OL37367326M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8942	8	Two Towers	eng	\N	HarperCollins Publishers	2009	9780061917950	\N	\N	OL37371067M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8943	8	Two Towers	eng	\N	HarperCollins Publishers	2009	9780061917943	\N	\N	OL37374820M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8944	8	The Two Towers	eng	\N	Recorded Books, Inc.	2021	9781705047613	1705047610	https://covers.openlibrary.org/b/id/12374479-M.jpg	OL35672197M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8945	8	The Two Towers	\N	\N	HighBridge Audio	2002	9781565116689	1565116682	\N	OL37935596M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8946	8	senor de los anillos	spa	\N	HarperCollins Publishers	2009	9780061756108	\N	\N	OL37370219M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8947	8	Il Signore degli anelli vol.2. Le due torri.	ita	\N	\N	2020	9788830102712	8830102717	https://covers.openlibrary.org/b/id/10632549-M.jpg	OL31951227M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8948	8	Las dos torres	spa	\N	Minotauro	2002	\N	8445073737	https://covers.openlibrary.org/b/id/10612041-M.jpg	OL31929387M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8949	8	Le Seigneur Des Anneaux Tome 2	fra	\N	Pocket/Presses Pocket	1986	9782266017527	2266017527	https://covers.openlibrary.org/b/id/10501930-M.jpg	OL30786543M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8950	8	指輪物語 第2部 二つの塔	jpn	\N	unknown	1992	9784566023512	4566023516	https://covers.openlibrary.org/b/id/10363198-M.jpg	OL28946809M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8951	8	The two towers	eng	\N	HarperCollins	1993	\N	\N	\N	OL19519470M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8952	8	The Two Towers	eng	\N	Grafton	1991	\N	0261102362	https://covers.openlibrary.org/b/id/14625772-M.jpg	OL51694031M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8953	8	The Two Towers	eng	\N	Guild Publishing	1988	\N	\N	https://covers.openlibrary.org/b/id/15207785-M.jpg	OL51711624M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8954	8	The Two Towers	eng	\N	Houghton Mifflin Company	\N	\N	\N	https://covers.openlibrary.org/b/id/14627564-M.jpg	OL51711454M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8955	8	The Two Towers	eng	\N	Quality Paperback Book Club	2001	9780739478080	\N	https://covers.openlibrary.org/b/id/14627219-M.jpg	OL51709270M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8956	8	The Two Towers	eng	\N	Ballantine Books	1966	\N	\N	https://covers.openlibrary.org/b/id/14627078-M.jpg	OL51708814M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8957	8	The Two Towers	eng	\N	Ballantine Books	1970	\N	\N	https://covers.openlibrary.org/b/id/14627068-M.jpg	OL51708763M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8958	8	The Two Towers	eng	\N	George Allen & Unwin Ltd	1963	\N	\N	https://covers.openlibrary.org/b/id/14627061-M.jpg	OL51708695M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8959	8	De to tårne	dan	\N	Gyldendal	2021	9788702347029	\N	https://covers.openlibrary.org/b/id/14627049-M.jpg	OL51708584M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9161	10	Lord of the Rings : Appendices	eng	\N	HarperCollins Publishers Limited	2001	9780007635566	\N	\N	OL44095980M	\N	2026-11-25 20:24:51.545748+00	2026-11-25 20:24:51.545748+00
8960	8	O Senhor dos Anéis: As duas torres	por	BR	Harper Collins	2019	9788595084766	8595084769	https://covers.openlibrary.org/b/id/15129593-M.jpg	OL51693970M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8961	8	In de ban van de ring II	nld	\N	Uitgeverij Het Spectrum	1976	\N	9027401691	https://covers.openlibrary.org/b/id/14625600-M.jpg	OL51693700M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8962	8	The two towers	eng	\N	Houghton Mifflin Co.	1986	\N	0395489334	https://covers.openlibrary.org/b/id/255849-M.jpg	OL2131709M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8963	8	Le Seigneur des Anneaux, tome 2 	fra	\N	Gallimard Jeunesse	1999	9782070522682	2070522687	https://covers.openlibrary.org/b/id/969327-M.jpg	OL8840039M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8964	8	The Two Towers	eng	\N	Ballantine Books	2001	\N	0345339711	https://covers.openlibrary.org/b/id/14624641-M.jpg	OL51688554M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8965	8	Le seigneur des anneaux	fra	\N	Christian Bourgois Editeur	2003	\N	2266132385	https://covers.openlibrary.org/b/id/14624293-M.jpg	OL51687486M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8966	8	Les Dos Torres	ast	\N	Ediciones Trabe	2022	9788419358028	\N	https://covers.openlibrary.org/b/id/14541636-M.jpg	OL49829878M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8967	8	Dvě Věže	ces	\N	Argo	2011	9788025705735	\N	\N	OL49200748M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8968	8	Die zwei Türme	deu	\N	Klett-Cotta	2002	\N	3608955372	https://covers.openlibrary.org/b/id/13133754-M.jpg	OL45498513M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8969	8	Der Herr der Ringe	deu	\N	Klett-Cotta Hobbit Presse	\N	9783129081907	3129081909	https://covers.openlibrary.org/b/id/8773923-M.jpg	OL27296256M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8970	8	Der Herr der Ringe	deu	\N	Klett-Cotta	2001	9783608955378	3608955372	\N	OL9076676M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8971	8	The Two Towers	eng	\N	HarperCollins Publishers	2010	9780007887675	0007887671	https://covers.openlibrary.org/b/id/12617859-M.jpg	OL37038870M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8972	8	The Two Towers	eng	\N	HarperCollins Publishers	1999	9780261102361	0261102362	https://covers.openlibrary.org/b/id/12513026-M.jpg	OL36619907M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8973	8	The Two Towers	eng	\N	HarperCollins	2008	9780007269716	0007269714	https://covers.openlibrary.org/b/id/12313592-M.jpg	OL35606917M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8974	8	Two Towers (the Lord of the Rings, Book 2)	eng	\N	HarperCollins Publishers Limited	2020	9780008376079	\N	https://covers.openlibrary.org/b/id/12398015-M.jpg	OL35542424M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8975	8	Two Towers	eng	\N	Houghton Mifflin Harcourt Publishing Company	2004	9781484490334	\N	\N	OL34091192M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8976	8	The Two Towers	eng	\N	Houghton Mifflin Company	1978	9780395082553	0395082552	https://covers.openlibrary.org/b/id/12451484-M.jpg	OL35716307M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8977	8	The Two Towers	eng	\N	Collins	2001	9780007680849	0007680848	https://covers.openlibrary.org/b/id/12373908-M.jpg	OL35616696M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8978	8	The Two Towers	eng	\N	Ballantine Books	1970	\N	\N	https://covers.openlibrary.org/b/id/12074893-M.jpg	OL35260301M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8979	8	El señor de los anillos	spa	\N	Minotauro	2002	9789706906526	9706906525	https://covers.openlibrary.org/b/id/12003391-M.jpg	OL33892053M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8980	8	The Two Towers Lib/E	\N	\N	HighBridge Audio	2021	9781665170994	1665170999	https://covers.openlibrary.org/b/id/10680138-M.jpg	OL32013724M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8981	8	El señor de los anillos II : las dos torres (2019)	\N	\N	Planeta Colombiana Editorial	2019	9789584280343	\N	https://covers.openlibrary.org/b/id/10511329-M.jpg	OL31013747M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8982	8	El Señor de los Anillos II. Las Dos Torres	\N	\N	Booket	2012	9788445000670	8445000675	https://covers.openlibrary.org/b/id/10506400-M.jpg	OL30903261M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8983	8	The Two Towers	bul	\N	Bard	2002	\N	9545853476	https://covers.openlibrary.org/b/id/11222997-M.jpg	OL32582179M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8984	8	Die Twee Torings	afr	\N	Protea Boekhuis	2019	9781485309765	148530976X	https://covers.openlibrary.org/b/id/10650935-M.jpg	OL31973621M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8985	8	Dwie Wieże	pol	\N	Zysk i S-ka	1997	9788371502422	8371502427	https://covers.openlibrary.org/b/id/10587086-M.jpg	OL31905985M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8986	8	The Two Towers	eng	\N	HarperCollins Publishers	2005	9780007203598	0007203594	https://covers.openlibrary.org/b/id/14573413-M.jpg	OL31905966M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8987	8	The Two Towers	eng	\N	Houghton Mifflin Company	\N	\N	\N	https://covers.openlibrary.org/b/id/14624658-M.jpg	OL31879906M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8988	8	The Two Towers	eng	\N	Mariner Books | Houghton Mifflin Harcourt	2020	9780358380245	0358380243	https://covers.openlibrary.org/b/id/12639911-M.jpg	OL29848960M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8989	8	The Lord of the Rings Part II - The Two Towers	\N	\N	HarperCollins Publishers Ltd	1996	9780261103399	0261103393	https://covers.openlibrary.org/b/id/10457086-M.jpg	OL30515689M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8990	8	Two Towers	eng	\N	Houghton Mifflin Harcourt Publishing Company	2012	9780547952024	\N	\N	OL29651668M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8991	8	The Two Towers	eng	\N	HarperCollins Publishers Limited	2020	9780008376130	\N	https://covers.openlibrary.org/b/id/15101803-M.jpg	OL29486367M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8992	8	Le seigneur des anneaux	fra	\N	Christian Bourgois editeur	1990	9782266026567	2266026569	https://covers.openlibrary.org/b/id/14625962-M.jpg	OL28342654M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8993	8	De Twee Torens	nld	\N	De Boekerij	2002	9789022531945	9022531945	https://covers.openlibrary.org/b/id/15149792-M.jpg	OL28345237M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8994	8	The Two Towers	eng	\N	HarperCollins	2012	9780007488322	0007488327	https://covers.openlibrary.org/b/id/10519441-M.jpg	OL28343164M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8995	8	Les Deux Tours	fra	\N	Pocket	1991	9782266107990	2266107992	https://covers.openlibrary.org/b/id/10290894-M.jpg	OL28342664M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8996	8	Le Seigneur des Anneaux 2 - Les Deux Tours	\N	\N	Pocket	2005	9782266154130	2266154133	https://covers.openlibrary.org/b/id/10293430-M.jpg	OL28345065M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8997	8	Lord of the Rings	\N	\N	HarperCollins Publishers Ltd	1992	9780261102934	0261102931	https://covers.openlibrary.org/b/id/10290014-M.jpg	OL28341707M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8998	8	The Two Towers	spa	\N	Texto Online	2001	\N	\N	\N	OL28162239M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
8999	8	The Two Towers	eng	\N	HarperCollins UK Audio	2005	9780007228393	0007228392	https://covers.openlibrary.org/b/id/9306363-M.jpg	OL27929032M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9000	8	Vlastelin kolets. Trilogiya. Kniga 2. Dve tverdyni (Vneklassnoe chtenie)	rus	\N	AST	2004	\N	517026416X	\N	OL12541183M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9001	8	Lord of the Rings. Trilogy. T. 2. Two strongholds / Vlastelin Kolets. Trilogiya. T. 2. Dve tverdyni	\N	\N	AST	2010	9785170675661	5170675666	https://covers.openlibrary.org/b/id/8575696-M.jpg	OL26913980M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9002	8	Mo jie er bu qu	zho	\N	Lian jing chu ban shi ye gong si	2012	9789570841015	957084101X	\N	OL27194456M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9003	8	The Two Towers	eng	\N	Houghton Mifflin Company	1993	9780395489338	0395489334	https://covers.openlibrary.org/b/id/9293885-M.jpg	OL27925420M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9004	8	The Two Towers	eng	\N	Houghton Mifflin Company	2002	9780618260270	0618260277	https://covers.openlibrary.org/b/id/9260088-M.jpg	OL27905605M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9005	8	Mo jie er bu qu	zho	\N	Lian jing chu ban shi ye gong si	2001	\N	9570823372	\N	OL23041747M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9006	8	The Two Towers	eng	\N	Houghton Mifflin Company	2001	9780618153992	0618153993	https://covers.openlibrary.org/b/id/8478134-M.jpg	OL7604000M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9007	8	The Two Towers	eng	\N	Ballantine Books	1974	9780345240330	0345240332	\N	OL10682119M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9008	8	The Two Towers	eng	\N	ISIS Large Print Books	1991	9781850894193	1850894191	\N	OL8969577M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9009	8	The Two Towers	eng	\N	Ballantine Books	1975	9780345248282	0345248287	https://covers.openlibrary.org/b/id/8167575-M.jpg	OL10682348M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9010	8	Dwie wieze	pol	\N	Zysk i S-ka	2001	9788372981134	8372981132	\N	OL16202838M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9011	8	The Two Towers	eng	\N	George Allen & Unwin	1967	\N	\N	https://covers.openlibrary.org/b/id/8166962-M.jpg	OL19740951M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9012	8	The Two Towers	eng	\N	Houghton Mifflin	1994	9780618002238	0618002235	https://covers.openlibrary.org/b/id/14624623-M.jpg	OL7603170M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9013	8	The Two Towers	eng	\N	Thorndike Press	2003	9780786251759	0786251751	https://covers.openlibrary.org/b/id/541022-M.jpg	OL3682821M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9014	8	The Two Towers	eng	\N	HarperCollins	2009	9780007322503	000732250X	https://covers.openlibrary.org/b/id/8169531-M.jpg	OL24266927M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9015	8	The Two Towers	eng	\N	Ballantine Books	1985	9780345332103	0345332105	https://covers.openlibrary.org/b/id/8168122-M.jpg	OL10684790M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9016	8	The Two Towers	eng	\N	Houghton Mifflin	2004	9780618574957	0618574956	https://covers.openlibrary.org/b/id/8169214-M.jpg	OL7605825M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9017	8	The Two Towers	eng	\N	Ballantine Books	1982	9780345296061	0345296060	https://covers.openlibrary.org/b/id/9260074-M.jpg	OL24371522M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9018	8	Dwie wieże	pol	\N	Czytelnik	1990	9788385100089	8385100083	\N	OL22944871M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9019	8	The Two Towers	eng	\N	Ballantine Books	1999	9780345917447	0345917448	\N	OL10686523M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9020	8	The Two Towers	eng	\N	Houghton Mifflin Company	2002	9780618129089	0618129081	https://covers.openlibrary.org/b/id/8554936-M.jpg	OL24935342M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9021	8	Две твердыни	rus	\N	Raduga	1990	9785050023971	5050023971	https://covers.openlibrary.org/b/id/14338259-M.jpg	OL21898446M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9022	8	The Two Towers	eng	\N	Methuen / Magnum	1977	9780458907601	045890760X	\N	OL7591510M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9023	8	The Two Towers	eng	\N	Recorded Books	1990	9780788739583	0788739581	\N	OL8151470M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9024	8	The Two Towers	eng	\N	Ballantine Books	1976	9780345253446	0345253442	https://covers.openlibrary.org/b/id/14624451-M.jpg	OL10682514M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9025	8	The Two Towers	eng	\N	Guild Publishing	1987	\N	\N	\N	OL17847198M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9026	8	The Two Towers	eng	\N	Houghton, Mifflin	2002	9780618260591	0618260595	https://covers.openlibrary.org/b/id/14624664-M.jpg	OL3777335M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9027	8	The Two Towers	eng	\N	HarperCollins Publishers	1991	9780261102323	026110232X	https://covers.openlibrary.org/b/id/14625749-M.jpg	OL10236388M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9028	8	The Two Towers	eng	\N	Ted Smart	1997	9780007637690	0007637691	https://covers.openlibrary.org/b/id/14625547-M.jpg	OL19134227M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9029	8	The Two Towers	eng	\N	HarperCollins	2009	9780061917929	0061952893	https://covers.openlibrary.org/b/id/8169553-M.jpg	OL24284966M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9030	8	The Two Towers	eng	\N	Ballantine Books	1973	9780345235107	034523510X	https://covers.openlibrary.org/b/id/14624639-M.jpg	OL10681987M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9031	8	As duas Torres	por	PT	Europa-America	2002	9789721041448	9721041440	\N	OL18774656M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9032	8	The Two Towers	eng	\N	Houghton Mifflin	1981	9780395312667	0395312663	https://covers.openlibrary.org/b/id/8167614-M.jpg	OL3848669M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9033	8	The Two Towers	eng	\N	HarperCollins Publishers	1997	9780261103580	026110358X	https://covers.openlibrary.org/b/id/14624433-M.jpg	OL10236418M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9034	8	Die zwei Türme	deu	\N	Klett-Cotta	2000	9783608935424	3608935428	\N	OL22106812M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9035	8	The Two Towers	eng	\N	Ballantine Books	1978	9780345272591	0345272595	https://covers.openlibrary.org/b/id/15254148-M.jpg	OL10682855M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9036	8	The Two Towers	eng	\N	G. Allen & Unwin	1966	\N	\N	https://covers.openlibrary.org/b/id/8166960-M.jpg	OL16007738M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9037	8	The Two Towers	eng	\N	Houghton Mifflin Company	1982	9780395272220	039527222X	https://covers.openlibrary.org/b/id/8167605-M.jpg	OL26446449M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9038	8	The Two Towers	eng	\N	George Allen & Unwin	1955	\N	\N	https://covers.openlibrary.org/b/id/8166954-M.jpg	OL26446086M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9039	8	A Ket Torony	hun	\N	Gondolat	1981	9789632809649	9632809645	\N	OL13103888M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9040	8	The Two Towers	eng	\N	Ballantine Books	1972	\N	\N	https://covers.openlibrary.org/b/id/8167235-M.jpg	OL26446263M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9041	8	The Two Towers	eng	\N	Unwin Books	1974	9780048231130	0048231134	\N	OL22830376M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9042	8	Dvije kule	hrv	\N	Algoritam	2005	9789532202809	9532202803	https://covers.openlibrary.org/b/id/8076571-M.jpg	OL26383805M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9043	8	The Two Towers	eng	\N	Unwin Paperbacks	1981	9780048231864	004823186X	\N	OL9228712M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9044	8	The Two Towers	eng	\N	George Allen & Unwin	1974	9780048230461	0048230464	https://covers.openlibrary.org/b/id/8167185-M.jpg	OL26446228M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9045	8	The Two Towers	eng	\N	George Allen & Unwin	1954	\N	\N	https://covers.openlibrary.org/b/id/8166952-M.jpg	OL19604318M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9046	8	The Two Towers	eng	\N	Ballantine Books	1970	9780345020208	0345020200	https://covers.openlibrary.org/b/id/8167582-M.jpg	OL26446436M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9047	8	The Two Towers	eng	\N	George Allen & Unwin	1963	\N	\N	https://covers.openlibrary.org/b/id/8166957-M.jpg	OL26446090M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9048	8	The Two Towers	eng	\N	Ballantine Books	1965	\N	\N	https://covers.openlibrary.org/b/id/8167233-M.jpg	OL26446091M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9049	8	The Two Towers	eng	\N	George Allen & Unwin	1954	\N	\N	\N	OL26446087M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9162	10	Appendices	\N	\N	HarperCollins	1999	9780261103993	0261103997	\N	OL42939828M	\N	2026-11-25 20:24:51.545748+00	2026-11-25 20:24:51.545748+00
9050	8	The Two Towers	eng	\N	Unwin Paperbacks	1979	9780048231567	0048231568	https://covers.openlibrary.org/b/id/13367057-M.jpg	OL22646050M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9051	8	The Two Towers	eng	\N	Readers Union / George Allen & Unwin	1960	\N	\N	https://covers.openlibrary.org/b/id/8166956-M.jpg	OL26446088M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9052	8	The Two Towers	eng	\N	HarperCollins	2003	9780007171989	0007171986	\N	OL16008007M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9053	8	The Two Towers	eng	\N	Houghton Mifflin Company	1967	\N	\N	https://covers.openlibrary.org/b/id/8167136-M.jpg	OL26446094M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9054	8	De Twee Torens	nld	\N	Het Spectrum	1979	9789027401694	9027401691	https://covers.openlibrary.org/b/id/7070708-M.jpg	OL25209457M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9055	8	The Two Towers	eng	\N	Ballantine Books	1972	9780345015341	0345015347	\N	OL26446269M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9056	8	Le seigneur des anneaux	fra	\N	Christian Bourgois	1984	9782253012085	2253012084	https://covers.openlibrary.org/b/id/14626125-M.jpg	OL26446256M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9057	8	The Two Towers	eng	\N	George Allen & Unwin	1969	\N	\N	https://covers.openlibrary.org/b/id/8167154-M.jpg	OL26446198M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9058	8	Las dos torres	spa	\N	Minotauro	2001	9788445070345	8445070347	https://covers.openlibrary.org/b/id/8167607-M.jpg	OL9131847M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9059	8	The Two Towers	eng	\N	George Allen & Unwin / Houghton Mifflin Company	1962	\N	\N	\N	OL26446089M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9060	8	The Two Towers	eng	\N	Ballantine Books	1975	9780345247865	0345247868	https://covers.openlibrary.org/b/id/14628225-M.jpg	OL26446437M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9061	8	The Two Towers	eng	\N	The Folio Society	1977	\N	\N	https://covers.openlibrary.org/b/id/8167223-M.jpg	OL13893007M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9062	8	The Two Towers	eng	\N	Houghton Mifflin Company	1955	\N	\N	https://covers.openlibrary.org/b/id/8167231-M.jpg	OL26446259M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9063	8	The Two Towers	eng	\N	Quality Paperback Book Club	1995	\N	\N	https://covers.openlibrary.org/b/id/8168268-M.jpg	OL26446957M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9064	8	The Two Towers	eng	\N	Tandem Library	1999	9780808520900	0808520903	https://covers.openlibrary.org/b/id/4988150-M.jpg	OL9561008M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9065	8	The Two Towers	eng	\N	Tandem Library	1999	9781417618408	141761840X	\N	OL8459058M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9066	8	Dve kule	hrv	\N	Rubikon	2002	9788673480688	867348068X	\N	OL19112577M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9067	8	The Two Towers	eng	\N	Houghton Mifflin Company	1982	\N	\N	https://covers.openlibrary.org/b/id/14628171-M.jpg	OL26446809M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9068	8	Les Deux Tours	fra	\N	Pocket	2002	9782266127929	2266127926	https://covers.openlibrary.org/b/id/2154095-M.jpg	OL9507942M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9069	8	The Two Towers	eng	\N	Ballantine Books	1988	9780345008633	0345008634	\N	OL9648045M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9070	8	雙城奇謀	zho	\N	Tsai Fong Books, Inc	2001	9789570823370	9570823372	\N	OL13059227M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9071	8	Las dos torres	spa	\N	Minotauro	2002	9788445071762	8445071769	https://covers.openlibrary.org/b/id/1047629-M.jpg	OL9131886M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9072	8	As Duas Torres	por	\N	\N	\N	9788483028261	8483028263	\N	OL13320854M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9073	8	魔戒	zho	\N	Yilin Chu Ban She	2001	9787806572665	780657266X	https://covers.openlibrary.org/b/id/9293874-M.jpg	OL13100881M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9074	8	The Two Towers	eng	\N	HarperCollins	2002	9780007149223	0007149220	https://covers.openlibrary.org/b/id/9218595-M.jpg	OL26447417M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9075	8	Las dos torres	spa	\N	Minotauro	2001	9789505470655	9505470657	https://covers.openlibrary.org/b/id/4912759-M.jpg	OL9137996M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9076	8	Las dos torres	spa	\N	French & European Pubns	2000	9780828869027	0828869022	\N	OL11461846M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9077	8	Le Seigneur des anneaux	fra	\N	Christian Bourgois editeur	1972	9782266046503	2266046500	https://covers.openlibrary.org/b/id/14625961-M.jpg	OL8889790M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9078	8	The Two Towers	eng	\N	Recorded Books	1979	9781556903229	1556903227	\N	OL9823508M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9079	8	Les Deux Tours	fra	\N	Pocket	2001	9782266118019	2266118013	https://covers.openlibrary.org/b/id/980300-M.jpg	OL8890372M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9080	8	Die zwei Türme	deu	\N	Klett-Cotta	2002	9783608934021	3608934022	https://covers.openlibrary.org/b/id/2233077-M.jpg	OL9377957M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9081	8	Les deux tours	fra	\N	Christian Bourgois editeur	1995	9782266070607	2266070606	https://covers.openlibrary.org/b/id/14625984-M.jpg	OL8889881M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9082	8	Le Due Torri	ita	\N	French & European Pubns	2002	9780828879767	0828879761	\N	OL11462327M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9083	8	The Two Towers	eng	\N	Perfection Learning	1978	9780812417852	0812417852	\N	OL11346374M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9084	8	The Two Towers	eng	\N	Harper	2002	9780007141302	0007141300	https://covers.openlibrary.org/b/id/8168684-M.jpg	OL9216863M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9085	8	Le due Torri	ita	\N	Bompiani	2000	9788845290428	8845290425	\N	OL24591556M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9086	8	Le seigneur des anneaux	fra	\N	Christian Bourgois editeur	2002	9782266120982	2266120980	https://covers.openlibrary.org/b/id/14626639-M.jpg	OL8890401M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9087	8	The Two Towers	eng	\N	Easton Press	1984	\N	\N	https://covers.openlibrary.org/b/id/8167652-M.jpg	OL26446483M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9088	8	The Two Towers	eng	\N	Collins	2001	9780007129713	0007129718	https://covers.openlibrary.org/b/id/14624674-M.jpg	OL7261843M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9089	8	The Two Towers	eng	\N	Houghton Mifflin	1991	9780395647394	0395647398	https://covers.openlibrary.org/b/id/256237-M.jpg	OL7467154M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9090	8	The Two Towers	eng	\N	HarperCollins	2002	9780007136568	0007136560	https://covers.openlibrary.org/b/id/8168944-M.jpg	OL26447308M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9091	8	The Two Towers	eng	\N	Quality Paperback Book Club	2001	9780965307819	0965307816	https://covers.openlibrary.org/b/id/10555427-M.jpg	OL26447189M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9092	8	The Two Towers	eng	\N	Recorded Books	2001	9780788789540	0788789546	https://covers.openlibrary.org/b/id/549853-M.jpg	OL8151613M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9093	8	Iki kule	tur	\N	Metis Yayinlari	1999	9789753421812	9753421818	\N	OL18363260M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9094	8	Las dos torres	spa	\N	Hermes Editorial	1994	9789684461130	9684461135	\N	OL9174564M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9095	8	The Two Towers	eng	\N	Houghton Mifflin Harcourt	2014	9780544449732	0544449738	https://covers.openlibrary.org/b/id/8170131-M.jpg	OL26314661M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9096	8	Les deux tours	fra	\N	Christian Bourgois éditeur	2015	9782267028928	2267028921	https://covers.openlibrary.org/b/id/13259087-M.jpg	OL26447983M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9097	8	The Two Towers	eng	\N	Large Print Press	2003	9781594130069	159413006X	https://covers.openlibrary.org/b/id/8478169-M.jpg	OL8875467M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9098	8	Две Твердыни	rus	\N	AST - Terra Fantastica	2000	9785170011803	5170011806	https://covers.openlibrary.org/b/id/13208949-M.jpg	OL12536750M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9099	8	Bi dorreak	eus	\N	Txalaparta	2003	9788481362602	8481362603	https://covers.openlibrary.org/b/id/8169190-M.jpg	OL26447422M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9100	8	Les deux tours	fra	\N	Gallimard	1988	9782070334810	2070334813	\N	OL22819322M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9101	8	The two towers	eng	\N	Houghton Mifflin	1954	\N	\N	\N	OL26885825M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9102	8	Die Zwei Türme	deu	\N	J.G. Cotta'sche, Buchhandlung Nachfolger GmbH	2002	9783608933529	3608933522	https://covers.openlibrary.org/b/id/1023157-M.jpg	OL9076578M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9103	8	Le Due Torri	ita	\N	French & European Pubns	2002	9780828866057	0828866058	\N	OL11461669M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9104	8	Dwie wieze	pol	\N	Literackie	2003	9788373194229	8373194223	\N	OL16418952M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9105	8	The Two Towers	\N	\N	Harpercollins	2002	9780007522910	0007522916	https://covers.openlibrary.org/b/id/9032031-M.jpg	OL27577748M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9106	8	O Senhor dos Anéis	por	BR	Martins Fontes	2000	9788533613386	8533613385	https://covers.openlibrary.org/b/id/8169164-M.jpg	OL9158210M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9107	8	Две твердыни	rus	\N	AST	2003	9785170162758	5170162758	\N	OL12538902M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9108	8	The Two Towers	eng	\N	Mariner Books / Houghton Mifflin Harcourt	1994	9780547928203	0547928203	https://covers.openlibrary.org/b/id/14625715-M.jpg	OL26447667M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9109	8	De to tårne	dan	\N	Gyldendal	2010	9788702093704	8702093707	https://covers.openlibrary.org/b/id/8169556-M.jpg	OL26447662M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9110	8	The two towers	eng	\N	Unwin Paperbacks	1974	\N	0048232297	https://covers.openlibrary.org/b/id/10289930-M.jpg	OL26535641M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9111	8	The Two Towers	eng	\N	HarperCollins	2001	9780007123834	0007123833	https://covers.openlibrary.org/b/id/14625721-M.jpg	OL27302580M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9112	8	The Two Towers	eng	\N	Recorded Books	2001	9780788789830	078878983X	https://covers.openlibrary.org/b/id/549861-M.jpg	OL8151618M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9113	8	The Two Towers	\N	\N	Quality Paperback Book Club	2001	9780007117123	0007117124	https://covers.openlibrary.org/b/id/8762919-M.jpg	OL27281065M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9114	8	Las dos torres	spa	\N	Planeta Pub Corp	2004	9789703701698	9703701698	\N	OL13152178M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9115	8	Las dos torres	spa	\N	Booket	2006	9788445075746	8445075748	https://covers.openlibrary.org/b/id/8169217-M.jpg	OL9483752M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9116	8	The Two Towers	eng	\N	Houghton Mifflin Company	2003	9780618346264	0618346260	https://covers.openlibrary.org/b/id/14624667-M.jpg	OL26447421M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9117	8	As duas torres	por	BR	Martins Fontes - Selo Martins	2013	9788580631029	8580631025	https://covers.openlibrary.org/b/id/8170083-M.jpg	OL26447957M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9118	8	Las dos torres	spa	\N	Ediciones Minotauro	2002	9788439596226	8439596227	https://covers.openlibrary.org/b/id/7284723-M.jpg	OL25492567M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9119	8	The Two Towers	eng	\N	Houghton Mifflin Company	2008	9780544087422	0544087429	https://covers.openlibrary.org/b/id/8200183-M.jpg	OL26466506M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9120	8	Die zwei Türme	deu	\N	Klett-Cotta	2012	9783608939828	3608939822	https://covers.openlibrary.org/b/id/8170090-M.jpg	OL26447964M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9121	8	The Two Towers	eng	\N	Recorded Books	2011	9781461836155	1461836158	https://covers.openlibrary.org/b/id/8169564-M.jpg	OL26447664M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9122	8	The Two Towers	ind	\N	Gramedia Pustaka Utama	2016	9786020332277	6020332276	https://covers.openlibrary.org/b/id/8170123-M.jpg	OL26447986M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9123	8	Dwie Wieze	pol	\N	Czytelnik	1990	9788307021737	8307021731	\N	OL19685555M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9124	8	Les Deux Tours	fra	\N	Christian Bourgois	1983	9782267001976	2267001977	https://covers.openlibrary.org/b/id/3108291-M.jpg	OL12510811M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9125	8	Dwie wieże	pol	\N	Czytelnik	1990	\N	\N	\N	OL26905588M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9126	8	As Duas Torres	por	BR	Martins Fontes	2002	9788533615564	8533615566	https://covers.openlibrary.org/b/id/8169161-M.jpg	OL9158226M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9127	8	Les Deux Tours	fra	\N	French & European Pubns	2000	9780828810760	0828810761	\N	OL11458616M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9128	8	Die Zwei Turme	deu	\N	French & European Pubns	2002	9780828808880	0828808880	\N	OL8171836M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9129	8	Die zwei Türme	deu	\N	Klett-Cotta	1972	9783608107142	3608107142	https://covers.openlibrary.org/b/id/8170100-M.jpg	OL26447965M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9130	8	וואס איז דער צוויטער טייל פון דער האר פון די פינגערלעך	yid	\N	Createspace	2015	9781512129038	1512129038	https://covers.openlibrary.org/b/id/8170122-M.jpg	OL26447985M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9131	8	Dwie Wieże	pol	\N	Wydawnictwo Amber	2009	9788324132874	\N	https://covers.openlibrary.org/b/id/8457572-M.jpg	OL26801971M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9132	8	Les Deux Tours	fra	\N	Gallimard	1980	9782070501410	2070501418	https://covers.openlibrary.org/b/id/2137405-M.jpg	OL9678474M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9133	8	The Two Towers	eng	\N	HarperCollins	2012	9780007488339	0007488335	https://covers.openlibrary.org/b/id/10511010-M.jpg	OL26447954M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9134	8	The Two Towers	eng	\N	HarperCollins	2014	9780008108304	0008108307	https://covers.openlibrary.org/b/id/8170108-M.jpg	OL26447968M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9135	8	The Two Towers	eng	\N	HarperCollins	2005	9780007203550	0007203551	https://covers.openlibrary.org/b/id/8169216-M.jpg	OL26447443M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9136	8	The Two Towers	eng	\N	Folio Society	1977	\N	\N	https://covers.openlibrary.org/b/id/8170085-M.jpg	OL26447963M	\N	2026-11-25 20:24:45.188895+00	2026-11-25 20:24:45.188895+00
9137	15	The Witcher. Blood of elves	\N	\N	Arrangement with the Patricia pasqualini literary agency	2021	9780316392099	\N	https://covers.openlibrary.org/b/id/14560445-M.jpg	OL50523882M	\N	2026-11-25 20:24:48.552273+00	2026-11-25 20:24:48.552273+00
9138	15	Blood of Elves	eng	\N	Orion Publishing Group, Limited	2023	9781399611404	\N	https://covers.openlibrary.org/b/id/14800293-M.jpg	OL46568045M	\N	2026-11-25 20:24:48.552273+00	2026-11-25 20:24:48.552273+00
9139	15	Blood of Elves	eng	\N	Orion Publishing Group, Limited	2010	9780575087491	\N	\N	OL36702368M	\N	2026-11-25 20:24:48.552273+00	2026-11-25 20:24:48.552273+00
9140	15	Blood of Elves	eng	\N	Orbit	2009	9781306768986	\N	\N	OL36721430M	\N	2026-11-25 20:24:48.552273+00	2026-11-25 20:24:48.552273+00
9141	15	Blood of Elves	eng	\N	Orbit	2022	9780316452663	\N	https://covers.openlibrary.org/b/id/13245125-M.jpg	OL38065772M	\N	2026-11-25 20:24:48.552273+00	2026-11-25 20:24:48.552273+00
9142	15	Blood of Elves	eng	\N	Orbit	2022	9780316453363	\N	https://covers.openlibrary.org/b/id/14629039-M.jpg	OL38153652M	\N	2026-11-25 20:24:48.552273+00	2026-11-25 20:24:48.552273+00
9143	15	Blood of Elves	eng	\N	Orion Publishing Group, Limited	2023	9781399611084	\N	\N	OL39551618M	\N	2026-11-25 20:24:48.552273+00	2026-11-25 20:24:48.552273+00
9144	15	Blood of Elves	\N	\N	Hachette Audio and Blackstone Audio	2015	9781478933847	1478933844	https://covers.openlibrary.org/b/id/10868712-M.jpg	OL32233015M	\N	2026-11-25 20:24:48.552273+00	2026-11-25 20:24:48.552273+00
9145	15	Blood of Elves	eng	\N	Orion Publishing Group, Limited	2021	9781473235106	\N	\N	OL33944695M	\N	2026-11-25 20:24:48.552273+00	2026-11-25 20:24:48.552273+00
9146	15	Blood of Elves Lib/E	\N	\N	Blackstone Audio Inc	2015	9781478933816	147893381X	https://covers.openlibrary.org/b/id/8964373-M.jpg	OL27507620M	\N	2026-11-25 20:24:48.552273+00	2026-11-25 20:24:48.552273+00
9147	15	Blood of Elves (The Witcher)	\N	\N	Orbit	2018	9780316438988	0316438987	https://covers.openlibrary.org/b/id/8437372-M.jpg	OL26784698M	\N	2026-11-25 20:24:48.552273+00	2026-11-25 20:24:48.552273+00
9148	15	Krew elfów	pol	\N	superNOWA	2014	9788375780833	\N	https://covers.openlibrary.org/b/id/14843062-M.jpg	OL57704278M	\N	2026-11-25 20:24:48.552273+00	2026-11-25 20:24:48.552273+00
9149	15	Krev elfů	ces	\N	Leonardo	2022	9788074770814	\N	https://covers.openlibrary.org/b/id/14548207-M.jpg	OL49953069M	\N	2026-11-25 20:24:48.552273+00	2026-11-25 20:24:48.552273+00
9150	15	La sangre de los elfos	spa	\N	Alamunt	2020	9788498890457	\N	https://covers.openlibrary.org/b/id/10657267-M.jpg	OL31982642M	\N	2026-11-25 20:24:48.552273+00	2026-11-25 20:24:48.552273+00
9151	15	Das Erbe der Elfen	deu	\N	Deutscher Taschenbuch-Verlag	2008	9783423247009	3423247002	https://covers.openlibrary.org/b/id/9354968-M.jpg	OL27966588M	\N	2026-11-25 20:24:48.552273+00	2026-11-25 20:24:48.552273+00
9152	15	Das Erbe der Elfen	deu	\N	Dt. Taschenbuch-Verlag	2009	9783423247542	3423247541	https://covers.openlibrary.org/b/id/8635110-M.jpg	OL27028890M	\N	2026-11-25 20:24:48.552273+00	2026-11-25 20:24:48.552273+00
9153	15	Blood of elves	eng	\N	Orbit	2009	9780316029193	031602919X	\N	OL24409569M	\N	2026-11-25 20:24:48.552273+00	2026-11-25 20:24:48.552273+00
9154	15	Blood of elves	eng	\N	Gollancz	2012	9780575084841	\N	https://covers.openlibrary.org/b/id/7912974-M.jpg	OL25940718M	\N	2026-11-25 20:24:48.552273+00	2026-11-25 20:24:48.552273+00
9155	15	Blood of Elves	eng	\N	Orbit	1994	9780316073714	\N	https://covers.openlibrary.org/b/id/12485175-M.jpg	OL24255147M	\N	2026-11-25 20:24:48.552273+00	2026-11-25 20:24:48.552273+00
9156	15	Blood of Elves	eng	\N	Orbit	2018	9780316485371	\N	\N	OL28922283M	\N	2026-11-25 20:24:48.552273+00	2026-11-25 20:24:48.552273+00
9157	15	Blood of Elves	eng	\N	Orion Publishing Group	2020	9781473231078	\N	https://covers.openlibrary.org/b/id/12432208-M.jpg	OL29485070M	\N	2026-11-25 20:24:48.552273+00	2026-11-25 20:24:48.552273+00
9158	15	Blood of elves	eng	\N	Gollancz	2008	9780575077843	0575077840	https://covers.openlibrary.org/b/id/8624327-M.jpg	OL27021782M	\N	2026-11-25 20:24:48.552273+00	2026-11-25 20:24:48.552273+00
9159	15	Krew elfów	pol	\N	SuperNOWA	2001	\N	8370540791	https://covers.openlibrary.org/b/id/8457620-M.jpg	OL3617706M	\N	2026-11-25 20:24:48.552273+00	2026-11-25 20:24:48.552273+00
9160	15	Krew elfów	pol	\N	SuperNOWA	1995	\N	8370540791	https://covers.openlibrary.org/b/id/8457622-M.jpg	OL626193M	\N	2026-11-25 20:24:48.552273+00	2026-11-25 20:24:48.552273+00
9164	10	Der Herr der Ringe	deu	\N	Klett-Cotta	2000	9783608932249	3608932240	https://covers.openlibrary.org/b/id/1023149-M.jpg	OL9076564M	\N	2026-11-25 20:24:51.545748+00	2026-11-25 20:24:51.545748+00
9165	10	Der Herr der Ringe	deu	\N	Klett-Cotta	2003	9783608936384	3608936386	https://covers.openlibrary.org/b/id/2233085-M.jpg	OL9814919M	\N	2026-11-25 20:24:51.545748+00	2026-11-25 20:24:51.545748+00
9166	10	Der Herr der Ringe	deu	\N	Klett-Cotta	2022	9783608987027	\N	https://covers.openlibrary.org/b/id/14627050-M.jpg	OL51708592M	\N	2026-11-25 20:24:51.545748+00	2026-11-25 20:24:51.545748+00
9167	10	El Señor de los Anillos. Apéndices	spa	\N	Circulo de Lectores	2002	\N	842269283X	https://covers.openlibrary.org/b/id/7013827-M.jpg	OL25175082M	\N	2026-11-25 20:24:51.545748+00	2026-11-25 20:24:51.545748+00
9168	10	El Señor de los Anillos	spa	\N	Ediciones Minotauro	2002	9788439597490	8439597495	https://covers.openlibrary.org/b/id/7284430-M.jpg	OL25449052M	\N	2026-11-25 20:24:51.545748+00	2026-11-25 20:24:51.545748+00
9169	10	El Señor de los Anillos	spa	\N	Minotauro	2001	9788445070703	8445070703	https://covers.openlibrary.org/b/id/8406792-M.jpg	OL9131861M	\N	2026-11-25 20:24:51.545748+00	2026-11-25 20:24:51.545748+00
\.


--
-- Data for Name: series; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.series (id, slug, name, wikidata_id, created_at, updated_at) FROM stdin;
5	as-cronicas-de-gelo-e-fogo	As Crónicas de Gelo e Fogo	Q45875	2026-11-25 18:15:49.99351+00	2026-11-25 20:23:47.502+00
6	os-jogos-da-fome	Os Jogos da Fome	Q11679	2026-11-25 18:17:41.421255+00	2026-11-25 20:24:10.842+00
1	duna	Duna	Q6095696	2026-11-25 18:13:26.621393+00	2026-11-25 20:25:31.874+00
2	o-senhor-dos-aneis	O Senhor dos Anéis	Q15228	2026-11-25 18:14:07.853321+00	2026-11-25 20:25:36.384+00
3	the-witcher	The Witcher	Q11835640	2026-11-25 18:14:32.183998+00	2026-11-25 20:25:43.625+00
4	harry-potter	Harry Potter	Q8337	2026-11-25 18:15:45.440237+00	2026-11-25 20:25:59.08+00
\.


--
-- Data for Name: series_works; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.series_works (series_id, work_id, ordinal, sort_key) FROM stdin;
6	42	1	1
6	43	2	2
6	44	4	4
6	45	5	5
6	46	3	3
4	22	2	2
4	20	1	1
4	24	7	7
4	25	6	6
4	21	4	4
4	26	5	5
4	23	3	3
4	28	\N	\N
5	29	1	1
5	34	4	4
5	35	6	6
5	36	7	7
5	31	2	2
5	32	3	3
5	33	5	5
5	37	\N	\N
1	5	3	3
1	1	1	1
1	6	6	6
1	2	2	2
1	3	4	4
1	4	5	5
2	9	3	3
2	7	1	1
2	8	2	2
3	14	4	4
3	13	8	8
3	16	2	2
3	17	6	6
3	12	1	1
3	15	3	3
3	18	5	5
3	19	\N	\N
\.


--
-- Data for Name: slug_redirects; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.slug_redirects (slug, work_id, created_at) FROM stdin;
o-senhor-dos-aneis-a-sociedade-do-anel	7	2026-11-25 20:22:40.252316+00
os-filhos-de-duna	5	2026-11-25 20:22:40.252316+00
the-return-of-the-king	9	2026-11-25 20:22:40.252316+00
season-of-storms	13	2026-11-25 20:22:40.252316+00
tempo-do-desprezo	14	2026-11-25 20:22:40.252316+00
a-feast-for-crows	34	2026-11-25 20:22:40.252316+00
a-clash-of-kings	31	2026-11-25 20:22:40.252316+00
a-storm-of-swords	32	2026-11-25 20:22:40.252316+00
harry-potter-e-as-reliquias-da-morte	24	2026-11-25 20:22:40.252316+00
harry-potter-and-the-half-blood-prince	25	2026-11-25 20:22:40.252316+00
o-jogos-da-fome-livro-i	42	2026-11-25 20:22:40.252316+00
the-ballad-of-songbirds-and-snakes	44	2026-11-25 20:22:40.252316+00
amanhecer-na-colheita	45	2026-11-25 20:22:40.252316+00
mockingjay	46	2026-11-25 20:22:40.252316+00
a-game-of-thrones	29	2026-11-25 20:22:40.252316+00
a-dance-with-dragons	33	2026-11-25 20:22:40.252316+00
fire-blood	37	2026-11-25 20:22:40.252316+00
harry-potter-and-the-cursed-child	28	2026-11-25 20:22:40.252316+00
harry-potter-and-the-chamber-of-secrets	22	2026-11-25 20:25:22.092099+00
\.


--
-- Data for Name: work_adaptations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.work_adaptations (work_id, adaptation_id, via_series) FROM stdin;
38	218	f
38	219	f
38	220	f
38	221	f
38	222	f
22	208	t
22	518	f
38	223	f
38	224	f
38	225	f
38	226	f
39	227	f
39	228	f
39	229	f
39	230	f
39	231	f
39	232	f
39	233	f
39	234	f
39	235	f
39	236	f
39	237	f
39	238	f
39	239	f
39	240	f
39	241	f
39	242	f
22	309	f
22	210	t
22	370	t
22	211	t
22	212	t
39	243	f
41	244	f
47	303	f
47	304	f
47	305	f
47	306	f
47	307	f
8	8	t
8	9	t
8	10	t
8	11	t
8	12	t
8	13	t
8	15	t
8	35	f
8	16	t
8	17	t
8	18	t
8	19	t
8	20	t
8	21	t
8	22	t
8	23	t
8	24	t
8	25	t
8	26	t
42	245	f
2	6	f
8	27	t
15	102	t
15	101	t
15	103	t
15	104	t
15	105	t
15	106	t
15	107	t
15	108	t
15	109	t
15	110	t
15	113	t
15	111	t
15	112	t
10	8	t
10	9	t
10	10	t
10	11	t
10	12	t
10	13	t
10	15	t
10	16	t
10	17	t
10	18	t
10	19	t
10	20	t
10	21	t
10	22	t
10	23	t
10	24	t
10	85	f
10	25	t
10	26	t
10	27	t
16	101	t
16	102	t
16	103	t
16	104	t
16	105	t
16	106	t
16	107	t
16	108	t
16	109	t
16	110	t
16	111	t
16	112	t
16	113	t
17	102	t
17	101	t
17	103	t
17	104	t
17	105	t
17	106	t
17	107	t
17	108	t
17	109	t
17	110	t
17	113	t
17	111	t
17	112	t
18	101	t
18	102	t
18	103	t
18	104	t
18	105	t
18	106	t
18	107	t
18	108	t
1	1	f
1	3	f
1	2	f
1	4	f
1	5	f
7	8	t
7	9	t
7	10	t
7	11	t
7	12	t
7	13	t
7	14	f
7	15	t
7	16	t
7	17	t
7	18	t
7	19	t
7	20	t
7	21	t
7	22	t
7	23	t
7	24	t
7	25	t
7	26	t
7	27	t
11	89	f
11	90	f
11	10	f
11	92	f
11	93	f
11	15	f
11	95	f
11	345	f
11	96	f
11	21	f
11	97	f
11	22	f
11	100	f
12	102	t
12	101	t
12	103	t
12	104	t
12	105	t
12	106	t
12	107	t
12	108	t
12	109	t
12	110	t
12	113	t
12	111	t
12	112	t
20	207	f
20	205	f
20	206	f
20	208	t
20	209	f
20	210	t
20	370	t
20	211	t
20	212	t
29	213	t
29	214	t
29	215	t
29	216	t
29	217	t
18	109	t
18	110	t
18	111	t
18	112	t
18	113	t
19	101	t
19	102	t
19	103	t
19	104	t
19	105	t
19	106	t
19	107	t
19	108	t
19	109	t
19	110	t
19	111	t
19	112	t
19	113	t
5	6	f
9	8	t
9	9	t
9	50	f
9	10	t
9	11	t
9	12	t
9	13	t
9	15	t
9	16	t
9	57	f
9	17	t
9	18	t
9	19	t
9	20	t
9	21	t
9	22	t
9	23	t
9	24	t
9	25	t
9	26	t
9	27	t
13	102	t
13	101	t
13	103	t
13	104	t
13	105	t
13	106	t
13	107	t
13	108	t
13	109	t
13	110	t
13	113	t
13	111	t
13	112	t
14	101	t
14	102	t
14	103	t
14	104	t
14	105	t
14	106	t
14	107	t
14	108	t
14	109	t
14	110	t
14	111	t
14	112	t
14	113	t
\.


--
-- Data for Name: work_authors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.work_authors (work_id, author_id, "position") FROM stdin;
1	1	0
7	2	0
11	2	0
12	3	0
20	4	0
29	5	0
38	6	0
39	7	0
40	8	0
41	9	0
42	10	0
47	11	0
2	1	0
6	1	0
4	1	0
8	2	0
15	3	0
10	2	0
16	3	0
17	3	0
18	3	0
19	3	0
3	1	0
5	1	0
9	2	0
13	3	0
14	3	0
22	4	0
\.


--
-- Data for Name: works; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.works (id, slug, title, original_title, original_language, first_published_year, synopsis, synopsis_language, synopsis_source_url, cover_url, subjects, wikidata_id, open_library_work_id, status, imported_at, created_at, updated_at, editor_note) FROM stdin;
1	duna	Duna	Dune	\N	1965	Duna é um romance de ficção científica do escritor estadunidense Frank Herbert (1920-1986), publicado originalmente pela editora Chilton Books nos Estados Unidos em 1965. Vencedor do prêmio Hugo de 1966, Duna é considerado o livro de ficção científica mais vendido de todos os tempos. Independentemente de seu sucesso comercial, Duna é continuadamente apontada como uma das mais renomadas obras de ficção e fantasia já lançadas, e um dos pilares da ficção científica moderna. É o início da série Duna, e a história contida no livro é expandida em outros cinco livros e um conto, todos escritos por Herbert, além de inspirar mais de uma dúzia de outros livros, escritos pelo filho do autor, Brian Herbert, em parceria com o também escritor estadunidense Kevin J. Anderson.	pt	https://pt.wikipedia.org/wiki/Duna_(romance)	https://covers.openlibrary.org/b/id/11481354-L.jpg	{"Dune (Imaginary place)",Fiction,"Fiction, science fiction, general","Dune (imaginary place), fiction","New York Times reviewed","Science fiction",Science-fiction,"American literature","New York Times bestseller","Hugo Award Winner","American Science fiction","Long Now Manual for Civilization",Ecology,"Fantasy fiction","Large type books"}	Q190192	OL893414W	full	2026-11-25 20:23:23.805+00	2026-11-25 18:13:26.621393+00	2026-11-25 20:23:23.855+00	\N
2	o-messias-de-duna	O Messias de Duna	Dune Messiah	en	1969	O Messias de Duna é um romance de ficção científica de 1969 do escritor americano Frank Herbert, o segundo de sua série de seis romances Duna. Sequência de Duna (1965), foi originalmente serializado na revista Galaxy em 1969, e então publicado pela Putnam Publishing no mesmo ano.	pt	https://pt.wikipedia.org/wiki/O_Messias_de_Duna	https://covers.openlibrary.org/b/id/980253-L.jpg	{"American Science fiction","Dune (Imaginary place)",Fiction,"Imaginary places","Science Fiction","Translations into Russian",Novela,"Dune (Lugar imaginario)","Lectures et morceaux choisis","Roman ame ricain","Science-fiction ame ricaine","Long Now Manual for Civilization","Roman américain","Science-fiction américaine","Dune (imaginary place), fiction","Fiction, science fiction, general","American fiction","Translations into Vietnamese","Anglais (Langue)"}	Q437383	OL893461W	full	2026-11-25 20:24:34.225+00	2026-11-25 18:13:26.621393+00	2026-11-25 20:24:34.257+00	\N
6	casa-do-capitulo-duna	Casa do Capítulo: Duna	Chapterhouse: Dune	en	1985	Chapterhouse: Dune, intitulado As Herdeiras de Duna no Brasil e Casa do Capítulo: Duna em Portugal, é um romance de ficção científica de 1985 escrito por Frank Herbert, sendo o último da sua série de seis livros Duna. A obra alcançou a 2ª posição na lista de mais vendidos do The New York Times.	pt	https://pt.wikipedia.org/wiki/Chapterhouse%3A_Dune	https://covers.openlibrary.org/b/id/5536140-L.jpg	{"Dune (Imaginary place)",Fiction,"Science fiction","Dune (imaginary place), fiction","Fiction, science fiction, general",Literature,"Fiction, science fiction, action & adventure","American literature"}	Q282814	OL893508W	full	2026-11-25 20:24:37.598+00	2026-11-25 18:13:26.621393+00	2026-11-25 20:24:37.632+00	\N
4	os-hereges-de-duna	Os Hereges de Duna	Heretics of Dune	en	1984	Os Hereges de Duna é um romance de ficção científica escrito pelo autor norte-americano Frank Herbert e o quinto de uma série de seis romances da saga de Duna. É uma sequência dos romances Duna (1965), O Messias de Duna (1969), Os Filhos de Duna (1976) e O Imperador-Deus de Duna (1981). Foi o 13º livro de ficção científica em capa dura mais vendido em 1984, segundo o The New York Times.	pt	https://pt.wikipedia.org/wiki/Os_Hereges_de_Duna	https://covers.openlibrary.org/b/id/284530-L.jpg	{"Science Fiction",Fiction,"Dune (Imaginary place)","Roman américain","Science-fiction américaine","Fiction, science fiction, general","Dune (imaginary place), fiction","Imaginary places","Dune (Lieu imaginaire)","Romans, nouvelles","American Science fiction","American literature",scifi,"ficção científica","Space Opera","Anglais (Langue)"}	Q437353	OL893502W	full	2026-11-25 20:24:40.709+00	2026-11-25 18:13:26.621393+00	2026-11-25 20:24:40.743+00	\N
12	o-ultimo-desejo	O Último Desejo	Ostatnie życzenie	pl	1993	O Último Desejo é o primeiro dos dois livros que colecionam contos do escritor de fantasia Andrzej Sapkowski e que antecedem os romances da série Wiedźmin. Traduzido para várias línguas, a primeira edição polaca do livro foi publicada em 1993, chegando ao Brasil em 2011.	pt	https://pt.wikipedia.org/wiki/O_%C3%9Altimo_Desejo	https://covers.openlibrary.org/b/id/7360819-L.jpg	{Fantasy,Fiction,"Translations into English","Polish fiction","Fiction, fantasy, general","Fiction, fantasy, short stories","New York Times bestseller","Fiction, fantasy, collections & anthologies",Sorcerers}	Q2414756	OL2577482W	full	2026-11-25 20:23:38.71+00	2026-11-25 18:14:32.183998+00	2026-11-25 20:23:38.714+00	\N
8	as-duas-torres	As Duas Torres	The Two Towers	en	1954	The Two Towers é o segundo volume da trilogia O Senhor dos Anéis, escrita pelo professor e filólogo britânico J. R. R. Tolkien. É a continuação de A Sociedade do Anel e antecede O Retorno do Rei. Foi publicado originalmente em 11 de novembro de 1954.	pt	https://pt.wikipedia.org/wiki/As_Duas_Torres	https://covers.openlibrary.org/b/id/14627564-L.jpg	{Ents,Orcs,hobbits,"Ficción fantástica inglesa",Ficción,"translations into Spanish","readers for new literates","The Lord of the Rings","English Fantasy fiction","Open Library Staff Picks",Fiction,Fantasy,"Popular Carousel","Middle Earth (Imaginary place)","Tierra Media (Lugar imaginario)","Baggins, Frodo (Personaje literario)","Chinese language materials","Translations into Chinese","English fiction","Frodo Baggins (Fictitious character)"}	Q332388	OL27479W	full	2026-11-25 20:24:45.191+00	2026-11-25 18:14:07.853321+00	2026-11-25 20:24:45.227+00	\N
15	o-sangue-dos-elfos	O Sangue dos Elfos	Krew elfów	pl	1994	O Sangue dos Elfos é o primeiro romance da série de livros Wiedźmin, escrita por Andrzej Sapkowski, sendo uma sequência dos contos presentes em O Último Desejo e A Espada do Destino. O romance foi publicado pela primeira vez na Polônia em 1994, chegando ao Brasil em 2013[carece de fontes]? e a Portugal em 2018	pt	https://pt.wikipedia.org/wiki/O_Sangue_dos_Elfos	https://covers.openlibrary.org/b/id/8457619-L.jpg	{Fantasy,Fiction,"Fiction, fantasy, general","Science fiction, fantasy, horror",Assassins,"Polish Fantasy fiction","Fiction, fantasy, epic","Vampires, fiction","New York Times bestseller","Fiction, fantasy, dragons & mythical creatures","Fiction, fantasy, paranormal"}	Q2652386	OL2577486W	full	2026-11-25 20:24:48.554+00	2026-11-25 18:14:32.183998+00	2026-11-25 20:24:48.585+00	\N
10	appendices-of-the-lord-of-the-rings	Appendices of The Lord of the Rings	The Lord of the Rings. Appendices	\N	1954	\N	\N	\N	https://covers.openlibrary.org/b/id/8406792-L.jpg	{Fiction,Ficción,"English Fantasy fiction","Middle Earth (Imaginary place)","Baggins, Frodo (Personaje literario)","Tierra Media (Lugar imaginario)","Frodo Baggins (Fictitious character)","Ficción fantástica inglesa","Fiction, fantasy, epic","Baggins, frodo (fictitious character), fiction","Middle earth (imaginary place), fiction","Gandalf (fictitious character), fiction"}	Q334335	OL27438W	full	2026-11-25 20:24:51.55+00	2026-11-25 18:14:07.853321+00	2026-11-25 20:24:51.591+00	\N
20	harry-potter-e-a-pedra-filosofal	Harry Potter e a Pedra Filosofal	Harry Potter and the Philosopher's Stone	en	1997	Harry Potter and the Philosopher's Stone é o primeiro dos sete livros da série de fantasia Harry Potter, escrita por J. K. Rowling. O livro conta a história de Harry Potter, um órfão criado pelos tios que descobre, em seu décimo primeiro aniversário, que é um bruxo. No romance, são narrados seus primeiros passos na comunidade bruxa, sua entrada na Escola de Magia e Bruxaria de Hogwarts e o início de sua amizade com Ron Weasley e Hermione Granger, os quais o ajudam a enfrentar Lord Voldemort — Lorde das Trevas e assassino dos pais de Harry, que agora procura um objeto lendário conhecido como a pedra filosofal.	pt	https://pt.wikipedia.org/wiki/Harry_Potter_e_a_Pedra_Filosofal	https://covers.openlibrary.org/b/id/15091495-L.jpg	{Ghosts,Monsters,Vampires,Witches,"Challenges and Overcoming Obstacles","Magic and Supernatural",Cleverness,"School Life",Wizards,Magic,MAGIA,MAGOS,"Juvenile fiction",Fiction,"NOVELAS INGLESAS",Schools,"England in fiction","Witches in fiction","Wizards in fiction",Alchemy}	Q43361	OL82563W	full	2026-11-25 20:23:43.357+00	2026-11-25 18:15:45.440237+00	2026-11-25 20:23:43.362+00	\N
16	a-espada-do-destino	A Espada do Destino	Miecz przeznaczenia	pl	1992	A Espada do Destino é o segundo dos dois livros que colecionam contos do escritor de fantasia Andrzej Sapkowski e que antecedem os romances da série Wiedźmin. A primeira edição polonesa do livro foi publicada em 1992, com sua versão brasileira tendo chegado em 2012 e a portuguesa em 2017.	pt	https://pt.wikipedia.org/wiki/A_Espada_do_Destino	https://covers.openlibrary.org/b/id/6757701-L.jpg	{"Fiction, fantasy, general","New York Times bestseller","Fiction, fantasy, short stories","Polish Fantasy fiction",Assassins,Monsters,Fiction,"Fiction, fantasy, collections & anthologies","Action & Adventure",Epic,Historical,Magic,Adventure,Fantasy}	Q2655197	OL2577472W	full	2026-11-25 20:24:57.007+00	2026-11-25 18:14:32.183998+00	2026-11-25 20:24:57.053+00	\N
17	a-torre-da-andorinha	A Torre da Andorinha	Wieża Jaskółki	pl	1997	\N	\N	\N	\N	{}	Q4080260	OL24140921W	full	2026-11-25 20:25:00.324+00	2026-11-25 18:14:32.183998+00	2026-11-25 20:25:00.359+00	\N
18	batismo-de-fogo	Batismo de Fogo	Chrzest ognia	pl	1996	Batismo de Fogo é o terceiro romance da série de livros Wiedźmin, escrita por Andrzej Sapkowski, sendo uma continuação direta de Tempo do Desprezo. O romance foi publicado pela primeira vez na Polônia em 1996, chegando ao Brasil em 2015. A edição britânica foi lançada pela Gollancz no dia 6 de março de 2014.	pt	https://pt.wikipedia.org/wiki/Batismo_de_Fogo	https://covers.openlibrary.org/b/id/8648762-L.jpg	{}	Q4240572	OL19849810W	full	2026-11-25 20:25:04.792+00	2026-11-25 18:14:32.183998+00	2026-11-25 20:25:04.831+00	\N
19	a-senhora-do-lago	A Senhora do Lago	Pani Jeziora	pl	1999	\N	\N	\N	\N	{}	Q4113386	OL27415166W	full	2026-11-25 20:25:12.584+00	2026-11-25 18:14:32.183998+00	2026-11-25 20:25:12.62+00	\N
13	tempos-de-tempestade	Tempos de Tempestade	Sezon burz	pl	2013	Oto nowy Sapkowski i nowy wiedźmin. Mistrz polskiej fantastyki znowu zaskakuje. "Sezon burz” nie opowiada bowiem o młodzieńczych latach białowłosego zabójcy potworów ani o jego losach po śmierci/nieśmierci kończącej ostatni tom sagi.\r\n\r\n"Nigdy nie mów nigdy!” W powieści pojawiają się osoby doskonale czytelnikom znane, jak wierny druh Geralta – bard i poeta Jaskier – oraz jego ukochana, zwodnicza czarodziejka Yennefer, ale na scenę wkraczają też dosłownie i w przenośni postaci z zupełnie innych bajek. Ludzie, nieludzie i magiczną sztuką wyhodowane bestie. Opowieść zaczyna się wedle reguł gatunku: od trzęsienia ziemi, a potem napięcie rośnie. Wiedźmin stacza morderczą walkę z drapieżnikiem, który żyje tylko po to, żeby zabijać, wdaje się w bójkę z rosłymi, niezbyt sympatycznymi strażniczkami miejskimi, staje przed sądem, traci swe słynne miecze i przeżywa burzliwy romans z rudowłosą pięknością, zwaną Koral. A w tle toczą się królewskie i czarodziejskie intrygi. Pobrzmiewają pioruny i szaleją burze. I tak przez 404 strony porywającej lektury.\r\n\r\n"Wiedźmin. Sezon Burz" to w wiedźmińskiej historii rzecz osobna, nie prapoczątek i nie kontynuacja. Jak pisze autor: Opowieść trwa. Historia nie kończy się nigdy…	en	https://openlibrary.org/works/OL18132591W	https://covers.openlibrary.org/b/id/8457629-L.jpg	{Monsters,Fiction,Assassins,Witches,"Polish Fantasy fiction",Magic,"Fiction, fantasy, general",Monstres,"Romans, nouvelles","Fairy Tales, Folk Tales, Legends & Mythology",Fantasy,"Action & Adventure","Dragons & Mythical Creatures",Epic,Historical}	Q15260619	OL18132591W	full	2026-11-25 20:25:38.747+00	2026-11-25 18:14:32.183998+00	2026-11-25 20:25:38.784+00	\N
21	harry-potter-e-o-calice-de-fogo	Harry Potter e o Cálice de Fogo	\N	\N	2000	\N	\N	\N	\N	{}	Q46751	\N	stub	\N	2026-11-25 18:15:45.440237+00	2026-11-25 20:25:59.098+00	\N
26	harry-potter-e-a-ordem-da-fenix	Harry Potter e a Ordem da Fénix	\N	\N	2003	\N	\N	\N	\N	{}	Q80817	\N	stub	\N	2026-11-25 18:15:45.440237+00	2026-11-25 20:25:59.101+00	\N
11	o-hobbit	O Hobbit	The Hobbit	en	1937	The Hobbit, or There and Back Again é um livro infantojuvenil de alta fantasia escrito pelo filólogo e professor britânico J. R. R. Tolkien. Publicado originalmente em 21 de setembro de 1937, foi aclamado pela crítica, sendo nomeado à Medalha Carnegie e recebendo um prêmio do jornal norte-americano New York Herald Tribune de melhor ficção juvenil. O romance se mantém popular com o passar dos anos e é reconhecido como um clássico da literatura infantil, tendo vendido mais de 190 milhões de cópias.	pt	https://pt.wikipedia.org/wiki/O_Hobbit	https://covers.openlibrary.org/b/id/14627509-L.jpg	{Fantasy,Arkenstone,"Battle of Five Armies",invisibility,thrushes,hobbits,wizards,dwarves,elves,trolls,"giant spiders","the one ring","juvenile fantasy","Fantasy fiction","Juvenile fiction",Fiction,Classics,General,"Media Tie-In","Teen & Young Adult literature"}	Q74287	OL27482W	full	2026-11-25 20:23:33.022+00	2026-11-25 18:14:26.107462+00	2026-11-25 20:23:33.028+00	\N
39	orgulho-e-preconceito	Orgulho e Preconceito	Pride and Prejudice	en	1813	Pride and Prejudice é um romance da escritora britânica Jane Austen. Publicado pela primeira vez em 1813, embora houvesse sido concluído em 1797, antes de a autora completar 21 anos, em Steventon, Hampshire, onde Jane morava com os pais. Originalmente denominado First Impressions, nunca foi publicado sob este título; ao fazer a revisão dos escritos, Jane intitulou a obra e a publicou como Pride and Prejudice. Austen pode ter tido em mente o capítulo final do romance de Fanny Burney, Cecilia, chamado "Pride and Prejudice".	pt	https://pt.wikipedia.org/wiki/Orgulho_e_Preconceito	https://covers.openlibrary.org/b/id/14348537-L.jpg	{"Fiction, Romance, Historical, Regency","British and Irish fiction (fictional works by one author)","Brothers and sisters",Courtship,Drama,"English fiction","English literature",Families,Family,"Family life","Fiction Classics",History,"Interpersonal relations","Literary Fiction","Love stories",manners,"Manners and customs",Sisters,"Social classes","Social life and customs"}	Q170583	OL66554W	full	2026-11-25 20:23:59.907+00	2026-11-25 18:16:08.375321+00	2026-11-25 20:23:59.911+00	\N
40	os-maias	Os Maias	Os Maias	pt	1888	Os Maias é uma das obras mais conhecidas do escritor português Eça de Queiroz, publicado pela Livraria Lello & Irmão no Porto, em 1888. A obra ocupa-se da história de uma família (Maia) ao longo de três gerações, centrando-se depois na última com a história de amor entre Carlos da Maia e Maria Eduarda.	pt	https://pt.wikipedia.org/wiki/Os_Maias	https://covers.openlibrary.org/b/id/13156084-L.jpg	{Fiction,"Portuguese fiction",Landowners,"Fiction, general","Lisbon (portugal), fiction","Alcoholic beverages",Family,Gastronomy,Knowledge,Quotations,"Quotations, maxims","Social conditions","Social life and customs","Wine and wine making","Family -- Portugal -- Fiction.",Families,tragédia,incesto,adultério,aristrocacia}	Q3057582	OL846513W	full	2026-11-25 20:24:02.166+00	2026-11-25 18:16:11.573378+00	2026-11-25 20:24:02.169+00	\N
43	em-chamas	Em Chamas	\N	\N	2009	\N	\N	\N	\N	{}	Q837140	\N	stub	\N	2026-11-25 18:17:41.421255+00	2026-11-25 20:24:10.847+00	\N
44	a-balada-dos-passaros-e-das-serpentes	A Balada dos Pássaros e das Serpentes	\N	\N	2020	\N	\N	\N	\N	{}	Q81925268	\N	stub	\N	2026-11-25 18:17:41.421255+00	2026-11-25 20:24:10.852+00	\N
45	amanhecer-na-ceifa	Amanhecer na Ceifa	\N	\N	2025	\N	\N	\N	\N	{}	Q126390804	\N	stub	\N	2026-11-25 18:17:41.421255+00	2026-11-25 20:24:10.855+00	\N
46	a-revolta	A Revolta	\N	\N	2010	\N	\N	\N	\N	{}	Q40354	\N	stub	\N	2026-11-25 18:17:41.421255+00	2026-11-25 20:24:10.859+00	\N
22	harry-potter-e-a-camara-dos-segredos	Harry Potter e a Câmara dos Segredos	Harry Potter and the Chamber of Secrets	\N	1998	Harry Potter and the Chamber of Secrets é um romance de fantasia escrito pela britânica J. K. Rowling. É o segundo livro da série Harry Potter. O livro se envolve em torno da lenda de uma câmara secreta localizada na Escola de Magia e Bruxaria de Hogwarts, na qual abriga um monstro que matará a todos os bruxos que não provém de famílias mágicas. Diversos alunos aparecem petrificados e Harry Potter, além de ser apontado como o maior suspeito, tenta desvendar e resolver o mistério junto de seus melhores amigos, Rony Weasley e Hermione Granger.	pt	https://pt.wikipedia.org/wiki/Harry_Potter_and_the_Chamber_of_Secrets	https://covers.openlibrary.org/b/id/15145255-L.jpg	{"Fantasy fiction",Fiction,Fantasy,"Nestlé Smarties Book Prize winner","Juvenile fiction",Wizards,Magic,Schools,"Spanish language materials",Magia,Escuelas,"Ficción juvenil","Novela fantástica","Hogwarts School of Witchcraft and Wizardry (Imaginary place)","Harry Potter (Fictitious character)","Wizards -- Juvenile fiction",Witches,"Hogwarts School of Witchcraft and Wizardry (Imaginary organization)",Magos,"Translations from English"}	Q47209	OL82537W	full	2026-11-25 20:25:58.918+00	2026-11-25 18:15:45.440237+00	2026-11-25 20:25:58.948+00	\N
7	a-irmandade-do-anel	A Irmandade do Anel	The Fellowship of the Ring	en	1954	The Fellowship of the Ring é o primeiro volume da trilogia O Senhor dos Anéis, escrita pelo professor e filólogo britânico J. R. R. Tolkien. É seguido de As Duas Torres e O Retorno do Rei. Foi publicado originalmente em 29 de julho de 1954 no Reino Unido.	pt	https://pt.wikipedia.org/wiki/The_Fellowship_of_the_Ring	https://covers.openlibrary.org/b/id/15120679-L.jpg	{Elves,Dwarves,evil,Ficción,"Ficción fantástica inglesa","Fantastic fiction","The Lord of the Rings","English Fantasy fiction","Open Library Staff Picks",Fiction,Fantasy,"Fairy tales","Adventure stories","Fantasy fiction","Middle Earth (Imaginary place)","History and criticism","FICTION / Fantasy / Epic","Adventure fiction","English fiction","Translations in Chinese"}	Q208002	OL27513W	full	2026-11-25 20:23:29.33+00	2026-11-25 18:14:07.853321+00	2026-11-25 20:23:29.335+00	\N
33	a-danca-dos-dragoes	A Dança dos Dragões	\N	\N	2011	\N	\N	\N	\N	{}	Q28306	\N	stub	\N	2026-11-25 18:15:49.99351+00	2026-11-25 20:23:47.52+00	Em Portugal, a Saída de Emergência publicou este livro em dois volumes: A Dança dos Dragões e Os Reinos do Caos.
37	sangue-e-fogo	Sangue e Fogo	\N	\N	2018	\N	\N	\N	\N	{}	Q55611675	\N	stub	\N	2026-11-25 18:15:49.99351+00	2026-11-25 20:23:47.524+00	\N
38	1984	1984	Nineteen Eighty-Four	en	1949	Mil novecentos e oitenta e quatro é um romance distópico do escritor inglês George Orwell. Foi publicado em 8 de junho de 1949 pela Secker & Warburg como o nono e último livro de Orwell concluído em vida. Tematicamente, centra-se nas consequências do totalitarismo, da vigilância em massa e da lavagem cerebral na sociedade. Orwell, um socialista democrático, modelou o Estado autoritário descrito no romance com base na União Soviética stalinista e na Alemanha Nazista. De forma mais ampla, o romance examina o papel da verdade e dos fatos nas sociedades e as formas como eles podem ser manipulados.	pt	https://pt.wikipedia.org/wiki/1984_(livro)	https://covers.openlibrary.org/b/id/15257493-L.jpg	{futurology,censorship,surveillance,rebels,"sting operations","historical negationism","memory holes",thoughtcrime,"Outer Party","resistance movements",Newspeak,"perpetual war",telescreens,"cult of personality",Ingsoc,"Satirical literature","English science fiction","FICTION CLASSICS","Man-woman relationships",Politique}	Q208460	OL1168083W	full	2026-11-25 20:23:55.534+00	2026-11-25 18:15:54.964525+00	2026-11-25 20:23:55.539+00	\N
23	harry-potter-e-o-prisioneiro-de-azkaban	Harry Potter e o Prisioneiro de Azkaban	\N	\N	1999	\N	\N	\N	\N	{}	Q47598	\N	stub	\N	2026-11-25 18:15:45.440237+00	2026-11-25 20:25:59.105+00	\N
3	o-imperador-deus-de-duna	O Imperador Deus de Duna	God Emperor of Dune	en	1981	O Imperador-Deus de Duna é um romance de ficção científica de Frank Herbert publicado em 1981. É a quarta obra da sua série de seis romances Duna. Foi lançado pela editora Putnam em 1981 nos Estados Unidos, pela Editora Nova Fronteira em 1986 no Brasil e pela editora Relógio D'Água em Portugal no ano de 2023. Foi classificado como best-seller de ficção de capa dura número 11 de 1981 pela Publishers Weekly.	pt	https://pt.wikipedia.org/wiki/O_Imperador-Deus_de_Duna	https://covers.openlibrary.org/b/id/6711531-L.jpg	{"American Science fiction","Dune (imaginary place), fiction","Fiction, science fiction, general","Dune (Imaginary place)",Fiction,"Science fiction",Roman,Science-fiction,"Littérature fantastique","Lectures et morceaux choisis","American literature","Français (Langue)"}	Q401619	OL893515W	full	2026-11-25 20:25:28.385+00	2026-11-25 18:13:26.621393+00	2026-11-25 20:25:28.427+00	\N
5	filhos-de-duna	Filhos de Duna	Children of Dune	en	1976	Os Filhos de Duna é um romance de ficção científica escrito por Frank Herbert e publicado pela primeira vez em 1976 pela G. P. Putnam's Sons. É o terceiro livro da série Duna iniciada com o romance Duna, tendo sido indicado ao Prémio Hugo de Melhor Romance de 1977. O romance foi lançado no Brasil em 1985 pela editora Nova Fronteira e em Portugal, no ano de 2022, pela editora Relógio D'Água.	pt	https://pt.wikipedia.org/wiki/Os_Filhos_de_Duna	https://covers.openlibrary.org/b/id/6976407-L.jpg	{"Dune (Imaginary place)",Fiction,"Fiction in English","Science Fiction","Dune (imaginary place), fiction","Fiction, science fiction, general","Fiction, fantasy, general","American Science fiction","Reading Level-Grade 7","Reading Level-Grade 9","Reading Level-Grade 8","Reading Level-Grade 11","Reading Level-Grade 10","Reading Level-Grade 12","American literature"}	Q437365	OL893516W	full	2026-11-25 20:25:31.779+00	2026-11-25 18:13:26.621393+00	2026-11-25 20:25:31.816+00	\N
9	o-regresso-do-rei	O Regresso do Rei	The Return of the King	en	1955	The Return of the King, é o terceiro e último volume da trilogia O Senhor dos Anéis, de J. R. R. Tolkien, seguindo A Sociedade do Anel e As Duas Torres. Foi primeiro publicado em 1955.	pt	https://pt.wikipedia.org/wiki/The_Return_of_the_King	https://covers.openlibrary.org/b/id/14627062-L.jpg	{Elves,Hobbits,"The Lord of the Rings",Fiction,Fantasy,"English Fantasy fiction","Juvenile fiction","Fantastic fiction","Textual Criticism","Middle Earth (Imaginary place)","Chinese language materials",Adventure,"Fantasy fiction","Frodo Baggins (Fictional character)","Frodo Baggins (Fictitious character)","Fiction, fantasy, epic","Middle earth (imaginary place), fiction","Baggins, frodo (fictitious character), fiction","British and irish fiction (fictional works by one author)","Gandalf (fictitious character), fiction"}	Q332581	OL27455W	full	2026-11-25 20:25:36.201+00	2026-11-25 18:14:07.853321+00	2026-11-25 20:25:36.232+00	\N
47	it	It	IT	en	1986	It é um romance de terror de 1986 do autor estadunidense Stephen King. Foi seu 22º livro e seu 17º romance escrito em seu próprio nome. A história segue as experiências de sete crianças, que são aterrorizadas por uma entidade maligna que explora os medos de suas vítimas para se disfarçar enquanto caçam suas presas. "It" aparece principalmente na forma do palhaço Pennywise para atrair sua presa preferida: crianças pequenas.	pt	https://pt.wikipedia.org/wiki/It_(romance)	https://covers.openlibrary.org/b/id/8569284-L.jpg	{"Schwinn bicycles",catatonia,"blood oaths",Omniscience,mummies,lepers,we,clownrewolves,"nonlinear narrative",third-person,"Open Library Staff Picks",Fiction,"Good and evil","horror stories","Horror fiction","Reading Level-Grade 9","Reading Level-Grade 11","Reading Level-Grade 10","Reading Level-Grade 12","New York Times bestseller"}	Q602288	OL81613W	full	2026-11-25 20:24:14.504+00	2026-11-25 18:27:13.989428+00	2026-11-25 20:49:58.396+00	\N
14	o-tempo-do-desprezo	O Tempo do Desprezo	Czas pogardy	pl	1995	Tempo do Desprezo é o segundo romance da série de livros Wiedźmin, escrita por Andrzej Sapkowski, sendo uma continuação direta de O Sangue dos Elfos. O romance foi publicado pela primeira vez na Polônia em 1995, chegando ao Brasil em 2014.	pt	https://pt.wikipedia.org/wiki/Tempo_do_Desprezo	https://covers.openlibrary.org/b/id/8309685-L.jpg	{"Polish Fantasy fiction","Fiction, fantasy, epic",Monsters,Fiction,Assassins,Suffering,Murder,Magic,Prophecy,Wizards,"Fiction, fantasy, general","Fiction, action & adventure","Criminals, fiction","Powieść fantastyczna polska",Assasins,"Polish Science fiction",Bodyguards,"Fantastischer Roman",Polnisch,Epic}	Q2045474	OL2577481W	full	2026-11-25 20:25:43.511+00	2026-11-25 18:14:32.183998+00	2026-11-25 20:25:43.558+00	\N
24	harry-potter-e-os-talismas-da-morte	Harry Potter e os Talismãs da Morte	\N	\N	\N	\N	\N	\N	\N	{}	Q46758	\N	stub	\N	2026-11-25 18:15:45.440237+00	2026-11-25 20:25:59.088+00	\N
34	o-festim-dos-corvos	O Festim dos Corvos	\N	\N	2005	\N	\N	\N	\N	{}	Q1764445	\N	stub	\N	2026-11-25 18:15:49.99351+00	2026-11-25 20:23:47.505+00	Em Portugal, a Saída de Emergência publicou este livro em dois volumes: O Festim dos Corvos e O Mar de Ferro.
35	the-winds-of-winter	The Winds of Winter	\N	\N	\N	\N	\N	\N	\N	{}	Q2712708	\N	stub	\N	2026-11-25 18:15:49.99351+00	2026-11-25 20:23:47.508+00	Ainda não publicado.
36	a-dream-of-spring	A Dream of Spring	\N	\N	\N	\N	\N	\N	\N	{}	Q10371726	\N	stub	\N	2026-11-25 18:15:49.99351+00	2026-11-25 20:23:47.511+00	Ainda não publicado.
31	a-furia-dos-reis	A Fúria dos Reis	\N	\N	1998	\N	\N	\N	\N	{}	Q300370	\N	stub	\N	2026-11-25 18:15:49.99351+00	2026-11-25 20:23:47.514+00	Em Portugal, a Saída de Emergência publicou este livro em dois volumes: A Fúria dos Reis e O Despertar da Magia.
32	a-tormenta-de-espadas	A Tormenta de Espadas	\N	\N	2000	\N	\N	\N	\N	{}	Q431927	\N	stub	\N	2026-11-25 18:15:49.99351+00	2026-11-25 20:23:47.517+00	Em Portugal, a Saída de Emergência publicou este livro em dois volumes: A Tormenta de Espadas e A Glória dos Traidores.
42	os-jogos-da-fome	Os Jogos da Fome	The Hunger Games	en	2008	The Hunger Games é um livro de aventura, ação, distópico e pós-apocalíptico para jovens e adultos escrito pela norte-americana Suzanne Collins. O primeiro de uma trilogia que leva seu nome foi originalmente publicado nos Estados Unidos, em 14 de setembro de 2008, pela editora Scholastic, e lançado em Portugal e no Brasil, respectivamente, em 20 de outubro de 2009, pela Editorial Presença, e 29 de maio 2010, pela editora Rocco.	pt	https://pt.wikipedia.org/wiki/The_Hunger_Games	https://covers.openlibrary.org/b/id/14844157-L.jpg	{"severe poverty",starvation,oppression,"effects of war",self-sacrifice,"Science fiction","Apocalyptic fiction","Dystopian fiction",Fiction,"Juvenile works",Novels,"Young adult works","Juvenile fiction",contensts,"Young adult fiction","Game shows","Television programs","New York Times bestseller",Contests,"Long Now Manual for Civilization"}	Q11678	OL5735363W	full	2026-11-25 20:24:10.753+00	2026-11-25 18:17:41.421255+00	2026-11-25 20:24:10.789+00	\N
25	harry-potter-e-o-principe-misterioso	Harry Potter e o Príncipe Misterioso	\N	\N	2005	\N	\N	\N	\N	{}	Q46887	\N	stub	\N	2026-11-25 18:15:45.440237+00	2026-11-25 20:25:59.093+00	\N
29	a-guerra-dos-tronos	A Guerra dos Tronos	A Game of Thrones	en	1996	A Game of Thrones é o primeiro livro da série de fantasia épica As Crônicas de Gelo e Fogo, escrita pelo norte-americano George R. R. Martin e publicada pela editora Bantam Spectra. Lançado originalmente em 6 de agosto de 1996, o livro venceu o Prêmio Locus de 1997 e o Prêmio Nebula de 1998, tendo sido indicado também ao World Fantasy Award de 1997. A novela Blood of the Dragon, compreendendo os capítulos de Daenerys Targaryen do romance, venceu o Prêmio Hugo de 1997 para "Melhor Novela".	pt	https://pt.wikipedia.org/wiki/A_Game_of_Thrones	https://covers.openlibrary.org/b/id/9269962-L.jpg	{Adult,"Action & Adventure",Fantasy,"High Fantasy",Epic,"Epic Fantasy","Epic Fiction","Epic Literature","Fiction, fantasy, epic","Fiction, fantasy, general","Science Fiction","Fantastic Fiction",Fiction,Ficción,"Moral Ambiguity",Betrayal,Loyalty,Family,Revenge,Vengeance}	Q1751870	OL257943W	full	2026-11-25 20:23:47.435+00	2026-11-25 18:15:49.99351+00	2026-11-25 20:23:47.439+00	Em Portugal, a Saída de Emergência publicou este livro em dois volumes: A Guerra dos Tronos e A Muralha de Gelo.
41	ensaio-sobre-a-cegueira	Ensaio sobre a Cegueira	Ensaio sobre a Cegueira	pt	1995	Ensaio sobre a Cegueira é um romance do escritor português José Saramago, publicado em 1995, e traduzido para diversas línguas. A obra narra a história da epidemia de cegueira branca que se espalha por uma cidade, causando um grande colapso na vida das pessoas e abalando as estruturas sociais. O romance se tornou um dos mais famosos e renomados do autor, juntamente com Memorial do Convento e O Evangelho segundo Jesus Cristo, e fora, sem dúvida, um dos principais motivos para a escolha dele ao prêmio Nobel de literatura em 1998.	pt	https://pt.wikipedia.org/wiki/Ensaio_sobre_a_Cegueira	https://covers.openlibrary.org/b/id/1054349-L.jpg	{Blind,Blindness,Fiction,"Modern Literature",Allegories,"Psychological fiction",Psychology,Epidemics,Survival,"Blind in literature",Violence,"Large type books",Novela,Portugal,Dystopian,"Literary Fiction","Disease Outbreaks","Fiction, general","Fiction, psychological","People with disabilities, fiction"}	Q826428	OL27420W	full	2026-11-25 20:24:06.225+00	2026-11-25 18:16:31.54798+00	2026-11-25 20:24:06.23+00	\N
28	harry-potter-e-a-crianca-amaldicoada	Harry Potter e a Criança Amaldiçoada	\N	\N	2016	\N	\N	\N	\N	{}	Q77808986	\N	stub	\N	2026-11-25 18:15:45.440237+00	2026-11-25 20:25:59.107+00	\N
\.


--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE SET; Schema: drizzle; Owner: -
--

SELECT pg_catalog.setval('drizzle.__drizzle_migrations_id_seq', 4, true);


--
-- Name: adaptations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.adaptations_id_seq', 578, true);


--
-- Name: authors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.authors_id_seq', 11, true);


--
-- Name: editions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.editions_id_seq', 10124, true);


--
-- Name: import_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.import_events_id_seq', 1, false);


--
-- Name: series_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.series_id_seq', 6, true);


--
-- Name: works_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.works_id_seq', 47, true);


--
-- Name: __drizzle_migrations __drizzle_migrations_pkey; Type: CONSTRAINT; Schema: drizzle; Owner: -
--

ALTER TABLE ONLY drizzle.__drizzle_migrations
    ADD CONSTRAINT __drizzle_migrations_pkey PRIMARY KEY (id);


--
-- Name: account account_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account
    ADD CONSTRAINT account_pkey PRIMARY KEY (id);


--
-- Name: adaptations adaptations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.adaptations
    ADD CONSTRAINT adaptations_pkey PRIMARY KEY (id);


--
-- Name: adaptations adaptations_wikidataId_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.adaptations
    ADD CONSTRAINT "adaptations_wikidataId_unique" UNIQUE (wikidata_id);


--
-- Name: authors authors_openLibraryId_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.authors
    ADD CONSTRAINT "authors_openLibraryId_unique" UNIQUE (open_library_id);


--
-- Name: authors authors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.authors
    ADD CONSTRAINT authors_pkey PRIMARY KEY (id);


--
-- Name: authors authors_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.authors
    ADD CONSTRAINT authors_slug_unique UNIQUE (slug);


--
-- Name: authors authors_wikidataId_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.authors
    ADD CONSTRAINT "authors_wikidataId_unique" UNIQUE (wikidata_id);


--
-- Name: editions editions_googleBooksId_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.editions
    ADD CONSTRAINT "editions_googleBooksId_unique" UNIQUE (google_books_id);


--
-- Name: editions editions_openLibraryEditionId_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.editions
    ADD CONSTRAINT "editions_openLibraryEditionId_unique" UNIQUE (open_library_edition_id);


--
-- Name: editions editions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.editions
    ADD CONSTRAINT editions_pkey PRIMARY KEY (id);


--
-- Name: import_events import_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_events
    ADD CONSTRAINT import_events_pkey PRIMARY KEY (id);


--
-- Name: rate_limit rate_limit_key_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rate_limit
    ADD CONSTRAINT rate_limit_key_unique UNIQUE (key);


--
-- Name: rate_limit rate_limit_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rate_limit
    ADD CONSTRAINT rate_limit_pkey PRIMARY KEY (id);


--
-- Name: reading_status reading_status_user_id_work_id_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reading_status
    ADD CONSTRAINT reading_status_user_id_work_id_pk PRIMARY KEY (user_id, work_id);


--
-- Name: reviews reviews_user_id_work_id_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_user_id_work_id_pk PRIMARY KEY (user_id, work_id);


--
-- Name: series series_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.series
    ADD CONSTRAINT series_pkey PRIMARY KEY (id);


--
-- Name: series series_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.series
    ADD CONSTRAINT series_slug_unique UNIQUE (slug);


--
-- Name: series series_wikidataId_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.series
    ADD CONSTRAINT "series_wikidataId_unique" UNIQUE (wikidata_id);


--
-- Name: series_works series_works_series_id_work_id_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.series_works
    ADD CONSTRAINT series_works_series_id_work_id_pk PRIMARY KEY (series_id, work_id);


--
-- Name: session session_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session
    ADD CONSTRAINT session_pkey PRIMARY KEY (id);


--
-- Name: session session_token_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session
    ADD CONSTRAINT session_token_unique UNIQUE (token);


--
-- Name: slug_redirects slug_redirects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.slug_redirects
    ADD CONSTRAINT slug_redirects_pkey PRIMARY KEY (slug);


--
-- Name: user user_email_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_email_unique UNIQUE (email);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (id);


--
-- Name: verification verification_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.verification
    ADD CONSTRAINT verification_pkey PRIMARY KEY (id);


--
-- Name: work_adaptations work_adaptations_work_id_adaptation_id_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_adaptations
    ADD CONSTRAINT work_adaptations_work_id_adaptation_id_pk PRIMARY KEY (work_id, adaptation_id);


--
-- Name: work_authors work_authors_work_id_author_id_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_authors
    ADD CONSTRAINT work_authors_work_id_author_id_pk PRIMARY KEY (work_id, author_id);


--
-- Name: work_overrides work_overrides_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_overrides
    ADD CONSTRAINT work_overrides_pkey PRIMARY KEY (work_id);


--
-- Name: works works_openLibraryWorkId_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.works
    ADD CONSTRAINT "works_openLibraryWorkId_unique" UNIQUE (open_library_work_id);


--
-- Name: works works_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.works
    ADD CONSTRAINT works_pkey PRIMARY KEY (id);


--
-- Name: works works_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.works
    ADD CONSTRAINT works_slug_unique UNIQUE (slug);


--
-- Name: works works_wikidataId_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.works
    ADD CONSTRAINT "works_wikidataId_unique" UNIQUE (wikidata_id);


--
-- Name: account_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX account_user_id_index ON public.account USING btree (user_id);


--
-- Name: authors_name_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX authors_name_trgm ON public.authors USING gin (public.f_unaccent(name) public.gin_trgm_ops);


--
-- Name: editions_isbn13_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX editions_isbn13_index ON public.editions USING btree (isbn13);


--
-- Name: editions_language_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX editions_language_index ON public.editions USING btree (language);


--
-- Name: editions_work_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX editions_work_id_index ON public.editions USING btree (work_id);


--
-- Name: import_events_user_id_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX import_events_user_id_created_at_index ON public.import_events USING btree (user_id, created_at);


--
-- Name: reading_status_user_id_state_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX reading_status_user_id_state_index ON public.reading_status USING btree (user_id, state);


--
-- Name: reading_status_work_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX reading_status_work_id_index ON public.reading_status USING btree (work_id);


--
-- Name: reviews_work_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX reviews_work_id_index ON public.reviews USING btree (work_id);


--
-- Name: series_name_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX series_name_trgm ON public.series USING gin (public.f_unaccent(name) public.gin_trgm_ops);


--
-- Name: series_works_work_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX series_works_work_id_index ON public.series_works USING btree (work_id);


--
-- Name: session_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX session_user_id_index ON public.session USING btree (user_id);


--
-- Name: verification_identifier_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX verification_identifier_index ON public.verification USING btree (identifier);


--
-- Name: work_adaptations_adaptation_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX work_adaptations_adaptation_id_index ON public.work_adaptations USING btree (adaptation_id);


--
-- Name: work_authors_author_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX work_authors_author_id_index ON public.work_authors USING btree (author_id);


--
-- Name: works_original_title_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX works_original_title_trgm ON public.works USING gin (public.f_unaccent(original_title) public.gin_trgm_ops);


--
-- Name: works_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX works_status_index ON public.works USING btree (status);


--
-- Name: works_title_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX works_title_trgm ON public.works USING gin (public.f_unaccent(title) public.gin_trgm_ops);


--
-- Name: account account_user_id_user_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account
    ADD CONSTRAINT account_user_id_user_id_fk FOREIGN KEY (user_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: editions editions_work_id_works_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.editions
    ADD CONSTRAINT editions_work_id_works_id_fk FOREIGN KEY (work_id) REFERENCES public.works(id) ON DELETE CASCADE;


--
-- Name: import_events import_events_user_id_user_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_events
    ADD CONSTRAINT import_events_user_id_user_id_fk FOREIGN KEY (user_id) REFERENCES public."user"(id) ON DELETE SET NULL;


--
-- Name: import_events import_events_work_id_works_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_events
    ADD CONSTRAINT import_events_work_id_works_id_fk FOREIGN KEY (work_id) REFERENCES public.works(id) ON DELETE SET NULL;


--
-- Name: reading_status reading_status_user_id_user_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reading_status
    ADD CONSTRAINT reading_status_user_id_user_id_fk FOREIGN KEY (user_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: reading_status reading_status_work_id_works_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reading_status
    ADD CONSTRAINT reading_status_work_id_works_id_fk FOREIGN KEY (work_id) REFERENCES public.works(id) ON DELETE CASCADE;


--
-- Name: reviews reviews_user_id_user_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_user_id_user_id_fk FOREIGN KEY (user_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: reviews reviews_work_id_works_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_work_id_works_id_fk FOREIGN KEY (work_id) REFERENCES public.works(id) ON DELETE CASCADE;


--
-- Name: series_works series_works_series_id_series_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.series_works
    ADD CONSTRAINT series_works_series_id_series_id_fk FOREIGN KEY (series_id) REFERENCES public.series(id) ON DELETE CASCADE;


--
-- Name: series_works series_works_work_id_works_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.series_works
    ADD CONSTRAINT series_works_work_id_works_id_fk FOREIGN KEY (work_id) REFERENCES public.works(id) ON DELETE CASCADE;


--
-- Name: session session_user_id_user_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session
    ADD CONSTRAINT session_user_id_user_id_fk FOREIGN KEY (user_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: slug_redirects slug_redirects_work_id_works_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.slug_redirects
    ADD CONSTRAINT slug_redirects_work_id_works_id_fk FOREIGN KEY (work_id) REFERENCES public.works(id) ON DELETE CASCADE;


--
-- Name: work_adaptations work_adaptations_adaptation_id_adaptations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_adaptations
    ADD CONSTRAINT work_adaptations_adaptation_id_adaptations_id_fk FOREIGN KEY (adaptation_id) REFERENCES public.adaptations(id) ON DELETE CASCADE;


--
-- Name: work_adaptations work_adaptations_work_id_works_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_adaptations
    ADD CONSTRAINT work_adaptations_work_id_works_id_fk FOREIGN KEY (work_id) REFERENCES public.works(id) ON DELETE CASCADE;


--
-- Name: work_authors work_authors_author_id_authors_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_authors
    ADD CONSTRAINT work_authors_author_id_authors_id_fk FOREIGN KEY (author_id) REFERENCES public.authors(id) ON DELETE CASCADE;


--
-- Name: work_authors work_authors_work_id_works_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_authors
    ADD CONSTRAINT work_authors_work_id_works_id_fk FOREIGN KEY (work_id) REFERENCES public.works(id) ON DELETE CASCADE;


--
-- Name: work_overrides work_overrides_updated_by_user_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_overrides
    ADD CONSTRAINT work_overrides_updated_by_user_id_fk FOREIGN KEY (updated_by) REFERENCES public."user"(id) ON DELETE SET NULL;


--
-- Name: work_overrides work_overrides_work_id_works_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_overrides
    ADD CONSTRAINT work_overrides_work_id_works_id_fk FOREIGN KEY (work_id) REFERENCES public.works(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict L2FuSA6r1gUKCuo1fOk78pgOu6GKBZJrJMTMikoQnH8duXwJhigpuRgxdQHoUOT

